package com.localwebapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class RecentProject(
    val name: String,
    val uri: String,
    val lastOpened: Long
)

class RecentProjectsAdapter(
    private var projects: MutableList<RecentProject>,
    private val onOpen: (RecentProject) -> Unit,
    private val onDelete: (RecentProject) -> Unit
) : RecyclerView.Adapter<RecentProjectsAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.projectName)
        val date: TextView = view.findViewById(R.id.projectDate)
        val deleteBtn: View = view.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_project, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val project = projects[position]
        holder.name.text = project.name
        val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
        holder.date.text = "Last opened: ${sdf.format(Date(project.lastOpened))}"
        holder.itemView.setOnClickListener { onOpen(project) }
        holder.deleteBtn.setOnClickListener { onDelete(project) }
    }

    override fun getItemCount() = projects.size

    fun updateProjects(newProjects: List<RecentProject>) {
        projects.clear()
        projects.addAll(newProjects)
        notifyDataSetChanged()
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: RecentProjectsAdapter
    private lateinit var emptyView: View
    private val prefs by lazy { getSharedPreferences("LocalWebApp", MODE_PRIVATE) }

    private val openFolderLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let { treeUri ->
                // Persist permission across reboots
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                contentResolver.takePersistableUriPermission(treeUri, flags)

                val docFile = DocumentFile.fromTreeUri(this, treeUri)
                if (docFile == null || !docFile.isDirectory) {
                    Toast.makeText(this, "Invalid folder selected", Toast.LENGTH_SHORT).show()
                    return@let
                }

                // Check for index.html
                val indexFile = docFile.findFile("index.html")
                if (indexFile == null) {
                    AlertDialog.Builder(this)
                        .setTitle("No index.html found")
                        .setMessage("The selected folder doesn't contain an index.html file. Open it anyway?")
                        .setPositiveButton("Open Anyway") { _, _ ->
                            launchWebApp(treeUri, docFile.name ?: "Web App")
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                } else {
                    launchWebApp(treeUri, docFile.name ?: "Web App")
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(findViewById(R.id.toolbar))

        recyclerView = findViewById(R.id.recyclerView)
        emptyView = findViewById(R.id.emptyView)

        adapter = RecentProjectsAdapter(
            mutableListOf(),
            onOpen = { project ->
                val uri = Uri.parse(project.uri)
                launchWebApp(uri, project.name)
            },
            onDelete = { project ->
                AlertDialog.Builder(this)
                    .setTitle("Remove Project")
                    .setMessage("Remove \"${project.name}\" from recent projects?")
                    .setPositiveButton("Remove") { _, _ ->
                        removeRecentProject(project.uri)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener {
            openFolderLauncher.launch(null)
        }

        loadRecentProjects()
    }

    override fun onResume() {
        super.onResume()
        loadRecentProjects()
    }

    private fun launchWebApp(uri: Uri, name: String) {
        saveRecentProject(name, uri.toString())
        val intent = Intent(this, WebAppActivity::class.java).apply {
            putExtra(WebAppActivity.EXTRA_URI, uri.toString())
            putExtra(WebAppActivity.EXTRA_TITLE, name)
        }
        startActivity(intent)
    }

    private fun saveRecentProject(name: String, uriStr: String) {
        val projects = loadProjectsJson()
        // Remove existing entry with same URI
        val filtered = (0 until projects.length())
            .map { projects.getJSONObject(it) }
            .filter { it.getString("uri") != uriStr }
            .toMutableList()

        val entry = JSONObject().apply {
            put("name", name)
            put("uri", uriStr)
            put("lastOpened", System.currentTimeMillis())
        }
        filtered.add(0, entry)

        // Keep only last 20 recent projects
        val trimmed = filtered.take(20)
        val arr = JSONArray()
        trimmed.forEach { arr.put(it) }
        prefs.edit().putString("recent_projects", arr.toString()).apply()
        loadRecentProjects()
    }

    private fun removeRecentProject(uriStr: String) {
        val projects = loadProjectsJson()
        val filtered = (0 until projects.length())
            .map { projects.getJSONObject(it) }
            .filter { it.getString("uri") != uriStr }

        val arr = JSONArray()
        filtered.forEach { arr.put(it) }
        prefs.edit().putString("recent_projects", arr.toString()).apply()
        loadRecentProjects()
    }

    private fun loadProjectsJson(): JSONArray {
        val json = prefs.getString("recent_projects", "[]") ?: "[]"
        return try { JSONArray(json) } catch (e: Exception) { JSONArray() }
    }

    private fun loadRecentProjects() {
        val arr = loadProjectsJson()
        val projects = (0 until arr.length()).map {
            val obj = arr.getJSONObject(it)
            RecentProject(
                name = obj.getString("name"),
                uri = obj.getString("uri"),
                lastOpened = obj.getLong("lastOpened")
            )
        }
        adapter.updateProjects(projects)
        emptyView.visibility = if (projects.isEmpty()) View.VISIBLE else View.GONE
        recyclerView.visibility = if (projects.isEmpty()) View.GONE else View.VISIBLE
    }
}
