package com.localwebapp

import android.content.ContentResolver
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import java.io.OutputStream
import java.net.ServerSocket
import java.net.URLDecoder
import java.util.concurrent.Executors

/**
 * Lightweight HTTP/1.1 server that reads files from a SAF document tree
 * and serves them on localhost. Enables full same-origin semantics:
 * localStorage, fetch(), ES modules, WebSockets all work correctly.
 */
class DocumentFileServer(
    private val resolver: ContentResolver,
    private val rootTreeUri: Uri
) {
    private var serverSocket: ServerSocket? = null
    var port: Int = 0
        private set
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var active = false

    fun start() {
        serverSocket = ServerSocket(0).also { port = it.localPort }
        active = true
        pool.submit {
            while (active) {
                try {
                    val client = serverSocket!!.accept()
                    pool.submit {
                        try {
                            handleRequest(client)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        } finally {
                            client.close()
                        }
                    }
                } catch (e: Exception) {
                    if (active) e.printStackTrace()
                }
            }
        }
    }

    fun stop() {
        active = false
        try { serverSocket?.close() } catch (e: Exception) { /* ignore */ }
        pool.shutdownNow()
    }

    private fun handleRequest(socket: java.net.Socket) {
        val reader = socket.inputStream.bufferedReader(Charsets.ISO_8859_1)
        val out = socket.outputStream

        val requestLine = reader.readLine() ?: return
        val tokens = requestLine.trim().split(" ")
        if (tokens.size < 2) return
        val method = tokens[0]
        var rawPath = tokens[1]

        // Consume all headers
        do { val h = reader.readLine() ?: break } while (h.isNotBlank())

        if (method.equals("OPTIONS", ignoreCase = true)) {
            writeHeaders(out, 204, "No Content", emptyMap())
            return
        }

        // Decode and clean path
        rawPath = URLDecoder.decode(rawPath.substringBefore("?").substringBefore("#"), "UTF-8")
        if (rawPath.isEmpty() || rawPath == "/") rawPath = "/index.html"

        val segments = rawPath.trimStart('/').split("/").filter { it.isNotEmpty() && it != ".." }
        val file = resolveFile(segments)

        when {
            file == null || !file.exists() -> {
                // SPA fallback: serve index.html for unknown paths
                val index = resolveFile(listOf("index.html"))
                if (index != null && index.exists() && !index.isDirectory) {
                    serveFile(out, index)
                } else {
                    writeError(out, 404, "Not Found", "File not found: $rawPath")
                }
            }
            file.isDirectory -> {
                val index = file.findFile("index.html")
                if (index != null && index.exists()) serveFile(out, index)
                else writeError(out, 404, "Not Found", "No index.html in directory")
            }
            else -> serveFile(out, file)
        }
    }

    private fun resolveFile(segments: List<String>): DocumentFile? {
        var current: DocumentFile = DocumentFileCompat.fromTreeUri(resolver, rootTreeUri) ?: return null
        for (seg in segments) {
            current = current.findFile(seg) ?: return null
        }
        return current
    }

    private fun serveFile(out: OutputStream, file: DocumentFile) {
        val bytes = resolver.openInputStream(file.uri)?.use { it.readBytes() }
            ?: run { writeError(out, 500, "Internal Server Error", "Cannot open file"); return }

        val mime = getMime(file.name ?: "")
        val headers = mapOf(
            "Content-Type" to mime,
            "Content-Length" to bytes.size.toString(),
            "Cache-Control" to "no-cache",
            "Access-Control-Allow-Origin" to "*"
        )
        writeHeaders(out, 200, "OK", headers)
        out.write(bytes)
        out.flush()
    }

    private fun writeError(out: OutputStream, code: Int, status: String, body: String) {
        val html = "<html><body><h2>$code $status</h2><p>${escapeHtml(body)}</p></body></html>"
        val bytes = html.toByteArray(Charsets.UTF_8)
        writeHeaders(out, code, status, mapOf(
            "Content-Type" to "text/html; charset=utf-8",
            "Content-Length" to bytes.size.toString(),
            "Access-Control-Allow-Origin" to "*"
        ))
        out.write(bytes)
        out.flush()
    }

    private fun writeHeaders(out: OutputStream, code: Int, status: String, headers: Map<String, String>) {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 $code $status\r\n")
        headers.forEach { (k, v) -> sb.append("$k: $v\r\n") }
        sb.append("\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
    }

    private fun getMime(filename: String): String {
        val ext = filename.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "html", "htm"   -> "text/html; charset=utf-8"
            "css"           -> "text/css; charset=utf-8"
            "js", "mjs"     -> "application/javascript; charset=utf-8"
            "ts"            -> "application/typescript"
            "json"          -> "application/json; charset=utf-8"
            "svg"           -> "image/svg+xml"
            "png"           -> "image/png"
            "jpg", "jpeg"   -> "image/jpeg"
            "gif"           -> "image/gif"
            "webp"          -> "image/webp"
            "ico"           -> "image/x-icon"
            "woff"          -> "font/woff"
            "woff2"         -> "font/woff2"
            "ttf"           -> "font/ttf"
            "otf"           -> "font/otf"
            "mp4"           -> "video/mp4"
            "webm"          -> "video/webm"
            "mp3"           -> "audio/mpeg"
            "ogg"           -> "audio/ogg"
            "wav"           -> "audio/wav"
            "pdf"           -> "application/pdf"
            "xml"           -> "application/xml"
            "wasm"          -> "application/wasm"
            "map"           -> "application/json"
            "txt"           -> "text/plain; charset=utf-8"
            "md"            -> "text/markdown; charset=utf-8"
            else            -> MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
    }

    private fun escapeHtml(s: String) = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
}

/**
 * Helper to create DocumentFile from tree URI using only ContentResolver.
 * Works by extracting context from the ContentResolver via its internals.
 */
object DocumentFileCompat {
    fun fromTreeUri(resolver: ContentResolver, treeUri: Uri): DocumentFile? {
        return try {
            // ContentResolver holds a reference to Context internally.
            // We access it via reflection as a last resort — safe on all API 26+.
            val contextField = ContentResolver::class.java
                .getDeclaredField("mContext")
                .apply { isAccessible = true }
            val context = contextField.get(resolver) as android.content.Context
            DocumentFile.fromTreeUri(context, treeUri)
        } catch (e: Exception) {
            null
        }
    }
}
