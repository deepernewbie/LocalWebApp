# Keep JavascriptInterface methods accessible from WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep DocumentFile classes
-keep class androidx.documentfile.** { *; }

# Keep our bridge class
-keep class com.localwebapp.AndroidBridge { *; }
-keep class com.localwebapp.DocumentFileCompat { *; }
