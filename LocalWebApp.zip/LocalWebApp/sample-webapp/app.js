// Detect platform
const isAndroid = typeof Android !== 'undefined';
document.getElementById('platform').textContent =
  'Platform: ' + (isAndroid ? '✅ Android Native App' : '🌐 Web Browser');

if (isAndroid) {
  document.getElementById('version').textContent = 'App Version: ' + Android.getAppVersion();
}

// Restore saved value
const saved = localStorage.getItem('myValue');
if (saved) document.getElementById('savedValue').textContent = 'Saved: ' + saved;

function saveData() {
  const val = document.getElementById('storageInput').value;
  localStorage.setItem('myValue', val);
  document.getElementById('savedValue').textContent = 'Saved: ' + val;
}

function showToast() {
  if (isAndroid) Android.toast('Hello from your web app! 👋');
  else alert('Toast: Hello from your web app!');
}

function shareText() {
  if (isAndroid) Android.share('Check out Local Web App Runner!', 'Local Web App');
  else alert('Share not available in browser');
}
