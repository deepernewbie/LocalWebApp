# Local Web App Runner for Android

Run any local web app folder as a native Android application — no server, no deployment, no rebuilding.

## How It Works

1. Tap **+** and pick a folder containing your web app (must have `index.html`)
2. The app spins up a localhost HTTP server that reads files directly from that folder via Android's Storage Access Framework
3. A fullscreen WebView loads `http://localhost:<port>/`
4. Your web app runs with full same-origin semantics — `fetch()`, `localStorage`, ES modules, WASM, Web Workers all work

## Features

- 📁 Pick any folder from device storage or cloud drives (Google Drive, etc.)
- 🔄 Recent projects list — tap to reopen instantly
- 🌐 Full JavaScript support (same-origin via localhost)
- 💾 `localStorage` and `sessionStorage` persist between sessions
- 📱 Android JS Bridge — call native Android functions from your JS:
  - `Android.toast(message)` — show a native toast
  - `Android.share(text, title)` — open share sheet
  - `Android.isNativeApp()` — returns `true`
  - `Android.getPlatform()` — returns `"android"`
  - `Android.getAppVersion()` — returns app version string
  - `Android.log(message)` — log to Android Logcat
- ↩️ Back button navigates WebView history
- 🔒 External links open in the system browser

## Requirements

- Android 8.0+ (API 26+)
- Android Studio Hedgehog or newer to build

## Build Instructions

1. Install [Android Studio](https://developer.android.com/studio)
2. Open this project folder
3. Wait for Gradle sync to complete
4. Connect an Android device (USB debugging enabled) or start an emulator
5. Click **Run** ▶

## Project Structure

```
app/src/main/java/com/localwebapp/
├── MainActivity.kt          # Home screen: folder picker + recent projects
├── WebAppActivity.kt        # Fullscreen WebView host
├── DocumentFileServer.kt    # Localhost HTTP server (reads SAF document tree)
```

## Sample Web App

A sample web app is included in `sample-webapp/`. Copy this folder to your Android device and open it with the app to see a working demo of the Android bridge, localStorage, and environment detection.

## Tips

- **SPA routing**: Unknown paths automatically fall back to `index.html`
- **MIME types**: All common web types supported (JS, CSS, WASM, fonts, images, video, audio)
- **Permissions**: The app requests persistent URI permissions so your folder stays accessible after reboots
- **Debugging**: Connect via `adb` and open `chrome://inspect` in desktop Chrome to debug the WebView

## License

MIT
