// js/app.js — main entry: wires storage, STT, and UI.

import { bridge } from './bridge.js';
import {
  loadNotes, saveNotes,
  loadSettings, saveSettings,
  exportNotesBlob, mergeImport, wipeAll, storageFacts,
} from './storage.js';
import {
  createNote, createChild, touchNote, fromLocalInput, parseTags,
} from './notes.js';
import {
  $, $$,
  renderList, openSheet, closeSheet, closeAllSheets,
  fillEditor, renderChildren, appendChildRow, collectChildrenFromDOM,
  setActiveFilter, showBanner, hideBanner,
} from './ui.js';
import {
  onSTT, initModel, isModelReady,
  startRecording, stopRecording, cancelRecording,
  transcribe, getWaveform, getElapsedMs, isRecording,
} from './stt.js';
import {
  installLogCapture, renderEnv, runNetworkProbe, runSttProbe, runMicProbe,
  runStorageProbe, copyDiagnostic, clearLogs,
} from './debug.js';

// Install log capture immediately so we catch startup errors too.
installLogCapture();

// ────────────────────────── state ──────────────────────────

let store = { version: 1, notes: [] };
let settings = loadSettings();
let editing = null;          // currently-open note (object) or null
let query = '';
let filter = 'all';

// where the recorder sends text when it finishes:
// 'new'    -> create a new note from transcription
// 'body'   -> append to editor body
// 'child'  -> append to a specific child textarea (id stored)
let micTarget = { mode: 'new', childId: null };

// ────────────────────────── boot ──────────────────────────

(async function boot() {
  // Log diagnostics
  bridge.log(`boot — platform=${bridge.platform()} native=${bridge.isNative()} v=${bridge.version()}`);

  // Wait for the APK's AndroidFS shim to inject. It's delivered via
  // evaluateJavascript from the WebView's onPageFinished callback, which
  // races with the module script's first tick. If we call loadNotes
  // immediately we'll miss the bridge, find nothing at OPFS either,
  // and show an empty list even though notes.json is sitting on disk.
  //
  // Poll every 50 ms for up to 3 seconds. If the bridge never appears
  // (e.g. running in a plain browser for dev) we fall through and
  // loadNotes resolves via OPFS / localStorage.
  if (bridge.isNative()) {
    const deadline = Date.now() + 3000;
    while (Date.now() < deadline) {
      if (window.AndroidFS && typeof window.AndroidFS.read === 'function') {
        bridge.log('AndroidFS bridge ready after ' + (3000 - (deadline - Date.now())) + 'ms');
        break;
      }
      await new Promise(r => setTimeout(r, 50));
    }
    if (!(window.AndroidFS && typeof window.AndroidFS.read === 'function')) {
      bridge.log('AndroidFS bridge never appeared, falling back');
    }
  }

  store = await loadNotes();
  renderAll();

  wireTopbar();
  wireSearch();
  wireFab();
  wireEditor();
  wireMenu();
  wireSettings();
  wireSTTEvents();

  // Watch for viewport (Android soft keyboard)
  document.documentElement.classList.toggle('native', bridge.isNative());

  // Warm up the STT model in the background. The transformers.js cache
  // and the APK's netcache both persist the bytes on disk, so after the
  // first full download this is just file I/O + WASM session init —
  // typically <2s. Running it here means by the time the user taps the
  // mic, the pipeline is already ready. Fire-and-forget: if it fails,
  // ensureModelReady() will retry synchronously on first mic tap.
  (async () => {
    window.__sttWarming = true;
    try {
      await ensureModelReady(true);
      bridge.log('model warmup complete');
    } catch (e) {
      bridge.log('model warmup failed (will retry on mic tap): ' + e.message);
    } finally {
      window.__sttWarming = false;
    }
  })();
})();

// ────────────────────────── render ──────────────────────────

function renderAll() {
  renderList({
    listEl: $('#notesList'),
    emptyEl: $('#empty'),
    notes: store.notes,
    query, filter,
    onOpen: openEditor,
    onToggle: toggleStatus,
  });
}

async function persist() {
  store = await saveNotes(store);
}

// ────────────────────────── topbar ──────────────────────────

function wireTopbar() {
  $('#searchBtn').addEventListener('click', () => {
    const bar = $('#searchBar');
    bar.hidden = !bar.hidden;
    if (!bar.hidden) $('#searchInput').focus();
  });
  $('#menuBtn').addEventListener('click', () => openSheet('menuSheet'));
}

function wireSearch() {
  $('#searchInput').addEventListener('input', (e) => {
    query = e.target.value;
    renderAll();
  });
  $$('.chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      filter = chip.dataset.filter;
      setActiveFilter(filter);
      renderAll();
    });
  });
  setActiveFilter(filter);
}

// ────────────────────────── FAB ──────────────────────────

function wireFab() {
  const fab = $('#recordFab');
  // FAB is simple now: tap to start, tap to stop. No long-press
  // distinction because the FAB always creates a new memo.
  fab.addEventListener('click', (ev) => {
    ev.preventDefault();
    toggleMainRecord();
  });
}

async function toggleMainRecord(opts = {}) {
  if (isRecording()) {
    await finishMainRecord();
    return;
  }
  // FAB always creates a new memo — no editor opens.
  // User taps FAB, records, taps FAB again to stop, transcription
  // auto-titles + saves the memo. If they want to edit, they tap
  // the resulting card afterwards.
  micTarget = { mode: 'new', childId: null };
  await startMainRecord();
}

async function startMainRecord() {
  try {
    if (settings.haptics) bridge.vibrate();
    // Silent warmup: no floating banner. If the model isn't ready yet,
    // the FAB shows a loading state until the pipeline is ready. For
    // in-editor dictation, the dict-strip handles its own loading state
    // (see startDictation below).
    const needsLoad = !isModelReady(settings.model);
    if (needsLoad) $('#recordFab').classList.add('is-loading');
    await ensureModelReady(true);
    $('#recordFab').classList.remove('is-loading');

    await startRecording();
    $('#recordFab').classList.add('is-recording');
    $('#fabTimer').hidden = false;
    // Drive the FAB timer from the same rAF loop we used for the old
    // visualizer — but we don't render waveform anywhere, just update
    // the digits.
    startFabTimer();
  } catch (e) {
    const name = e.name ? `[${e.name}] ` : '';
    bridge.log('record start failed: ' + name + e.message);
    bridge.toast('Mic unavailable: ' + name + e.message);
    $('#recordFab').classList.remove('is-recording');
    $('#recordFab').classList.remove('is-loading');
    $('#fabTimer').hidden = true;
  }
}

async function finishMainRecord() {
  if (settings.haptics) bridge.vibrate();
  $('#recordFab').classList.remove('is-recording');
  $('#fabTimer').hidden = true;
  stopFabTimer();
  const audio = await stopRecording();
  if (!audio || audio.length < 16000 * 0.3) {
    bridge.toast('Too short — discarded');
    return;
  }
  await doTranscribe(audio);
}

function cancelMainRecord() {
  cancelRecording();
  $('#recordFab').classList.remove('is-recording');
  $('#recordFab').classList.remove('is-loading');
  $('#fabTimer').hidden = true;
  stopFabTimer();
  stopDictation({ silent: true });
}

// Lightweight timer just for the FAB digits — no waveform render.
let fabTimerRaf = null;
function startFabTimer() {
  const tick = () => {
    const ms = getElapsedMs();
    const secs = Math.floor(ms / 1000);
    const mm = String(Math.floor(secs / 60)).padStart(2, '0');
    const ss = String(secs % 60).padStart(2, '0');
    const el = $('#fabTimer'); if (el) el.textContent = `${mm}:${ss}`;
    const d = $('#dictTimer'); if (d && !d.closest('[hidden]')) d.textContent = `${mm}:${ss}`;
    fabTimerRaf = requestAnimationFrame(tick);
  };
  fabTimerRaf = requestAnimationFrame(tick);
}
function stopFabTimer() {
  if (fabTimerRaf) { cancelAnimationFrame(fabTimerRaf); fabTimerRaf = null; }
}

// ────────────────────────── in-editor dictation ──────────────────────────
// Shows the compact dict-strip anchored at the top of the sheet body
// while recording into a specific field (body or a sub-note). On stop,
// transcription is appended/merged into the targeted field's text.

let dictationActive = false;

async function startDictation(target) {
  // target: { mode: 'body' } | { mode: 'child', childId: string }
  if (isRecording()) return;  // ignore re-taps while already listening
  if (settings.haptics) bridge.vibrate();

  micTarget = target;
  dictationActive = true;

  // Show the strip immediately with a "preparing" state if the model
  // isn't ready yet, so the user sees feedback on the tap.
  const strip = $('#dictStrip');
  const label = $('#dictLabel');
  const timer = $('#dictTimer');
  strip.hidden = false;
  label.textContent = isModelReady(settings.model) ? 'Listening…' : 'Preparing model…';
  timer.textContent = '00:00';
  highlightField(target, true);

  try {
    await ensureModelReady(true);
    label.textContent = 'Listening…';
    await startRecording();
    startFabTimer();  // reuse timer loop to update #dictTimer
  } catch (e) {
    bridge.log('dictation start failed: ' + e.name + ' ' + e.message);
    bridge.toast('Mic unavailable: ' + e.message);
    stopDictation({ silent: true });
  }
}

async function finishDictation() {
  if (!dictationActive) return;
  dictationActive = false;
  if (settings.haptics) bridge.vibrate();

  const audio = await stopRecording();
  stopFabTimer();
  $('#dictStrip').hidden = true;
  highlightField(micTarget, false);

  if (!audio || audio.length < 16000 * 0.3) {
    bridge.toast('Too short — discarded');
    return;
  }
  // Reuse the same transcription routing as the FAB flow — micTarget
  // is already set to body or child.
  await doTranscribe(audio);
}

function stopDictation({ silent = false } = {}) {
  dictationActive = false;
  $('#dictStrip').hidden = true;
  highlightField(micTarget, false);
  stopFabTimer();
  if (!silent && isRecording()) {
    cancelRecording();
  }
}

function highlightField(target, on) {
  // Remove any existing highlight first.
  document.querySelectorAll('.is-dictating').forEach(el => el.classList.remove('is-dictating'));
  if (!on || !target) return;
  if (target.mode === 'body') {
    const field = $('#fBody').closest('.field');
    if (field) field.classList.add('is-dictating');
  } else if (target.mode === 'child') {
    const row = $(`#childrenList .child[data-id="${target.childId}"]`);
    if (row) row.classList.add('is-dictating');
  }
}

// ────────────────────────── STT model lifecycle ──────────────────────────

async function ensureModelReady(silent = false) {
  if (isModelReady(settings.model)) return;
  if (!silent) showBanner('Preparing transcription model…', 0);
  try {
    await initModel(settings.model);
  } catch (e) {
    if (!silent) hideBanner();
    if (!silent) bridge.toast('Model load failed: ' + (e && e.message || e));
    bridge.log('model init failed: ' + (e && e.stack || e));
    throw e;
  }
  hideBanner();
}

function wireSTTEvents() {
  onSTT((e) => {
    // Suppress banners during silent warmup at boot — the user shouldn't
    // see loading progress if they didn't ask for STT yet. If the mic is
    // tapped mid-warmup, ensureModelReady() will switch silent off and
    // the banner will start rendering again on the next progress event.
    if (window.__sttWarming) return;
    if (e.type === 'progress') {
      const pct = e.progress ? Math.round(e.progress) : (e.loaded && e.total ? Math.round((e.loaded / e.total) * 100) : null);
      const label = e.file ? `Loading ${shortFileName(e.file)}` : 'Loading model';
      showBanner(pct !== null ? `${label} · ${pct}%` : label, pct);
    } else if (e.type === 'ready') {
      hideBanner();
    } else if (e.type === 'error') {
      hideBanner();
      bridge.toast('STT error: ' + e.message);
    }
  });
}

function shortFileName(f) {
  const parts = String(f).split('/');
  return parts[parts.length - 1];
}

// ────────────────────────── transcription flow ──────────────────────────

async function doTranscribe(audio) {
  showBanner('Transcribing…', null);
  let res;
  try {
    res = await transcribe(audio, settings.language);
  } catch (e) {
    hideBanner();
    bridge.toast('Transcribe failed: ' + e.message);
    return;
  }
  hideBanner();
  const text = (res.text || '').trim();
  if (!text) {
    // transcribe() returns a 'skipped' tag when it filtered the output,
    // so we can tell the user whether the mic was silent or the model
    // hallucinated. Distinguishing helps when the previous run seemed
    // to "work" but produced garbage.
    if (res.skipped === 'silence') {
      bridge.toast('No audio detected — check mic');
    } else if (res.skipped === 'hallucination') {
      bridge.toast('Audio too ambiguous — try again');
      bridge.log('hallucination filtered: ' + (res.original || '?'));
    } else {
      bridge.toast('No speech detected');
    }
    return;
  }
  bridge.log(`transcribed ${text.length} chars in ${res.durationMs}ms  peak=${res.rawPeak?.toFixed(3)}`);

  // route to target
  if (micTarget.mode === 'new') {
    const n = createNote({
      title: deriveTitle(text),
      body: text,
      language: res.language,
    });
    store.notes.push(n);
    await persist();
    renderAll();
    // Brief, non-intrusive confirmation. User can tap the card to edit.
    bridge.toast('Saved · ' + (n.title || 'memo'));
    if (settings.haptics) bridge.vibrate();
  } else if (micTarget.mode === 'body') {
    const ta = $('#fBody');
    // Append with a space separator. If the field is empty, skip the
    // leading space. Cursor stays at the end of the appended text so
    // the user can keep typing or dictating.
    ta.value = (ta.value ? ta.value.trim() + ' ' : '') + text;
    ta.dispatchEvent(new Event('input'));
    ta.focus();
    try { ta.setSelectionRange(ta.value.length, ta.value.length); } catch {}
  } else if (micTarget.mode === 'child') {
    const row = $(`#childrenList .child[data-id="${micTarget.childId}"]`);
    if (row) {
      const ta = row.querySelector('textarea');
      // Same append-with-space behavior for sub-notes.
      ta.value = (ta.value ? ta.value.trim() + ' ' : '') + text;
      ta.dispatchEvent(new Event('input'));
    }
  }
}

// Derive a concise title from transcribed text.
//
//   - Strip bracketed non-speech markers Whisper adds for sounds it
//     couldn't transcribe as words: [KAPI ÇALIYOR], [music], [applause].
//     These are artifacts, not content the user meant.
//   - Take the first sentence-ish clause.
//   - If it's long, truncate on the nearest word boundary at ~50 chars.
//   - Cap hard at 60 chars with ellipsis.
//   - Capitalize the first letter for presentation.
function deriveTitle(text) {
  if (!text) return 'Untitled memo';

  // Remove common Whisper non-speech annotations in both English and
  // Turkish. Pattern: [SOMETHING] or (something) that looks like an
  // annotation rather than spoken content.
  let cleaned = text
    .replace(/\[[^\]]{1,40}\]/g, '')      // [KAPI ÇALIYOR], [music]
    .replace(/\([^)]{1,40}\)/g, (m) => {  // keep parenthetical content that's speech
      // Heuristic: if fully uppercase or single word in a known set, drop.
      const inner = m.slice(1, -1).trim();
      if (/^[A-ZÇĞİÖŞÜ\s]+$/.test(inner)) return '';
      if (/^(music|applause|laughter|müzik|alkış|kahkaha)$/i.test(inner)) return '';
      return m;
    })
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleaned) return 'Untitled memo';

  // First sentence: break on ., !, ?, …, Turkish/Arabic variants, newlines
  const first = cleaned.split(/[.!?…؟\n]/)[0].trim();
  let candidate = first || cleaned;

  // Break on comma/semicolon if still long
  if (candidate.length > 60) {
    const onComma = candidate.split(/[,;]/)[0].trim();
    if (onComma.length >= 10) candidate = onComma;
  }

  // Word-boundary truncate at ~50 chars
  if (candidate.length > 50) {
    const cut = candidate.slice(0, 50);
    const lastSpace = cut.lastIndexOf(' ');
    candidate = (lastSpace > 20 ? cut.slice(0, lastSpace) : cut).trim() + '…';
  }

  // Capitalize first letter (Turkish-safe for common cases — İ handled
  // by the browser's locale-aware toLocaleUpperCase).
  if (candidate.length > 0) {
    candidate = candidate[0].toLocaleUpperCase('tr-TR') + candidate.slice(1);
  }

  return candidate || 'Untitled memo';
}

// ────────────────────────── editor ──────────────────────────

function wireEditor() {
  // Close buttons use inline onclick="__closeSheet(...)" defined in
  // index.html — that's a plain non-module script attribute which works
  // regardless of any module-loading behaviour in the WebView.
  //
  // Watches the editor sheet so we clean up state whenever it's hidden,
  // regardless of which close strategy fired.
  const editor = $('#editorSheet');
  const isHidden = () => editor.hidden || editor.classList.contains('is-closed') || editor.style.display === 'none';
  let lastHidden = isHidden();
  new MutationObserver(() => {
    const now = isHidden();
    if (now && !lastHidden) {
      if (isRecording()) cancelMainRecord();
      editing = null;
    }
    lastHidden = now;
  }).observe(editor, { attributes: true, attributeFilter: ['hidden', 'class', 'style'] });

  $('#saveNote').addEventListener('click', onSaveNote);
  $('#deleteNote').addEventListener('click', onDeleteNote);

  $('#micInBody').addEventListener('click', async () => {
    if (dictationActive) { await finishDictation(); return; }
    await startDictation({ mode: 'body', childId: null });
  });

  // Dict-strip controls
  $('#dictStop').addEventListener('click', () => finishDictation());
  $('#dictCancel').addEventListener('click', () => stopDictation());

  $('#addChild').addEventListener('click', () => {
    const c = createChild('');
    appendChildRow(c);
  });

  // delegate for child row buttons
  $('#childrenList').addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const row = btn.closest('.child');
    if (!row) return;
    const id = row.dataset.id;
    if (btn.dataset.action === 'del-child') {
      row.remove();
    } else if (btn.dataset.action === 'mic-child') {
      if (dictationActive) { await finishDictation(); return; }
      await startDictation({ mode: 'child', childId: id });
    }
  });
}

function openEditor(id, opts = {}) {
  const n = store.notes.find((x) => x.id === id);
  if (!n) return;
  editing = n;
  fillEditor(n);
  $('#dangerZone').hidden = false;
  // Reset any dictation UI left over from a previous session.
  $('#dictStrip').hidden = true;
  stopDictation({ silent: true });
  openSheet('editorSheet');
}

async function onSaveNote() {
  const title = $('#fTitle').value.trim();
  const body = $('#fBody').value.trim();
  const assignee = $('#fAssignee').value.trim();
  const dueAt = fromLocalInput($('#fDue').value);
  const priority = $('#fPriority').value;
  const tags = parseTags($('#fTags').value);
  const childrenRaw = collectChildrenFromDOM();

  if (!title && !body && !childrenRaw.length) {
    bridge.toast('Empty memo — nothing to save');
    return;
  }

  if (editing) {
    const existingById = new Map((editing.children || []).map((c) => [c.id, c]));
    const children = childrenRaw.map(({ id, text }) => {
      const prev = existingById.get(id);
      if (prev && prev.text === text) return prev;
      if (prev) return { ...prev, text, updatedAt: new Date().toISOString() };
      return createChild(text);
    });
    const updated = touchNote(editing, {
      title, body, assignee, dueAt, priority, tags, children,
    });
    const idx = store.notes.findIndex((x) => x.id === editing.id);
    store.notes[idx] = updated;
  } else {
    const children = childrenRaw.map(({ text }) => createChild(text));
    const n = createNote({ title, body, assignee, dueAt, priority, tags, children });
    store.notes.push(n);
  }
  await persist();
  renderAll();
  closeSheet('editorSheet');
  editing = null;
  if (settings.haptics) bridge.vibrate();
}

async function onDeleteNote() {
  if (!editing) return;
  if (!confirm('Delete this memo? This cannot be undone.')) return;
  store.notes = store.notes.filter((x) => x.id !== editing.id);
  await persist();
  renderAll();
  closeSheet('editorSheet');
  editing = null;
  bridge.toast('Memo deleted');
}

async function toggleStatus(id) {
  const n = store.notes.find((x) => x.id === id);
  if (!n) return;
  const updated = touchNote(n, { status: n.status === 'done' ? 'open' : 'done' });
  const idx = store.notes.findIndex((x) => x.id === id);
  store.notes[idx] = updated;
  await persist();
  renderAll();
  if (settings.haptics) bridge.vibrate();
}

// ────────────────────────── menu ──────────────────────────

function wireMenu() {
  $('#mExport').addEventListener('click', async () => {
    closeSheet('menuSheet');
    await onExport();
  });
  $('#mImport').addEventListener('click', () => {
    closeSheet('menuSheet');
    $('#fileImport').click();
  });
  $('#fileImport').addEventListener('change', onImport);
  $('#mSettings').addEventListener('click', () => {
    closeSheet('menuSheet');
    openSettings();
  });
  $('#mAbout').addEventListener('click', async () => {
    closeSheet('menuSheet');
    await openAbout();
  });
  $('#mDebug').addEventListener('click', () => {
    closeSheet('menuSheet');
    openDebug();
  });
}

function openDebug() {
  openSheet('debugSheet');
  renderEnv();
  // Wire buttons (idempotent — overwrites handlers each open, no leak since
  // we replace the same handler each time).
  const net = $('#dbgNet');
  const stt = $('#dbgStt');
  const mic = $('#dbgMic');
  const store_ = $('#dbgStore');
  const copy = $('#dbgCopy');
  const clr = $('#dbgClear');
  if (net) net.onclick = () => runNetworkProbe();
  if (stt) stt.onclick = () => runSttProbe();
  if (mic) mic.onclick = () => runMicProbe();
  if (store_) store_.onclick = () => runStorageProbe();
  if (clr) clr.onclick = () => clearLogs();
  if (copy) copy.onclick = async () => {
    const ok = await copyDiagnostic();
    bridge.toast(ok ? 'Diagnostic copied' : 'Copy failed');
  };
}

async function onExport() {
  const { blob, filename } = exportNotesBlob(store);
  const text = await blob.text();

  // Prefer Android.share if available and JSON isn't too huge
  if (bridge.isNative() && text.length < 200_000) {
    const ok = bridge.share(text);
    if (ok) { bridge.toast('Share sheet opened'); return; }
  }
  // Fallback: download via anchor
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
  bridge.toast(`Exported ${filename}`);
}

async function onImport(e) {
  const file = e.target.files && e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const text = await file.text();
    const imported = JSON.parse(text);
    const { store: merged, added, updated } = mergeImport(store, imported);
    store = merged;
    await persist();
    renderAll();
    bridge.toast(`Import: ${added} added, ${updated} updated`);
  } catch (err) {
    bridge.toast('Import failed: ' + err.message);
  }
}

// ────────────────────────── settings ──────────────────────────

function openSettings() {
  $('#sLang').value = settings.language;
  $('#sModel').value = settings.model;
  $('#sHaptics').checked = !!settings.haptics;
  $('#sAutoSave').checked = !!settings.autoSave;
  $('#sAppend').checked = !!settings.appendToLast;
  openSheet('settingsSheet');
}

function wireSettings() {
  const bind = (id, key) => $(id).addEventListener('change', () => {
    settings = saveSettings({ ...settings, [key]: $(id).value });
  });
  const bindBool = (id, key) => $(id).addEventListener('change', () => {
    settings = saveSettings({ ...settings, [key]: $(id).checked });
  });
  bind('#sLang', 'language');
  bindBool('#sHaptics', 'haptics');
  bindBool('#sAutoSave', 'autoSave');
  bindBool('#sAppend', 'appendToLast');

  // model change also triggers reload next recording
  $('#sModel').addEventListener('change', async () => {
    settings = saveSettings({ ...settings, model: $('#sModel').value });
    bridge.toast('Model will load on next recording');
  });

  $('#wipeAll').addEventListener('click', async () => {
    if (!confirm('Delete ALL notes permanently?')) return;
    await wipeAll();
    store = { version: 1, notes: [] };
    renderAll();
    closeSheet('settingsSheet');
    bridge.toast('All notes wiped');
  });
}

async function openAbout() {
  const facts = await storageFacts();
  const dl = $('#aboutFacts');
  dl.innerHTML = '';
  const rows = {
    'Platform':  bridge.platform(),
    'Native':    bridge.isNative() ? 'yes' : 'no',
    'App ver.':  bridge.version(),
    'Free MB':   bridge.freeMB() ?? '—',
    'Notes':     String(store.notes.length),
    'STT model': settings.model,
    'STT lang':  settings.language,
    'OPFS':      facts['OPFS'] || '—',
    'Quota':     facts['Quota'] || '—',
    'Used':      facts['Used'] || '—',
    'UA':        (navigator.userAgent || '').slice(0, 60) + '…',
  };
  for (const [k, v] of Object.entries(rows)) {
    const dt = document.createElement('dt'); dt.textContent = k;
    const dd = document.createElement('dd'); dd.textContent = v;
    dl.append(dt, dd);
  }
  openSheet('aboutSheet');
}
