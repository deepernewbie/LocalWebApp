// Debug utilities: log capture, network probe, STT strategy tester.
// All three strategies for loading transformers.js are tested so we can
// see exactly which one succeeds in the APK's WebView.

const TRANSFORMERS_URL =
  'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/transformers.web.js';
const TRANSFORMERS_URL_MIN =
  'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/transformers.min.js';
const TRANSFORMERS_PKG =
  'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1';
const MAX_LOG_LINES = 200;

// ---------- Console log capture ----------
const logBuffer = [];
function pushLog(level, args) {
  const time = new Date().toLocaleTimeString('en-GB', { hour12: false });
  const msg = Array.from(args).map(a => {
    if (a instanceof Error) return `${a.name}: ${a.message}`;
    if (typeof a === 'object') {
      try { return JSON.stringify(a); } catch { return String(a); }
    }
    return String(a);
  }).join(' ');
  logBuffer.push(`[${time}] ${level.padEnd(5)} ${msg}`);
  if (logBuffer.length > MAX_LOG_LINES) logBuffer.shift();
  const el = document.getElementById('dbgLog');
  if (el) el.textContent = logBuffer.join('\n') || '(no logs yet)';
}

export function installLogCapture() {
  const orig = { log: console.log, warn: console.warn, error: console.error, info: console.info };
  console.log = (...a) => { pushLog('log', a); orig.log.apply(console, a); };
  console.warn = (...a) => { pushLog('warn', a); orig.warn.apply(console, a); };
  console.error = (...a) => { pushLog('error', a); orig.error.apply(console, a); };
  console.info = (...a) => { pushLog('info', a); orig.info.apply(console, a); };
  window.addEventListener('error', e => {
    pushLog('error', [`uncaught: ${e.message} @ ${e.filename}:${e.lineno}`]);
  });
  window.addEventListener('unhandledrejection', e => {
    pushLog('error', [`unhandled: ${e.reason && e.reason.message || e.reason}`]);
  });
}

export function clearLogs() {
  logBuffer.length = 0;
  const el = document.getElementById('dbgLog');
  if (el) el.textContent = '(cleared)';
}

// ---------- Environment info ----------
export function renderEnv() {
  const el = document.getElementById('dbgEnv');
  if (!el) return;
  const lines = [];
  lines.push(`build: ${window.__BUILD__ || 'unknown'}`);
  lines.push(`url:   ${location.href}`);
  lines.push(`ua:    ${navigator.userAgent}`);
  lines.push(`native:${!!(window.Android && window.Android.isNativeApp)}`);
  if (window.Android) {
    try {
      if (typeof window.Android.getPlatform === 'function')
        lines.push(`platf: ${window.Android.getPlatform()}`);
      if (typeof window.Android.getAppVersion === 'function')
        lines.push(`vapp:  ${window.Android.getAppVersion()}`);
      if (typeof window.Android.getFreeMB === 'function')
        lines.push(`freeMB:${window.Android.getFreeMB()}`);
    } catch (e) { lines.push(`android bridge err: ${e.message}`); }
  }
  lines.push(`online:${navigator.onLine}`);
  lines.push(`cores: ${navigator.hardwareConcurrency || '?'}`);
  lines.push(`mem:   ${navigator.deviceMemory || '?'} GB`);
  lines.push(`wasm:  ${typeof WebAssembly !== 'undefined'}`);
  lines.push(`opfs:  ${!!(navigator.storage && navigator.storage.getDirectory)}`);
  lines.push(`fs:    ${!!(window.AndroidFS && typeof window.AndroidFS.read === 'function')}`);
  lines.push(`sab:   ${typeof SharedArrayBuffer !== 'undefined'}`);
  lines.push(`xcoop: ${self.crossOriginIsolated}`);
  // Confirm the importmap in index.html was parsed. If the <script
  // type="importmap"> is malformed or came after other module scripts,
  // it's silently ignored and bare-spec imports fail.
  const imapEl = document.querySelector('script[type="importmap"]');
  if (imapEl) {
    try {
      const m = JSON.parse(imapEl.textContent);
      const n = Object.keys(m.imports || {}).length;
      lines.push(`imap:  ${n} entries`);
    } catch (e) {
      lines.push(`imap:  PARSE ERROR ${e.message}`);
    }
  } else {
    lines.push(`imap:  missing`);
  }
  lines.push(`stt:   ${window.__transformersLoadStrategy || '(not loaded yet)'}`);
  el.textContent = lines.join('\n');
}

// ---------- Network probe ----------
export async function runNetworkProbe() {
  const el = document.getElementById('dbgNetOut');
  if (!el) return;
  el.textContent = 'probing…\n';
  const append = line => { el.textContent += line + '\n'; };

  const targets = [
    { name: 'localhost root', url: location.origin + '/' },
    { name: 'jsDelivr package.json', url: TRANSFORMERS_PKG + '/package.json' },
    { name: 'jsDelivr bare pkg (no ext)', url: TRANSFORMERS_PKG },
    { name: 'jsDelivr transformers.web.js', url: TRANSFORMERS_URL },
    { name: 'jsDelivr transformers.min.js', url: TRANSFORMERS_URL_MIN },
    { name: 'huggingface.co', url: 'https://huggingface.co/Xenova/whisper-base/resolve/main/config.json' },
  ];

  for (const t of targets) {
    const t0 = performance.now();
    try {
      const r = await fetch(t.url, { method: 'GET', mode: 'cors' });
      const dt = Math.round(performance.now() - t0);
      append(`✓ ${t.name}`);
      append(`  status: ${r.status} ${r.statusText}   ${dt}ms`);
      append(`  type:   ${r.type}`);
      const ct = r.headers.get('content-type') || '(none)';
      const cl = r.headers.get('content-length') || '(none)';
      const cors = r.headers.get('access-control-allow-origin') || '(none)';
      append(`  ctype: ${ct}`);
      append(`  clen:  ${cl}`);
      append(`  cors:  ${cors}`);
      // Drain a chunk to confirm body readable
      try {
        const txt = await r.clone().text();
        append(`  body:  ${txt.length} bytes (first: ${JSON.stringify(txt.slice(0, 40))})`);
      } catch (bodyErr) {
        append(`  body:  READ FAILED ${bodyErr.message}`);
      }
    } catch (e) {
      const dt = Math.round(performance.now() - t0);
      append(`✗ ${t.name}  ${dt}ms`);
      append(`  err: ${e.name}: ${e.message}`);
    }
    append('');
  }
  append('done.');
}

// ---------- STT load probe with multiple strategies ----------
export async function runSttProbe() {
  const el = document.getElementById('dbgSttOut');
  if (!el) return;
  el.textContent = '';
  const append = line => { el.textContent += line + '\n'; };

  const probe = async (label, url) => {
    append(label);
    try {
      const t0 = performance.now();
      const mod = await import(/* @vite-ignore */ url);
      const dt = Math.round(performance.now() - t0);
      const keys = Object.keys(mod);
      const hasPipeline = typeof mod.pipeline === 'function';
      const hasEnv = mod.env && typeof mod.env === 'object';
      append(`  ✓ surface load ${dt}ms — ${keys.length} export(s)`);
      append(`  pipeline: ${hasPipeline ? 'YES' : 'NO'}   env: ${hasEnv ? 'YES' : 'NO'}`);
      if (!hasPipeline || !hasEnv) {
        append(`  ⚠ loaded but missing pipeline/env — skipping deep check.`);
        append('');
        return;
      }
      // Deep check — touch the onnxruntime backend accessor. If bare
      // imports inside the bundle haven't been resolved (no import map,
      // wrong URL, etc.) this is where the TypeError surfaces.
      try {
        const ok = !!(mod.env.backends && mod.env.backends.onnx);
        append(`  onnx backend accessor: ${ok ? 'reachable' : 'MISSING'}`);
        window.__transformers = mod;
        append(`  → cached on window.`);
      } catch (deep) {
        append(`  ✗ deep access failed: ${deep.name}: ${deep.message}`);
      }
    } catch (e) {
      append(`  ✗ ${e.name}: ${e.message}`);
    }
    append('');
  };

  // Primary test — uses the import map from index.html to resolve both
  // @huggingface/transformers AND its nested onnxruntime-* dependencies.
  await probe('STRATEGY 1: import "@huggingface/transformers" (via importmap)',
              '@huggingface/transformers');
  // Controls — these bypass the import map and will fail at runtime
  // inside the bundle when it tries to import "onnxruntime-common".
  await probe('STRATEGY 2a: direct URL — transformers.web.js (no importmap)',
              TRANSFORMERS_URL);
  await probe('STRATEGY 2b: direct URL — transformers.min.js (no importmap)',
              TRANSFORMERS_URL_MIN);

  append('STRATEGY 2: fetch → blob URL → import');
  try {
    const t0 = performance.now();
    const r = await fetch(TRANSFORMERS_URL);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const src = await r.text();
    const dt1 = Math.round(performance.now() - t0);
    append(`  fetched: ${src.length} bytes, ${dt1}ms`);
    const blob = new Blob([src], { type: 'text/javascript' });
    const blobUrl = URL.createObjectURL(blob);
    append(`  blob url: ${blobUrl.slice(0, 60)}…`);
    try {
      const mod = await import(/* @vite-ignore */ blobUrl);
      const dt2 = Math.round(performance.now() - t0);
      append(`  ✓ SUCCESS ${dt2}ms — keys: ${Object.keys(mod).slice(0, 5).join(',')}…`);
      window.__transformers = mod;
    } catch (impErr) {
      append(`  ✗ import of blob failed: ${impErr.name}: ${impErr.message}`);
      append(`     (this means the blob loader also fails — rare)`);
    } finally {
      URL.revokeObjectURL(blobUrl);
    }
  } catch (e) {
    append(`  ✗ fetch step failed: ${e.name}: ${e.message}`);
  }
  append('');

  append('STRATEGY 3: <script type="module"> injection');
  try {
    await new Promise((resolve, reject) => {
      const id = '__dbg_transformers_script';
      document.getElementById(id)?.remove();
      const s = document.createElement('script');
      s.id = id;
      s.type = 'module';
      s.textContent = `
        import * as T from "${TRANSFORMERS_URL}";
        window.__transformers = T;
        window.dispatchEvent(new CustomEvent('__tfOk'));
      `;
      const okH = () => { cleanup(); resolve(); };
      const errH = e => { cleanup(); reject(new Error(e.message || 'script error')); };
      function cleanup() {
        window.removeEventListener('__tfOk', okH);
        window.removeEventListener('error', errH, true);
      }
      window.addEventListener('__tfOk', okH, { once: true });
      window.addEventListener('error', errH, true);
      document.head.appendChild(s);
      setTimeout(() => { cleanup(); reject(new Error('timeout 30s')); }, 30000);
    });
    const mod = window.__transformers;
    append(`  ✓ SUCCESS — keys: ${Object.keys(mod || {}).slice(0, 5).join(',')}…`);
  } catch (e) {
    append(`  ✗ ${e.name}: ${e.message}`);
  }
  append('');
  append('done. if any strategy succeeded, window.__transformers is set');
  append('and app.js can use it directly without reloading.');
}

// ---------- Mic probe ----------
export async function runMicProbe() {
  const el = document.getElementById('dbgMicOut');
  if (!el) return;
  el.textContent = '';
  const append = line => { el.textContent += line + '\n'; };

  // 1. Enumerate devices first — confirms the permission layer at least
  //    acknowledges a mic exists.
  try {
    const devs = await navigator.mediaDevices.enumerateDevices();
    const mics = devs.filter(d => d.kind === 'audioinput');
    append(`enumerateDevices: ${mics.length} audio input(s)`);
    mics.forEach((m, i) => append(`  [${i}] id=${m.deviceId.slice(0, 8) || '(empty)'} label=${JSON.stringify(m.label)}`));
  } catch (e) {
    append(`enumerateDevices failed: ${e.name}: ${e.message}`);
  }
  append('');

  const profiles = [
    { label: 'full (EC/NS/AGC)', audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } },
    { label: 'raw mono',         audio: { channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false } },
    { label: 'mono only',        audio: { channelCount: 1 } },
    { label: 'default (audio:true)', audio: true },
  ];

  for (const p of profiles) {
    append(`profile: ${p.label}`);
    const t0 = performance.now();
    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: p.audio });
      const dt = Math.round(performance.now() - t0);
      append(`  ✓ acquired ${dt}ms`);
      const track = stream.getAudioTracks()[0];
      if (track) {
        const settings = track.getSettings ? track.getSettings() : {};
        append(`  label: ${track.label}`);
        append(`  state: ${track.readyState}  muted: ${track.muted}`);
        append(`  settings: ${JSON.stringify(settings)}`);
      }
      // Try to open an AudioContext on it — this is the step that
      // "Could not start audio source" complains about.
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        if (ctx.state === 'suspended') await ctx.resume();
        const src = ctx.createMediaStreamSource(stream);
        const ana = ctx.createAnalyser();
        src.connect(ana);
        append(`  audio graph: OK (sr=${ctx.sampleRate}, state=${ctx.state})`);
        src.disconnect(); ana.disconnect();
        await ctx.close();
      } catch (acErr) {
        append(`  ✗ audio graph: ${acErr.name}: ${acErr.message}`);
      }
      // Release and stop trying more profiles — first success wins.
      try { stream.getTracks().forEach(t => t.stop()); } catch {}
      append('');
      append('done. mic works with this profile.');
      return;
    } catch (e) {
      const dt = Math.round(performance.now() - t0);
      append(`  ✗ ${dt}ms  ${e.name}: ${e.message}`);
      if (e.constraint) append(`    constraint: ${e.constraint}`);
    } finally {
      if (stream) try { stream.getTracks().forEach(t => t.stop()); } catch {}
    }
    append('');
  }
  append('all profiles failed. the DOMException names above identify the root cause.');
}


// ---------- Storage probe ----------
export async function runStorageProbe() {
  const el = document.getElementById('dbgStoreOut');
  if (!el) return;
  el.textContent = '';
  const append = line => { el.textContent += line + '\n'; };

  // 1. API surface check
  append('=== API SURFACE ===');
  append(`window.AndroidFS: ${typeof window.AndroidFS === 'object' ? 'present' : 'missing'}`);
  if (window.AndroidFS) {
    const methods = ['read','write','exists','delete','list','mkdir','readBytes','writeBytes'];
    for (const m of methods) {
      append(`  .${m}: ${typeof window.AndroidFS[m]}`);
    }
  }
  append(`OPFS (navigator.storage.getDirectory): ${
    !!(navigator.storage && navigator.storage.getDirectory)
  }`);
  append('');

  // 2. Round-trip test
  if (window.AndroidFS && typeof window.AndroidFS.write === 'function') {
    append('=== ANDROIDFS ROUND-TRIP ===');
    const testPath = 'notes/_probe.txt';
    const testContent = 'hello-' + Date.now();
    try {
      if (typeof window.AndroidFS.mkdir === 'function') {
        const mkd = await window.AndroidFS.mkdir('notes');
        append(`mkdir('notes') → ${JSON.stringify(mkd)}`);
      }
      const w = await window.AndroidFS.write(testPath, testContent);
      append(`write('${testPath}', '${testContent}') → ${JSON.stringify(w)}`);

      const exists = typeof window.AndroidFS.exists === 'function'
        ? await window.AndroidFS.exists(testPath) : '(no exists)';
      append(`exists('${testPath}') → ${JSON.stringify(exists)} (type=${typeof exists})`);

      const back = await window.AndroidFS.read(testPath);
      append(`read('${testPath}') → ${JSON.stringify(back)}`);
      append(`match: ${back === testContent ? '✓' : '✗'}`);

      if (typeof window.AndroidFS.list === 'function') {
        const list = await window.AndroidFS.list('notes');
        append(`list('notes') → ${JSON.stringify(list)}`);
      }

      if (typeof window.AndroidFS.delete === 'function') {
        const del = await window.AndroidFS.delete(testPath);
        append(`delete('${testPath}') → ${JSON.stringify(del)}`);
      }
    } catch (e) {
      append(`✗ ${e.name}: ${e.message}`);
    }
    append('');

    // 3. Actual notes.json status
    append('=== ACTUAL notes/notes.json ===');
    try {
      const exists = typeof window.AndroidFS.exists === 'function'
        ? await window.AndroidFS.exists('notes/notes.json') : '(no exists)';
      append(`exists: ${JSON.stringify(exists)}`);
      const body = await window.AndroidFS.read('notes/notes.json');
      if (body == null) {
        append(`read: null`);
      } else {
        append(`read: ${String(body).length} chars`);
        try {
          const parsed = JSON.parse(body);
          append(`parsed notes: ${Array.isArray(parsed.notes) ? parsed.notes.length : '(not array)'}`);
          if (parsed.updatedAt) append(`updatedAt: ${parsed.updatedAt}`);
        } catch (pe) {
          append(`parse error: ${pe.message}`);
        }
      }
    } catch (e) {
      append(`read error: ${e.name}: ${e.message}`);
    }
    append('');
  }

  // 4. localStorage state
  append('=== LOCALSTORAGE ===');
  try {
    const raw = localStorage.getItem('vm.notes.v1');
    append(`vm.notes.v1: ${raw == null ? 'absent' : raw.length + ' chars'}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      append(`  notes: ${parsed.notes?.length ?? '?'}`);
    }
  } catch (e) {
    append(`error: ${e.message}`);
  }
  append('');

  // 5. Storage trace since boot
  append('=== TRACE (last 40) ===');
  const tr = window.__storageTrace || [];
  const shown = tr.slice(-40);
  if (shown.length === 0) append('(empty — no storage calls made yet)');
  for (const line of shown) append(line);
}


export async function copyDiagnostic() {
  const parts = [];
  const add = id => {
    const e = document.getElementById(id);
    if (e) parts.push(`=== ${id} ===\n${e.textContent}\n`);
  };
  add('dbgEnv');
  add('dbgNetOut');
  add('dbgSttOut');
  add('dbgMicOut');
  add('dbgStoreOut');
  add('dbgLog');
  const text = parts.join('\n');
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {}
  // fallback: textarea + execCommand
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    return true;
  } catch {
    return false;
  }
}
