// opencode (web) — main UI controller.
// Wires up screens, models, sessions, file browser, agent runs.

import { KV, Sessions, VFS, inCouchFlow } from './storage.js';
import { Agent } from './agent.js';
import { buildSystemPrompt, DEFAULT_SYSTEM_PROMPT } from './prompts.js';
import { $, $$, el, toast, modal, openSheet, renderMarkdown, asciiLogo, logoMark, logoWordmark, dismissStack } from './ui.js';
import { buildPreview } from './preview.js';

const APP_VERSION = '0.1.0';

// --------------------------------------------------- state

const state = {
  settings: null,         // {apiKey, baseUrl, models:[{id,label}], defaultModel, mode, maxSteps, systemPrompt}
  currentScreen: 'sessions',
  currentSession: null,   // { meta, messages }
  agent: null,            // active Agent instance
  filesPath: '',
};

const DEFAULT_SETTINGS = {
  apiKey: '',
  baseUrl: 'https://openrouter.ai/api/v1',
  models: [
    { id: 'anthropic/claude-sonnet-4.5',                label: 'claude sonnet 4.5' },
    { id: 'anthropic/claude-opus-4.1',                  label: 'claude opus 4.1' },
    { id: 'openai/gpt-5',                                label: 'gpt-5' },
    { id: 'google/gemini-2.5-pro',                       label: 'gemini 2.5 pro' },
    { id: 'deepseek/deepseek-chat-v3.1',                label: 'deepseek v3.1' },
    { id: 'qwen/qwen3-coder',                           label: 'qwen3 coder' },
  ],
  defaultModel: 'anthropic/claude-sonnet-4.5',
  mode: 'build',
  maxSteps: 40,
  systemPrompt: '',
  // Optional CORS proxy for arbitrary webfetch / DuckDuckGo HTML search.
  // Format: either a base URL we append the target to, or a template
  // containing {url} which we substitute. Examples:
  //   https://corsproxy.io/?url={url}
  //   https://api.allorigins.win/raw?url={url}
  // Empty string disables proxy fallback entirely.
  corsProxy: '',
};

// Mirror tool-relevant settings to a global so tools.js can pick them up
// without importing app.js (which would create a cycle).
function syncToolEnv() {
  window.opencodeWebSettings = {
    corsProxy: state.settings?.corsProxy || '',
  };
}

// --------------------------------------------------- bootstrap

async function init() {
  // Load settings
  const stored = await KV.get('settings');
  state.settings = { ...DEFAULT_SETTINGS, ...(stored || {}) };
  if (!state.settings.models?.length) state.settings.models = DEFAULT_SETTINGS.models.slice();

  // Expose to tools.js — webfetch and websearch read corsProxy from here
  // when present (they have no other clean import path).
  syncToolEnv();

  // Show banner if not in CouchFlow
  if (!inCouchFlow) {
    setTimeout(() => toast('running in browser mode — files use localStorage', 4000), 400);
  }

  bindGlobalUI();
  bindSessionsScreen();
  bindChatScreen();
  bindFilesScreen();
  bindFileViewScreen();
  bindPreviewScreen();
  bindSettingsScreen();

  $('#about-version').textContent = `v${APP_VERSION} · ${inCouchFlow ? 'couchflow' : 'browser'}`;
  const aboutLogo = $('#about-logo');
  if (aboutLogo) {
    aboutLogo.innerHTML = '';
    aboutLogo.appendChild(logoWordmark());
  }
  const topbarBrand = $('#topbar-brand');
  if (topbarBrand) {
    topbarBrand.innerHTML = '';
    topbarBrand.appendChild(logoWordmark());
  }
  // Compact opencode mark in the chat topbar — keeps the brand visible
  // during project work without crowding out the session title.
  const chatBrand = $('#chat-brand');
  if (chatBrand) {
    chatBrand.innerHTML = '';
    chatBrand.appendChild(logoMark());
  }

  await renderSessions();
  // Seed history with the initial screen so popstate has somewhere to land.
  history.replaceState({ screen: 'sessions', sid: null }, '', '#sessions');
  showScreen('sessions', { replace: true });

  // Theme bar
  if (window.Android?.setBarColor) {
    try { Android.setBarColor('#161616'); } catch {}
  }
}

// --------------------------------------------------- screens
//
// Screen navigation uses the browser History API so that the Android
// hardware back button (forwarded by CouchFlow as webView.goBack()) can
// step back through screens naturally. Each showScreen() pushes a state
// entry; popstate rolls the UI back to the previous one.
//
// The history payload is just `{screen, sessionId?}` — enough to restore
// the right view without a full reload.

function showScreen(name, opts = {}) {
  if (state.currentScreen === 'preview' && name !== 'preview') {
    closePreview();
  }
  state.currentScreen = name;
  for (const s of $$('.screen')) s.classList.add('hidden');
  $('#screen-' + name).classList.remove('hidden');

  // Push a history entry unless we're already restoring from popstate
  // (in which case `replace` is true and we just sync the URL).
  if (!opts.replace && !opts._fromPop) {
    const sid = state.currentSession?.meta?.id || null;
    history.pushState({ screen: name, sid }, '', '#' + name);
  }
}

// Hardware back button: close any open dismissable layer (modal, sheet,
// preview console) before stepping back through screens. Layers register
// themselves via pushDismiss() in ui.js.
window.addEventListener('popstate', (e) => {
  // 1. If a modal/sheet is open, close it and re-push the current screen
  //    so we don't lose our place. Each layer fn returns true if it
  //    actually had something to close.
  while (dismissStack.length) {
    const fn = dismissStack[dismissStack.length - 1];
    const closed = fn();
    if (closed) {
      const sid = state.currentSession?.meta?.id || null;
      history.pushState({ screen: state.currentScreen, sid }, '', '#' + state.currentScreen);
      return;
    }
    dismissStack.pop();
  }

  // 2. Normal screen pop. e.state contains {screen, sid} from when the
  //    current screen was pushed. If null, we've gone past the first
  //    entry — re-seed sessions and let the next back exit the app.
  const target = e.state?.screen;
  if (!target) {
    history.pushState({ screen: 'sessions', sid: null }, '', '#sessions');
    showScreen('sessions', { _fromPop: true });
    return;
  }
  if (target === 'chat' && e.state.sid && state.currentSession?.meta?.id !== e.state.sid) {
    Sessions.load(e.state.sid).then(data => {
      if (data) {
        state.currentSession = data;
        $('#chat-title').textContent = data.meta.title || 'session';
        updateChatChips();
        renderMessages();
        renderTodoPanel(data.meta.todos || []);
        updateUsageStrip();
      }
      showScreen(target, { _fromPop: true });
    });
  } else {
    showScreen(target, { _fromPop: true });
  }
});

// --------------------------------------------------- sessions

function bindSessionsScreen() {
  $('#btn-new-session').onclick = () => createSession();
  $('#btn-settings').onclick   = () => openSettings();
}

async function renderSessions() {
  const list = await Sessions.list();
  const root = $('#sessions-list');
  root.innerHTML = '';

  if (list.length === 0) {
    const empty = el('div', { class: 'empty-state empty-hero' });
    empty.appendChild(logoWordmark());
    empty.appendChild(el('div', { class: 'empty-tag', text: 'a coding agent for your phone' }));
    empty.appendChild(el('div', { class: 'empty-hint', text: 'tap + to start a session' }));
    root.appendChild(empty);
    return;
  }

  for (const s of list) {
    const row = el('div', { class: 'session-row' });
    row.appendChild(el('div', { class: 'session-icon' }, [
      el('span', { html: '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9.4 16.6 4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0L19.2 12l-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/></svg>' }),
    ]));
    row.appendChild(el('div', { class: 'session-meta' }, [
      el('div', { class: 'session-title', text: s.title || 'untitled' }),
      el('div', { class: 'session-sub', text: `${s.messageCount || 0} msgs · ${formatTime(s.updatedAt)} · ${s.model ? shortModel(s.model) : '—'}` }),
    ]));
    row.onclick = () => openSession(s.id);

    // long-press: actions
    let lpTimer = null;
    row.addEventListener('touchstart', () => {
      lpTimer = setTimeout(() => sessionActions(s), 500);
    }, { passive: true });
    row.addEventListener('touchend',   () => clearTimeout(lpTimer));
    row.addEventListener('touchmove',  () => clearTimeout(lpTimer));

    root.appendChild(row);
  }
}

function shortModel(id) {
  const m = state.settings.models.find(x => x.id === id);
  if (m) return m.label;
  const slash = id.lastIndexOf('/');
  return slash >= 0 ? id.slice(slash + 1) : id;
}

function formatTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) {
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

async function sessionActions(s) {
  openSheet({
    title: s.title,
    items: [
      { label: 'open',   action: 'open' },
      { label: 'rename', action: 'rename' },
      { label: 'duplicate (no files)', action: 'duplicate' },
      { label: 'delete', action: 'delete', danger: true },
    ],
    onPick: async ({ action }) => {
      if (action === 'open') openSession(s.id);
      else if (action === 'rename') {
        const input = el('input', { type: 'text', value: s.title || '' });
        const r = await modal({
          title: 'rename session',
          body: input,
          actions: [
            { label: 'cancel', kind: 'cancel' },
            { label: 'save', kind: 'primary', onClick: () => input.value.trim() },
          ],
        });
        if (r) {
          await Sessions.update(s.id, { title: r });
          await renderSessions();
        }
      } else if (action === 'duplicate') {
        const ns = await Sessions.create({ title: (s.title || 'session') + ' copy', model: s.model, mode: s.mode });
        const data = await Sessions.load(s.id);
        if (data) await Sessions.setMessages(ns.id, data.messages || []);
        await renderSessions();
        toast('duplicated');
      } else if (action === 'delete') {
        const r = await modal({
          title: 'delete session?',
          body: 'this also deletes the simulated project files for this session.',
          actions: [
            { label: 'cancel', kind: 'cancel' },
            { label: 'delete', kind: 'danger', value: true },
          ],
        });
        if (r) {
          await Sessions.delete(s.id);
          await renderSessions();
          toast('deleted');
        }
      }
    },
  });
}

async function createSession() {
  if (!state.settings.apiKey) {
    const ok = await modal({
      title: 'add openrouter API key first',
      body: 'open settings and paste your key from openrouter.ai/keys.',
      actions: [
        { label: 'cancel', kind: 'cancel' },
        { label: 'open settings', kind: 'primary', value: true },
      ],
    });
    if (ok) openSettings();
    return;
  }
  const input = el('input', { type: 'text', placeholder: 'session title (optional)' });
  const title = await modal({
    title: 'new session',
    body: input,
    actions: [
      { label: 'cancel', kind: 'cancel' },
      { label: 'create', kind: 'primary', onClick: () => input.value.trim() || 'untitled' },
    ],
  });
  if (!title) return;
  const sess = await Sessions.create({
    title,
    model: state.settings.defaultModel,
    mode:  state.settings.mode || 'build',
  });
  await renderSessions();
  await openSession(sess.id);
}

async function openSession(id) {
  const data = await Sessions.load(id);
  if (!data) { toast('session missing'); return; }
  state.currentSession = data;
  // Sanity defaults
  data.messages = data.messages || [];
  if (!data.meta.model) data.meta.model = state.settings.defaultModel;
  if (!data.meta.mode)  data.meta.mode  = state.settings.mode || 'build';

  $('#chat-title').textContent = data.meta.title || 'session';
  updateChatChips();
  renderMessages();
  renderTodoPanel(data.meta.todos || []);
  updateUsageStrip();
  showScreen('chat');
  setTimeout(() => scrollMessagesToBottom({ force: true }), 50);
}

// --------------------------------------------------- chat screen

function bindChatScreen() {
  $('#btn-back-chat').onclick = async () => {
    if (state.agent?.running) {
      const ok = await modal({
        title: 'stop generation?',
        body: 'the agent is still running.',
        actions: [
          { label: 'keep running', kind: 'cancel' },
          { label: 'stop & leave', kind: 'danger', value: true },
        ],
      });
      if (!ok) return;
      state.agent.stop();
      state.agent = null;
    }
    state.currentSession = null;
    await renderSessions();
    history.back();
  };

  $('#btn-files').onclick = () => openFiles();

  $('#btn-chat-menu').onclick = () => chatMenu();

  $('#chip-model').onclick  = () => pickModel();
  $('#chip-mode').onclick   = () => pickMode();
  $('#chip-stop').onclick   = () => state.agent?.stop();

  const ta = $('#composer-input');
  const send = $('#btn-send');
  ta.addEventListener('input', () => {
    autosize(ta);
    // Send stays enabled while the agent is running — clicking it queues
    // the message as a mid-run inject instead of starting a new turn.
    send.disabled = !ta.value.trim();
  });
  ta.addEventListener('keydown', e => {
    // mobile soft kbd: Enter inserts newline. Don't intercept.
  });
  send.onclick = onSend;

  // Todo panel toggle
  $('#todo-panel-header').onclick = () => {
    const panel = $('#todo-panel');
    panel.classList.toggle('collapsed');
    // Persist user's open/closed preference per session
    const sess = state.currentSession;
    if (sess) {
      sess.meta.todosCollapsed = panel.classList.contains('collapsed');
      Sessions.update(sess.meta.id, { todosCollapsed: sess.meta.todosCollapsed }).catch(() => {});
    }
  };
}

function autosize(ta) {
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, window.innerHeight * 0.3) + 'px';
}

function updateChatChips() {
  const sess = state.currentSession;
  if (!sess) return;
  $('#chip-model-text').textContent = sess.meta.model ? shortModel(sess.meta.model) : 'no model';
  $('#chip-mode-text').textContent  = sess.meta.mode || 'build';
  $('#chip-stop').hidden = !state.agent?.running;
  $('#btn-send').disabled = !$('#composer-input').value.trim();
}

function chatMenu() {
  openSheet({
    title: state.currentSession?.meta?.title || 'session',
    items: [
      { label: 'preview project', action: 'preview' },
      { label: 'view project files', action: 'files' },
      { label: 'download project (zip)', action: 'zip' },
      { label: 'share project (zip)',    action: 'zip-share' },
      { label: 'copy conversation (debug)', action: 'copy-transcript', sub: 'paste into any LLM chat for debugging' },
      { label: 'rename session', action: 'rename' },
      { label: 'clear messages', action: 'clear', danger: true },
    ],
    onPick: async ({ action }) => {
      const id = state.currentSession?.meta?.id;
      if (!id) return;
      if (action === 'rename') {
        const input = el('input', { type: 'text', value: state.currentSession.meta.title || '' });
        const r = await modal({
          title: 'rename',
          body: input,
          actions: [
            { label: 'cancel', kind: 'cancel' },
            { label: 'save', kind: 'primary', onClick: () => input.value.trim() },
          ],
        });
        if (r) {
          await Sessions.update(id, { title: r });
          state.currentSession.meta.title = r;
          $('#chat-title').textContent = r;
        }
      } else if (action === 'clear') {
        const r = await modal({
          title: 'clear messages?',
          body: 'project files are NOT deleted, only the conversation.',
          actions: [
            { label: 'cancel', kind: 'cancel' },
            { label: 'clear', kind: 'danger', value: true },
          ],
        });
        if (r) {
          state.currentSession.messages = [];
          await Sessions.setMessages(id, []);
          renderMessages();
        }
      } else if (action === 'zip') {
        await exportProjectZip(id, false);
      } else if (action === 'zip-share') {
        await exportProjectZip(id, true);
      } else if (action === 'files') {
        openFiles();
      } else if (action === 'preview') {
        openPreview();
      } else if (action === 'copy-transcript') {
        await copyDebugTranscript();
      }
    },
  });
}

// Build a complete debuggable transcript of the current session and copy it
// to the clipboard. The intent: the user pastes this back into a chat with
// any LLM (or another opencode instance) to ask "why did this go wrong?" so
// we capture EVERYTHING — not just the human-readable summary, but the raw
// structure the agent and the model exchanged: system prompt, every message,
// every tool call's args and output, agent settings (model, mode, max steps),
// usage stats. Sensitive values (API key) are redacted.
async function copyDebugTranscript() {
  const sess = state.currentSession;
  if (!sess) { toast('no session'); return; }

  const lines = [];
  const sep = '─'.repeat(72);

  // ---- Header
  lines.push('# opencode-web debug transcript');
  lines.push(`session id: ${sess.meta.id}`);
  lines.push(`title:      ${sess.meta.title || '(untitled)'}`);
  lines.push(`created:    ${new Date(sess.meta.createdAt).toISOString()}`);
  lines.push(`exported:   ${new Date().toISOString()}`);
  lines.push(`model:      ${sess.meta.model || '(none)'}`);
  lines.push(`mode:       ${sess.meta.mode || 'build'}`);
  lines.push(`runtime:    ${inCouchFlow ? 'couchflow' : 'browser'}`);
  lines.push(`app version: ${APP_VERSION}`);
  if (sess.usage) {
    lines.push(`usage:      ↑${sess.usage.in} tokens · ↓${sess.usage.out} tokens · ` +
               `last input ${sess.usage.lastIn} · ${sess.usage.turns} turn(s)`);
  }
  lines.push(`max steps:  ${state.settings.maxSteps || 40}`);
  if (state.settings.systemPrompt) lines.push('custom system prompt: yes');
  if (state.settings.corsProxy)    lines.push('cors proxy configured: yes');
  lines.push('');

  // ---- System prompt
  lines.push(sep);
  lines.push('# system prompt');
  lines.push(sep);
  try {
    const sys = await buildSystemPrompt({
      sessionId: sess.meta.id,
      mode:      sess.meta.mode,
      custom:    state.settings.systemPrompt,
    });
    lines.push(sys);
  } catch (e) {
    lines.push('(failed to build system prompt: ' + (e?.message || e) + ')');
  }
  lines.push('');

  // ---- Available tools (just names; the model received full schemas)
  lines.push(sep);
  lines.push('# tools available to agent (' + (sess.meta.mode || 'build') + ' mode)');
  lines.push(sep);
  // Hardcoded mirror of tools.js mode lists. Update both if the lists
  // change there.
  const TOOLS_BY_MODE = {
    build: ['read', 'write', 'edit', 'glob', 'grep', 'bash', 'webfetch',
            'websearch', 'wikiimage', 'todowrite', 'task', 'question'],
    plan:  ['read', 'glob', 'grep', 'webfetch', 'websearch', 'wikiimage',
            'todowrite', 'task', 'question', 'plan_exit'],
  };
  lines.push((TOOLS_BY_MODE[sess.meta.mode || 'build'] || []).join(', '));
  lines.push('');

  // ---- Persisted todo list (separate from message history)
  if (sess.meta.todos?.length) {
    lines.push(sep);
    lines.push('# current todo list');
    lines.push(sep);
    for (const t of sess.meta.todos) {
      const mark = t.status === 'done'        ? '[x]'
                 : t.status === 'in_progress' ? '[~]'
                 : t.status === 'cancelled'   ? '[-]'
                 : '[ ]';
      lines.push(`${mark} ${t.text}`);
    }
    lines.push('');
  }

  // ---- Messages
  lines.push(sep);
  lines.push('# messages (' + (sess.messages?.length || 0) + ')');
  lines.push(sep);
  lines.push('');
  for (let i = 0; i < (sess.messages || []).length; i++) {
    const m = sess.messages[i];
    const tag = m.role.toUpperCase()
              + (m.injected ? ' (injected mid-run)' : '')
              + (m.compacted ? ' (compacted summary)' : '');
    lines.push(`──── [${i+1}] ${tag} · ${new Date(m.ts).toISOString()}`);
    for (const p of (m.parts || [])) {
      if (p.type === 'text') {
        lines.push(p.text || '');
      } else if (p.type === 'reasoning') {
        lines.push('--- reasoning ---');
        lines.push(p.text || '');
      } else if (p.type === 'tool_call') {
        lines.push(`--- tool_call: ${p.name} (${p.status || 'pending'}) ---`);
        lines.push('args: ' + safeJSON(p.args, 4000));
        if (p.output != null) lines.push('output: ' + clamp(String(p.output), 4000));
        if (p.error)          lines.push('error: '  + p.error);
        if (p.diff)           lines.push('diff: '   + clamp(String(p.diff), 2000));
      } else {
        lines.push(`--- ${p.type} ---`);
        lines.push(safeJSON(p, 1000));
      }
    }
    lines.push('');
  }

  // ---- Settings (sanitized)
  lines.push(sep);
  lines.push('# app settings (sanitized)');
  lines.push(sep);
  const safeSettings = {
    ...state.settings,
    apiKey: state.settings.apiKey ? '<redacted>' : '',
  };
  lines.push(safeJSON(safeSettings, 4000));
  lines.push('');

  const text = lines.join('\n');

  // Strategy: try clipboard first (fast path for short transcripts), but
  // ALSO always save the transcript to Downloads as a file so the user has
  // a reliable way to retrieve it. Large transcripts (>16KB) often fail to
  // copy silently on Android WebView. The file fallback is bulletproof.
  let clipboardOK = false;
  try {
    clipboardOK = await copyToClipboard(text);
  } catch (_) { /* ignore */ }

  // Save to a file too — name with timestamp so re-exports don't clobber
  const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename = `opencode-debug-${ts}.txt`;
  let savedToFile = false;
  try {
    await downloadBlob(new Blob([text], { type: 'text/plain' }), filename);
    savedToFile = true;
  } catch (e) {
    console.error('debug transcript file save failed', e);
  }

  // Tell the user what happened, with the most reliable destination first
  if (savedToFile && clipboardOK) {
    toast(`saved to Downloads/${filename} (also copied)`);
  } else if (savedToFile) {
    toast(`saved to Downloads/${filename}`);
  } else if (clipboardOK) {
    toast(`copied ${text.length.toLocaleString()} chars to clipboard`);
  } else {
    // Last resort: show in a modal so user can long-press and select all
    const ta = el('textarea', { class: 'debug-textarea' });
    ta.value = text;
    ta.readOnly = true;
    ta.style.width = '100%';
    ta.style.height = '60vh';
    ta.style.fontFamily = 'monospace';
    ta.style.fontSize = '11px';
    ta.style.background = 'var(--c-bg-3)';
    ta.style.color = 'var(--c-text)';
    ta.style.border = 'none';
    ta.style.padding = '8px';
    ta.style.resize = 'none';
    await modal({
      title: 'debug transcript (copy failed)',
      body: ta,
      actions: [{ label: 'close', kind: 'cancel' }],
    });
  }
}

// JSON.stringify with truncation for huge values, so a runaway tool output
// doesn't blow up the transcript. Length is total chars after stringify.
function safeJSON(value, maxChars) {
  let s;
  try { s = JSON.stringify(value, null, 2); }
  catch { s = String(value); }
  if (s.length > maxChars) s = s.slice(0, maxChars) + `\n…[truncated, original was ${s.length} chars]`;
  return s;
}

function clamp(s, maxChars) {
  if (s.length <= maxChars) return s;
  return s.slice(0, maxChars) + `\n…[truncated, original was ${s.length} chars]`;
}

async function pickModel() {
  const items = state.settings.models.map(m => ({
    label: m.label,
    sub: m.id,
    checked: m.id === state.currentSession?.meta?.model,
    pick: m.id,
  }));
  items.push({ label: '+ add a model', sub: 'go to settings', pick: '__add' });
  openSheet({
    title: 'model',
    items,
    onPick: async (item) => {
      if (item.pick === '__add') { openSettings(); return; }
      await Sessions.update(state.currentSession.meta.id, { model: item.pick });
      state.currentSession.meta.model = item.pick;
      updateChatChips();
    },
  });
}

function pickMode() {
  openSheet({
    title: 'mode',
    items: [
      { label: 'build — full tool access', pick: 'build', checked: state.currentSession.meta.mode === 'build' },
      { label: 'plan — read only',         pick: 'plan',  checked: state.currentSession.meta.mode === 'plan' },
    ],
    onPick: async (item) => {
      await Sessions.update(state.currentSession.meta.id, { mode: item.pick });
      state.currentSession.meta.mode = item.pick;
      updateChatChips();
    },
  });
}

// --------------------------------------------------- slash commands

// Built-in slash commands. Each returns true if the command was recognized
// and handled (so the user input shouldn't be sent to the LLM as a message),
// or false to fall through and treat the input as a normal message.
//
// Commands ported from opencode TUI: /help, /compact (alias /summarize),
// /init, /models, /sessions, /share, /clear, /new.
//
// Custom commands defined in settings (template-based, like opencode's
// commands/) get expanded into the user's message and sent normally.
async function handleSlashCommand(input) {
  const m = input.match(/^\/([a-zA-Z][\w-]*)\s*(.*)$/s);
  if (!m) return false;
  const cmd  = m[1].toLowerCase();
  const args = m[2].trim();

  // Custom commands first — defined in settings, override built-ins
  const custom = (state.settings.commands || []).find(c => c.name === cmd);
  if (custom) {
    // Expand $ARGUMENTS, $1, $2, ... into the template
    const positional = args.split(/\s+/);
    let expanded = (custom.template || '').replace(/\$ARGUMENTS\b/g, args);
    expanded = expanded.replace(/\$(\d+)/g, (_, n) => positional[+n - 1] || '');
    // Send the expanded text as a normal message — fall through
    $('#composer-input').value = expanded;
    return false;
  }

  switch (cmd) {
    case 'help':      return cmdHelp();
    case 'compact':
    case 'summarize': return cmdCompact();
    case 'init':      return cmdInit();
    case 'models':
    case 'model':     return cmdModels();
    case 'sessions':  return cmdSessions();
    case 'share':     return cmdShare();
    case 'clear':     return cmdClear();
    case 'new':       return cmdNew();
    case 'preview':   return cmdPreview();
    case 'files':     return cmdFiles();
    case 'btw':
    case 'ask':       return cmdBtw(args);
    default:
      toast(`unknown command: /${cmd}`);
      return true;
  }
}

const BUILT_IN_COMMANDS = [
  { name: 'help',      desc: 'show this list of commands' },
  { name: 'btw',       desc: 'ask a side question without polluting the main thread (alias: /ask)' },
  { name: 'compact',   desc: 'summarize the conversation to free up context (alias: /summarize)' },
  { name: 'init',      desc: 'have the agent inspect the project and produce an initial plan' },
  { name: 'models',    desc: 'pick the model for this session (alias: /model)' },
  { name: 'sessions',  desc: 'switch to another session' },
  { name: 'share',     desc: 'export this session and project as a shareable zip' },
  { name: 'clear',     desc: 'clear messages in this session (project files kept)' },
  { name: 'new',       desc: 'start a new session' },
  { name: 'preview',   desc: 'open the live preview' },
  { name: 'files',     desc: 'open the file browser' },
];

function cmdHelp() {
  const lines = [];
  lines.push('# commands');
  lines.push('');
  for (const c of BUILT_IN_COMMANDS) {
    lines.push(`- \`/${c.name}\` — ${c.desc}`);
  }
  const custom = state.settings.commands || [];
  if (custom.length) {
    lines.push('');
    lines.push('# custom');
    for (const c of custom) {
      lines.push(`- \`/${c.name}\` — ${c.description || '(no description)'}`);
    }
  }
  lines.push('');
  lines.push('# tips');
  lines.push('- type and send while the agent is running to **queue a note** — it gets picked up at the next step without stopping the workflow');
  lines.push('- use `/btw <question>` to ask a quick aside without polluting the main thread');
  appendSystemNote(lines.join('\n'));
  return true;
}

function cmdCompact() {
  if (state.agent?.running) {
    toast('agent is running, stop it first');
    return true;
  }
  // Heuristic compact: trigger an agent turn with a special user message
  // asking it to summarize the conversation, then replace the message log
  // with a single "compacted history" system note + the summary.
  startCompaction();
  return true;
}

async function startCompaction() {
  const sess = state.currentSession;
  if (!sess?.messages?.length) {
    toast('nothing to compact');
    return;
  }
  if (!state.settings.apiKey) {
    toast('add openrouter API key in settings');
    return;
  }
  appendSystemNote('compacting conversation…');

  // Build a prompt for the model to summarize
  const transcript = sess.messages.map(m => {
    const text = (m.parts || [])
      .filter(p => p.type === 'text')
      .map(p => p.text).join('\n');
    return `[${m.role}] ${text}`.trim();
  }).filter(Boolean).join('\n\n');

  const sysPrompt = `You are a conversation summarizer. Produce a tight, factual summary of the conversation below, preserving:
- the user's overall goal
- key decisions made
- important file paths, function names, and code identifiers mentioned
- open questions and outstanding work

Keep it under 30 lines. Use bullet points. Do not add commentary outside the summary.`;

  try {
    const res = await fetch((state.settings.baseUrl || 'https://openrouter.ai/api/v1') + '/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + state.settings.apiKey,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://opencode-web.local',
        'X-Title': 'opencode (web)',
      },
      body: JSON.stringify({
        model: sess.meta.model,
        messages: [
          { role: 'system', content: sysPrompt },
          { role: 'user',   content: transcript },
        ],
        stream: false,
      }),
    });
    if (!res.ok) throw new Error('summarize failed: HTTP ' + res.status);
    const data = await res.json();
    const summary = data?.choices?.[0]?.message?.content?.trim() || '(empty summary)';
    const usage = data?.usage;

    // Replace history with a single condensed note
    const compacted = [{
      id: 'm_' + Date.now().toString(36),
      role: 'assistant',
      parts: [{ type: 'text', text: '## previous conversation summary\n\n' + summary }],
      ts: Date.now(),
      compacted: true,
    }];
    sess.messages = compacted;
    await Sessions.setMessages(sess.meta.id, compacted);
    if (usage) accrueUsage(sess, usage);
    renderMessages();
    toast('conversation compacted');
  } catch (e) {
    appendSystemNote('compact failed: ' + (e?.message || e));
  }
}

function cmdInit() {
  // Inject a prompt that asks the agent to scan the project and produce a plan
  $('#composer-input').value =
    'Inspect every file in the project sandbox (use read on the root, then read key files). ' +
    'Then produce a brief summary of what this project is, the file structure, and what could ' +
    'be improved or built next. Use todowrite to track follow-ups.';
  // fall through — let it send normally
  return false;
}

function cmdModels() { pickModel();   return true; }
function cmdSessions() {
  // back to sessions list
  showScreen('sessions');
  renderSessions();
  return true;
}
async function cmdShare() {
  await exportProjectZip(state.currentSession?.meta?.id, true);
  return true;
}
async function cmdClear() {
  const r = await modal({
    title: 'clear messages?',
    body: 'project files are NOT deleted, only the conversation.',
    actions: [
      { label: 'cancel', kind: 'cancel' },
      { label: 'clear',  kind: 'danger', value: true },
    ],
  });
  if (r) {
    state.currentSession.messages = [];
    state.currentSession.meta.todos = [];
    state.currentSession.usage = null;
    await Sessions.setMessages(state.currentSession.meta.id, []);
    await Sessions.update(state.currentSession.meta.id, { todos: [], usage: null }).catch(() => {});
    renderMessages();
    renderTodoPanel([]);
    updateUsageStrip();
  }
  return true;
}
async function cmdNew() {
  await createSession();
  return true;
}
function cmdPreview() { openPreview(); return true; }
function cmdFiles()   { openFiles();   return true; }

// /btw — side question. Forks the current context, asks one question with
// no tools available, streams the answer into a modal panel. The exchange
// is NEVER appended to the main message log, so the main thread stays clean.
//
// Same idea as a side-channel "by the way" question in many coding agents:
// same context, same model, same system prompt, but tools are stripped from
// the request and the answer doesn't write back.
async function cmdBtw(question) {
  if (!question) {
    toast('usage: /btw <your question>');
    return true;
  }
  const sess = state.currentSession;
  if (!sess) { toast('no session'); return true; }
  if (!state.settings.apiKey) { toast('add openrouter API key in settings'); return true; }
  if (!sess.meta.model)       { toast('pick a model first'); return true; }

  // Build the side-question modal up-front so the user sees the streaming.
  const body = el('div', { class: 'btw-modal' });
  const qEl = el('div', { class: 'btw-question' });
  qEl.appendChild(el('div', { class: 'btw-q-label', text: 'side question' }));
  qEl.appendChild(el('div', { class: 'btw-q-text',  text: question }));
  body.appendChild(qEl);

  const ansEl = el('div', { class: 'btw-answer' });
  ansEl.appendChild(el('div', { class: 'btw-a-label', text: 'answer' }));
  const ansBody = el('div', { class: 'btw-a-text', text: 'thinking…' });
  ansEl.appendChild(ansBody);
  body.appendChild(ansEl);

  const modalPromise = modal({
    title: 'btw',
    body,
    dismissable: true,
    actions: [
      { label: 'close', kind: 'cancel', value: true },
    ],
  });

  // Build the fork: same system prompt + same conversation as the main
  // thread, plus the question wrapped in a system-reminder so the model
  // knows it's an aside.
  const sysPrompt = await buildSystemPrompt({
    sessionId: sess.meta.id,
    mode:      sess.meta.mode,
    custom:    state.settings.systemPrompt,
  });

  const oaiMessages = [{ role: 'system', content: sysPrompt }];
  for (const m of sess.messages) {
    if (m.role === 'user') {
      const text = (m.parts || []).filter(p => p.type === 'text').map(p => p.text).join('\n');
      if (text.trim()) oaiMessages.push({ role: 'user', content: text });
    } else if (m.role === 'assistant') {
      const text = (m.parts || []).filter(p => p.type === 'text').map(p => p.text).join('');
      if (text.trim()) oaiMessages.push({ role: 'assistant', content: text });
    }
  }
  const sideReminder =
    `<system-reminder>This is a side question. The user is asking for a quick clarification — answer directly and concisely. Do NOT modify any files, do NOT use tools, and do NOT continue the previous task. Your answer will not be saved to the main conversation.</system-reminder>\n\n` +
    question;
  oaiMessages.push({ role: 'user', content: sideReminder });

  // Stream the response
  ansBody.textContent = '';
  let cancelled = false;
  modalPromise.finally(() => { cancelled = true; });

  try {
    const url = (state.settings.baseUrl || 'https://openrouter.ai/api/v1').replace(/\/+$/, '') + '/chat/completions';
    const r = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + state.settings.apiKey,
        'Content-Type':  'application/json',
        'HTTP-Referer':  'https://opencode-web.local',
        'X-Title':       'opencode (web)',
      },
      body: JSON.stringify({
        model: sess.meta.model,
        messages: oaiMessages,
        // Note: no `tools` field — side questions never invoke tools.
        stream: true,
        usage: { include: true },
      }),
    });
    if (!r.ok) {
      const txt = await r.text().catch(() => '');
      ansBody.textContent = `error: HTTP ${r.status} ${txt.slice(0, 200)}`;
      return true;
    }
    const reader = r.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';
    let answer = '';
    let usage = null;

    while (!cancelled) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let idx;
      while ((idx = buffer.indexOf('\n\n')) !== -1) {
        const event = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 2);
        for (const rawLine of event.split('\n')) {
          const line = rawLine.trim();
          if (!line || !line.startsWith('data:')) continue;
          const payload = line.slice(5).trim();
          if (payload === '[DONE]') continue;
          let ev; try { ev = JSON.parse(payload); } catch { continue; }
          if (ev.usage) usage = ev.usage;
          const delta = ev.choices?.[0]?.delta?.content;
          if (typeof delta === 'string') {
            answer += delta;
            ansBody.innerHTML = renderMarkdown(answer);
          }
        }
      }
    }
    if (usage) {
      // Track the side-question cost too — small bar at the bottom of the answer.
      const u = el('div', { class: 'btw-usage', text:
        `↑${fmtTokens(usage.prompt_tokens || 0)} ↓${fmtTokens(usage.completion_tokens || 0)} (not counted in main thread)` });
      ansEl.appendChild(u);
    }
  } catch (e) {
    ansBody.textContent = 'error: ' + (e?.message || e);
  }
  return true;
}

// Append a small system-style note to the chat (not a real LLM message).
function appendSystemNote(markdown) {
  const sess = state.currentSession;
  if (!sess) return;
  sess.messages.push({
    id: 'm_' + Date.now().toString(36),
    role: 'system',
    parts: [{ type: 'text', text: markdown }],
    ts: Date.now(),
  });
  Sessions.setMessages(sess.meta.id, sess.messages);
  renderMessages();
}

// --------------------------------------------------- usage tracking
//
// Aggregate per-session token usage. Each turn returns prompt_tokens (input
// the model received this turn) and completion_tokens (it generated). We
// keep both running totals AND the last-turn input tokens, because the
// last input count is the best estimate of "current context window fill".

function accrueUsage(sess, usage) {
  if (!sess) return;
  const prompt = Number(usage.prompt_tokens ?? usage.input_tokens ?? 0) || 0;
  const compl  = Number(usage.completion_tokens ?? usage.output_tokens ?? 0) || 0;
  if (!sess.usage) sess.usage = { in: 0, out: 0, lastIn: 0, turns: 0 };
  sess.usage.in   += prompt;
  sess.usage.out  += compl;
  sess.usage.lastIn = prompt;
  sess.usage.turns += 1;
  // Persist
  Sessions.update(sess.meta.id, { usage: sess.usage }).catch(() => {});
}

// Rough context window for the current model. We don't have a registry, so
// we look up by suffix match on the model id. Sensible defaults for the
// seeded models; users can override via settings.modelLimits.
const MODEL_CONTEXT_WINDOWS = {
  // Anthropic
  'claude-sonnet-4.5':  200_000,
  'claude-opus-4.1':    200_000,
  'claude-3-5-sonnet':  200_000,
  // OpenAI
  'gpt-5':              400_000,
  'gpt-4o':             128_000,
  'gpt-4-turbo':        128_000,
  // Google
  'gemini-2.5-pro':   1_000_000,
  'gemini-1.5-pro':   2_000_000,
  // DeepSeek / Qwen
  'deepseek-chat-v3.1': 128_000,
  'qwen3-coder':        256_000,
};

function contextWindowFor(modelId) {
  if (!modelId) return 128_000;
  const id = modelId.toLowerCase();
  // exact-ish match
  for (const k of Object.keys(MODEL_CONTEXT_WINDOWS)) {
    if (id.includes(k)) return MODEL_CONTEXT_WINDOWS[k];
  }
  return 128_000;
}

function fmtTokens(n) {
  if (!Number.isFinite(n) || n <= 0) return '0';
  if (n < 1_000)     return String(n);
  if (n < 1_000_000) return (n / 1_000).toFixed(n < 10_000 ? 1 : 0) + 'k';
  return (n / 1_000_000).toFixed(2) + 'M';
}

function updateUsageStrip() {
  const strip = $('#usage-strip');
  if (!strip) return;
  const sess = state.currentSession;
  const u = sess?.usage;
  if (!sess || !u || !u.turns) {
    strip.hidden = true;
    return;
  }
  strip.hidden = false;
  const ctx = contextWindowFor(sess.meta.model);
  const fill = Math.min(1, u.lastIn / ctx);
  $('#usage-bar-fill').style.width = (fill * 100).toFixed(1) + '%';
  // Mark color tier
  $('#usage-bar-fill').dataset.tier =
    fill < 0.5 ? 'low' : fill < 0.8 ? 'mid' : 'high';
  $('#usage-text').textContent =
    `${fmtTokens(u.lastIn)} / ${fmtTokens(ctx)} ctx · ` +
    `↑${fmtTokens(u.in)} ↓${fmtTokens(u.out)} · ` +
    `${u.turns} turn${u.turns === 1 ? '' : 's'}`;
}

// Visible indicator that mid-run user notes are queued and waiting to be
// picked up by the agent at the next loop boundary. Read straight from the
// agent's internal queue so it's always in sync.
function updateInjectIndicator(_count) {
  const chip = $('#chip-queued');
  if (!chip) return;
  const n = state.agent?.injectQueue?.length ?? 0;
  if (n > 0) {
    chip.hidden = false;
    $('#chip-queued-text').textContent = `${n} queued`;
  } else {
    chip.hidden = true;
  }
}


// --------------------------------------------------- send

async function onSend() {
  const ta = $('#composer-input');
  const text = ta.value.trim();
  if (!text) return;

  // Slash commands — intercept before sending to the LLM. handleSlashCommand
  // returns true if it consumed the input, false to fall through (e.g. the
  // command rewrote the text and wants it sent as a normal user message).
  if (text.startsWith('/')) {
    const handled = await handleSlashCommand(text);
    if (handled) {
      ta.value = '';
      autosize(ta);
      return;
    }
    // If a command rewrote the textarea (e.g. /init), pick that up.
    const refreshed = ta.value.trim();
    if (refreshed && refreshed !== text) {
      // Re-enter onSend with the new text (avoiding infinite loop because
      // refreshed won't start with / again).
      return onSend();
    }
  }

  if (!state.settings.apiKey) {
    toast('add openrouter API key in settings');
    return;
  }
  if (!state.currentSession.meta.model) {
    toast('pick a model first');
    return;
  }

  // Mid-run inject: if the agent is running, queue this message as an
  // aside instead of starting a new agent. The agent picks it up at the
  // next loop boundary as a synthetic user message wrapped in <user-note>.
  if (state.agent?.running) {
    state.agent.injectUserMessage(text);
    ta.value = '';
    autosize(ta);
    toast('queued — will be picked up at next step');
    updateInjectIndicator();
    return;
  }

  const sess = state.currentSession;
  const userMsg = {
    id: 'm_' + Date.now().toString(36),
    role: 'user',
    parts: [{ type: 'text', text }],
    ts: Date.now(),
  };
  sess.messages.push(userMsg);
  ta.value = '';
  autosize(ta);
  await Sessions.setMessages(sess.meta.id, sess.messages);

  // First user message — derive title from it if title is generic
  if (sess.messages.filter(m => m.role === 'user').length === 1
      && (sess.meta.title === 'untitled' || /^session/.test(sess.meta.title))) {
    const newTitle = text.slice(0, 60).split('\n')[0];
    await Sessions.update(sess.meta.id, { title: newTitle });
    sess.meta.title = newTitle;
    $('#chat-title').textContent = newTitle;
  }

  renderMessages();

  // Build agent
  const sysPrompt = await buildSystemPrompt({
    sessionId: sess.meta.id,
    mode:      sess.meta.mode,
    custom:    state.settings.systemPrompt,
  });

  state.agent = new Agent({
    apiKey:       state.settings.apiKey,
    baseUrl:      state.settings.baseUrl,
    modelId:      sess.meta.model,
    systemPrompt: sysPrompt,
    mode:         sess.meta.mode,
    maxSteps:     state.settings.maxSteps || 40,
    sessionId:    sess.meta.id,
    messages:     sess.messages,
    initialTodos: sess.meta.todos || [],
    handlers: {
      onUpdate: () => renderMessages(),
      onUsage:  (usage) => {
        accrueUsage(sess, usage);
        updateUsageStrip();
      },
      onTodos:  (todos) => {
        // Persist on the session so the panel survives reload
        sess.meta.todos = todos;
        Sessions.update(sess.meta.id, { todos }).catch(() => {});
        renderTodoPanel(todos);
      },
      onInjectQueued:  (count) => updateInjectIndicator(count),
      onInjectFlushed: ()      => updateInjectIndicator(0),
      onError:  (e) => {
        console.error(e);
        toast('error: ' + (e?.message || e), 4000);
        // append a system note
        sess.messages.push({
          id: 'm_' + Date.now().toString(36),
          role: 'assistant',
          parts: [{ type: 'text', text: '⚠ ' + (e?.message || String(e)) }],
          ts: Date.now(),
        });
        renderMessages();
      },
      onDone: () => {
        const finalPlan = state.agent?.planExitFinal;
        state.agent = null;
        updateChatChips();
        if (finalPlan) {
          modal({
            title: 'plan ready',
            body: 'switch to build mode and execute this plan?',
            actions: [
              { label: 'stay in plan', kind: 'cancel', value: false },
              { label: 'switch to build', kind: 'primary', value: true },
            ],
          }).then(yes => {
            if (yes && state.currentSession) {
              state.currentSession.meta.mode = 'build';
              Sessions.update(state.currentSession.meta.id, { mode: 'build' });
              updateChatChips();
              toast('switched to build mode');
            }
          });
        }
      },
      onAskUser: async ({ question, resolve }) => {
        const body = el('div');
        body.appendChild(el('div', { class: 'q-text', text: question }));
        const ta = el('textarea', {
          class: 'q-input',
          placeholder: 'your answer',
          rows: '3',
        });
        body.appendChild(ta);
        setTimeout(() => ta.focus(), 50);
        const answer = await modal({
          title: 'agent question',
          body,
          dismissable: false,
          actions: [
            { label: 'skip', kind: 'cancel', value: null },
            { label: 'reply', kind: 'primary', onClick: () => ta.value.trim() },
          ],
        });
        resolve(answer || '(user skipped)');
      },
    },
  });

  updateChatChips();
  state.agent.run();
}

function renderMessages() {
  const sess = state.currentSession;
  if (!sess) return;
  const root = $('#messages');
  const sc   = $('#messages-scroll');

  // Capture scroll state before rebuilding the DOM so we can preserve
  // the user's reading position. Without this, every streaming update
  // would either jump to the new bottom or jump to the top.
  const wasAtBottom    = sc ? isUserNearBottom() : true;
  const prevScrollTop  = sc ? sc.scrollTop : 0;

  root.innerHTML = '';

  // Empty-session welcome banner. Visible only before the user sends their
  // first prompt — `sess.messages.length === 0`. Once a message exists, the
  // loop below renders messages and this banner is naturally absent.
  if (sess.messages.length === 0) {
    const hero = el('div', { class: 'chat-empty-hero' });
    hero.appendChild(logoWordmark());
    hero.appendChild(el('div', { class: 'chat-empty-tag', text: 'a coding agent for your phone' }));
    hero.appendChild(el('div', { class: 'chat-empty-hint', text: 'describe what you want to build' }));
    root.appendChild(hero);
    // No messages to iterate; restore scroll and return.
    if (sc) sc.scrollTop = wasAtBottom ? sc.scrollHeight : prevScrollTop;
    return;
  }

  for (let i = 0; i < sess.messages.length; i++) {
    const m = sess.messages[i];
    const cls = 'msg' + (m.injected ? ' injected' : '');
    const wrap = el('div', { class: cls });
    const role = el('div', { class: 'msg-role ' + m.role });
    role.appendChild(el('span', { class: 'role-dot' }));
    role.appendChild(document.createTextNode(m.role));
    wrap.appendChild(role);

    if (m.role === 'user') {
      const text = (m.parts || []).filter(p => p.type === 'text').map(p => p.text).join('\n');
      const body = el('div', { class: 'msg-body user-text' });
      body.textContent = text;
      wrap.appendChild(body);
    } else {
      // Decide collapse state for assistant turns:
      // Decide collapse state for assistant turns. We default to EXPANDED
      // for every turn — matching opencode CLI behavior where each step's
      // text and tool details are visible in real time. The user can still
      // tap the role label to collapse any turn manually (we track the
      // explicit choice on the message object).
      const collapsed = !!m.userCollapsed;
      if (collapsed) wrap.classList.add('collapsed');

      // Make the role label tap-target for toggling
      role.classList.add('toggle');
      const chev = el('span', { class: 'toggle-chev' });
      chev.innerHTML = '<svg viewBox="0 0 24 24" width="12" height="12"><path fill="currentColor" d="M7 10l5 5 5-5z"/></svg>';
      role.insertBefore(chev, role.firstChild);
      role.onclick = () => {
        m.userCollapsed = !m.userCollapsed;
        renderMessages();
      };

      // Body wrapper enables the fade overlay when collapsed
      const bodyWrap = el('div', { class: 'msg-content' });

      if (collapsed) {
        // Build a compact preview: concatenate text parts, fall back to a
        // tool-call summary if the message has no text yet (e.g. it's mid-
        // tool-call sequence). This way the user always sees *something*
        // meaningful when peeking at a collapsed bubble.
        const textPieces = (m.parts || [])
          .filter(p => p.type === 'text' && p.text)
          .map(p => p.text);
        const reasoningPieces = (m.parts || [])
          .filter(p => p.type === 'reasoning' && p.text?.trim())
          .map(p => p.text);
        const toolPieces = (m.parts || [])
          .filter(p => p.type === 'tool_call')
          .map(p => {
            const sum = summarizeArgs(p.name, p.args);
            return sum ? `${p.name}(${sum.slice(0, 40)}${sum.length > 40 ? '…' : ''})` : p.name;
          });

        let previewText = textPieces.join(' ').trim();
        if (!previewText && reasoningPieces.length) {
          // Reasoning-only turn — show a hint with the reasoning
          previewText = '💭 ' + reasoningPieces.join(' ').trim();
        }
        if (!previewText && toolPieces.length) {
          // Pure tool-call turn — show what tools ran
          previewText = '⚡ ' + toolPieces.slice(0, 3).join(' · ');
          if (toolPieces.length > 3) previewText += ` · +${toolPieces.length - 3} more`;
        }
        // Cap preview to a reasonable length so it always fits the 2-line box
        const PREVIEW_MAX = 220;
        if (previewText.length > PREVIEW_MAX) {
          previewText = previewText.slice(0, PREVIEW_MAX).trimEnd() + '…';
        }

        const body = el('div', { class: 'msg-body msg-preview' });
        body.textContent = previewText || '(empty)';
        bodyWrap.appendChild(body);

        // Footer hint: number of tool calls / reasoning blocks below preview
        const pieces = [];
        if (toolPieces.length)      pieces.push(`${toolPieces.length} tool call${toolPieces.length === 1 ? '' : 's'}`);
        if (reasoningPieces.length) pieces.push(`${reasoningPieces.length} reasoning`);
        if (pieces.length) {
          bodyWrap.appendChild(el('div', { class: 'msg-collapsed-meta', text: pieces.join(' · ') }));
        }
      } else {
        // Expanded: render parts in order
        for (const p of (m.parts || [])) {
          if (p.type === 'text') {
            const body = el('div', { class: 'msg-body' });
            body.innerHTML = renderMarkdown(p.text);
            // streaming cursor if running
            if (state.agent?.running && m === sess.messages[sess.messages.length - 1]) {
              body.appendChild(el('span', { class: 'stream-cursor' }));
            }
            bodyWrap.appendChild(body);
          } else if (p.type === 'reasoning') {
            if (p.text.trim()) {
              const r = el('div', { class: 'thinking', text: p.text });
              bodyWrap.appendChild(r);
            }
          } else if (p.type === 'tool_call') {
            bodyWrap.appendChild(renderToolCall(p));
          }
        }
      }

      wrap.appendChild(bodyWrap);
    }

    root.appendChild(wrap);
  }

  // Restore scroll: if user was at bottom, keep them there. Otherwise
  // preserve their previous scrollTop so streaming content doesn't yank
  // them away from what they were reading. Since our renderer appends
  // turns at the bottom (existing content above is unchanged), just
  // restoring the same scrollTop keeps the same text visible.
  if (sc) {
    if (wasAtBottom) {
      sc.scrollTop = sc.scrollHeight;
    } else {
      sc.scrollTop = prevScrollTop;
    }
  }
}

function renderToolCall(tc) {
  const card = el('div', { class: 'tool' + (tc.expanded ? ' expanded' : '') });

  // Build a one-line argument summary
  const arg = summarizeArgs(tc.name, tc.args);

  const header = el('div', { class: 'tool-header' });
  header.appendChild(el('span', { html: '<svg class="tool-chevron" viewBox="0 0 24 24"><path fill="currentColor" d="M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>' }));
  header.appendChild(el('span', { class: 'tool-name', text: tc.name || '?' }));
  header.appendChild(el('span', { class: 'tool-arg', text: arg }));
  const status = tc.status || 'pending';
  const statusEl = el('span', { class: 'tool-status ' + status, text: status });
  header.appendChild(statusEl);
  header.onclick = () => {
    tc.expanded = !tc.expanded;
    card.classList.toggle('expanded');
  };
  card.appendChild(header);

  const body = el('div', { class: 'tool-body' });

  // Args
  if (tc.args && Object.keys(tc.args).length > 0) {
    body.appendChild(el('div', { class: 'tool-section' }, [
      el('div', { class: 'tool-section-label', text: 'args' }),
      el('pre', { text: prettyArgs(tc.name, tc.args) }),
    ]));
  }

  // Render specialized output
  if (tc.name === 'todowrite' && tc.args?.todos) {
    body.appendChild(renderTodos(tc.args.todos));
  } else if ((tc.name === 'write' || tc.name === 'edit') && tc.diff) {
    body.appendChild(el('div', { class: 'tool-section' }, [
      el('div', { class: 'tool-section-label', text: 'diff' }),
      renderDiff(tc.diff),
    ]));
  } else if (tc.output) {
    body.appendChild(el('div', { class: 'tool-section' }, [
      el('div', { class: 'tool-section-label', text: tc.status === 'error' ? 'error' : 'output' }),
      el('pre', { text: String(tc.output).slice(0, 8000) }),
    ]));
  } else if (tc.status === 'running') {
    body.appendChild(el('div', { class: 'muted', text: 'running…' }));
  }

  card.appendChild(body);
  return card;
}

function summarizeArgs(name, args) {
  if (!args) return '';
  if (args.__parseError) return '(parsing args…)';
  switch (name) {
    case 'read':       return args.filePath || '';
    case 'write':      return `${args.filePath || ''} (${(args.content || '').length}b)`;
    case 'edit':       return args.filePath || '';
    case 'glob':       return args.pattern || '';
    case 'grep':       return `/${args.pattern || ''}/${args.include ? ' in ' + args.include : ''}`;
    case 'bash':       return args.command || '';
    case 'webfetch':   return args.url || '';
    case 'websearch':  return args.query || '';
    case 'wikiimage':  return args.query || '';
    case 'todowrite':  return `${(args.todos || []).length} items`;
    case 'task':       return args.description || (args.prompt || '').slice(0, 40);
    case 'question':   return (args.question || '').slice(0, 60);
    case 'plan_exit':  return 'finalize plan';
    default:           return '';
  }
}

function prettyArgs(name, args) {
  // For write/edit, don't dump full content into the args section — too long
  if (name === 'write') {
    const a = { ...args };
    if (a.content && a.content.length > 200) a.content = a.content.slice(0, 200) + ` … [${a.content.length} bytes]`;
    return JSON.stringify(a, null, 2);
  }
  if (name === 'edit') {
    const a = { ...args };
    if (a.oldString && a.oldString.length > 200) a.oldString = a.oldString.slice(0, 200) + ` … [${a.oldString.length}b]`;
    if (a.newString && a.newString.length > 200) a.newString = a.newString.slice(0, 200) + ` … [${a.newString.length}b]`;
    return JSON.stringify(a, null, 2);
  }
  return JSON.stringify(args, null, 2);
}

function renderDiff(diff) {
  const pre = el('pre');
  for (const line of String(diff).split('\n')) {
    let cls = 'diff-line ctx';
    if (line.startsWith('+ ') || line.startsWith('+')) cls = 'diff-line add';
    else if (line.startsWith('- ')) cls = 'diff-line del';
    pre.appendChild(el('span', { class: cls, text: line + '\n' }));
  }
  return pre;
}

function renderTodos(todos) {
  const ul = el('ul', { class: 'todos' });
  for (const t of todos) {
    const li = el('li', { class: t.status });
    li.appendChild(el('span', { class: 'check', text: t.status === 'done' ? '✓' : (t.status === 'in_progress' ? '◐' : '·') }));
    li.appendChild(el('span', { class: 'text', text: t.text }));
    ul.appendChild(li);
  }
  return ul;
}

// Render the persistent todo panel that sits above the messages list.
// Mirrors what opencode shows on desktop — a checklist that stays visible
// as the agent works, with items ticking off in real time.
function renderTodoPanel(todos) {
  const panel = $('#todo-panel');
  const list  = $('#todo-panel-list');
  const count = $('#todo-panel-count');
  if (!panel || !list || !count) return;

  if (!Array.isArray(todos) || todos.length === 0) {
    panel.hidden = true;
    list.innerHTML = '';
    return;
  }

  panel.hidden = false;
  list.innerHTML = '';

  let done = 0, inProg = 0;
  for (const t of todos) {
    if (t.status === 'done') done++;
    if (t.status === 'in_progress') inProg++;
    const li = el('li', { class: t.status });
    const check = t.status === 'done'         ? '✓'
                : t.status === 'in_progress'  ? '◐'
                : t.status === 'cancelled'    ? '✕'
                : '·';
    li.appendChild(el('span', { class: 'check', text: check }));
    li.appendChild(el('span', { class: 'text',  text: t.text }));
    list.appendChild(li);
  }
  count.textContent = `${done}/${todos.length}` + (inProg ? ` · ${inProg} active` : '');

  // Honor session-level collapsed preference
  const sess = state.currentSession;
  panel.classList.toggle('collapsed', !!sess?.meta?.todosCollapsed);
}

// Auto-scroll only when the user is already near the bottom of the
// messages list. If they've scrolled up to read earlier output, leave
// their scroll position alone — we don't want to fight the user.
//
// "Near the bottom" = within ~120px of the scrollable extent. That's
// roughly one short message worth of slack. The threshold is generous
// because mobile users naturally hover near the bottom.
const SCROLL_FOLLOW_THRESHOLD = 120;

function isUserNearBottom() {
  const sc = $('#messages-scroll');
  if (!sc) return true;
  const distance = sc.scrollHeight - sc.scrollTop - sc.clientHeight;
  return distance <= SCROLL_FOLLOW_THRESHOLD;
}

function scrollMessagesToBottom(opts = {}) {
  const sc = $('#messages-scroll');
  if (!sc) return;
  // `force: true` ignores user's current scroll position. Used when the
  // user just sent a message — they expect to see their own input.
  // Otherwise only scroll if they're already anchored to the bottom.
  if (!opts.force && !isUserNearBottom()) return;
  sc.scrollTop = sc.scrollHeight;
}

// --------------------------------------------------- files screen

function bindFilesScreen() {
  $('#btn-back-files').onclick = () => history.back();
  $('#btn-file-add').onclick   = () => addFileFlow();
  $('#btn-file-export').onclick = () => exportProjectZip(state.currentSession?.meta?.id);
  $('#btn-file-preview').onclick = () => openPreview();
}

async function openFiles(path = '') {
  state.filesPath = path;
  await renderFiles();
  showScreen('files');
}

async function renderFiles() {
  const sid = state.currentSession?.meta?.id;
  if (!sid) return;
  const list = await VFS.list(sid, state.filesPath);
  list.sort((a, b) => {
    if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  $('#files-breadcrumb').textContent = '/' + state.filesPath;
  const root = $('#files-list');
  root.innerHTML = '';

  // .. parent
  if (state.filesPath) {
    const up = el('div', { class: 'file-row' });
    up.appendChild(el('div', { class: 'file-icon dir', html: '<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="m12 8-6 6h12z"/></svg>' }));
    up.appendChild(el('div', { class: 'file-name', text: '..' }));
    up.onclick = () => {
      const parts = state.filesPath.split('/').filter(Boolean);
      parts.pop();
      openFiles(parts.join('/'));
    };
    root.appendChild(up);
  }

  if (list.length === 0 && !state.filesPath) {
    root.appendChild(el('div', { class: 'empty-state' }, [
      el('div', { text: 'no files yet' }),
      el('div', { class: 'empty-hint', text: 'the agent will create files here, or tap + to upload one' }),
    ]));
    return;
  }

  for (const it of list) {
    const row = el('div', { class: 'file-row' });
    row.appendChild(el('div', { class: 'file-icon ' + (it.isDir ? 'dir' : '') }, [
      el('span', { html: it.isDir
          ? '<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>'
          : '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm4 18H6V4h7v5h5v11z"/></svg>',
      }),
    ]));
    row.appendChild(el('div', { class: 'file-name', text: it.name + (it.isDir ? '/' : '') }));
    if (!it.isDir) row.appendChild(el('div', { class: 'file-size', text: humanSize(it.size) }));
    row.onclick = () => {
      if (it.isDir) {
        const next = state.filesPath ? state.filesPath + '/' + it.name : it.name;
        openFiles(next);
      } else {
        openFileViewer(state.filesPath ? state.filesPath + '/' + it.name : it.name);
      }
    };
    // long-press for actions
    let lp;
    row.addEventListener('touchstart', () => {
      lp = setTimeout(() => fileActions(it, state.filesPath), 500);
    }, { passive: true });
    row.addEventListener('touchend', () => clearTimeout(lp));
    row.addEventListener('touchmove', () => clearTimeout(lp));
    root.appendChild(row);
  }
}

function humanSize(n) {
  if (n < 1024) return n + 'b';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + 'k';
  return (n / 1024 / 1024).toFixed(1) + 'm';
}

async function addFileFlow() {
  openSheet({
    title: 'add file',
    items: [
      { label: 'create new text file', action: 'new' },
      { label: 'upload file from device', action: 'upload' },
      { label: 'create new folder', action: 'mkdir' },
    ],
    onPick: async ({ action }) => {
      const sid = state.currentSession.meta.id;
      if (action === 'new') {
        const nameI = el('input', { type: 'text', placeholder: 'filename, e.g. index.html' });
        const body  = el('textarea', { rows: '8', placeholder: 'content (optional)' });
        const wrap = el('div');
        wrap.appendChild(el('label', { text: 'filename' }));
        wrap.appendChild(nameI);
        wrap.appendChild(el('label', { text: 'content' }));
        wrap.appendChild(body);
        const r = await modal({
          title: 'new file',
          body: wrap,
          actions: [
            { label: 'cancel', kind: 'cancel' },
            { label: 'create', kind: 'primary', onClick: () => ({ name: nameI.value.trim(), content: body.value }) },
          ],
        });
        if (r && r.name) {
          const target = state.filesPath ? state.filesPath + '/' + r.name : r.name;
          await VFS.write(sid, target, r.content);
          await renderFiles();
          toast('created');
        }
      } else if (action === 'upload') {
        await uploadFiles();
      } else if (action === 'mkdir') {
        const inp = el('input', { type: 'text', placeholder: 'folder name' });
        const r = await modal({
          title: 'new folder',
          body: inp,
          actions: [
            { label: 'cancel', kind: 'cancel' },
            { label: 'create', kind: 'primary', onClick: () => inp.value.trim() },
          ],
        });
        if (r) {
          // create a placeholder so the folder exists
          const target = (state.filesPath ? state.filesPath + '/' : '') + r;
          await VFS.mkdir(sid, target);
          await renderFiles();
        }
      }
    },
  });
}

function uploadFiles() {
  return new Promise(resolve => {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.multiple = true;
    inp.style.display = 'none';
    inp.onchange = async () => {
      const files = Array.from(inp.files || []);
      const sid = state.currentSession.meta.id;
      let count = 0;
      for (const f of files) {
        try {
          const text = await f.text();
          const target = state.filesPath ? state.filesPath + '/' + f.name : f.name;
          await VFS.write(sid, target, text);
          count++;
        } catch (e) {
          console.warn('upload', f.name, e);
        }
      }
      document.body.removeChild(inp);
      await renderFiles();
      toast(`uploaded ${count} file${count === 1 ? '' : 's'}`);
      resolve();
    };
    document.body.appendChild(inp);
    inp.click();
  });
}

async function fileActions(item, parent) {
  const sid = state.currentSession.meta.id;
  const fullPath = parent ? parent + '/' + item.name : item.name;
  openSheet({
    title: item.name,
    items: [
      !item.isDir && { label: 'view',     action: 'view' },
      !item.isDir && { label: 'download', action: 'download' },
      !item.isDir && { label: 'share',    action: 'share' },
                    { label: 'rename',   action: 'rename' },
                    { label: 'delete',   action: 'delete', danger: true },
    ].filter(Boolean),
    onPick: async ({ action }) => {
      if (action === 'view') openFileViewer(fullPath);
      else if (action === 'download') downloadFile(sid, fullPath, false);
      else if (action === 'share')    downloadFile(sid, fullPath, true);
      else if (action === 'rename') {
        const inp = el('input', { type: 'text', value: item.name });
        const r = await modal({
          title: 'rename',
          body: inp,
          actions: [
            { label: 'cancel', kind: 'cancel' },
            { label: 'save', kind: 'primary', onClick: () => inp.value.trim() },
          ],
        });
        if (r && r !== item.name) {
          const newPath = parent ? parent + '/' + r : r;
          if (item.isDir) {
            // copy all files under, then delete
            const files = await VFS.walk(sid, fullPath);
            for (const f of files) {
              const rel = f.path.slice(fullPath.length + 1);
              const c = await VFS.read(sid, f.path);
              if (c != null) await VFS.write(sid, newPath + '/' + rel, c);
            }
          } else {
            const c = await VFS.read(sid, fullPath);
            if (c != null) await VFS.write(sid, newPath, c);
          }
          await VFS.delete(sid, fullPath);
          await renderFiles();
        }
      } else if (action === 'delete') {
        const r = await modal({
          title: 'delete?',
          body: item.isDir ? `delete folder ${item.name} and everything in it?` : `delete ${item.name}?`,
          actions: [
            { label: 'cancel', kind: 'cancel' },
            { label: 'delete', kind: 'danger', value: true },
          ],
        });
        if (r) {
          await VFS.delete(sid, fullPath);
          await renderFiles();
        }
      }
    },
  });
}

// --------------------------------------------------- file viewer

let viewerCurrentPath = null;

function bindFileViewScreen() {
  $('#btn-back-fileview').onclick = () => history.back();
  $('#btn-file-download').onclick = () => downloadFile(state.currentSession.meta.id, viewerCurrentPath);
  $('#btn-file-delete').onclick   = async () => {
    const r = await modal({
      title: 'delete file?',
      body: viewerCurrentPath,
      actions: [
        { label: 'cancel', kind: 'cancel' },
        { label: 'delete', kind: 'danger', value: true },
      ],
    });
    if (r) {
      await VFS.delete(state.currentSession.meta.id, viewerCurrentPath);
      toast('deleted');
      await renderFiles();
      showScreen('files');
    }
  };
}

async function openFileViewer(path) {
  viewerCurrentPath = path;
  const sid = state.currentSession.meta.id;
  const c = await VFS.read(sid, path);
  $('#fileview-name').textContent = path;
  const pre = $('#fileview-pre');
  pre.textContent = c != null ? c : '(unreadable)';
  $('#fileview-scroll').scrollTop = 0;
  showScreen('file-view');
}

// --------------------------------------------------- export / download

// Copy plain text to the system clipboard. Tries the modern async
// Clipboard API first, falls back to the legacy execCommand path which
// works in older WebView builds and inside iframes where the Clipboard
// API may be unavailable due to permission restrictions.
async function copyToClipboard(text) {
  // Modern API: requires user gesture + secure context. On localhost
  // (CouchFlow) and https sites this works without prompting.
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (_) {
    // Fall through to legacy path
  }
  // Legacy: detached textarea + execCommand('copy'). Battle-tested across
  // Android WebView versions back to 5.0.
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    ta.style.pointerEvents = 'none';
    ta.setAttribute('readonly', '');
    document.body.appendChild(ta);
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch (e) {
    console.error('copyToClipboard failed', e);
    return false;
  }
}

// Download a Blob as a file.
//
// In CouchFlow:
//   The WebView has no DownloadListener attached, so the standard
//   `<a download>` trick is silent. Instead, we use AndroidFS (or fetch PUT
//   for large blobs) to write into the picked folder under Downloads/. The
//   user finds the file in their file manager — visible and shareable.
//
// In a regular browser:
//   Standard <a download> blob URL works fine.
async function downloadBlob(blob, filename) {
  // CouchFlow path — write to the picked folder under Downloads/
  if (window.CouchFlow) {
    try {
      // Use fetch PUT — the doc says it streams large bodies straight to
      // disk. Works for any size, no base64 round-trip.
      const path = `Downloads/${filename}`;
      const res = await fetch('./' + path, { method: 'PUT', body: blob });
      if (res.ok) {
        toast(`saved to ./Downloads/${filename}`);
        return;
      }
      // Fallback to AndroidFS direct if fetch PUT didn't work
      if (window.AndroidFS) {
        if (typeof blob.arrayBuffer === 'function') {
          const u8 = new Uint8Array(await blob.arrayBuffer());
          if (typeof AndroidFS.writeBytes === 'function') {
            const ok = await AndroidFS.writeBytes(path, u8);
            if (ok) { toast(`saved to ./Downloads/${filename}`); return; }
          }
          // Last-resort: text write (only good for text formats)
          if (typeof blob.text === 'function' && /^(text\/|application\/(json|xml|javascript))/.test(blob.type)) {
            const ok = await AndroidFS.write(path, await blob.text());
            if (ok) { toast(`saved to ./Downloads/${filename}`); return; }
          }
        }
      }
    } catch (e) {
      console.warn('couchflow download failed, falling back to <a download>', e);
    }
  }

  // Browser fallback — standard <a download>
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    try { document.body.removeChild(a); } catch {}
    try { URL.revokeObjectURL(url); } catch {}
  }, 250);
  toast(`saved · ${filename}`);
}

// Explicit share via system share sheet. Use this when the user picks
// "share" rather than "download".
async function shareBlob(blob, filename) {
  try {
    if (navigator.canShare && navigator.share) {
      const file = new File([blob], filename, { type: blob.type || 'application/octet-stream' });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: filename });
        return;
      }
    }
  } catch (e) {
    // user cancelled or share failed — fall through to download
  }
  await downloadBlob(blob, filename);
}

async function downloadFile(sid, path, share = false) {
  const c = await VFS.read(sid, path);
  if (c == null) { toast('not found'); return; }
  const name = path.split('/').pop();
  // guess mime
  const ext = (name.split('.').pop() || '').toLowerCase();
  const mime = ({
    html: 'text/html', htm: 'text/html', css: 'text/css', js: 'application/javascript',
    json: 'application/json', md: 'text/markdown', txt: 'text/plain', svg: 'image/svg+xml',
  })[ext] || 'text/plain';
  const blob = new Blob([c], { type: mime });
  if (share) await shareBlob(blob, name);
  else await downloadBlob(blob, name);
}

async function exportProjectZip(sid, share = false) {
  if (!sid) return;
  const snap = await VFS.snapshot(sid);
  if (Object.keys(snap).length === 0) {
    toast('project is empty');
    return;
  }
  toast('packing zip…');
  try {
    const blob = await makeZip(snap);
    const sess = (await Sessions.list()).find(s => s.id === sid);
    const name = (sess?.title || 'project').replace(/[^a-z0-9-_]+/gi, '-').replace(/^-+|-+$/g, '') || 'project';
    if (share) await shareBlob(blob, `${name}.zip`);
    else await downloadBlob(blob, `${name}.zip`);
  } catch (e) {
    toast('zip failed: ' + e.message);
  }
}

// --------------------------------------------------- minimal ZIP writer (no compression — STORE method)
// Self-contained — produces a valid .zip file with method=0 (stored).

async function makeZip(files) {
  const enc = new TextEncoder();
  const records = [];   // { name, data, crc, offset }
  const chunks  = [];
  let offset = 0;

  for (const [path, content] of Object.entries(files)) {
    const nameBytes = enc.encode(path);
    const data = enc.encode(content);
    const crc = crc32(data);

    // Local file header
    const lfh = new Uint8Array(30 + nameBytes.length);
    const dv = new DataView(lfh.buffer);
    dv.setUint32(0, 0x04034b50, true);             // sig
    dv.setUint16(4, 20, true);                      // version
    dv.setUint16(6, 0, true);                       // flags
    dv.setUint16(8, 0, true);                       // method (store)
    dv.setUint16(10, dosTime(), true);
    dv.setUint16(12, dosDate(), true);
    dv.setUint32(14, crc, true);
    dv.setUint32(18, data.length, true);            // compressed size
    dv.setUint32(22, data.length, true);            // uncompressed size
    dv.setUint16(26, nameBytes.length, true);
    dv.setUint16(28, 0, true);                      // extra
    lfh.set(nameBytes, 30);

    chunks.push(lfh);
    chunks.push(data);
    records.push({ name: nameBytes, size: data.length, crc, offset });
    offset += lfh.length + data.length;
  }

  // Central directory
  const cdStart = offset;
  for (const r of records) {
    const cd = new Uint8Array(46 + r.name.length);
    const dv = new DataView(cd.buffer);
    dv.setUint32(0, 0x02014b50, true);
    dv.setUint16(4, 20, true);                       // version made by
    dv.setUint16(6, 20, true);                       // version needed
    dv.setUint16(8, 0, true);
    dv.setUint16(10, 0, true);
    dv.setUint16(12, dosTime(), true);
    dv.setUint16(14, dosDate(), true);
    dv.setUint32(16, r.crc, true);
    dv.setUint32(20, r.size, true);
    dv.setUint32(24, r.size, true);
    dv.setUint16(28, r.name.length, true);
    dv.setUint16(30, 0, true);                       // extra len
    dv.setUint16(32, 0, true);                       // comment len
    dv.setUint16(34, 0, true);                       // disk
    dv.setUint16(36, 0, true);                       // internal attrs
    dv.setUint32(38, 0, true);                       // external attrs
    dv.setUint32(42, r.offset, true);                // local header offset
    cd.set(r.name, 46);
    chunks.push(cd);
    offset += cd.length;
  }
  const cdSize = offset - cdStart;

  // End of central directory
  const eocd = new Uint8Array(22);
  const dv = new DataView(eocd.buffer);
  dv.setUint32(0, 0x06054b50, true);
  dv.setUint16(4, 0, true);
  dv.setUint16(6, 0, true);
  dv.setUint16(8, records.length, true);
  dv.setUint16(10, records.length, true);
  dv.setUint32(12, cdSize, true);
  dv.setUint32(16, cdStart, true);
  dv.setUint16(20, 0, true);
  chunks.push(eocd);

  return new Blob(chunks, { type: 'application/zip' });
}

function dosTime() {
  const d = new Date();
  return ((d.getHours() & 0x1f) << 11) | ((d.getMinutes() & 0x3f) << 5) | ((d.getSeconds() / 2) & 0x1f);
}
function dosDate() {
  const d = new Date();
  return (((d.getFullYear() - 1980) & 0x7f) << 9) | (((d.getMonth() + 1) & 0x0f) << 5) | (d.getDate() & 0x1f);
}

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

// --------------------------------------------------- preview screen

let previewState = { current: null, listener: null, logs: [] };

function bindPreviewScreen() {
  $('#btn-back-preview').onclick = () => history.back();
  $('#btn-preview-reload').onclick = () => openPreview();
  $('#btn-preview-console').onclick = () => {
    $('#preview-console').classList.toggle('hidden');
    renderConsoleLogs();
  };
  $('#btn-preview-console-clear').onclick = () => {
    previewState.logs = [];
    renderConsoleLogs();
  };
  $('#btn-preview-console-copy').onclick = async () => {
    if (!previewState.logs.length) {
      toast('console is empty');
      return;
    }
    // Format each log line as `[LEVEL] message` joined by newlines —
    // close to how a developer console transcript reads when pasted.
    const text = previewState.logs.map(log => {
      const args = log.args.join(' ');
      return `[${log.level}] ${args}`;
    }).join('\n');
    await copyToClipboard(text);
    toast(`copied ${previewState.logs.length} lines`);
  };

  // Listen for postMessage from the iframe
  if (!previewState.listener) {
    previewState.listener = (e) => {
      const data = e.data;
      if (!data || !data.__opencodeConsole) return;
      previewState.logs.push({ level: data.level, args: data.args, ts: Date.now() });
      if (previewState.logs.length > 500) previewState.logs.shift();
      // Live-render if console is open
      if (!$('#preview-console').classList.contains('hidden')) {
        renderConsoleLogs();
      }
      // Surface errors as a small badge
      if (data.level === 'error') {
        const btn = $('#btn-preview-console');
        if (btn) btn.classList.add('has-errors');
      }
    };
    window.addEventListener('message', previewState.listener);
  }
}

async function openPreview() {
  const sid = state.currentSession?.meta?.id;
  if (!sid) { toast('no session'); return; }

  // Tear down any prior preview
  closePreview();
  previewState.logs = [];
  $('#btn-preview-console').classList.remove('has-errors');
  renderConsoleLogs();

  showScreen('preview');
  $('#preview-title').textContent = 'preview · building…';

  try {
    const built = await buildPreview(sid);
    const frame = $('#preview-frame');
    // Error / empty-project case (no url, no srcdoc)
    if (!built.url && !built.srcdoc) {
      $('#preview-title').textContent = 'preview';
      frame.removeAttribute('srcdoc');
      frame.src = 'about:blank';
      const empty = $('#preview-empty');
      empty.innerHTML = '';
      empty.appendChild(el('div', { text: built.error || 'no entry file' }));
      empty.appendChild(el('div', { class: 'empty-hint', text: 'create an index.html to enable preview' }));
      empty.classList.remove('hidden');
      return;
    }
    $('#preview-empty').classList.add('hidden');
    previewState.current = built;
    $('#preview-title').textContent = 'preview · ' + built.entryPath;
    if (built.url) {
      // Native CouchFlow path: iframe loads via the localhost server. Same
      // origin as us → no navigation crash, fetch() works, modules work.
      frame.removeAttribute('srcdoc');
      frame.src = built.url;
    } else {
      // Browser fallback: srcdoc with rewritten HTML and blob URLs for assets.
      frame.removeAttribute('src');
      frame.srcdoc = built.srcdoc;
    }
  } catch (e) {
    console.error(e);
    toast('preview failed: ' + (e?.message || e));
    $('#preview-title').textContent = 'preview · failed';
  }
}

function closePreview() {
  if (previewState.current?.cleanup) {
    try {
      const r = previewState.current.cleanup();
      if (r && typeof r.catch === 'function') r.catch(() => {});
    } catch {}
  }
  previewState.current = null;
  const f = $('#preview-frame');
  if (f) {
    f.removeAttribute('srcdoc');
    f.src = 'about:blank';
  }
}

function renderConsoleLogs() {
  const body = $('#preview-console-body');
  if (!body) return;
  body.innerHTML = '';
  if (previewState.logs.length === 0) {
    body.appendChild(el('div', { class: 'console-empty', text: '(no output)' }));
    return;
  }
  for (const log of previewState.logs) {
    const line = el('div', { class: 'console-line console-' + log.level });
    line.appendChild(el('span', { class: 'console-level', text: log.level }));
    line.appendChild(el('span', { class: 'console-msg', text: log.args.join(' ') }));
    body.appendChild(line);
  }
  body.scrollTop = body.scrollHeight;
}


function bindSettingsScreen() {
  $('#btn-back-settings').onclick = async () => {
    await saveSettingsFromUI();
    if (state.currentSession) {
      updateChatChips();
    } else {
      await renderSessions();
    }
    history.back();
  };

  $('#btn-add-model').onclick = () => addModelFlow();

  $('#btn-reset-prompt').onclick = () => {
    $('#setting-system-prompt').value = '';
    toast('reset to default');
  };

  $('#btn-export-all').onclick = () => exportEverything();
  $('#btn-clear-all').onclick  = () => clearEverythingFlow();

  $('#link-or-keys').addEventListener('click', e => {
    if (window.Android?.openExternalUrl) {
      e.preventDefault();
      try { Android.openExternalUrl('https://openrouter.ai/keys'); } catch {}
    }
  });
}

async function openSettings() {
  // Save any pending session work first
  if (state.currentSession) await Sessions.setMessages(state.currentSession.meta.id, state.currentSession.messages);

  // Populate form
  $('#setting-api-key').value         = state.settings.apiKey || '';
  $('#setting-base-url').value        = state.settings.baseUrl || DEFAULT_SETTINGS.baseUrl;
  $('#setting-mode').value            = state.settings.mode || 'build';
  $('#setting-max-steps').value       = state.settings.maxSteps || 40;
  $('#setting-system-prompt').value   = state.settings.systemPrompt || '';
  $('#setting-system-prompt').setAttribute('placeholder', DEFAULT_SYSTEM_PROMPT.slice(0, 500) + '…');
  const proxyEl = $('#setting-cors-proxy');
  if (proxyEl) proxyEl.value = state.settings.corsProxy || '';

  renderModelsList();
  renderModelDropdown();

  showScreen('settings');
}

function renderModelsList() {
  const root = $('#models-list');
  root.innerHTML = '';
  if (!state.settings.models?.length) {
    root.appendChild(el('div', { class: 'muted small', text: 'no models yet — tap +add' }));
    return;
  }
  for (const m of state.settings.models) {
    const row = el('div', { class: 'model-row' });
    const col = el('div', { class: 'col' });
    col.appendChild(el('div', { class: 'model-id', text: m.label || m.id }));
    if (m.label && m.label !== m.id) col.appendChild(el('div', { class: 'model-label', text: m.id }));
    row.appendChild(col);
    const x = el('button', { class: 'row-x', html: '<svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>' });
    x.onclick = async () => {
      state.settings.models = state.settings.models.filter(x => x.id !== m.id);
      if (state.settings.defaultModel === m.id) state.settings.defaultModel = state.settings.models[0]?.id || '';
      await KV.set('settings', state.settings);
      renderModelsList();
      renderModelDropdown();
    };
    row.appendChild(x);
    root.appendChild(row);
  }
}

function renderModelDropdown() {
  const sel = $('#setting-default-model');
  sel.innerHTML = '';
  for (const m of state.settings.models) {
    const opt = el('option', { value: m.id, text: m.label || m.id });
    if (m.id === state.settings.defaultModel) opt.selected = true;
    sel.appendChild(opt);
  }
}

async function saveSettingsFromUI() {
  state.settings.apiKey       = $('#setting-api-key').value.trim();
  state.settings.baseUrl      = $('#setting-base-url').value.trim() || DEFAULT_SETTINGS.baseUrl;
  state.settings.mode         = $('#setting-mode').value;
  state.settings.maxSteps     = parseInt($('#setting-max-steps').value, 10) || 40;
  state.settings.systemPrompt = $('#setting-system-prompt').value;
  state.settings.defaultModel = $('#setting-default-model').value;
  const proxyEl = $('#setting-cors-proxy');
  if (proxyEl) state.settings.corsProxy = proxyEl.value.trim();
  await KV.set('settings', state.settings);
  syncToolEnv();
}

async function addModelFlow() {
  const idI = el('input', { type: 'text', placeholder: 'provider/model-id' });
  const labelI = el('input', { type: 'text', placeholder: 'short label (optional)' });
  const wrap = el('div');
  wrap.appendChild(el('label', { text: 'model id (e.g. openai/gpt-5 or google/gemini-2.5-pro)' }));
  wrap.appendChild(idI);
  wrap.appendChild(el('label', { text: 'label' }));
  wrap.appendChild(labelI);
  wrap.appendChild(el('div', { class: 'muted small', text: 'see openrouter.ai/models for available ids', style: { marginTop: '6px' } }));
  const r = await modal({
    title: 'add model',
    body: wrap,
    actions: [
      { label: 'cancel', kind: 'cancel' },
      { label: 'add', kind: 'primary', onClick: () => ({ id: idI.value.trim(), label: labelI.value.trim() }) },
    ],
  });
  if (r && r.id) {
    if (state.settings.models.some(m => m.id === r.id)) {
      toast('already added');
      return;
    }
    state.settings.models.push({ id: r.id, label: r.label || r.id });
    if (!state.settings.defaultModel) state.settings.defaultModel = r.id;
    await KV.set('settings', state.settings);
    renderModelsList();
    renderModelDropdown();
  }
}

async function exportEverything() {
  const sessions = await Sessions.list();
  if (sessions.length === 0) { toast('nothing to export'); return; }
  const out = {};
  out['_opencode-web-export.json'] = JSON.stringify({
    version: APP_VERSION, exportedAt: new Date().toISOString(),
    sessionCount: sessions.length,
    settings: { ...state.settings, apiKey: '<redacted>' },
  }, null, 2);
  for (const s of sessions) {
    const data = await Sessions.load(s.id);
    if (data) {
      const name = (s.title || s.id).replace(/[^a-z0-9-_]+/gi, '-').replace(/^-+|-+$/g, '') || s.id;
      out[`sessions/${name}-${s.id}.json`] = JSON.stringify(data, null, 2);
      const snap = await VFS.snapshot(s.id);
      for (const [p, c] of Object.entries(snap)) {
        out[`projects/${name}-${s.id}/${p}`] = c;
      }
    }
  }
  toast('packing…');
  const blob = await makeZip(out);
  await downloadBlob(blob, 'opencode-web-backup.zip');
}

async function clearEverythingFlow() {
  const r = await modal({
    title: 'clear everything?',
    body: 'all sessions, all simulated project files, and all settings will be deleted. this cannot be undone.',
    actions: [
      { label: 'cancel', kind: 'cancel' },
      { label: 'clear', kind: 'danger', value: true },
    ],
  });
  if (!r) return;
  // Wipe sessions + projects
  const list = await Sessions.list();
  for (const s of list) await Sessions.delete(s.id);
  // Wipe settings
  await KV.del('settings');
  // Wipe local fallback
  for (const k of Object.keys(localStorage)) {
    if (k.startsWith('couchcode:')) localStorage.removeItem(k);
  }
  state.settings = { ...DEFAULT_SETTINGS };
  toast('cleared');
  await renderSessions();
  showScreen('sessions');
}

// --------------------------------------------------- global UI bindings

function bindGlobalUI() {
  // ESC / back hardware: hide modals/sheets
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      $('#modal-root').classList.add('hidden');
      $('#sheet-root').classList.add('hidden');
    }
  });
}

// --------------------------------------------------- go

window.addEventListener('DOMContentLoaded', init);
