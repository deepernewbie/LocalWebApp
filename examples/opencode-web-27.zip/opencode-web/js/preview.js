// Preview module: build a runnable bundle from the VFS and load it in an iframe.
//
// Two strategies, picked at runtime:
//
//   1. CouchFlow path (preferred): the host runs at http://localhost:<port>/.
//      We materialize the VFS into a `_preview/<sid>/` subfolder of the
//      picked folder via AndroidFS, then point the iframe at
//      `./_preview/<sid>/index.html`. This is a real HTTP URL — same origin
//      as the host, so no blob URL acrobatics, no path rewriting needed.
//      Avoids the WebViewClient navigation crash that blob: URLs trigger
//      (see CouchFlow source: shouldOverrideUrlLoading sends any non-localhost
//      URL out as an Android Intent, which kills the parent webview when
//      the URL is a blob:).
//
//   2. Browser fallback: build all files as blob URLs, rewrite all relative
//      paths in HTML/CSS/JS, return the resulting HTML as `srcdoc` for the
//      iframe.

import { VFS } from './storage.js';

const inCouchFlow = typeof window !== 'undefined' && !!window.CouchFlow;
const hasAndroidFS = typeof window !== 'undefined'
                  && window.AndroidFS
                  && typeof window.AndroidFS.write === 'function';

const MIME = {
  html: 'text/html',
  htm:  'text/html',
  css:  'text/css',
  js:   'text/javascript',
  mjs:  'text/javascript',
  json: 'application/json',
  svg:  'image/svg+xml',
  png:  'image/png',
  jpg:  'image/jpeg',
  jpeg: 'image/jpeg',
  gif:  'image/gif',
  webp: 'image/webp',
  ico:  'image/x-icon',
  txt:  'text/plain',
  md:   'text/plain',
  xml:  'application/xml',
  woff: 'font/woff',
  woff2:'font/woff2',
  ttf:  'font/ttf',
  otf:  'font/otf',
};

function mimeFor(path) {
  const ext = (path.split('.').pop() || '').toLowerCase();
  return MIME[ext] || 'application/octet-stream';
}

// Normalize a path: strip leading ./ or /, collapse //, resolve ../ against base.
function resolvePath(base, ref) {
  if (/^[a-z]+:/i.test(ref) || ref.startsWith('//') || ref.startsWith('data:') || ref.startsWith('blob:')) {
    return null; // external — leave alone
  }
  if (ref.startsWith('#') || ref.startsWith('mailto:') || ref.startsWith('tel:')) {
    return null;
  }
  // strip query/hash for resolution; we'll re-attach later if needed
  const [pathPart, queryHash] = splitQuery(ref);
  const baseParts = (base || '').split('/').slice(0, -1);
  const refParts  = pathPart.split('/');
  const out = [...baseParts];
  for (const p of refParts) {
    if (p === '' || p === '.') continue;
    if (p === '..') out.pop();
    else out.push(p);
  }
  return { path: out.join('/').replace(/^\/+/, ''), queryHash };
}

function splitQuery(s) {
  const m = s.match(/^([^?#]*)(.*)$/);
  return [m ? m[1] : s, m ? m[2] : ''];
}

// Build the bundle. Returns one of:
//
//   CouchFlow path:  { url: '...', entryPath, fileCount, cleanup }
//                    where url is a relative HTTP URL into the picked folder
//
//   Browser fallback: { srcdoc, entryPath, fileCount, urls, cleanup }
//                     where srcdoc is HTML with all paths rewritten to blob URLs
//
//   Empty/missing:   { error, fileCount, cleanup }
export async function buildPreview(sessionId) {
  const files = await VFS.walk(sessionId, '');
  if (files.length === 0) {
    return { error: 'project is empty', fileCount: 0, cleanup: () => {} };
  }

  // Find an entry. Prefer index.html at root, else first .html.
  let entry = files.find(f => f.path.toLowerCase() === 'index.html');
  if (!entry) entry = files.find(f => f.path.toLowerCase().endsWith('.html'));
  if (!entry) {
    return { error: 'no index.html found', fileCount: files.length, cleanup: () => {} };
  }

  // Phase 1: read all file content
  const contents = new Map();
  for (const f of files) {
    try {
      const text = await VFS.read(sessionId, f.path);
      contents.set(f.path, text ?? '');
    } catch (e) {
      contents.set(f.path, '');
    }
  }

  // Native CouchFlow path: write project files into the picked folder under
  // _preview/<sid>/ and serve them via the localhost HTTP server. Iframe
  // navigates to a same-origin URL — no blob: tricks needed.
  if (inCouchFlow && hasAndroidFS) {
    try {
      const result = await buildPreviewNative(sessionId, contents, entry);
      if (result) return result;
      // fall through to blob-URL strategy if writing failed
    } catch (e) {
      console.warn('[preview] native materialize failed, falling back to srcdoc', e);
    }
  }

  // Browser fallback: blob URLs + srcdoc
  return buildPreviewSrcdoc(sessionId, contents, entry, files);
}

// ---- Native (CouchFlow) strategy: materialize files to disk ----------------

async function buildPreviewNative(sessionId, contents, entry) {
  const root = `_preview/${sessionId}`;
  // Wipe stale preview files for this session before re-materializing.
  // We only delete files we know about; AndroidFS.delete on a directory
  // recursively handles its children (per CouchFlow source).
  try { await AndroidFS.delete(root); } catch {}

  // Inject the console-forwarding shim into the entry HTML before writing.
  const entryHtml = injectConsoleShim(contents.get(entry.path) || '');
  contents.set(entry.path, entryHtml);

  // Write every file. Text vs binary detection: AndroidFS.write expects a
  // string. We treat all content from the VFS as text for now (the VFS
  // currently stores everything as strings), but plumb writeBytes for
  // binaries in case the VFS gains binary support.
  for (const [path, content] of contents) {
    const target = `${root}/${path}`;
    try {
      if (typeof content === 'string') {
        const ok = await AndroidFS.write(target, content);
        if (!ok) {
          console.warn('[preview] write failed for', target);
          return null;
        }
      } else if (content instanceof Uint8Array && typeof AndroidFS.writeBytes === 'function') {
        const ok = await AndroidFS.writeBytes(target, content);
        if (!ok) {
          console.warn('[preview] writeBytes failed for', target);
          return null;
        }
      }
    } catch (e) {
      console.warn('[preview] write threw for', target, e);
      return null;
    }
  }

  return {
    url: `./${root}/${entry.path}`,
    entryPath: entry.path,
    fileCount: contents.size,
    cleanup: async () => {
      try { await AndroidFS.delete(root); } catch {}
    },
  };
}

// ---- Browser fallback: blob URLs + srcdoc HTML ------------------------------

async function buildPreviewSrcdoc(sessionId, contents, entry, files) {
  // Phase 2: pre-create blob URLs for all non-text-rewritable files (binary,
  // CSS, etc.) and a *placeholder* for the rewritable ones. We'll fill those
  // in once we've rewritten their content.
  const urls = new Map(); // path → blob url
  const blobs = new Map(); // path → Blob (so we can rebuild urls after rewriting)

  // Rewritable types: html, js, css. These reference other files by path.
  const REWRITABLE = new Set(['html', 'htm', 'js', 'mjs', 'css']);

  // First pass: blob URLs for non-rewritable assets (images, fonts, json, etc.)
  for (const [path, content] of contents) {
    const ext = (path.split('.').pop() || '').toLowerCase();
    if (REWRITABLE.has(ext)) continue;
    const blob = new Blob([content], { type: mimeFor(path) });
    blobs.set(path, blob);
    urls.set(path, URL.createObjectURL(blob));
  }

  // Topological-ish rewrite: rewrite leaves first (CSS), then JS, then HTML.
  // But JS imports JS, so we need to do JS in a way that handles internal cross-refs.
  // Approach: rewrite each rewritable file's *text*, where any unresolved
  // cross-ref to another rewritable file uses a stable placeholder; then in a
  // final pass we generate blob URLs for all rewritable files in topological
  // order (CSS, JS, HTML).

  // Step 2a: rewrite CSS (only refs to assets — usually images/fonts, all
  // already in `urls`).
  const rewrittenCss = new Map();
  for (const [path, content] of contents) {
    if (!path.toLowerCase().endsWith('.css')) continue;
    rewrittenCss.set(path, rewriteCss(content, path, urls));
  }
  for (const [path, txt] of rewrittenCss) {
    const blob = new Blob([txt], { type: 'text/css' });
    blobs.set(path, blob);
    urls.set(path, URL.createObjectURL(blob));
  }

  // Step 2b: rewrite JS. JS may import other JS — so we do two passes:
  //   pass 1: rewrite each JS, leaving cross-JS refs as marker tokens
  //   pass 2: replace markers with the blob URLs once they're all created
  const jsTextOrig = new Map();
  for (const [path, content] of contents) {
    const lower = path.toLowerCase();
    if (lower.endsWith('.js') || lower.endsWith('.mjs')) {
      jsTextOrig.set(path, content);
    }
  }
  // Pass 1: identify cross-JS dependencies, replace with placeholders
  const jsRewritten = new Map();
  for (const [path, content] of jsTextOrig) {
    jsRewritten.set(path, rewriteJs(content, path, urls, jsTextOrig));
  }
  // Pass 2: create blob URLs for each JS, then resolve placeholders
  // (we need blob URLs first; a JS file's blob URL doesn't depend on its
  // content's resolution of placeholders — but the *text* it contains must
  // resolve to the right blob URL of its imports, which means we have to
  // create blob URLs in a specific order: any JS that has no JS imports
  // first, then ones that import it, etc. But blob URLs are random anyway,
  // so we just create them for every JS first, then replace placeholders
  // pointing at them, then re-blob-ify.)

  const placeholderToPath = new Map();
  for (const [path] of jsTextOrig) {
    const placeholder = `__OPENCODE_JS_BLOB__${path}__`;
    placeholderToPath.set(placeholder, path);
  }

  // Create initial blob URLs for each JS (with placeholders still in text)
  for (const [path, txt] of jsRewritten) {
    const blob = new Blob([txt], { type: 'text/javascript' });
    blobs.set(path, blob);
    urls.set(path, URL.createObjectURL(blob));
  }
  // Now substitute placeholders with the actual blob URLs and re-create blobs.
  for (const [path, txt] of jsRewritten) {
    let resolved = txt;
    for (const [marker, refPath] of placeholderToPath) {
      const url = urls.get(refPath);
      if (url) resolved = resolved.split(marker).join(url);
    }
    if (resolved !== txt) {
      // revoke the old URL and replace
      URL.revokeObjectURL(urls.get(path));
      const newBlob = new Blob([resolved], { type: 'text/javascript' });
      blobs.set(path, newBlob);
      urls.set(path, URL.createObjectURL(newBlob));
    }
  }

  // Step 2c: rewrite HTML — last, so all referenced assets have blob URLs
  let htmlText = contents.get(entry.path) || '';
  htmlText = rewriteHtml(htmlText, entry.path, urls);
  // Inject a console-forwarding shim at the top of <head> so the parent can
  // capture logs/errors.
  htmlText = injectConsoleShim(htmlText);

  // We deliberately don't make a blob URL for the entry HTML — the iframe
  // gets it via `srcdoc` instead. Setting iframe.src to a blob: URL caused
  // the parent webview to crash on some Android WebView configurations
  // (CouchFlow); srcdoc avoids that whole code path because no top-level
  // navigation happens. Sub-resources (CSS/JS/images) still come from blob
  // URLs and are loaded by the iframe itself once the srcdoc HTML executes.
  return {
    srcdoc: htmlText,
    entryPath: entry.path,
    fileCount: files.length,
    urls,
    cleanup: () => {
      for (const u of urls.values()) {
        try { URL.revokeObjectURL(u); } catch {}
      }
    },
  };
}

// ---- Rewriters ----------------------------------------------------------

function rewriteHtml(html, basePath, urls) {
  // attributes that take a URL: src, href, srcset, action, poster, data
  return html.replace(/(src|href|action|poster|data)\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/gi, (m, attr, _, dq, sq, raw) => {
    const val = dq != null ? dq : sq != null ? sq : raw;
    const quote = dq != null ? '"' : sq != null ? "'" : '';
    const resolved = resolvePath(basePath, val);
    if (!resolved) return m;
    const url = urls.get(resolved.path);
    if (!url) return m;
    return `${attr}=${quote}${url}${resolved.queryHash || ''}${quote}`;
  })
  // also swap srcset entries
  .replace(/srcset\s*=\s*"([^"]*)"/gi, (m, val) => {
    const swapped = val.split(',').map(part => {
      const [u, ...rest] = part.trim().split(/\s+/);
      const r = resolvePath(basePath, u);
      const url = r && urls.get(r.path);
      return [(url ? url + (r.queryHash || '') : u), ...rest].join(' ');
    }).join(', ');
    return `srcset="${swapped}"`;
  });
}

function rewriteCss(css, basePath, urls) {
  // url(...) and @import "..."
  return css
    .replace(/url\(\s*("([^"]+)"|'([^']+)'|([^)\s]+))\s*\)/g, (m, _q, dq, sq, raw) => {
      const val = dq || sq || raw;
      const r = resolvePath(basePath, val);
      const url = r && urls.get(r.path);
      return url ? `url("${url}${r.queryHash || ''}")` : m;
    })
    .replace(/@import\s+("([^"]+)"|'([^']+)')/g, (m, _q, dq, sq) => {
      const val = dq || sq;
      const r = resolvePath(basePath, val);
      const url = r && urls.get(r.path);
      return url ? `@import "${url}"` : m;
    });
}

// Rewrite JS imports / dynamic imports / new URL(...,import.meta.url) paths.
// For refs that point to other rewritable JS files, we substitute a placeholder
// like __OPENCODE_JS_BLOB__path__ that the second pass replaces with the
// finalized blob URL.
function rewriteJs(js, basePath, urls, jsTextOrig) {
  function resolveOne(spec) {
    const r = resolvePath(basePath, spec);
    if (!r) return null;
    if (jsTextOrig.has(r.path)) {
      return `__OPENCODE_JS_BLOB__${r.path}__`;
    }
    const url = urls.get(r.path);
    if (url) return url + (r.queryHash || '');
    return null;
  }
  // static `import ... from "x"` and `import "x"`
  js = js.replace(/(\bimport\s+(?:[^'"]+?\s+from\s+)?)(["'])([^"']+)(\2)/g, (m, prefix, q, spec) => {
    if (!isRelative(spec)) return m;
    const out = resolveOne(spec);
    return out ? `${prefix}${q}${out}${q}` : m;
  });
  // export ... from "x"
  js = js.replace(/(\bexport\s+(?:[^'"]+?\s+from\s+))(["'])([^"']+)(\2)/g, (m, prefix, q, spec) => {
    if (!isRelative(spec)) return m;
    const out = resolveOne(spec);
    return out ? `${prefix}${q}${out}${q}` : m;
  });
  // dynamic import("x")
  js = js.replace(/(\bimport\s*\(\s*)(["'])([^"']+)(\2)(\s*\))/g, (m, p1, q, spec, _q2, p3) => {
    if (!isRelative(spec)) return m;
    const out = resolveOne(spec);
    return out ? `${p1}${q}${out}${q}${p3}` : m;
  });
  // new URL("x", import.meta.url)
  js = js.replace(/(new\s+URL\s*\(\s*)(["'])([^"']+)(\2)(\s*,\s*import\.meta\.url\s*\))/g, (m, p1, q, spec, _q2, p3) => {
    if (!isRelative(spec)) return m;
    const out = resolveOne(spec);
    return out ? `${p1}${q}${out}${q}${p3}` : m;
  });
  return js;
}

function isRelative(spec) {
  return spec.startsWith('./') || spec.startsWith('../') || spec.startsWith('/') ||
         (!spec.includes(':') && !spec.startsWith('http') && !spec.startsWith('//'));
}

// Inject a small shim that forwards console logs and errors to the parent
// window via postMessage. The console panel listens for these.
function injectConsoleShim(html) {
  const shim = `<script>(function(){
    function send(level, args){
      try {
        var safe = Array.prototype.map.call(args, function(a){
          if (a instanceof Error) return a.stack || (a.name + ': ' + a.message);
          if (typeof a === 'object') {
            try { return JSON.stringify(a); } catch(e){ return String(a); }
          }
          return String(a);
        });
        parent.postMessage({ __opencodeConsole: true, level: level, args: safe }, '*');
      } catch(e) {}
    }
    ['log','info','warn','error','debug'].forEach(function(lvl){
      var orig = console[lvl];
      console[lvl] = function(){ send(lvl, arguments); orig && orig.apply(console, arguments); };
    });
    window.addEventListener('error', function(e){
      send('error', [(e.message || 'error') + (e.filename ? ' (' + e.filename + ':' + e.lineno + ')' : '')]);
    });
    window.addEventListener('unhandledrejection', function(e){
      send('error', ['Unhandled rejection: ' + (e.reason && e.reason.message || e.reason)]);
    });
  })();</script>`;
  if (html.match(/<head[^>]*>/i)) {
    return html.replace(/<head[^>]*>/i, m => m + shim);
  }
  if (html.match(/<html[^>]*>/i)) {
    return html.replace(/<html[^>]*>/i, m => m + '<head>' + shim + '</head>');
  }
  return shim + html;
}
