// Small UI helpers used throughout the app.

export const $ = sel => document.querySelector(sel);
export const $$ = sel => Array.from(document.querySelectorAll(sel));

export function el(tag, attrs = {}, children = []) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k === 'style') Object.assign(e.style, v);
    else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2), v);
    else if (k === 'html') e.innerHTML = v;
    else if (k === 'text') e.textContent = v;
    else if (v != null && v !== false) e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of [].concat(children)) {
    if (c == null || c === false) continue;
    if (typeof c === 'string') e.appendChild(document.createTextNode(c));
    else e.appendChild(c);
  }
  return e;
}

// ---- Toast
let toastTimer = null;
export function toast(msg, ms = 2500) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), ms);
}
// ---- "opencode" logo, using the official wordmark/mark SVGs.
//
// Two variants:
//   logoMark()      → small square mark only (32×40 native viewBox)
//   logoWordmark()  → "opencode" wordmark with a (web) tag suffix
//
// Both use `currentColor` for fill, so they adapt to the containing element's
// `color`. The lighter "shadow" pixels are rendered at 85% opacity, so the
// entire logo stays mono-color and matches dark/light themes without changes.
//
// Sizing is driven entirely by the container's CSS — set `height` (or
// `width`) on `.logo-mark` / `.logo-wordmark` and the SVG scales
// proportionally via viewBox. Resolution-agnostic.

const MARK_PATHS = `
  <path d="M24 32H8V16H24V32Z" class="logo-shadow"/>
  <path d="M24 8H8V32H24V8ZM32 40H0V0H32V40Z" class="logo-fill"/>
`;

const WORDMARK_PATHS = `
  <path d="M18 30H6V18H18V30Z" class="logo-shadow"/>
  <path d="M18 12H6V30H18V12ZM24 36H0V6H24V36Z" class="logo-fill"/>
  <path d="M48 30H36V18H48V30Z" class="logo-shadow"/>
  <path d="M36 30H48V12H36V30ZM54 36H36V42H30V6H54V36Z" class="logo-fill"/>
  <path d="M84 24V30H66V24H84Z" class="logo-shadow"/>
  <path d="M84 24H66V30H84V36H60V6H84V24ZM66 18H78V12H66V18Z" class="logo-fill"/>
  <path d="M108 36H96V18H108V36Z" class="logo-shadow"/>
  <path d="M108 12H96V36H90V6H108V12ZM114 36H108V12H114V36Z" class="logo-fill"/>
  <path d="M144 30H126V18H144V30Z" class="logo-shadow"/>
  <path d="M144 12H126V30H144V36H120V6H144V12Z" class="logo-fill"/>
  <path d="M168 30H156V18H168V30Z" class="logo-shadow"/>
  <path d="M168 12H156V30H168V12ZM174 36H150V6H174V36Z" class="logo-fill"/>
  <path d="M198 30H186V18H198V30Z" class="logo-shadow"/>
  <path d="M198 12H186V30H198V12ZM204 36H180V6H198V0H204V36Z" class="logo-fill"/>
  <path d="M234 24V30H216V24H234Z" class="logo-shadow"/>
  <path d="M216 12V18H228V12H216ZM234 24H216V30H234V36H210V6H234V24Z" class="logo-fill"/>
`;

// Just the small mark (no "opencode" text). Use in tight spots.
export function logoMark() {
  const wrap = document.createElement('span');
  wrap.className = 'logo-mark';
  wrap.innerHTML = `<svg viewBox="0 0 32 40" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">${MARK_PATHS}</svg>`;
  return wrap;
}

// "opencode" wordmark with a small (web) tag to the right.
//
// Tag dimensions are tied to the wordmark's own grid: it's 18 viewBox units
// wide × 36 tall, matching the height of the main letters. Inside is the
// text "(web)" rotated -90° at a font size that fills the slot.
export function logoWordmark() {
  const wrap = document.createElement('span');
  wrap.className = 'logo-wordmark';
  const TAG_GAP = 8;
  const TAG_W = 18;
  const TAG_H = 36;
  const TOTAL_W = 234 + TAG_GAP + TAG_W;
  const TOTAL_H = 42;
  const TAG_X = 234 + TAG_GAP;
  const TAG_Y = (TOTAL_H - TAG_H) / 2;
  const TAG_CX = TAG_X + TAG_W / 2;
  const TAG_CY = TOTAL_H / 2;
  wrap.innerHTML = `
    <svg viewBox="0 0 ${TOTAL_W} ${TOTAL_H}" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMid meet">
      ${WORDMARK_PATHS}
      <rect x="${TAG_X}" y="${TAG_Y}" width="${TAG_W}" height="${TAG_H}"
            fill="none" stroke="currentColor" stroke-width="2"/>
      <text x="${TAG_CX}" y="${TAG_CY}"
            text-anchor="middle" dominant-baseline="central"
            transform="rotate(-90 ${TAG_CX} ${TAG_CY})"
            font-family="ui-monospace, monospace" font-weight="700"
            font-size="14" fill="currentColor"
            letter-spacing="0.5">(web)</text>
    </svg>`;
  return wrap;
}

// Backwards-compat alias — older call sites import asciiLogo.
export const asciiLogo = logoWordmark;

// ---- Modal (promise-based)
// Dismiss-stack registry. Screens (e.g. preview console) and overlays
// (modal, sheet) push close-functions here so the hardware back button
// can dismiss the topmost overlay before navigating screens.
// Each fn returns true if it actually closed something.
export const dismissStack = [];
export function pushDismiss(fn) {
  dismissStack.push(fn);
  return () => {
    const idx = dismissStack.lastIndexOf(fn);
    if (idx >= 0) dismissStack.splice(idx, 1);
  };
}

export function modal({ title, body, actions, dismissable = true }) {
  return new Promise(resolve => {
    const root = $('#modal-root');
    const titleEl = $('#modal-title');
    const bodyEl  = $('#modal-body');
    const actsEl  = $('#modal-actions');
    titleEl.textContent = title || '';
    bodyEl.innerHTML = '';
    if (typeof body === 'string') bodyEl.textContent = body;
    else if (body) bodyEl.appendChild(body);
    actsEl.innerHTML = '';

    let unhook = null;
    function close(value) {
      root.classList.add('hidden');
      $('#modal-backdrop').onclick = null;
      if (unhook) unhook();
      // We DON'T touch history here on programmatic close. The synthetic
      // overlay entry stays in the stack. If the user navigates forward
      // (e.g. into the settings screen), pushState replaces the next slot
      // and everything stays consistent. If they go back via hardware,
      // they'll consume the (now-orphan) overlay entry first as a no-op,
      // then the actual previous screen — one extra tap, but no race
      // condition with subsequent navigations triggered from this modal.
      resolve(value);
    }

    for (const a of actions || []) {
      const btn = el('button', { class: a.kind || 'cancel' });
      btn.textContent = a.label;
      btn.onclick = () => {
        const v = a.onClick ? a.onClick(bodyEl) : a.value;
        if (v && typeof v.then === 'function') v.then(close);
        else close(v);
      };
      actsEl.appendChild(btn);
    }

    if (dismissable) {
      $('#modal-backdrop').onclick = () => close(null);
    }
    root.classList.remove('hidden');
    // Push a synthetic history entry so the hardware back button has
    // something to pop, and popstate will close the modal first.
    if (typeof history !== 'undefined') {
      try { history.pushState({ overlay: 'modal' }, '', location.hash || '#'); } catch {}
    }
    unhook = pushDismiss(() => {
      if (root.classList.contains('hidden')) return false;
      close(null);
      return true;
    });
  });
}

// ---- Bottom sheet (returns a function to close)
export function openSheet({ title, items, onPick }) {
  const root = $('#sheet-root');
  const titleEl = $('#sheet-title');
  const bodyEl  = $('#sheet-body');
  titleEl.textContent = title || '';
  bodyEl.innerHTML = '';

  let unhook = null;
  function close() {
    root.classList.add('hidden');
    $('#sheet-backdrop').onclick = null;
    if (unhook) unhook();
    // Same as modal: don't touch history on programmatic close (avoids
    // race with any subsequent navigation triggered from a sheet item).
  }

  for (const item of items || []) {
    const it = el('div', { class: 'sheet-item' + (item.danger ? ' danger' : '') });
    const col = el('div', { class: 'col' });
    const id = el('div', { class: 'id', text: item.label });
    col.appendChild(id);
    if (item.sub) col.appendChild(el('div', { class: 'si-meta', text: item.sub }));
    it.appendChild(col);
    if (item.checked) it.appendChild(el('div', { class: 'check', text: '✓' }));
    it.onclick = () => {
      onPick?.(item);
      close();
    };
    bodyEl.appendChild(it);
  }

  $('#sheet-backdrop').onclick = close;
  root.classList.remove('hidden');
  if (typeof history !== 'undefined') {
    try { history.pushState({ overlay: 'sheet' }, '', location.hash || '#'); } catch {}
  }
  unhook = pushDismiss(() => {
    if (root.classList.contains('hidden')) return false;
    close();
    return true;
  });
  return close;
}

// ---- Naive markdown → HTML for assistant text
export function renderMarkdown(text) {
  const escape = s => s.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

  // Code fences first
  const codeBlocks = [];
  text = text.replace(/```([a-zA-Z0-9_+-]*)\n([\s\S]*?)```/g, (_, lang, body) => {
    codeBlocks.push({ lang, body });
    return `\u0000CODE${codeBlocks.length - 1}\u0000`;
  });

  let html = escape(text);
  // Inline code
  html = html.replace(/`([^`\n]+)`/g, '<code>$1</code>');
  // Bold
  html = html.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  // Italic (avoid ** clash)
  html = html.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>');
  // Auto-link http
  html = html.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1">$1</a>');

  // Re-insert code blocks
  html = html.replace(/\u0000CODE(\d+)\u0000/g, (_, i) => {
    const cb = codeBlocks[+i];
    return `<pre><code>${escape(cb.body)}</code></pre>`;
  });

  // Preserve paragraph breaks but keep linebreaks
  return html;
}
