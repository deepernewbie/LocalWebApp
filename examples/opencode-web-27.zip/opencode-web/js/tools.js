// Tool definitions — schemas for the LLM + executors that act on the VFS.
// Adapted from opencode's tool set, simulated for the opencode-web sandbox.

import { VFS } from './storage.js';

// --------------------------------------------------- helpers

function clamp(s, max) {
  if (s == null) return s;
  if (s.length <= max) return s;
  return s.slice(0, max) + `\n… [truncated, ${s.length - max} more chars]`;
}

function lineNumber(text, max = 2000) {
  const lines = text.split('\n');
  const truncatedLines = lines.slice(0, max);
  const out = truncatedLines.map((l, i) => {
    if (l.length > 2000) l = l.slice(0, 2000) + ' …[line truncated]';
    return `${i + 1}: ${l}`;
  }).join('\n');
  if (lines.length > max) return out + `\n…[${lines.length - max} more lines]`;
  return out;
}

// glob matcher: support **, *, ?
function globToRegex(pattern) {
  let re = '^';
  let i = 0;
  while (i < pattern.length) {
    const c = pattern[i];
    if (c === '*') {
      if (pattern[i + 1] === '*') {
        // **
        re += '.*';
        i += 2;
        if (pattern[i] === '/') i++;
      } else {
        re += '[^/]*';
        i++;
      }
    } else if (c === '?') {
      re += '[^/]';
      i++;
    } else if (c === '.') {
      re += '\\.';
      i++;
    } else if ('+()|^$[]{}\\'.includes(c)) {
      re += '\\' + c;
      i++;
    } else {
      re += c;
      i++;
    }
  }
  re += '$';
  return new RegExp(re);
}

function makeUnifiedDiff(oldStr, newStr, contextLines = 2) {
  const a = oldStr.split('\n');
  const b = newStr.split('\n');
  // tiny LCS-based diff
  const m = a.length, n = b.length;
  const dp = Array(m + 1).fill(0).map(() => Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--)
    for (let j = n - 1; j >= 0; j--)
      dp[i][j] = a[i] === b[j] ? dp[i+1][j+1] + 1 : Math.max(dp[i+1][j], dp[i][j+1]);

  const ops = [];
  let i = 0, j = 0;
  while (i < m && j < n) {
    if (a[i] === b[j]) { ops.push({op: '=', l: a[i]}); i++; j++; }
    else if (dp[i+1][j] >= dp[i][j+1]) { ops.push({op: '-', l: a[i]}); i++; }
    else { ops.push({op: '+', l: b[j]}); j++; }
  }
  while (i < m) { ops.push({op: '-', l: a[i]}); i++; }
  while (j < n) { ops.push({op: '+', l: b[j]}); j++; }

  // condense
  const out = [];
  let lastChange = -Infinity;
  const changeIdxs = ops.map((o, k) => o.op !== '=' ? k : -1).filter(k => k >= 0);
  if (changeIdxs.length === 0) return '(no changes)';
  const keep = new Set();
  for (const idx of changeIdxs) {
    for (let k = Math.max(0, idx - contextLines); k <= Math.min(ops.length - 1, idx + contextLines); k++) keep.add(k);
  }
  let prev = -2;
  for (let k = 0; k < ops.length; k++) {
    if (!keep.has(k)) continue;
    if (k > prev + 1) out.push('…');
    const o = ops[k];
    out.push((o.op === '=' ? '  ' : (o.op === '+' ? '+ ' : '- ')) + o.l);
    prev = k;
  }
  return out.join('\n');
}

// --------------------------------------------------- tool registry

// Mode-based filtering: in 'plan' mode, write/edit/bash are excluded; plan_exit is added.
const ALL_TOOLS    = ['read', 'write', 'edit', 'glob', 'grep', 'bash', 'webfetch', 'websearch', 'wikiimage', 'todowrite', 'task', 'question'];
const PLAN_TOOLS   = ['read', 'glob', 'grep', 'webfetch', 'websearch', 'wikiimage', 'todowrite', 'task', 'question', 'plan_exit'];

export function getToolNamesForMode(mode) {
  return mode === 'plan' ? PLAN_TOOLS : ALL_TOOLS;
}

// JSON Schema for OpenRouter / OpenAI-compatible function calling
export function getToolSchemas(mode) {
  const tools = [
    {
      name: 'read',
      description:
        'Read a file from the project filesystem.\n' +
        'Returns up to 2000 lines starting at offset (1-indexed). Each line is prefixed with "<n>: ".\n' +
        'If filePath is a directory, lists its entries instead (names with a trailing slash for dirs).\n' +
        'Use this before editing any file. The path is relative to the project root.',
      parameters: {
        type: 'object',
        properties: {
          filePath: { type: 'string', description: 'Path relative to project root, e.g. "src/app.js" or "src/" for a listing' },
          offset:   { type: 'integer', description: 'Line number to start from (1-indexed). Default 1.' },
          limit:    { type: 'integer', description: 'Max lines to return. Default 2000.' },
        },
        required: ['filePath'],
      },
    },
    {
      name: 'write',
      description:
        'Write a file to the project filesystem, creating parent directories as needed. Overwrites existing content.\n' +
        'For existing files you MUST use read first; this tool will fail otherwise.\n' +
        'NEVER proactively create README/docs unless asked.',
      parameters: {
        type: 'object',
        properties: {
          filePath: { type: 'string' },
          content:  { type: 'string' },
        },
        required: ['filePath', 'content'],
      },
    },
    {
      name: 'edit',
      description:
        'Replace an exact string occurrence in a file.\n' +
        'You MUST have called read on this file earlier in the session.\n' +
        'oldString must match exactly (preserve indentation; do NOT include the "<n>: " line-number prefix from read).\n' +
        'Fails if oldString is not found, or if found multiple times unless replaceAll is true.',
      parameters: {
        type: 'object',
        properties: {
          filePath:   { type: 'string' },
          oldString:  { type: 'string' },
          newString:  { type: 'string' },
          replaceAll: { type: 'boolean', description: 'Replace every occurrence. Default false.' },
        },
        required: ['filePath', 'oldString', 'newString'],
      },
    },
    {
      name: 'glob',
      description:
        'Find files matching a glob pattern (supports **, *, ?). Returns paths relative to project root, sorted by mtime desc.',
      parameters: {
        type: 'object',
        properties: {
          pattern: { type: 'string', description: 'e.g. "**/*.js" or "src/**/*.html"' },
        },
        required: ['pattern'],
      },
    },
    {
      name: 'grep',
      description:
        'Search file contents for a regex pattern across the project. Returns matching lines with file:line: prefix.\n' +
        'Use this to locate code by content; use glob to find files by name.',
      parameters: {
        type: 'object',
        properties: {
          pattern:    { type: 'string' },
          path:       { type: 'string', description: 'Subdir to limit search. Optional.' },
          include:    { type: 'string', description: 'Glob to filter file paths, e.g. "*.js"' },
          ignoreCase: { type: 'boolean' },
        },
        required: ['pattern'],
      },
    },
    {
      name: 'bash',
      description:
        'EMULATED in this sandbox. Only a small set of read-only commands is supported: ls, cat, pwd, find, wc.\n' +
        'You CANNOT install packages, run python/node/npm/etc. The user is on a phone — there is no real shell.\n' +
        'For writing files use the write/edit tools, NOT echo or heredoc.\n' +
        'Most of the time you should NOT call bash; use the dedicated tools (read/write/edit/glob/grep) instead.',
      parameters: {
        type: 'object',
        properties: {
          command: { type: 'string' },
          description: { type: 'string', description: '5-10 word summary' },
        },
        required: ['command'],
      },
    },
    {
      name: 'webfetch',
      description:
        'Fetch a URL and return its content as plain text/markdown. Read-only.',
      parameters: {
        type: 'object',
        properties: {
          url:    { type: 'string' },
          format: { type: 'string', enum: ['text', 'html', 'markdown'], description: 'default markdown' },
        },
        required: ['url'],
      },
    },
    {
      name: 'websearch',
      description:
        'Search the web. Uses Wikipedia OpenSearch and DuckDuckGo Instant Answer ' +
        'as primary sources (both CORS-enabled, no key needed). If the user has ' +
        'configured a CORS proxy in settings, also falls back to full web search ' +
        'via DuckDuckGo HTML. Use for current events, docs, package info, definitions.',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string' },
          maxResults: { type: 'integer', description: 'default 5, max 10' },
        },
        required: ['query'],
      },
    },
    {
      name: 'wikiimage',
      description:
        'Search Wikimedia Commons for images by topic and return image URLs ' +
        'with captions. CORS-enabled, no key needed. Use when the user wants ' +
        'an image of something (a person, a place, an object, a diagram).',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string' },
          maxResults: { type: 'integer', description: 'default 5, max 10' },
        },
        required: ['query'],
      },
    },
    {
      name: 'todowrite',
      description:
        'Replace the session todo list. Use to plan multi-step work and check things off as you go.\n' +
        'Status values: pending, in_progress, done.',
      parameters: {
        type: 'object',
        properties: {
          todos: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id:     { type: 'string' },
                text:   { type: 'string' },
                status: { type: 'string', enum: ['pending', 'in_progress', 'done'] },
              },
              required: ['text', 'status'],
            },
          },
        },
        required: ['todos'],
      },
    },
    {
      name: 'task',
      description:
        'Spawn a sub-agent to handle a focused, well-defined unit of work.\n' +
        'The sub-agent runs autonomously with read-only tools (read/glob/grep/webfetch/websearch) and returns a single text summary when done.\n' +
        'Use for: searching the codebase for something open-ended, researching docs on the web, or any task whose result you only need as a summary.\n' +
        'Do NOT use for trivial single-tool calls — just call the tool yourself. Provide a self-contained prompt; the sub-agent has no other context.',
      parameters: {
        type: 'object',
        properties: {
          description: { type: 'string', description: '3-5 word label for the task' },
          prompt:      { type: 'string', description: 'The full instructions for the sub-agent' },
        },
        required: ['description', 'prompt'],
      },
    },
    {
      name: 'question',
      description:
        'Ask the user a clarifying question and wait for their reply before continuing.\n' +
        'Use sparingly — only when truly blocked by ambiguity that you cannot resolve from context.\n' +
        'Do NOT use for permission ("should I…?") — just do the work.',
      parameters: {
        type: 'object',
        properties: {
          question: { type: 'string' },
        },
        required: ['question'],
      },
    },
    {
      name: 'plan_exit',
      description:
        'Signal that planning is complete and you are ready to leave plan mode and start executing.\n' +
        'Only available in plan mode. Provide the final plan as the body.',
      parameters: {
        type: 'object',
        properties: {
          plan: { type: 'string', description: 'Markdown summary of the plan to execute' },
        },
        required: ['plan'],
      },
    },
  ];

  const allowed = new Set(getToolNamesForMode(mode));
  return tools.filter(t => allowed.has(t.name));
}

// --------------------------------------------------- executors

// Per-session state: tracks which files have been read.
// The agent loop owns one of these; tools mutate it.
export function makeToolState() {
  return {
    reads: new Set(),         // filePaths that have been read this session
    todos: [],
  };
}

export async function execTool(name, args, ctx) {
  const fn = EXECUTORS[name];
  if (!fn) return { error: `unknown tool "${name}"` };
  try {
    return await fn(args || {}, ctx);
  } catch (e) {
    return { error: String(e?.message || e) };
  }
}

const EXECUTORS = {
  // ----- read
  async read(args, { sessionId, state }) {
    const filePath = args.filePath || args.file_path || args.path || args.file;
    const offset = args.offset ?? args.start ?? args.start_line;
    const limit = args.limit ?? args.lines ?? args.max_lines;
    if (!filePath) return { error: 'filePath required' };
    const exists = await VFS.exists(sessionId, filePath);
    if (!exists) return { error: `file not found: ${filePath}` };
    const stat = await VFS.stat(sessionId, filePath);
    if (stat?.isDir) {
      // emulate opencode: list directory contents
      const items = await VFS.list(sessionId, filePath);
      items.sort((a, b) => a.name.localeCompare(b.name));
      const out = items.map(it => it.isDir ? it.name + '/' : it.name).join('\n');
      return { ok: true, output: out, isDir: true, count: items.length };
    }
    const content = await VFS.read(sessionId, filePath);
    if (content == null) return { error: `unreadable: ${filePath}` };
    state.reads.add(normalizePath(filePath));

    const startLine = Math.max(1, offset || 1);
    const maxLines = Math.max(1, Math.min(limit || 2000, 5000));
    const allLines = content.split('\n');
    const sliced = allLines.slice(startLine - 1, startLine - 1 + maxLines);
    const numbered = sliced.map((l, i) => {
      const ln = startLine + i;
      if (l.length > 2000) l = l.slice(0, 2000) + ' …[line truncated]';
      return `${ln}: ${l}`;
    }).join('\n');
    const totalLines = allLines.length;
    let suffix = '';
    if (startLine - 1 + sliced.length < totalLines)
      suffix = `\n…[${totalLines - (startLine - 1 + sliced.length)} more lines, total ${totalLines}]`;
    return {
      ok: true,
      output: numbered + suffix,
      meta: { lines: totalLines, returned: sliced.length, size: content.length },
    };
  },

  // ----- write
  async write(args, { sessionId, state }) {
    const filePath = args.filePath || args.file_path || args.path || args.file;
    const content = args.content ?? args.text ?? args.body ?? args.data;
    if (!filePath) return { error: 'filePath required' };
    if (content == null) return { error: 'content required' };
    const np = normalizePath(filePath);
    const exists = await VFS.exists(sessionId, np);
    if (exists) {
      // require prior read for existing files
      if (!state.reads.has(np)) {
        return { error: `must call read on existing file "${filePath}" before write` };
      }
    }
    const before = exists ? (await VFS.read(sessionId, np)) || '' : null;
    await VFS.write(sessionId, np, content);
    state.reads.add(np);
    const diff = before == null
      ? `(new file, ${content.split('\n').length} lines, ${content.length} bytes)`
      : makeUnifiedDiff(before, content);
    return {
      ok: true,
      output: `${exists ? 'updated' : 'created'} ${np} (${content.length} bytes)`,
      diff,
      meta: { isNew: !exists, size: content.length },
    };
  },

  // ----- edit
  async edit(args, { sessionId, state }) {
    // Accept common parameter-name hallucinations as aliases. Cheaper
    // models often emit oldStr/newStr (or even old_string/new_string)
    // instead of the schema's oldString/newString. Rather than letting
    // the agent spin retrying with bad arg names, normalize here.
    const filePath = args.filePath || args.file_path || args.path;
    const oldString = args.oldString ?? args.oldStr ?? args.old_string ?? args.old_str ?? args.search ?? args.find;
    const newString = args.newString ?? args.newStr ?? args.new_string ?? args.new_str ?? args.replace ?? args.replacement;
    const replaceAll = args.replaceAll ?? args.replace_all ?? args.all ?? false;

    if (!filePath) return { error: 'filePath required' };
    if (oldString == null) return { error: 'oldString required (you sent: ' + Object.keys(args).join(', ') + ')' };
    if (newString == null) return { error: 'newString required (you sent: ' + Object.keys(args).join(', ') + ')' };
    const np = normalizePath(filePath);
    if (!state.reads.has(np)) {
      return { error: `must call read on "${filePath}" before edit` };
    }
    let content = await VFS.read(sessionId, np);
    if (content == null) return { error: `file not found: ${filePath}` };
    if (oldString === newString) return { error: 'oldString and newString are identical' };
    if (oldString === '') return { error: 'oldString cannot be empty (use the write tool to create a new file or replace the whole content)' };

    // Detect regex-like patterns being passed as oldString — some models
    // confuse edit with a sed-style regex tool. Tell them clearly.
    if (looksLikeRegex(oldString)) {
      return {
        error:
          'oldString must be a literal substring of the file, NOT a regex pattern. ' +
          'Got something that looks like regex syntax: "' + oldString.slice(0, 80) + '". ' +
          'Re-read the file and copy the exact characters you want to replace.',
      };
    }

    // Auto-correct two of the most common edit failures we've observed:
    //
    //   1. Line-number prefix mistake: read returns lines as "<n>: text",
    //      and the model sometimes pastes those prefixes into oldString.
    //      Detect: every line of oldString starts with /^\d+:[ \t]?/.
    //      If so, strip the prefix and try the corrected version.
    //
    //   2. CRLF mismatch: file uses \n but model emitted \r\n (or vice
    //      versa). Normalize both sides to \n for comparison.
    //
    // We only auto-correct when the original oldString fails to match.
    // If the corrected version still doesn't match, return a diagnostic
    // error explaining what was tried so the model knows how to fix.
    function tryMatch(haystack, needle, prefix) {
      const idx = haystack.indexOf(needle);
      if (idx === -1) return null;
      const idx2 = haystack.indexOf(needle, idx + needle.length);
      return { idx, multiple: idx2 !== -1, needle, prefix };
    }
    function stripLinePrefixes(s) {
      const lines = s.split('\n');
      const re = /^\d+:[ \t]?/;
      if (!lines.every(l => l === '' || re.test(l))) return null;
      return lines.map(l => l.replace(re, '')).join('\n');
    }

    let m = tryMatch(content, oldString, 'exact');
    let normContent = null;
    let normOld = null;
    if (!m) {
      // Try CRLF normalization
      normContent = content.replace(/\r\n/g, '\n');
      normOld     = oldString.replace(/\r\n/g, '\n');
      if (normContent !== content || normOld !== oldString) {
        m = tryMatch(normContent, normOld, 'crlf-normalized');
        if (m) content = normContent;  // commit the normalization
      }
    }
    if (!m) {
      // Try stripping line-number prefixes from oldString
      const stripped = stripLinePrefixes(oldString);
      if (stripped) {
        m = tryMatch(content, stripped, 'prefix-stripped');
        if (!m && normContent) m = tryMatch(normContent, stripped.replace(/\r\n/g, '\n'), 'prefix-stripped-crlf');
      }
    }
    if (!m) {
      // Final attempt: trim trailing whitespace on each line on both sides
      const trim = s => s.split('\n').map(l => l.replace(/[ \t]+$/, '')).join('\n');
      const tc = trim(content);
      const to = trim(oldString);
      if (tc.indexOf(to) !== -1) {
        m = tryMatch(tc, to, 'trailing-ws-trimmed');
        if (m) content = tc;
      }
    }
    if (!m) {
      // Genuine miss — give the model actionable feedback
      const head = oldString.split('\n').slice(0, 3).join(' / ').slice(0, 120);
      return {
        error:
          `oldString not found in ${np}. Re-read the file to confirm exact ` +
          `content (don't include the "<n>: " line-number prefix from read), ` +
          `then retry. First line(s) of oldString tried: "${head}…"`,
      };
    }
    if (m.multiple && !replaceAll) {
      return {
        error:
          `Found multiple matches for oldString in ${np}. Provide more ` +
          `surrounding context to identify the correct match, or set ` +
          `replaceAll=true to replace every occurrence.`,
      };
    }

    // Perform the actual edit using the (possibly normalized) content
    let next;
    let count;
    if (replaceAll) {
      next = content.split(m.needle).join(newString);
      count = content.split(m.needle).length - 1;
    } else {
      next = content.slice(0, m.idx) + newString + content.slice(m.idx + m.needle.length);
      count = 1;
    }
    await VFS.write(sessionId, np, next);
    const note = m.prefix !== 'exact' ? ` (auto-corrected: ${m.prefix})` : '';
    return {
      ok: true,
      output: `edited ${np} (${count} replacement${count === 1 ? '' : 's'})${note}`,
      diff: makeUnifiedDiff(content, next),
    };
  },

  // ----- list
  async list({ path }, { sessionId }) {
    const items = await VFS.list(sessionId, path || '');
    items.sort((a, b) => {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    if (items.length === 0) return { ok: true, output: '(empty)' };
    const out = items.map(it => it.isDir ? `${it.name}/` : it.name).join('\n');
    return { ok: true, output: out, meta: { count: items.length } };
  },

  // ----- glob
  async glob({ pattern }, { sessionId }) {
    if (!pattern) return { error: 'pattern required' };
    const re = globToRegex(pattern);
    const all = await VFS.walk(sessionId, '');
    const matches = all.filter(f => re.test(f.path));
    matches.sort((a, b) => b.mtime - a.mtime);
    if (matches.length === 0) return { ok: true, output: '(no matches)' };
    return { ok: true, output: matches.map(m => m.path).join('\n'), meta: { count: matches.length } };
  },

  // ----- grep
  async grep({ pattern, path, include, ignoreCase }, { sessionId }) {
    if (!pattern) return { error: 'pattern required' };
    let re;
    try { re = new RegExp(pattern, ignoreCase ? 'i' : ''); }
    catch (e) { return { error: 'invalid regex: ' + e.message }; }
    const all = await VFS.walk(sessionId, path || '');
    const includeRe = include ? globToRegex(include) : null;
    const out = [];
    let total = 0;
    for (const f of all) {
      if (includeRe && !includeRe.test(f.path)) continue;
      const c = await VFS.read(sessionId, f.path);
      if (c == null) continue;
      const lines = c.split('\n');
      for (let i = 0; i < lines.length; i++) {
        if (re.test(lines[i])) {
          out.push(`${f.path}:${i+1}: ${lines[i].slice(0, 300)}`);
          total++;
          if (total >= 200) break;
        }
      }
      if (total >= 200) break;
    }
    if (out.length === 0) return { ok: true, output: '(no matches)' };
    return { ok: true, output: out.join('\n'), meta: { count: out.length } };
  },

  // ----- bash (emulated)
  async bash({ command }, { sessionId }) {
    if (!command) return { error: 'command required' };
    const trimmed = command.trim();

    // Dispatch on first token
    const first = trimmed.split(/\s+/)[0];
    const allowed = ['ls', 'cat', 'pwd', 'find', 'wc', 'echo', 'true', 'false'];
    if (!allowed.includes(first)) {
      return {
        error: `Bash is emulated in this sandbox. Command "${first}" is not supported. ` +
               `Allowed: ${allowed.join(', ')}. Use the read/write/edit/glob/grep tools instead of shell commands.`,
      };
    }
    if (first === 'pwd') return { ok: true, output: '/' };
    if (first === 'true') return { ok: true, output: '' };
    if (first === 'false') return { ok: true, output: '', exitCode: 1 };
    if (first === 'echo') {
      const rest = trimmed.slice(4).trim();
      // strip surrounding quotes
      const m = rest.match(/^["'](.*)["']$/);
      return { ok: true, output: m ? m[1] : rest };
    }
    if (first === 'ls') {
      const arg = trimmed.slice(2).trim() || '';
      const items = await VFS.list(sessionId, arg);
      items.sort((a, b) => a.name.localeCompare(b.name));
      return { ok: true, output: items.map(it => it.isDir ? it.name + '/' : it.name).join('\n') };
    }
    if (first === 'cat') {
      const arg = trimmed.slice(3).trim();
      const c = await VFS.read(sessionId, arg);
      if (c == null) return { error: `cat: ${arg}: no such file` };
      return { ok: true, output: clamp(c, 50000) };
    }
    if (first === 'find') {
      const all = await VFS.walk(sessionId, '');
      return { ok: true, output: all.map(f => f.path).join('\n') };
    }
    if (first === 'wc') {
      // wc -l <file>
      const tokens = trimmed.split(/\s+/);
      const file = tokens[tokens.length - 1];
      const c = await VFS.read(sessionId, file);
      if (c == null) return { error: `wc: ${file}: no such file` };
      const lines = c.split('\n').length;
      const words = c.trim().split(/\s+/).filter(Boolean).length;
      const bytes = c.length;
      return { ok: true, output: `${lines} ${words} ${bytes} ${file}` };
    }
  },

  // ----- webfetch
  //
  // Fetches a URL and returns its body. Many sites don't send CORS headers,
  // so direct fetches will fail; if a CORS proxy is configured (settings
  // .corsProxy), retry through it on failure. Format options: 'html', 'text',
  // 'markdown' — default strips tags to plain text.
  async webfetch({ url, format }, ctx) {
    if (!url) return { error: 'url required' };
    if (!/^https?:\/\//i.test(url)) return { error: 'url must start with http(s)://' };

    const proxy = ctx?.state?.corsProxy || (typeof window !== 'undefined' && window.opencodeWebSettings?.corsProxy);

    async function tryFetch(u) {
      const r = await fetch(u, {
        headers: { 'Accept': 'text/html,application/xhtml+xml,application/xml,text/plain,*/*;q=0.8' },
        redirect: 'follow',
      });
      if (!r.ok) throw new Error(`HTTP ${r.status} ${r.statusText}`);
      const ct = r.headers.get('content-type') || '';
      const text = await r.text();
      return { ct, text };
    }

    let result;
    let attempts = [];
    try {
      result = await tryFetch(url);
    } catch (e) {
      attempts.push('direct: ' + (e?.message || e));
      if (proxy) {
        const proxied = proxy.includes('{url}')
          ? proxy.replace('{url}', encodeURIComponent(url))
          : proxy.replace(/\/+$/, '') + '/' + url;
        try {
          result = await tryFetch(proxied);
        } catch (e2) {
          attempts.push('proxy: ' + (e2?.message || e2));
          return { error: 'fetch failed (' + attempts.join(', ') + ')' };
        }
      } else {
        return { error: 'fetch failed (' + attempts[0] + '). Configure settings.corsProxy to enable proxy fallback.' };
      }
    }

    const { ct, text } = result;
    if (format === 'html' || (!format && !ct.includes('text/html') && !ct.includes('xml'))) {
      return { ok: true, output: clamp(text, 60000) };
    }
    if (format === 'text' || format === 'markdown' || !format) {
      const stripped = htmlToText(text);
      return { ok: true, output: clamp(stripped, 60000) };
    }
    return { ok: true, output: clamp(text, 60000) };
  },

  // ----- websearch
  //
  // The web search problem in a sandboxed WebView: most search engines and
  // arbitrary sites don't send Access-Control-Allow-Origin, so direct
  // browser fetches fail with CORS errors. We solve this in three layers:
  //
  //   1. Wikipedia OpenSearch + REST summary API — fully CORS-enabled
  //      (with &origin=*), no key, free, returns titles + URLs + summaries
  //      for general topical queries. This is our primary source.
  //
  //   2. DuckDuckGo Instant Answer API — CORS-enabled but only returns
  //      curated answers for famous topics; useful for definitions,
  //      celebrities, products, etc. Used as a supplemental layer.
  //
  //   3. CORS proxy fallback — if the user has configured a proxy in
  //      settings (`settings.corsProxy`), we route DuckDuckGo HTML
  //      scraping through it for full general-web search. Off by default
  //      since users probably don't want to trust a third-party proxy.
  async websearch({ query, maxResults }, ctx) {
    if (!query) return { error: 'query required' };
    const max = Math.min(Math.max(1, maxResults || 5), 10);

    const lines = [];
    let any = false;

    // 1. Wikipedia OpenSearch — gives us titles + page URLs
    try {
      const wikiUrl = 'https://en.wikipedia.org/w/api.php?'
        + 'action=opensearch&format=json&namespace=0&origin=*'
        + '&limit=' + max
        + '&search=' + encodeURIComponent(query);
      const r = await fetch(wikiUrl);
      if (r.ok) {
        const data = await r.json();
        // OpenSearch shape: [query, [titles], [descriptions], [urls]]
        const titles = data[1] || [];
        const descs  = data[2] || [];
        const urls   = data[3] || [];
        if (titles.length) {
          lines.push('## Wikipedia');
          for (let i = 0; i < titles.length; i++) {
            const desc = descs[i] || '';
            lines.push(`${i+1}. ${titles[i]}`);
            lines.push(`   ${urls[i]}`);
            if (desc) lines.push(`   ${desc}`);
          }
          any = true;
        }
      }
    } catch (_) {
      // Continue — Wikipedia may be unavailable; fall through to other sources.
    }

    // 2. DuckDuckGo Instant Answer (curated answers, abstracts)
    try {
      const ddUrl = 'https://api.duckduckgo.com/?format=json&no_redirect=1&no_html=1&skip_disambig=1&q='
        + encodeURIComponent(query);
      const r = await fetch(ddUrl);
      if (r.ok) {
        const d = await r.json();
        const ddLines = [];
        if (d.AbstractText) {
          ddLines.push(`${d.Heading || query}`);
          if (d.AbstractURL) ddLines.push(`   ${d.AbstractURL}`);
          ddLines.push(`   ${d.AbstractText}`);
        }
        if (Array.isArray(d.RelatedTopics)) {
          let n = 0;
          for (const t of d.RelatedTopics) {
            if (n >= max) break;
            if (t.FirstURL && t.Text) {
              ddLines.push(`- ${t.Text}`);
              ddLines.push(`  ${t.FirstURL}`);
              n++;
            }
          }
        }
        if (ddLines.length) {
          if (any) lines.push('');
          lines.push('## DuckDuckGo');
          lines.push(...ddLines);
          any = true;
        }
      }
    } catch (_) {
      // Continue
    }

    // 3. Optional CORS proxy fallback for full DuckDuckGo HTML search
    const proxy = ctx?.state?.corsProxy || (typeof window !== 'undefined' && window.opencodeWebSettings?.corsProxy);
    if (!any && proxy) {
      try {
        const ddHtmlUrl = 'https://duckduckgo.com/html/?q=' + encodeURIComponent(query);
        const proxied = proxy.includes('{url}')
          ? proxy.replace('{url}', encodeURIComponent(ddHtmlUrl))
          : proxy.replace(/\/+$/, '') + '/' + ddHtmlUrl;
        const r = await fetch(proxied);
        if (r.ok) {
          const html = await r.text();
          const results = parseDDG(html, max);
          if (results.length) {
            lines.push('## Web');
            results.forEach((res, i) => {
              lines.push(`${i+1}. ${res.title}`);
              lines.push(`   ${res.url}`);
              if (res.snippet) lines.push(`   ${res.snippet}`);
            });
            any = true;
          }
        }
      } catch (_) {
        // Ignore — proxy may be down
      }
    }

    if (!any) {
      return {
        error:
          'No search results — all CORS-friendly sources returned empty. ' +
          'For broader web search, configure a CORS proxy in settings ' +
          '(corsProxy: "https://corsproxy.io/?url={url}" or similar).',
      };
    }
    return { ok: true, output: lines.join('\n') };
  },

  // ----- wikiimage
  //
  // Search Wikimedia Commons for images by topic. Wikimedia's API supports
  // CORS via origin=*. Returns up to N image URLs with titles.
  async wikiimage({ query, maxResults }) {
    if (!query) return { error: 'query required' };
    const max = Math.min(Math.max(1, maxResults || 5), 10);
    try {
      // Step 1: search for media files matching the query
      const searchUrl = 'https://commons.wikimedia.org/w/api.php?'
        + 'action=query&format=json&origin=*'
        + '&list=search&srnamespace=6'  // namespace 6 = File:
        + '&srlimit=' + max
        + '&srsearch=' + encodeURIComponent(query);
      const r = await fetch(searchUrl);
      if (!r.ok) return { error: `wikimedia search HTTP ${r.status}` };
      const data = await r.json();
      const hits = data?.query?.search || [];
      if (hits.length === 0) return { ok: true, output: '(no images found)' };

      // Step 2: resolve image URLs with imageinfo
      const titles = hits.map(h => h.title).join('|');
      const infoUrl = 'https://commons.wikimedia.org/w/api.php?'
        + 'action=query&format=json&origin=*'
        + '&prop=imageinfo&iiprop=url|extmetadata&iiurlwidth=800'
        + '&titles=' + encodeURIComponent(titles);
      const r2 = await fetch(infoUrl);
      if (!r2.ok) return { error: `imageinfo HTTP ${r2.status}` };
      const info = await r2.json();
      const pages = info?.query?.pages || {};
      const out = [];
      for (const [pid, page] of Object.entries(pages)) {
        const ii = page.imageinfo?.[0];
        if (!ii) continue;
        const title = (page.title || '').replace(/^File:/, '');
        const meta  = ii.extmetadata || {};
        const desc  = (meta.ImageDescription?.value || '').replace(/<[^>]+>/g, '').trim();
        out.push(`- ${title}`);
        out.push(`  ${ii.thumburl || ii.url}`);
        if (desc) out.push(`  ${desc.slice(0, 200)}${desc.length > 200 ? '…' : ''}`);
      }
      return { ok: true, output: out.join('\n') };
    } catch (e) {
      return { error: 'wikiimage failed: ' + (e?.message || e) };
    }
  },

  // ----- todowrite
  async todowrite({ todos }, { state }) {
    if (!Array.isArray(todos)) return { error: 'todos must be an array' };
    const VALID = ['pending', 'in_progress', 'done', 'completed', 'cancelled'];
    const cleaned = todos.map((t, i) => {
      // Normalize 'completed' → 'done' so downstream rendering is uniform.
      let status = String(t.status || 'pending');
      if (status === 'completed') status = 'done';
      if (!VALID.includes(status)) status = 'pending';
      return {
        id:     String(t.id || `t${i+1}`),
        text:   String(t.text || ''),
        status,
      };
    });
    state.todos = cleaned;
    const summary = cleaned.map(t => {
      const mark = t.status === 'done' ? 'x'
                 : t.status === 'in_progress' ? '~'
                 : t.status === 'cancelled' ? '-'
                 : ' ';
      return `[${mark}] ${t.text}`;
    }).join('\n');
    return { ok: true, output: summary || '(empty)' };
  },

  // ----- task (sub-agent delegation)
  // Spawns a fresh Agent with read-only tools. Returns its final text response.
  async task({ description, prompt }, { sessionId, state, spawnSubAgent }) {
    if (!prompt) return { error: 'prompt required' };
    if (typeof spawnSubAgent !== 'function') {
      return { error: 'sub-agent runtime unavailable in this context' };
    }
    const result = await spawnSubAgent({
      description: description || 'sub-task',
      prompt,
      // Sub-agent inherits the session's VFS but gets read-only tools.
      readOnly: true,
    });
    return {
      ok: true,
      output: result?.text || '(no response)',
      meta: { description: description || 'sub-task', steps: result?.steps || 0 },
    };
  },

  // ----- question (asks user, blocks the agent loop until reply)
  async question({ question }, { askUser }) {
    if (!question) return { error: 'question required' };
    if (typeof askUser !== 'function') {
      return { error: 'cannot prompt user from this context' };
    }
    const answer = await askUser(question);
    return { ok: true, output: `User answered: ${answer}` };
  },

  // ----- plan_exit (signals planning done; the agent loop catches this)
  async plan_exit({ plan }, { signalPlanExit }) {
    if (!plan) return { error: 'plan required' };
    if (typeof signalPlanExit === 'function') signalPlanExit(plan);
    return { ok: true, output: 'Plan finalized. Switch to build mode to execute.', planFinalized: true };
  },
};

// --------------------------------------------------- utilities

function normalizePath(p) {
  return (p || '').replace(/^\.?\//, '').replace(/\/+/g, '/').replace(/\/$/, '');
}

// Heuristic: does this string look like a regex pattern instead of literal text?
// Triggered by character classes ([\s\S], [a-z]+), escaped metachars (\s, \w,
// \d), wildcards (.*, .+, .*?), and anchor combos. Used by edit to bail out
// early when a model misuses the tool as if it were sed/grep, instead of
// silently failing and looping.
function looksLikeRegex(s) {
  if (!s || typeof s !== 'string') return false;
  if (s.length > 500) return false;            // long literal text won't be a pattern
  if (s.includes('\n')) return false;          // multi-line literals are typical edit targets

  let hits = 0;
  // /.../ delimited form
  if (/^\/.*\/[gimsuy]*$/.test(s.trim())) hits += 3;
  // Character class with regex escapes inside: [\s\S], [\w-]+, [a-z]
  if (/\[[^\]]*\\[swdSWD][^\]]*\]/.test(s)) hits += 3;
  if (/\[[a-zA-Z]-[a-zA-Z]\]/.test(s)) hits += 2;
  // Greedy/lazy wildcards
  if (/\.\*\??/.test(s) || /\.\+\??/.test(s)) hits += 2;
  // Quantifiers on grouping
  if (/\)[*+?]/.test(s) || /\][*+?]/.test(s)) hits += 1;
  // Anchored end-of-string
  if (/[^\\]\$$/.test(s) || /^\^/.test(s)) hits += 1;
  // Escaped regex metachars (\., \*, \+, \?) appearing in source
  const escapedMeta = (s.match(/\\[.*+?(){}|^$]/g) || []).length;
  if (escapedMeta >= 2) hits += 2;
  return hits >= 3;
}

function htmlToText(html) {
  // Drop scripts/styles
  html = html.replace(/<script[\s\S]*?<\/script>/gi, '')
             .replace(/<style[\s\S]*?<\/style>/gi, '')
             .replace(/<noscript[\s\S]*?<\/noscript>/gi, '');
  // Replace block elements with newlines
  html = html.replace(/<(br|p|div|li|tr|h\d|section|article|hr)[^>]*>/gi, '\n')
             .replace(/<\/(p|div|li|tr|h\d|section|article)>/gi, '\n');
  // Strip remaining tags
  html = html.replace(/<[^>]+>/g, '');
  // Decode entities (basic)
  html = html.replace(/&nbsp;/g, ' ')
             .replace(/&amp;/g, '&')
             .replace(/&lt;/g, '<')
             .replace(/&gt;/g, '>')
             .replace(/&quot;/g, '"')
             .replace(/&#39;/g, "'")
             .replace(/&#(\d+);/g, (m, n) => String.fromCharCode(parseInt(n, 10)));
  // Collapse whitespace
  html = html.replace(/[ \t]+/g, ' ').replace(/\n[ \t]*/g, '\n').replace(/\n{3,}/g, '\n\n');
  return html.trim();
}

function parseDDG(html, max) {
  const results = [];
  // DDG html version uses <a class="result__a" href="...">title</a> ... <a class="result__snippet">snippet</a>
  const re = /<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>([\s\S]*?)(?=<a[^>]+class="[^"]*result__a|$)/g;
  let m;
  while ((m = re.exec(html)) !== null && results.length < max) {
    let url = m[1];
    // DDG redirect strip
    const redir = url.match(/uddg=([^&]+)/);
    if (redir) try { url = decodeURIComponent(redir[1]); } catch {}
    if (url.startsWith('//')) url = 'https:' + url;
    const title = stripTags(m[2]).trim();
    const block = m[3];
    let snippet = '';
    const sm = block.match(/<a[^>]+class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>/);
    if (sm) snippet = stripTags(sm[1]).trim();
    if (title && url) results.push({ title, url, snippet });
  }
  return results;
}

function stripTags(s) {
  return s.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
}
