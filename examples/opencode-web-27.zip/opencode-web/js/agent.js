// Agent loop: connects to OpenRouter (OpenAI-compatible /chat/completions),
// streams responses, handles tool calls, persists messages to the session.

import { getToolSchemas, getToolNamesForMode, execTool, makeToolState } from './tools.js';
import { Sessions } from './storage.js';
import { buildSystemPrompt } from './prompts.js';

// Internal message format (similar to opencode's MessageV2.Part):
// {
//   id, role: 'user' | 'assistant' | 'tool',
//   parts: [
//     { type: 'text', text },
//     { type: 'tool_call', id, name, args, status: 'running'|'done'|'error', result?, output?, diff? },
//     { type: 'reasoning', text }      // for models that emit thinking
//   ],
//   ts
// }

export class Agent {
  /**
   * @param {object} cfg
   * @param {string} cfg.apiKey
   * @param {string} cfg.baseUrl
   * @param {string} cfg.modelId           — OpenRouter model id (provider/model)
   * @param {string} cfg.systemPrompt
   * @param {string} cfg.mode              — 'build' | 'plan'
   * @param {number} cfg.maxSteps
   * @param {string} cfg.sessionId
   * @param {Array}  cfg.messages          — existing message log (modified in place)
   * @param {object} cfg.handlers          — UI callbacks
   *   onUpdate(messages)
   *   onError(err)
   *   onDone()
   *   onToolStart(tc), onToolEnd(tc)
   */
  constructor(cfg) {
    this.cfg = cfg;
    this.abort = new AbortController();
    this.toolState = makeToolState();
    // Hydrate todos from session if the caller stashed them. This keeps the
    // checklist alive across app reloads — opencode does the same.
    if (Array.isArray(cfg.initialTodos)) this.toolState.todos = cfg.initialTodos;
    this.running = false;
    // Queue of messages typed by the user while the agent is mid-run.
    // Flushed into the conversation at the next loop boundary so the agent
    // picks them up without us having to stop+restart.
    this.injectQueue = [];
  }

  // Queue a user message to be appended to the conversation at the next
  // tool-loop boundary. Called from the UI when the user types & sends
  // while the agent is already running.
  injectUserMessage(text) {
    if (!text || !text.trim()) return;
    this.injectQueue.push(text.trim());
    this.cfg.handlers?.onInjectQueued?.(this.injectQueue.length);
  }

  stop() {
    this.abort.abort();
    this.running = false;
  }

  // Convert internal messages → OpenAI/OpenRouter chat format
  toOpenAIMessages(messages) {
    const out = [];
    if (this.cfg.systemPrompt) {
      out.push({ role: 'system', content: this.cfg.systemPrompt });
    }
    for (const m of messages) {
      if (m.role === 'user') {
        const text = m.parts.filter(p => p.type === 'text').map(p => p.text).join('\n');
        // Mid-run injects get a system-reminder wrapper so the model knows
        // this is the user adding context to an in-flight task, not a new
        // top-level instruction. Plain user messages pass through unchanged.
        const content = m.injected
          ? `<user-note>The user added this note while you were working. Take it into account, but continue the original task. If it changes the task, acknowledge briefly and adapt.</user-note>\n\n${text}`
          : text;
        out.push({ role: 'user', content });
      } else if (m.role === 'assistant') {
        // assistant turn: text + tool_calls
        const textParts = m.parts.filter(p => p.type === 'text').map(p => p.text).join('');
        const toolCalls = m.parts.filter(p => p.type === 'tool_call');
        const obj = { role: 'assistant', content: textParts || '' };
        if (toolCalls.length > 0) {
          obj.tool_calls = toolCalls.map(tc => ({
            id: tc.id,
            type: 'function',
            function: {
              name: tc.name,
              arguments: JSON.stringify(tc.args ?? {}),
            },
          }));
        }
        out.push(obj);
        // After assistant w/ tool_calls: emit one tool message per call.
        for (const tc of toolCalls) {
          out.push({
            role: 'tool',
            tool_call_id: tc.id,
            content: tc.output != null ? String(tc.output) : (tc.error || ''),
          });
        }
      }
    }
    return out;
  }

  buildToolsParam() {
    const schemas = getToolSchemas(this.cfg.mode);
    return schemas.map(s => ({
      type: 'function',
      function: {
        name: s.name,
        description: s.description,
        parameters: s.parameters,
      },
    }));
  }

  async run() {
    if (this.running) return;
    this.running = true;
    const { messages, handlers, sessionId } = this.cfg;

    let step = 0;
    const maxSteps = this.cfg.maxSteps || 40;

    try {
      while (step++ < maxSteps && !this.abort.signal.aborted) {
        // Flush any user notes typed while we were running. Each becomes a
        // synthetic user message wrapped in <user-note> so the model can
        // tell apart "primary instruction" from "by-the-way addition."
        if (this.injectQueue.length > 0) {
          const notes = this.injectQueue.splice(0);
          for (const text of notes) {
            messages.push({
              id: 'm_inj_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
              role: 'user',
              parts: [{ type: 'text', text }],
              ts: Date.now(),
              injected: true,
            });
          }
          await Sessions.setMessages(sessionId, messages);
          handlers.onUpdate(messages);
          handlers.onInjectFlushed?.(notes.length);
        }

        // New assistant message for this turn
        const asst = {
          id: 'm_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          role: 'assistant',
          parts: [],
          ts: Date.now(),
        };
        messages.push(asst);
        handlers.onUpdate(messages);

        const result = await this.streamOne(asst);

        // Persist after each step
        await Sessions.setMessages(sessionId, messages);

        if (this.abort.signal.aborted) break;

        if (result.toolCalls.length === 0) {
          // No tool calls — turn complete unless we got new injects
          if (this.injectQueue.length > 0) continue;
          break;
        }

        // Execute every tool call (sequentially for safety)
        for (const tc of result.toolCalls) {
          if (this.abort.signal.aborted) break;
          tc.status = 'running';
          handlers.onUpdate(messages);
          handlers.onToolStart?.(tc);

          const res = await execTool(tc.name, tc.args, {
            sessionId,
            state: this.toolState,
            askUser: (q) => this.askUser(q, tc),
            spawnSubAgent: (opts) => this.spawnSubAgent(opts),
            signalPlanExit: (plan) => { this.planExitFinal = plan; },
          });

          if (res.error) {
            tc.status = 'error';
            tc.error  = res.error;
            tc.output = res.error;
          } else {
            tc.status = 'done';
            tc.output = res.output ?? '';
            if (res.diff) tc.diff = res.diff;
            if (res.meta) tc.meta = res.meta;
          }
          // If the agent updated its todo list, broadcast to the UI so the
          // persistent todo panel can re-render in real time. Same data the
          // executor stashed in toolState.todos.
          if (tc.name === 'todowrite' && Array.isArray(this.toolState.todos)) {
            handlers.onTodos?.(this.toolState.todos);
          }
          handlers.onUpdate(messages);
          handlers.onToolEnd?.(tc);
          await Sessions.setMessages(sessionId, messages);
        }

        // loop again — model gets to see tool results
      }

      // If we exited because of the maxSteps cap (not because the model
      // stopped naturally with a final assistant message), surface that to
      // the UI so the user knows why the agent halted. Without this the
      // chat just goes quiet and the user thinks "is it broken?".
      if (step > maxSteps && !this.abort.signal.aborted) {
        const last = messages[messages.length - 1];
        const stoppedNaturally = last?.role === 'assistant'
          && (last.parts || []).every(p => p.type !== 'tool_call' || p.status === 'done' || p.status === 'error');
        if (!stoppedNaturally) {
          messages.push({
            id: 'm_halt_' + Date.now().toString(36),
            role: 'assistant',
            parts: [{
              type: 'text',
              text: `[agent halted — reached max steps (${maxSteps}). Increase max steps in settings if you want the agent to continue, or send a follow-up message.]`,
            }],
            ts: Date.now(),
          });
          handlers.onUpdate(messages);
          await Sessions.setMessages(sessionId, messages);
        }
      }

      handlers.onDone?.();
    } catch (e) {
      if (e?.name !== 'AbortError') {
        handlers.onError?.(e);
      }
    } finally {
      this.running = false;
      await Sessions.setMessages(sessionId, messages);
    }
  }

  // Pause the agent loop and wait for a user reply. The UI binds to this via
  // handlers.onAskUser({question, resolve}) — when the user submits, the UI
  // calls resolve(text), which unblocks this promise.
  askUser(question, toolCall) {
    return new Promise((resolve) => {
      const handler = this.cfg.handlers.onAskUser;
      if (typeof handler === 'function') {
        handler({ question, toolCall, resolve });
      } else {
        resolve('(no answer — UI does not support questions in this context)');
      }
    });
  }

  // Spawn a fresh, read-only sub-agent for the task tool.
  // It shares the parent's API config + sessionId (same VFS) but uses a
  // synthetic message log and read-only tool whitelist.
  async spawnSubAgent({ description, prompt, readOnly = true }) {
    const { apiKey, baseUrl, modelId, sessionId, systemPrompt } = this.cfg;
    const subMessages = [
      {
        id: 'sub_u_' + Date.now().toString(36),
        role: 'user',
        parts: [{ type: 'text', text: prompt }],
        ts: Date.now(),
      },
    ];
    // Sub-agent gets a slimmer prompt focused on the task.
    const subSystem =
      systemPrompt +
      '\n\n---\nYou are a sub-agent invoked via the `task` tool. ' +
      'You have read-only tools (read, glob, grep, webfetch, websearch, todowrite). ' +
      'Complete the focused task below and return a concise summary as your final message. ' +
      'Do not ask the user for clarification — make a reasonable interpretation and proceed.';
    const sub = new Agent({
      apiKey, baseUrl, modelId,
      systemPrompt: subSystem,
      mode: 'plan',  // plan mode = read-only set, plus plan_exit (harmless here)
      maxSteps: Math.min(this.cfg.maxSteps || 40, 15),
      sessionId,
      messages: subMessages,
      handlers: {
        onUpdate: () => {},
        onError:  () => {},
        onDone:   () => {},
      },
    });
    // Inherit the parent's abort: stopping the parent stops the sub.
    sub.abort = this.abort;
    await sub.run();
    // Pull text from the last assistant message.
    const last = [...subMessages].reverse().find(m => m.role === 'assistant');
    const text = last?.parts?.filter(p => p.type === 'text').map(p => p.text).join('').trim() || '';
    return { text, steps: subMessages.filter(m => m.role === 'assistant').length };
  }

  // Stream one assistant message. Returns { text, toolCalls }.
  async streamOne(asstMessage) {
    const { messages, handlers, apiKey, baseUrl, modelId } = this.cfg;
    const oaiMessages = this.toOpenAIMessages(messages.slice(0, -1)); // exclude the empty asst we just pushed
    const tools = this.buildToolsParam();

    const body = {
      model: modelId,
      messages: oaiMessages,
      tools: tools.length ? tools : undefined,
      tool_choice: tools.length ? 'auto' : undefined,
      stream: true,
      // Ask OpenRouter to include usage in the last SSE event so we can show
      // tokens consumed and aggregate context-fill across the session.
      usage: { include: true },
      // OpenRouter passthrough hints
      // temperature default
    };

    const url = (baseUrl || 'https://openrouter.ai/api/v1').replace(/\/+$/, '') + '/chat/completions';

    const r = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + apiKey,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://opencode-web.local',
        'X-Title': 'opencode (web)',
      },
      body: JSON.stringify(body),
      signal: this.abort.signal,
    });

    if (!r.ok) {
      const txt = await safeText(r);
      throw new Error(`OpenRouter ${r.status}: ${txt}`);
    }
    if (!r.body) throw new Error('no response body');

    // Streaming SSE parser
    const reader = r.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';

    // Collected text + tool_calls. tool_calls is keyed by index.
    let textPart = null;       // {type:'text', text:''}
    let reasoningPart = null;  // {type:'reasoning', text:''}
    const toolCallsByIdx = new Map();

    while (true) {
      if (this.abort.signal.aborted) break;
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // SSE: events separated by \n\n; lines start with "data: "
      let idx;
      while ((idx = buffer.indexOf('\n\n')) !== -1) {
        const event = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 2);
        for (const rawLine of event.split('\n')) {
          const line = rawLine.trim();
          if (!line || !line.startsWith('data:')) continue;
          const payload = line.slice(5).trim();
          if (payload === '[DONE]') { buffer = ''; break; }
          let ev;
          try { ev = JSON.parse(payload); } catch { continue; }
          this.consumeStreamEvent(ev, asstMessage, { textPartRef: () => textPart, setTextPart: p => textPart = p, reasoningRef: () => reasoningPart, setReasoning: p => reasoningPart = p, toolCallsByIdx });
          handlers.onUpdate(messages);
        }
      }
    }

    // Settle text part
    const tcArr = Array.from(toolCallsByIdx.values()).map(tc => {
      let parsedArgs = {};
      try { parsedArgs = tc.argsStr ? JSON.parse(tc.argsStr) : {}; }
      catch (e) { parsedArgs = { __parseError: true, raw: tc.argsStr }; }
      tc.args = parsedArgs;
      delete tc.argsStr;
      return tc;
    });
    return {
      text: textPart?.text || '',
      toolCalls: tcArr,
    };
  }

  consumeStreamEvent(ev, asstMessage, helpers) {
    // OpenRouter sends `usage` in the final SSE chunk (when usage.include
    // was requested). It can arrive on the same event as choices or, for
    // some providers, on a final event with empty choices array.
    if (ev.usage) {
      this.lastUsage = ev.usage;
      // Notify caller via handler for live updates (e.g. usage strip)
      if (typeof this.cfg.handlers?.onUsage === 'function') {
        try { this.cfg.handlers.onUsage(ev.usage); } catch {}
      }
    }
    // OpenAI/OpenRouter format
    const choice = ev.choices?.[0];
    if (!choice) return;
    const delta = choice.delta || {};

    // 1. Text content
    if (typeof delta.content === 'string' && delta.content.length > 0) {
      let tp = helpers.textPartRef();
      if (!tp) {
        tp = { type: 'text', text: '' };
        asstMessage.parts.push(tp);
        helpers.setTextPart(tp);
      }
      tp.text += delta.content;
    }

    // 2. Reasoning content (some models, e.g. deepseek-r1)
    if (typeof delta.reasoning === 'string' && delta.reasoning.length > 0) {
      let rp = helpers.reasoningRef();
      if (!rp) {
        rp = { type: 'reasoning', text: '' };
        asstMessage.parts.push(rp);
        helpers.setReasoning(rp);
      }
      rp.text += delta.reasoning;
    }
    // OpenRouter sometimes uses reasoning_content
    if (typeof delta.reasoning_content === 'string' && delta.reasoning_content.length > 0) {
      let rp = helpers.reasoningRef();
      if (!rp) {
        rp = { type: 'reasoning', text: '' };
        asstMessage.parts.push(rp);
        helpers.setReasoning(rp);
      }
      rp.text += delta.reasoning_content;
    }

    // 3. Tool calls
    if (Array.isArray(delta.tool_calls)) {
      for (const tcDelta of delta.tool_calls) {
        const idx = tcDelta.index ?? 0;
        let tc = helpers.toolCallsByIdx.get(idx);
        if (!tc) {
          tc = {
            type: 'tool_call',
            id: tcDelta.id || ('tc_' + Date.now().toString(36) + Math.random().toString(36).slice(2,6)),
            name: tcDelta.function?.name || '',
            argsStr: '',
            status: 'pending',
          };
          helpers.toolCallsByIdx.set(idx, tc);
          asstMessage.parts.push(tc);
        }
        if (tcDelta.id && !tc.id) tc.id = tcDelta.id;
        if (tcDelta.function?.name) tc.name = tcDelta.function.name;
        if (typeof tcDelta.function?.arguments === 'string') {
          tc.argsStr += tcDelta.function.arguments;
        }
      }
    }
  }
}

async function safeText(r) {
  try { return await r.text(); } catch { return r.statusText; }
}
