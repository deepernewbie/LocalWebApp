// Storage layer — wraps AndroidFS with localStorage/IDB fallback.
// Two namespaces:
//   - app data (settings, sessions): lives in localStorage + AndroidFS mirror
//   - simulated project files: AndroidFS-backed virtual file system rooted at projects/<id>/

const hasFS = typeof window !== 'undefined'
           && window.AndroidFS
           && typeof window.AndroidFS.read === 'function';

export const inCouchFlow = !!window.CouchFlow;

// ---------------------------------------------------------------- KV (settings, sessions index)

const LS_PREFIX = 'couchcode:';

export const KV = {
  async get(key) {
    // Prefer AndroidFS for cross-device portability when present
    if (hasFS) {
      try {
        const text = await AndroidFS.read(`couchcode/${key}.json`);
        if (text != null) return JSON.parse(text);
      } catch (e) { console.warn('KV.get fs', key, e); }
    }
    const raw = localStorage.getItem(LS_PREFIX + key);
    if (raw == null) return null;
    try { return JSON.parse(raw); } catch { return null; }
  },

  async set(key, value) {
    const text = JSON.stringify(value, null, 2);
    localStorage.setItem(LS_PREFIX + key, text);
    if (hasFS) {
      try { await AndroidFS.write(`couchcode/${key}.json`, text); }
      catch (e) { console.warn('KV.set fs', key, e); }
    }
  },

  async del(key) {
    localStorage.removeItem(LS_PREFIX + key);
    if (hasFS) {
      try { await AndroidFS.delete(`couchcode/${key}.json`); }
      catch (e) {}
    }
  },
};

// ---------------------------------------------------------------- Sessions

const SESSIONS_KEY = 'sessions';

export const Sessions = {
  async list() {
    return (await KV.get(SESSIONS_KEY)) || [];
  },

  async save(list) {
    await KV.set(SESSIONS_KEY, list);
  },

  async create({ title, model, mode = 'build' }) {
    const id = 'ses_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const sess = {
      id,
      title: title || 'new session',
      model: model || null,
      mode,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messageCount: 0,
    };
    const all = await this.list();
    all.unshift(sess);
    await this.save(all);
    await KV.set(`session/${id}`, { meta: sess, messages: [] });
    return sess;
  },

  async load(id) {
    return await KV.get(`session/${id}`);
  },

  async update(id, patch) {
    const all = await this.list();
    const idx = all.findIndex(s => s.id === id);
    if (idx >= 0) {
      all[idx] = { ...all[idx], ...patch, updatedAt: Date.now() };
      await this.save(all);
    }
    const stored = await KV.get(`session/${id}`);
    if (stored) {
      stored.meta = { ...stored.meta, ...patch, updatedAt: Date.now() };
      await KV.set(`session/${id}`, stored);
    }
  },

  async setMessages(id, messages) {
    const stored = await KV.get(`session/${id}`) || { meta: {}, messages: [] };
    stored.messages = messages;
    stored.meta = stored.meta || {};
    stored.meta.updatedAt = Date.now();
    stored.meta.messageCount = messages.length;
    await KV.set(`session/${id}`, stored);
    // sync the index too
    const all = await this.list();
    const idx = all.findIndex(s => s.id === id);
    if (idx >= 0) {
      all[idx].updatedAt = Date.now();
      all[idx].messageCount = messages.length;
      await this.save(all);
    }
  },

  async delete(id) {
    const all = (await this.list()).filter(s => s.id !== id);
    await this.save(all);
    await KV.del(`session/${id}`);
    // also remove the project sandbox tied to this session
    await VFS.removeProject(id);
  },
};

// ---------------------------------------------------------------- VFS — virtual file system
// Each session has its own sandbox at projects/<sessionId>/...
// All paths are relative to the project root. The agent sees clean paths
// like "src/app.js", we store under a real folder underneath.

function projRoot(sessionId) {
  return `couchcode/projects/${sessionId}`;
}

function joinPath(root, p) {
  // normalize p: strip leading /, collapse ..
  if (!p || p === '/' || p === '.') return root;
  let parts = p.split(/[\/]+/).filter(Boolean);
  const stack = [];
  for (const part of parts) {
    if (part === '.') continue;
    if (part === '..') { stack.pop(); continue; }
    stack.push(part);
  }
  return root + (stack.length ? '/' + stack.join('/') : '');
}

function normalize(p) {
  if (!p || p === '/') return '';
  let parts = p.split(/[\/]+/).filter(Boolean);
  const stack = [];
  for (const part of parts) {
    if (part === '.') continue;
    if (part === '..') { stack.pop(); continue; }
    stack.push(part);
  }
  return stack.join('/');
}

// Browser fallback: keep the entire VFS in localStorage as a single index.
// Format: { "<sessionId>/<path>": "content", ... }  (binary not supported here)
const FALLBACK_VFS_KEY = LS_PREFIX + 'vfs';
function loadFallback() {
  try { return JSON.parse(localStorage.getItem(FALLBACK_VFS_KEY) || '{}'); } catch { return {}; }
}
function saveFallback(obj) {
  localStorage.setItem(FALLBACK_VFS_KEY, JSON.stringify(obj));
}

export const VFS = {
  hasNative: hasFS,

  async read(sessionId, path) {
    const norm = normalize(path);
    if (hasFS) {
      const real = `${projRoot(sessionId)}/${norm}`;
      const text = await AndroidFS.read(real);
      return text;  // null when missing
    }
    const all = loadFallback();
    const key = `${sessionId}/${norm}`;
    return Object.prototype.hasOwnProperty.call(all, key) ? all[key] : null;
  },

  async write(sessionId, path, content) {
    const norm = normalize(path);
    if (!norm) throw new Error('invalid path: ' + path);
    if (hasFS) {
      const real = `${projRoot(sessionId)}/${norm}`;
      const ok = await AndroidFS.write(real, content);
      if (!ok) throw new Error('write failed');
      return true;
    }
    const all = loadFallback();
    all[`${sessionId}/${norm}`] = content;
    saveFallback(all);
    return true;
  },

  async delete(sessionId, path) {
    const norm = normalize(path);
    if (hasFS) {
      const real = `${projRoot(sessionId)}/${norm}`;
      // first check stat — recurse if dir
      const s = await AndroidFS.stat(real);
      if (s?.isDir) {
        const list = await AndroidFS.list(real);
        for (const child of list) {
          await this.delete(sessionId, `${norm}/${child}`);
        }
      }
      return await AndroidFS.delete(real);
    }
    const all = loadFallback();
    const prefix = `${sessionId}/${norm}`;
    let any = false;
    for (const k of Object.keys(all)) {
      if (k === prefix || k.startsWith(prefix + '/')) {
        delete all[k]; any = true;
      }
    }
    saveFallback(all);
    return any;
  },

  async exists(sessionId, path) {
    const norm = normalize(path);
    if (hasFS) {
      const real = `${projRoot(sessionId)}/${norm}`;
      return await AndroidFS.exists(real);
    }
    const all = loadFallback();
    const key = `${sessionId}/${norm}`;
    if (Object.prototype.hasOwnProperty.call(all, key)) return true;
    // check if it's a directory (any descendant exists)
    const dirPrefix = key + '/';
    for (const k of Object.keys(all)) if (k.startsWith(dirPrefix)) return true;
    return false;
  },

  async stat(sessionId, path) {
    const norm = normalize(path);
    if (hasFS) {
      const real = `${projRoot(sessionId)}/${norm}`;
      return await AndroidFS.stat(real);
    }
    const all = loadFallback();
    const key = `${sessionId}/${norm}`;
    if (Object.prototype.hasOwnProperty.call(all, key)) {
      const c = all[key];
      return { size: c.length, mtime: Date.now(), isDir: false };
    }
    const dirPrefix = key + '/';
    for (const k of Object.keys(all)) if (k.startsWith(dirPrefix)) {
      return { size: 0, mtime: Date.now(), isDir: true };
    }
    return null;
  },

  async mkdir(sessionId, path) {
    const norm = normalize(path);
    if (!norm) return true;
    if (hasFS) {
      const real = `${projRoot(sessionId)}/${norm}`;
      return await AndroidFS.mkdir(real);
    }
    // No-op in fallback — directories are implicit
    return true;
  },

  // List immediate children. Returns [{name, isDir, size, mtime}].
  async list(sessionId, path) {
    const norm = normalize(path);
    if (hasFS) {
      const real = norm ? `${projRoot(sessionId)}/${norm}` : projRoot(sessionId);
      const exists = await AndroidFS.exists(real);
      if (!exists) return [];
      const names = (await AndroidFS.list(real)) || [];
      const items = await Promise.all(names.map(async (name) => {
        const s = await AndroidFS.stat(`${real}/${name}`);
        return {
          name,
          isDir: !!s?.isDir,
          size: s?.size ?? 0,
          mtime: s?.mtime ?? 0,
        };
      }));
      return items;
    }
    const all = loadFallback();
    const dirKey = norm ? `${sessionId}/${norm}/` : `${sessionId}/`;
    const seen = new Map();
    for (const k of Object.keys(all)) {
      if (!k.startsWith(dirKey)) continue;
      const rest = k.slice(dirKey.length);
      const slash = rest.indexOf('/');
      if (slash === -1) {
        // file directly in this dir
        if (!seen.has(rest)) {
          seen.set(rest, { name: rest, isDir: false, size: all[k].length, mtime: Date.now() });
        }
      } else {
        const name = rest.slice(0, slash);
        if (!seen.has(name)) {
          seen.set(name, { name, isDir: true, size: 0, mtime: Date.now() });
        }
      }
    }
    return Array.from(seen.values());
  },

  // Walk all files under `path` recursively. Returns [{path, size, mtime}].
  async walk(sessionId, path = '') {
    const out = [];
    const stack = [normalize(path)];
    while (stack.length) {
      const cur = stack.pop();
      const items = await this.list(sessionId, cur);
      for (const it of items) {
        const full = cur ? `${cur}/${it.name}` : it.name;
        if (it.isDir) stack.push(full);
        else out.push({ path: full, size: it.size, mtime: it.mtime });
      }
    }
    return out;
  },

  // Whole project: returns { path: content }. Used for export.
  async snapshot(sessionId) {
    const out = {};
    const files = await this.walk(sessionId, '');
    for (const f of files) {
      const c = await this.read(sessionId, f.path);
      if (c != null) out[f.path] = c;
    }
    return out;
  },

  async removeProject(sessionId) {
    if (hasFS) {
      const real = projRoot(sessionId);
      if (await AndroidFS.exists(real)) {
        // recursive delete via our delete()
        await this.delete(sessionId, '');
        await AndroidFS.delete(real);
      }
    } else {
      const all = loadFallback();
      const prefix = sessionId + '/';
      for (const k of Object.keys(all)) if (k.startsWith(prefix)) delete all[k];
      saveFallback(all);
    }
  },
};
