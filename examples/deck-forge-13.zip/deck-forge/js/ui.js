// ui.js - lightweight UI helpers

export function toast(msg, ms = 2500) {
  if (typeof Android !== 'undefined' && Android.toast) {
    Android.toast(msg);
    return;
  }
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), ms);
}

export function vibrate() {
  if (typeof Android !== 'undefined' && Android.vibrate) Android.vibrate();
  else if (navigator.vibrate) navigator.vibrate(30);
}

export function modal({ title, subtitle, content, actions }) {
  return new Promise(resolve => {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    const box = document.createElement('div');
    box.className = 'modal';
    box.innerHTML = `
      <h3>${escapeHtml(title || '')}</h3>
      ${subtitle ? `<div class="sub">${escapeHtml(subtitle)}</div>` : ''}
      <div class="modal-body"></div>
      <div class="modal-actions" style="display:flex;gap:10px;margin-top:16px"></div>
    `;
    const bodyEl = box.querySelector('.modal-body');
    const actionsEl = box.querySelector('.modal-actions');

    if (typeof content === 'string') bodyEl.innerHTML = content;
    else if (content instanceof Node) bodyEl.appendChild(content);

    const close = (val) => { backdrop.remove(); resolve(val); };

    (actions || [{ label: 'Close', kind: 'ghost', value: null }]).forEach(a => {
      const b = document.createElement('button');
      b.className = 'btn btn-' + (a.kind || 'ghost');
      if (a.kind === 'primary' || a.kind === 'danger') b.style.flex = '1';
      else b.style.flex = '1';
      b.textContent = a.label;
      b.onclick = async () => {
        if (a.onClick) {
          const r = await a.onClick(box);
          if (r === false) return; // validation failed
          close(r ?? a.value);
        } else {
          close(a.value);
        }
      };
      actionsEl.appendChild(b);
    });

    backdrop.addEventListener('click', e => { if (e.target === backdrop) close(null); });
    backdrop.appendChild(box);
    document.body.appendChild(backdrop);
  });
}

export function confirm(message, title = 'Confirm') {
  return modal({
    title,
    content: `<div style="font-size:14px;color:var(--ink-soft);line-height:1.5">${escapeHtml(message)}</div>`,
    actions: [
      { label: 'Cancel', kind: 'ghost', value: false },
      { label: 'OK', kind: 'primary', value: true }
    ]
  });
}

export function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c =>
    ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

export function icon(name, size = 20) {
  const icons = {
    plus: 'M12 5v14M5 12h14',
    back: 'M15 18l-6-6 6-6',
    settings: 'M12 15a3 3 0 100-6 3 3 0 000 6zm7.5-3c0 .35-.03.69-.08 1.02l2.11 1.65a.5.5 0 01.12.64l-2 3.46a.5.5 0 01-.61.22l-2.49-1a7.03 7.03 0 01-1.77 1.02l-.38 2.65a.5.5 0 01-.5.43h-4a.5.5 0 01-.5-.43l-.38-2.65a7.03 7.03 0 01-1.77-1.02l-2.49 1a.5.5 0 01-.61-.22l-2-3.46a.5.5 0 01.12-.64l2.11-1.65A7.1 7.1 0 014.5 12c0-.35.03-.69.08-1.02L2.47 9.33a.5.5 0 01-.12-.64l2-3.46a.5.5 0 01.61-.22l2.49 1a7.03 7.03 0 011.77-1.02l.38-2.65A.5.5 0 0110.1 2h4a.5.5 0 01.5.43l.38 2.65a7.03 7.03 0 011.77 1.02l2.49-1a.5.5 0 01.61.22l2 3.46a.5.5 0 01-.12.64l-2.11 1.65c.05.33.08.67.08 1.02z',
    trash: 'M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6',
    edit: 'M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7M18.5 2.5a2.1 2.1 0 113 3L12 15l-4 1 1-4 9.5-9.5z',
    eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 15a3 3 0 100-6 3 3 0 000 6z',
    check: 'M20 6L9 17l-5-5',
    x: 'M18 6L6 18M6 6l12 12',
    play: 'M5 3l14 9-14 9V3z',
    save: 'M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2zM17 21v-8H7v8M7 3v5h8'
  };
  const d = icons[name] || '';
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="${size}" height="${size}">${d.includes('z') || d.split(' ').length > 4 ? `<path d="${d}"/>` : `<path d="${d}"/>`}</svg>`;
}
