// storage.js - thin wrapper over AndroidFS with localStorage fallback

const hasFS = typeof window !== 'undefined'
           && window.AndroidFS
           && typeof window.AndroidFS.read === 'function';

export const isNative = hasFS;

// ---- text ----

export async function readText(path) {
  if (hasFS) return await AndroidFS.read(path);
  return localStorage.getItem('fs::' + path);
}

export async function writeText(path, text) {
  if (hasFS) return await AndroidFS.write(path, text);
  localStorage.setItem('fs::' + path, text);
  return true;
}

// ---- json ----

export async function readJSON(path, fallback = null) {
  const t = await readText(path);
  if (!t) return fallback;
  try { return JSON.parse(t); } catch { return fallback; }
}

export async function writeJSON(path, data) {
  return await writeText(path, JSON.stringify(data, null, 2));
}

// ---- binary ----

export async function writeBytes(path, u8) {
  if (hasFS) return await AndroidFS.writeBytes(path, u8);
  // browser fallback — stash as base64 in localStorage
  const b64 = btoa(String.fromCharCode(...u8));
  localStorage.setItem('fs::' + path, 'B64:' + b64);
  return true;
}

export async function readBytes(path) {
  if (hasFS) return await AndroidFS.readBytes(path);
  const v = localStorage.getItem('fs::' + path);
  if (!v || !v.startsWith('B64:')) return null;
  const b64 = v.slice(4);
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

// ---- fs ops ----

export async function list(path) {
  if (hasFS) return await AndroidFS.list(path);
  // browser fallback — scan localStorage keys
  const prefix = 'fs::' + path.replace(/\/$/, '') + '/';
  const names = new Set();
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(prefix)) {
      const rest = k.slice(prefix.length);
      names.add(rest.split('/')[0]);
    }
  }
  return Array.from(names);
}

export async function exists(path) {
  if (hasFS) return await AndroidFS.exists(path);
  return localStorage.getItem('fs::' + path) !== null;
}

export async function mkdir(path) {
  if (hasFS) return await AndroidFS.mkdir(path);
  return true;
}

export async function remove(path) {
  if (hasFS) return await AndroidFS.delete(path);
  localStorage.removeItem('fs::' + path);
  return true;
}

// ---- helpers ----

export function slugify(s) {
  return s.toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 50) || 'untitled';
}

export function shortId() {
  return Math.random().toString(36).slice(2, 8);
}
