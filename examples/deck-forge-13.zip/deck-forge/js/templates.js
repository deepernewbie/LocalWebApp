// templates.js - registry + shared renderer + in-browser edit mode runtime

import { TEMPLATES_CORE } from './templates-core.js';
import { TEMPLATES_EXTRA_1 } from './templates-extra-1.js';
import { TEMPLATES_EXTRA_2 } from './templates-extra-2.js';
import { TEMPLATES_EXTRA_3 } from './templates-extra-3.js';
import { TEMPLATES_EXTRA_4 } from './templates-extra-4.js';

export const TEMPLATES = [
  ...TEMPLATES_CORE,
  ...TEMPLATES_EXTRA_1,
  ...TEMPLATES_EXTRA_2,
  ...TEMPLATES_EXTRA_3,
  ...TEMPLATES_EXTRA_4
];

export function getTemplate(id) {
  return TEMPLATES.find(t => t.id === id) || TEMPLATES[0];
}

// ============================================================
// SHARED SHELL: every template produces HTML that wraps its
// per-slide markup with a common navigation + edit-mode runtime.
// ============================================================

export function renderPresentation(project, template, opts = {}) {
  const { mode = 'auto', editable = false } = opts;
  const slides = project.slides || [];
  const slidesHtml = slides.map((s, i) => renderSlide(template, s, i, slides.length, project, editable)).join('\n');

  // Collect speaker notes per slide (indexed by position). Present iff at
  // least one slide has notes.
  const notes = slides.map(s => s.speakerNotes || '');
  const hasAnyNotes = notes.some(n => n && n.trim());
  const notesJsonLiteral = JSON.stringify(notes);

  const viewportMeta = mode === 'desktop'
    ? '<meta name="viewport" content="width=1280,initial-scale=1">'
    : '<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">';

  const sizingVars = mode === 'desktop'
    ? '--deck-base: min(100vw, calc(100vh * 16 / 9)); --slide-pad: 6vmin;'
    : mode === 'mobile'
    ? '--deck-base: 100vw; --slide-pad: 5vw;'
    : '--deck-base: 100vw; --slide-pad: clamp(24px, 5vw, 80px);';

  return `<!DOCTYPE html>
<html lang="${esc(project.language || 'en')}" data-mode="${mode}">
<head>
<meta charset="UTF-8">
${viewportMeta}
<title>${esc(project.topic)}</title>
${template.fonts || ''}
<style>
:root { ${sizingVars} ${template.vars || ''} }
${BASE_CSS}
${hasAnyNotes ? NOTES_CSS : ''}
${template.css}
${editable ? EDIT_MODE_CSS : ''}
</style>
</head>
<body class="tpl-${template.id} lang-${project.language || 'en'}${mode === 'desktop' ? ' mode-desktop' : ''}${mode === 'mobile' ? ' mode-mobile' : ''}${editable ? ' editable' : ''}">
<div class="deck">
${slidesHtml}
</div>
${NAV_UI}
${hasAnyNotes ? NOTES_UI : ''}
${NAV_SCRIPT}
${hasAnyNotes ? buildNotesScript(notesJsonLiteral) : ''}
${editable ? EDIT_MODE_SCRIPT : ''}
</body>
</html>`;
}

function renderSlide(template, slide, i, total, project, editable) {
  const ctx = {
    slide, index: i, total, project,
    isCover: i === 0,
    isEnd: i === total - 1,
    role: slide.role || (i === 0 ? 'cover' : (i === total - 1 ? 'conclusion' : 'content')),
    editable,
    esc, bullets, img, ed, imgSrc
  };
  let html = template.render(ctx);
  // Tag slides that contain an image so CSS can apply a landscape 2-column
  // layout in desktop mode without relying on :has() (older Android WebView
  // didn't support it). We modify the first <section class="slide ...">
  // occurrence — templates consistently use that pattern.
  if (imgSrc(slide)) {
    html = html.replace(/<section class="slide([^"]*)"/, '<section class="slide has-image$1"');
  }
  return html;
}

// ---- Helpers used by templates ----

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function bullets(arr, extraClass = '') {
  if (!Array.isArray(arr) || !arr.length) return '';
  return `<ul class="${extraClass}">` + arr.map((b, k) => `<li data-field="bullets" data-idx="${k}">${esc(b)}</li>`).join('') + '</ul>';
}

function imgSrc(slide) {
  if (slide.localImage) return `images/${slide.localImage}`;
  if (slide.imageUrl) return slide.imageUrl;
  return null;
}

function img(slide, cls = '') {
  const src = imgSrc(slide);
  if (!src) return '';
  return `<img src="${esc(src)}" alt="${esc(slide.imageCaption || slide.title || '')}" class="${cls}" loading="lazy">`;
}

// Editable field wrapper
function ed(field, text, tag = 'div', idx = null) {
  const attrs = `data-field="${field}"${idx !== null ? ` data-idx="${idx}"` : ''}`;
  return `<${tag} ${attrs}>${esc(text)}</${tag}>`;
}

// ============================================================
// BASE CSS shared by every template
// ============================================================

const BASE_CSS = `
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { height: 100%; overflow: hidden; }
body { font-size: 16px; }
.deck { position: relative; width: 100%; height: 100vh; }
.slide {
  position: absolute; inset: 0;
  display: none; flex-direction: column;
  padding: var(--slide-pad);
  overflow: hidden;
  /* Children shrink if needed so the title stays visible and bullets don't push
     the title out of view. Individual elements use flex-shrink to control how
     much they can compress. */
}
.slide.active { display: flex; }
/* Title-level elements never shrink and stay pinned at the top of the flow. */
.slide > h1, .slide > h2,
.slide > .kicker, .slide > .section-label, .slide > .article,
.slide > .tag, .slide > .tag-label, .slide > .breadcrumb,
.slide > .monogram, .slide > .ornament, .slide > .sys,
.slide > .japanese, .slide > .kanji, .slide > .emoji,
.slide > .title-box {
  flex-shrink: 0;
}
/* Body and bullet lists may shrink and scroll internally if content is long,
   so the slide never grows beyond its fixed size and pushes the title out. */
.slide > .body, .slide > p {
  flex-shrink: 1;
  min-height: 0;
  overflow: hidden;
}
.slide > ul, .slide > ol {
  flex-shrink: 1;
  min-height: 0;
  overflow: hidden;
}
/* Subtitle can shrink but usually doesn't need to. */
.slide > .subtitle {
  flex-shrink: 0;
}
.slide img {
  max-width: 100%; height: auto; object-fit: cover;
  flex-shrink: 1;
  min-height: 0;
}

/* Shared nav UI (can be overridden by templates) */
.deck-nav {
  position: fixed; z-index: 100;
  bottom: 14px; right: 18px;
  display: flex; gap: 8px; align-items: center;
  font-size: 12px;
  background: rgba(0,0,0,0.12); backdrop-filter: blur(8px);
  padding: 6px 10px; border-radius: 20px;
}
.nav-btn {
  width: 32px; height: 32px; border-radius: 50%;
  background: rgba(255,255,255,0.1); border: 1px solid currentColor;
  color: inherit; cursor: pointer; font-size: 16px;
  display: grid; place-items: center;
  font-family: inherit;
}
.nav-btn:hover { background: rgba(255,255,255,0.2); }
.nav-counter { font-family: inherit; opacity: 0.8; min-width: 40px; text-align: center; }
.deck-progress {
  position: fixed; top: 0; left: 0; height: 3px;
  width: var(--progress, 0%); z-index: 101;
  background: currentColor; transition: width 0.3s;
}

/* ==================================================================
   Desktop mode: the document is a fixed 1280x720 canvas. When the
   viewport is larger or smaller, a CSS transform scales the whole
   canvas to fit while preserving the 16:9 aspect ratio.

   We deliberately do NOT override the body background in desktop
   mode. Templates set their own body backgrounds (cream, dark navy,
   etc.) and text colors are chosen to contrast with them. Forcing
   a black body breaks templates where the slide doesn't cover its
   full area — you end up with dark text on black. If the viewport
   is wider than 16:9, the template's body color simply extends
   into the surrounding area, which usually looks fine.

   Media queries inside templates see the 1280px virtual width —
   their mobile fallbacks don't fire.
   ================================================================== */
body.mode-desktop {
  overflow: hidden;
  margin: 0;
  padding: 0;
}
body.mode-desktop .deck {
  position: fixed;
  top: 0; left: 0;
  width: 1280px;
  height: 720px;
  transform-origin: top left;
  --scale: min(calc(100vw / 1280), calc(100vh / 720));
  transform: translate(
    calc((100vw - 1280px * var(--scale)) / 2),
    calc((100vh - 720px * var(--scale)) / 2)
  ) scale(var(--scale));
  box-shadow: 0 0 0 9999px rgba(0,0,0,0.15), 0 20px 80px rgba(0,0,0,0.4);
  overflow: hidden;
  /* Inherit the template's body background so the deck matches the
     template exactly. */
  background: inherit;
}
body.mode-desktop .slide {
  width: 1280px;
  height: 720px;
}
/* Nav, progress and notes button stay in viewport coordinates so they're
   readable regardless of scale factor. */
body.mode-desktop .deck-nav { position: fixed; bottom: 20px; right: 24px; z-index: 1000; transform: none; }
body.mode-desktop .deck-progress { position: fixed; top: 0; left: 0; z-index: 1001; }
body.mode-desktop .notes-btn { position: fixed; bottom: 20px; left: 24px; z-index: 1000; }
body.mode-desktop .notes-panel { position: fixed; z-index: 999; }

/* ==================================================================
   Image-bearing slide layout (applies in both desktop and mobile)
   ------------------------------------------------------------------
   Templates were largely written assuming portrait phone viewports,
   so they stack title→subtitle→bullets→image vertically. On a 1280x720
   landscape desktop canvas this overflows or causes images to crowd
   bullets. We don't redesign templates — we just reposition the
   image element to sit beside the text on desktop, or below it with
   a sensible cap on mobile, so content stays legible across templates.

   The .has-image class is added by the renderer to slides that
   actually contain an image element (see renderSlide in this file).
   ================================================================== */

/* Desktop: image floats on the right half, text gets the left half. The
   image is positioned absolutely so it doesn't push other elements down,
   which is what was clipping titles in the original layouts. Templates'
   own typography (font sizes, colors, padding) continue to apply. */
body.mode-desktop .slide.has-image {
  position: relative; /* needed; .slide already has inset: 0 */
}
body.mode-desktop .slide.has-image > img {
  position: absolute !important;
  top: 8% !important;
  right: 4% !important;
  bottom: 8% !important;
  left: auto !important;
  width: 42% !important;
  max-width: none !important;
  max-height: none !important;
  height: auto !important;
  object-fit: contain !important;
  margin: 0 !important;
  border-radius: 4px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}
/* Constrain text content to the left half so it doesn't flow under the
   absolutely-positioned image. We target the actual content elements
   directly to avoid breaking absolute-positioned decorations (top bars,
   meta strips, kanji marks, ASCII banners, etc.) which templates use
   for full-width visual identity. */
body.mode-desktop .slide.has-image > h1,
body.mode-desktop .slide.has-image > h2,
body.mode-desktop .slide.has-image > .subtitle,
body.mode-desktop .slide.has-image > .body,
body.mode-desktop .slide.has-image > p,
body.mode-desktop .slide.has-image > ul,
body.mode-desktop .slide.has-image > ol,
body.mode-desktop .slide.has-image > .imageCaption {
  max-width: 52% !important;
}
/* Title block gets a bit more room — long titles otherwise wrap awkwardly. */
body.mode-desktop .slide.has-image > h1,
body.mode-desktop .slide.has-image > h2 {
  max-width: 56% !important;
}
/* Cover slides are an exception — image stays as decoration but title
   centers across the full slide. We detect cover by class. */
body.mode-desktop .slide.has-image.cover > img {
  top: auto !important;
  bottom: 5% !important;
  right: 50% !important;
  transform: translateX(50%);
  width: 30% !important;
  height: 35% !important;
}
body.mode-desktop .slide.has-image.cover > *:not(img) {
  max-width: 90% !important;
}

/* Mobile: image stays below text but is capped so it doesn't dominate
   the slide. Text overflow clips before the image gets pushed out. */
body.mode-mobile .slide.has-image > img {
  max-height: 32vh !important;
  width: auto !important;
  margin-top: 12px !important;
  flex-shrink: 0 !important;
}

/* ==================================================================
   Mobile mode: full-height portrait layout optimised for phones.
   ================================================================== */
body.mode-mobile .deck { width: 100vw; height: 100vh; }
body.mode-mobile .slide { padding: 6vw 5vw 10vw; }

/* ==================================================================
   Language-specific font fallbacks. Most templates use Latin-only
   fonts from Google Fonts; for Chinese we append CJK fallbacks so
   characters render. The system fallbacks cover Windows, macOS,
   iOS, and Android at the platform level.

   Note: we can't easily prepend a system CJK font to each template's
   own font stack (font-family: inherit + extras isn't valid CSS),
   so we layer CJK fallback fonts at the body level. Browsers walk
   the font-family list per-glyph: when a glyph is missing in the
   template's primary font, it falls through to these system fonts.
   ================================================================== */
body.lang-zh {
  font-family: "PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", "Source Han Sans SC", "Noto Sans CJK SC", sans-serif;
}
/* Templates that set their own font on body, h1, etc. still win for Latin
   characters because their fonts are listed first in their own selectors.
   For CJK characters that those Latin fonts don't have, the browser falls
   through to system fonts on the OS — which is what we want. */
`;

// ============================================================
// NAV UI + SCRIPT
// ============================================================

const NAV_UI = `
<div class="deck-progress"></div>
<div class="deck-nav">
  <button class="nav-btn" data-nav="prev" aria-label="Previous">\u2039</button>
  <span class="nav-counter" id="counter">1/1</span>
  <button class="nav-btn" data-nav="next" aria-label="Next">\u203A</button>
</div>
`;

const NAV_SCRIPT = `
<script>
(function(){
  let cur = 0;
  const slides = document.querySelectorAll('.slide');
  const total = slides.length;
  const counter = document.getElementById('counter');
  function show(i){
    cur = Math.max(0, Math.min(total-1, i));
    slides.forEach((s, k) => s.classList.toggle('active', k === cur));
    if (counter) counter.textContent = (cur+1) + '/' + total;
    document.documentElement.style.setProperty('--progress', ((cur+1)/total*100) + '%');
    window.parent && window.parent.postMessage({type:'deck:slide', index:cur}, '*');
  }
  window.__deckShow = show;
  window.__deckCurrent = () => cur;
  document.addEventListener('keydown', e => {
    if (document.activeElement && (document.activeElement.isContentEditable || /input|textarea/i.test(document.activeElement.tagName))) return;
    if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') { e.preventDefault(); show(cur+1); }
    else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); show(cur-1); }
    else if (e.key === 'Home') show(0);
    else if (e.key === 'End') show(total-1);
    else if (e.key === 'f' || e.key === 'F') {
      if (!document.fullscreenElement) document.documentElement.requestFullscreen();
      else document.exitFullscreen();
    }
  });
  let tx=0, ty=0;
  document.addEventListener('touchstart', e => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
  document.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - tx;
    const dy = e.changedTouches[0].clientY - ty;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) show(cur + (dx < 0 ? 1 : -1));
  }, { passive: true });
  document.addEventListener('click', e => {
    if (e.target.closest('.nav-btn')) return;
    if (e.target.closest('[contenteditable="true"]')) return;
    if (document.body.classList.contains('editable')) return;
    const w = window.innerWidth;
    if (e.clientX > w * 0.7) show(cur+1);
    else if (e.clientX < w * 0.3) show(cur-1);
  });
  document.querySelectorAll('[data-nav="prev"]').forEach(b => b.addEventListener('click', e => { e.stopPropagation(); show(cur-1); }));
  document.querySelectorAll('[data-nav="next"]').forEach(b => b.addEventListener('click', e => { e.stopPropagation(); show(cur+1); }));
  show(0);
})();
<\/script>
`;

// ============================================================
// EDIT MODE — applied when rendered with editable=true.
// Makes text fields contentEditable, listens for changes,
// and posts them back to the parent window via postMessage.
// ============================================================

const EDIT_MODE_CSS = `
body.editable [data-field] {
  outline: 1px dashed rgba(255,255,255,0.15);
  outline-offset: 2px;
  cursor: text;
  transition: outline-color 0.15s;
}
body.editable [data-field]:hover { outline-color: rgba(244,184,96,0.5); }
body.editable [data-field]:focus {
  outline: 2px solid #f4b860; outline-offset: 3px;
  background: rgba(244,184,96,0.06);
}
body.editable .edit-hint {
  position: fixed; top: 12px; left: 50%; transform: translateX(-50%);
  background: #f4b860; color: #1a1612;
  padding: 6px 14px; border-radius: 20px;
  font: 600 12px/1.3 system-ui, sans-serif;
  z-index: 200; pointer-events: none;
}
`;

const EDIT_MODE_SCRIPT = `
<script>
(function(){
  const hint = document.createElement('div');
  hint.className = 'edit-hint';
  hint.textContent = '\u270E Tap text to edit';
  document.body.appendChild(hint);
  setTimeout(() => hint.remove(), 3500);

  document.querySelectorAll('[data-field]').forEach(el => {
    el.setAttribute('contenteditable', 'true');
    el.setAttribute('spellcheck', 'false');
    el.addEventListener('focus', () => el.dataset.original = el.textContent);
    el.addEventListener('blur', () => {
      if (el.textContent === el.dataset.original) return;
      const slide = el.closest('.slide');
      if (!slide) return;
      const slideIdx = Array.from(document.querySelectorAll('.slide')).indexOf(slide);
      const field = el.dataset.field;
      const idx = el.dataset.idx != null ? parseInt(el.dataset.idx, 10) : null;
      const value = el.textContent;
      window.parent && window.parent.postMessage({
        type: 'deck:edit',
        slideIdx, field, idx, value
      }, '*');
    });
    el.addEventListener('keydown', e => {
      // Escape blurs without saving
      if (e.key === 'Escape') { el.textContent = el.dataset.original; el.blur(); }
      // Ctrl/Cmd+Enter blurs (saves)
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); el.blur(); }
    });
  });
})();
<\/script>
`;

// ============================================================
// SPEAKER NOTES — slide-out panel at the bottom of the screen
// showing the presenter's notes for the current slide.
// Toggled with the N key or the 📝 button.
// ============================================================

const NOTES_CSS = `
.notes-btn {
  position: fixed; z-index: 100;
  bottom: 14px; left: 18px;
  width: 36px; height: 36px;
  border-radius: 50%;
  background: rgba(0,0,0,0.35); color: #fff;
  border: 1px solid rgba(255,255,255,0.2);
  cursor: pointer; font-size: 15px;
  display: grid; place-items: center;
  font-family: system-ui, sans-serif;
}
.notes-btn:hover { background: rgba(0,0,0,0.55); }
.notes-btn.active { background: #f4b860; color: #1a1612; border-color: #f4b860; }
.notes-panel {
  position: fixed; z-index: 99;
  left: 0; right: 0; bottom: 0;
  background: rgba(20, 18, 15, 0.96);
  color: #f5f2e8;
  backdrop-filter: blur(10px);
  border-top: 1px solid rgba(244,184,96,0.3);
  padding: 18px 24px 22px;
  max-height: 38vh;
  overflow-y: auto;
  transform: translateY(100%);
  transition: transform 0.25s ease-out;
  font-family: system-ui, -apple-system, sans-serif;
  font-size: 15px;
  line-height: 1.55;
}
.notes-panel.open { transform: translateY(0); }
.notes-panel .np-header {
  display: flex; justify-content: space-between; align-items: baseline;
  margin-bottom: 10px;
  color: #f4b860; font-size: 11px;
  letter-spacing: 0.2em; text-transform: uppercase; font-weight: 700;
}
.notes-panel .np-counter { color: rgba(255,255,255,0.5); letter-spacing: 0.15em; }
.notes-panel .np-body { white-space: pre-wrap; }
.notes-panel .np-empty { color: rgba(255,255,255,0.4); font-style: italic; }
body.mode-desktop .notes-panel { max-height: 30vh; font-size: 16px; padding: 22px 40px 26px; }
`;

const NOTES_UI = `
<button class="notes-btn" id="notesBtn" aria-label="Toggle speaker notes" title="Speaker notes (press N)">\u{1F4DD}</button>
<div class="notes-panel" id="notesPanel">
  <div class="np-header"><span>Speaker Notes</span><span class="np-counter" id="npCounter"></span></div>
  <div class="np-body" id="npBody"></div>
</div>
`;

function buildNotesScript(notesJsonLiteral) {
  return `
<script>
(function(){
  const notes = ${notesJsonLiteral};
  const panel = document.getElementById('notesPanel');
  const btn = document.getElementById('notesBtn');
  const body = document.getElementById('npBody');
  const counter = document.getElementById('npCounter');
  let open = false;

  function update() {
    const idx = (typeof window.__deckCurrent === 'function') ? window.__deckCurrent() : 0;
    const n = (notes[idx] || '').trim();
    counter.textContent = 'slide ' + (idx + 1) + ' / ' + notes.length;
    if (n) {
      body.classList.remove('np-empty');
      body.textContent = n;
    } else {
      body.classList.add('np-empty');
      body.textContent = 'No notes for this slide.';
    }
  }

  function setOpen(v) {
    open = v;
    panel.classList.toggle('open', open);
    btn.classList.toggle('active', open);
    if (open) update();
  }

  btn.addEventListener('click', e => { e.stopPropagation(); setOpen(!open); });

  document.addEventListener('keydown', e => {
    if (document.activeElement && (document.activeElement.isContentEditable || /input|textarea/i.test(document.activeElement.tagName))) return;
    if (e.key === 'n' || e.key === 'N') { e.preventDefault(); setOpen(!open); }
  });

  // Refresh notes whenever the slide changes.
  const obs = new MutationObserver(() => { if (open) update(); });
  document.querySelectorAll('.slide').forEach(s => {
    obs.observe(s, { attributes: true, attributeFilter: ['class'] });
  });
})();
<\/script>
`;
}
