// swipe.js — Touch-driven swipe card stack
//
// Usage:
//   const deck = new SwipeDeck(container, {
//     render: (item) => htmlString,
//     onDecide: (item, action /* 'skip'|'save'|'open' */) => void,
//     getItems: () => [items...]   // pulls next items when stack refills
//   });
//   deck.setItems(items);
//   deck.refresh();

export class SwipeDeck {
  constructor(container, opts) {
    this.container = container;
    this.render = opts.render;
    this.onDecide = opts.onDecide;
    this.onEmpty = opts.onEmpty || (() => {});
    this.items = [];           // all available items (feed buffer)
    this.cursor = 0;           // index of next item to load onto stack
    this.liveCards = [];       // DOM elements currently on the stack, top first
    this.STACK_SIZE = 3;
    this.SWIPE_THRESHOLD = 80;   // px required to count as a swipe
    this.SWIPE_VELOCITY = 0.5;   // px/ms quick-swipe threshold

    this._touch = null;
    this._bindGlobalEvents();
  }

  setItems(items) {
    this.items = items;
    this.cursor = 0;
    this.refresh();
  }

  refresh() {
    // Clear and rebuild the stack from scratch
    this.container.innerHTML = '';
    this.liveCards = [];
    for (let i = 0; i < this.STACK_SIZE; i++) {
      this._pushCardFromBuffer();
    }
    this._updateStackVisuals();
    if (this.liveCards.length === 0) this.onEmpty();
  }

  _pushCardFromBuffer() {
    if (this.cursor >= this.items.length) return;
    const item = this.items[this.cursor++];
    const card = this._buildCard(item);
    // Insert BELOW the existing cards so the top card stays on top
    this.container.appendChild(card);
    // Reorder visually: most recently added should be at the back
    this.liveCards.push(card);
  }

  _buildCard(item) {
    const card = document.createElement('div');
    card.className = 'card';
    card.dataset.source = item.source;
    card.dataset.id = item.id;
    card._item = item;
    card.innerHTML =
      this.render(item) +
      `<div class="swipe-hint left">SKIP</div>
       <div class="swipe-hint right">SAVE</div>
       <div class="swipe-hint up">OPEN</div>`;
    this._bindCardEvents(card);
    return card;
  }

  _bindCardEvents(card) {
    card.addEventListener('touchstart', (e) => this._onStart(card, e), { passive: true });
    card.addEventListener('touchmove',  (e) => this._onMove(card, e),  { passive: false });
    card.addEventListener('touchend',   (e) => this._onEnd(card, e));
    card.addEventListener('touchcancel',(e) => this._onEnd(card, e));
    // mouse support for desktop/testing
    card.addEventListener('mousedown', (e) => this._onStart(card, e));
    card.addEventListener('mousemove', (e) => this._onMove(card, e));
    card.addEventListener('mouseup',   (e) => this._onEnd(card, e));
    card.addEventListener('mouseleave',(e) => { if (this._touch) this._onEnd(card, e); });
  }

  _bindGlobalEvents() {
    // nothing for now; kept for future keyboard shortcuts if needed
  }

  _isTopCard(card) {
    return this.liveCards[0] === card;
  }

  _pointerPos(e) {
    if (e.touches && e.touches[0]) return { x: e.touches[0].clientX, y: e.touches[0].clientY };
    if (e.changedTouches && e.changedTouches[0]) return { x: e.changedTouches[0].clientX, y: e.changedTouches[0].clientY };
    return { x: e.clientX, y: e.clientY };
  }

  _onStart(card, e) {
    if (!this._isTopCard(card)) return;
    // Don't hijack taps/scrolls inside the summary text
    if (e.target.closest('.card-summary') && (e.target.scrollHeight > e.target.clientHeight)) {
      // Still allow horizontal swipe, but be gentle
    }
    const { x, y } = this._pointerPos(e);
    this._touch = {
      card, startX: x, startY: y, startT: Date.now(),
      dx: 0, dy: 0, dragging: false
    };
    card.style.transition = 'none';
  }

  _onMove(card, e) {
    if (!this._touch || this._touch.card !== card) return;
    const { x, y } = this._pointerPos(e);
    const dx = x - this._touch.startX;
    const dy = y - this._touch.startY;

    // Decide whether we're dragging — needs a small threshold
    if (!this._touch.dragging) {
      if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
        this._touch.dragging = true;
      } else {
        return;
      }
    }

    // Only preventDefault for actual drag — lets taps/scrolls through
    if (e.cancelable && this._touch.dragging) e.preventDefault();

    this._touch.dx = dx;
    this._touch.dy = dy;

    const rotate = dx / 14;  // gentle rotation
    card.style.transform = `translate(${dx}px, ${dy}px) rotate(${rotate}deg)`;

    // Highlight the hint for the current direction
    const leftEl = card.querySelector('.swipe-hint.left');
    const rightEl = card.querySelector('.swipe-hint.right');
    const upEl = card.querySelector('.swipe-hint.up');
    const absX = Math.abs(dx), absY = Math.abs(dy);

    if (dy < -40 && absY > absX) {
      upEl.style.opacity = Math.min(1, -dy / 120);
      leftEl.style.opacity = rightEl.style.opacity = 0;
    } else if (dx > 0) {
      rightEl.style.opacity = Math.min(1, dx / 100);
      leftEl.style.opacity = upEl.style.opacity = 0;
    } else if (dx < 0) {
      leftEl.style.opacity = Math.min(1, -dx / 100);
      rightEl.style.opacity = upEl.style.opacity = 0;
    }
  }

  _onEnd(card, e) {
    if (!this._touch || this._touch.card !== card) return;
    const { dx, dy, startT, dragging } = this._touch;
    const dt = Math.max(1, Date.now() - startT);
    const vx = dx / dt;
    const vy = dy / dt;
    this._touch = null;

    if (!dragging) {
      // Was a tap — don't reset transition, just clean hint opacity
      this._clearHints(card);
      return;
    }

    const absX = Math.abs(dx), absY = Math.abs(dy);
    let action = null;

    // Decide action from delta + velocity
    if (dy < 0 && absY > absX && (absY > this.SWIPE_THRESHOLD || -vy > this.SWIPE_VELOCITY)) {
      action = 'open';
    } else if (dx > 0 && (dx > this.SWIPE_THRESHOLD || vx > this.SWIPE_VELOCITY)) {
      action = 'save';
    } else if (dx < 0 && (-dx > this.SWIPE_THRESHOLD || -vx > this.SWIPE_VELOCITY)) {
      action = 'skip';
    }

    if (action) {
      this._commitSwipe(card, action);
    } else {
      this._snapBack(card);
    }
  }

  _clearHints(card) {
    card.querySelectorAll('.swipe-hint').forEach(h => h.style.opacity = 0);
  }

  _snapBack(card) {
    card.style.transition = 'transform 0.28s cubic-bezier(0.2, 0.8, 0.2, 1)';
    card.style.transform = '';
    this._clearHints(card);
  }

  /**
   * Programmatic action (button press). Same effect as a swipe.
   */
  trigger(action) {
    const top = this.liveCards[0];
    if (!top) return;
    this._commitSwipe(top, action);
  }

  _commitSwipe(card, action) {
    const targetX =
      action === 'skip' ? -window.innerWidth * 1.2 :
      action === 'save' ?  window.innerWidth * 1.2 :
      0;
    const targetY = action === 'open' ? -window.innerHeight * 1.2 : 0;
    const rotate = action === 'skip' ? -30 : action === 'save' ? 30 : 0;

    card.style.transition = 'transform 0.36s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.36s';
    card.style.transform = `translate(${targetX}px, ${targetY}px) rotate(${rotate}deg)`;
    card.style.opacity = 0;

    // For "open", fire immediately (we want the URL to open without delay)
    const item = card._item;
    if (action === 'open') {
      this.onDecide(item, 'open');
    }

    // After the animation, remove the card and advance
    setTimeout(() => {
      card.remove();
      this.liveCards = this.liveCards.filter(c => c !== card);
      if (action !== 'open') this.onDecide(item, action);

      // Refill: bring in a new bottom card
      this._pushCardFromBuffer();
      this._updateStackVisuals();

      if (this.liveCards.length === 0) this.onEmpty();
    }, 340);
  }

  _updateStackVisuals() {
    this.liveCards.forEach((card, i) => {
      card.classList.remove('c-2', 'c-3', 'c-hidden');
      if (i === 0) {
        // Top card — no extra class
      } else if (i === 1) {
        card.classList.add('c-2');
      } else if (i === 2) {
        card.classList.add('c-3');
      } else {
        card.classList.add('c-hidden');
      }
      // Ensure proper stacking (top card on top z-order)
      card.style.zIndex = this.liveCards.length - i;
    });
  }

  /**
   * Called externally when the feed buffer is extended (e.g. new items loaded).
   */
  appendItems(newItems) {
    this.items.push(...newItems);
    // If the stack isn't full, top it up
    while (this.liveCards.length < this.STACK_SIZE && this.cursor < this.items.length) {
      this._pushCardFromBuffer();
    }
    this._updateStackVisuals();
  }

  remainingCount() {
    return Math.max(0, this.items.length - this.cursor) + this.liveCards.length;
  }
}
