// render.js — shared HTML rendering helpers for list items & cards

export function escapeHtml(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function formatDate(ms) {
  const d = new Date(ms);
  if (isNaN(d.getTime())) return '';
  const age = Date.now() - ms;
  const mins = Math.floor(age / 60000);
  const hrs = Math.floor(mins / 60);
  const days = Math.floor(hrs / 24);
  if (mins < 1) return 'just now';
  if (mins < 60) return mins + 'm ago';
  if (hrs < 24) return hrs + 'h ago';
  if (days < 7) return days + 'd ago';
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function topicBadges(item) {
  return (item.matchedTopics || []).map(t =>
    `<span class="item-chip">★ ${escapeHtml(t)}</span>`
  ).join('');
}

function classesFor(item, seen) {
  let cls = '';
  if (seen[item.id] === 'read') cls += ' read';
  if (seen[item.id] === 'saved') cls += ' saved';
  return cls;
}

function wrapper(item, seen, bodyHtml, index) {
  return `
    <li class="list-item${classesFor(item, seen)}" data-id="${item.id}" data-url="${escapeHtml(item.url)}">
      <div class="item-rank">${String(index + 1).padStart(2, '0')}</div>
      <div class="item-body">${bodyHtml}</div>
    </li>`;
}

// -------- Source-specific item renderers --------

export function renderHNItem(item, index, seen) {
  const body = `
    <div class="item-title">${escapeHtml(item.title)}</div>
    <div class="item-sub">
      <span class="points">▲ ${item.points}</span>
      <span class="dot"></span>
      <span>${item.comments} comments</span>
      <span class="dot"></span>
      <span>${escapeHtml(item.author || '')}</span>
      <span class="dot"></span>
      <span>${formatDate(item.date)}</span>
    </div>
    ${topicBadges(item) ? `<div class="item-topics">${topicBadges(item)}</div>` : ''}`;
  return wrapper(item, seen, body, index);
}

export function renderGithubItem(item, index, seen) {
  const langTags = (item.tags || []).slice(0, 3).map(t =>
    `<span style="opacity:0.7">#${escapeHtml(t)}</span>`
  ).join('  ');
  const body = `
    <div class="item-title">${escapeHtml(item.title)}</div>
    ${item.summary ? `<div class="item-desc">${escapeHtml(item.summary)}</div>` : ''}
    <div class="item-sub">
      <span class="stars">★ ${item.stars.toLocaleString()}</span>
      <span class="dot"></span>
      <span>${formatDate(item.date)}</span>
      ${langTags ? `<span class="dot"></span><span>${langTags}</span>` : ''}
    </div>
    ${topicBadges(item) ? `<div class="item-topics">${topicBadges(item)}</div>` : ''}`;
  return wrapper(item, seen, body, index);
}

export function renderArxivItem(item, index, seen) {
  const cats = (item.tags || []).slice(0, 3).join(' · ');
  const body = `
    <div class="item-title">${escapeHtml(item.title)}</div>
    ${item.summary ? `<div class="item-desc">${escapeHtml(item.summary)}</div>` : ''}
    <div class="item-sub">
      <span>${escapeHtml(item.author || '')}</span>
      <span class="dot"></span>
      <span>${formatDate(item.date)}</span>
      ${cats ? `<span class="dot"></span><span>${escapeHtml(cats)}</span>` : ''}
    </div>
    ${topicBadges(item) ? `<div class="item-topics">${topicBadges(item)}</div>` : ''}`;
  return wrapper(item, seen, body, index);
}

export function renderTopicMatchItem(item, index, seen) {
  const body = `
    <div class="item-title">${escapeHtml(item.title)}</div>
    <div class="item-sub">
      <span>${escapeHtml(item.sourceName || item.source)}</span>
      <span class="dot"></span>
      <span>${formatDate(item.date)}</span>
    </div>
    <div class="item-topics">${topicBadges(item)}</div>`;
  return wrapper(item, seen, body, index);
}

export function renderSavedItem(item, index, seen) {
  const body = `
    <div class="item-title">${escapeHtml(item.title)}</div>
    <div class="item-sub">
      <span>${escapeHtml(item.sourceName || item.source)}</span>
      <span class="dot"></span>
      <span>${formatDate(item.date)}</span>
    </div>`;
  return `
    <li class="list-item saved" data-id="${item.id}" data-url="${escapeHtml(item.url)}">
      <div class="item-rank">${String(index + 1).padStart(2, '0')}</div>
      <div class="item-body">${body}</div>
    </li>`;
}

export function renderCard(item) {
  const badges = (item.matchedTopics || []).map(t =>
    `<span class="card-tag topic-match">★ ${escapeHtml(t)}</span>`
  ).join('');
  const tags = (item.tags || []).slice(0, 4).map(t =>
    `<span class="card-tag">${escapeHtml(t)}</span>`
  ).join('');
  const summaryHtml = item.summary
    ? `<p>${escapeHtml(item.summary)}</p>`
    : `<p style="opacity:0.5;font-style:italic;">No preview available. Swipe up to open in browser.</p>`;
  const sourceLabel = item.sourceName || item.source.toUpperCase();

  return `
    <div class="card-top">
      <div class="card-src">${escapeHtml(sourceLabel)}</div>
      <div class="card-date">${formatDate(item.date)}</div>
    </div>
    <h2 class="card-title">${escapeHtml(item.title)}</h2>
    <div class="card-summary">${summaryHtml}</div>
    <div class="card-meta">${badges}${tags}</div>`;
}

export function renderEmptyListItem(message) {
  return `<li class="list-item"><div class="item-rank">—</div><div class="item-body"><div class="item-sub" style="font-style:italic;font-family:var(--serif);font-size:14px;">${escapeHtml(message)}</div></div></li>`;
}
