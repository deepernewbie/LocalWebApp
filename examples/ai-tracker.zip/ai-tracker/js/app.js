// app.js — Main application controller

import {
  fetchAllRSS, fetchHN, fetchGitHubTrending, fetchArxiv, tagTopicMatches
} from './sources.js';
import {
  getState, markSeen,
  addTopic, removeTopic, getTopics,
  cacheFeed, getCachedFeed
} from './storage.js';
import { SwipeDeck } from './swipe.js';
import {
  escapeHtml,
  renderCard,
  renderHNItem, renderGithubItem, renderArxivItem,
  renderTopicMatchItem, renderSavedItem, renderEmptyListItem
} from './render.js';

// ---------- DOM refs ----------
const $ = id => document.getElementById(id);
const tabs = document.querySelectorAll('.tab');
const panels = {
  feed:   $('panel-feed'),
  github: $('panel-github'),
  hn:     $('panel-hn'),
  arxiv:  $('panel-arxiv'),
  topics: $('panel-topics')
};
const statusText = $('status-text');
const statusCounts = $('status-counts');
const headerDate = $('header-date');
const refreshBtn = $('refresh-btn');
const cardStack = $('card-stack');
const feedEmpty = $('feed-empty');
const feedRefreshBtn = $('feed-refresh-btn');
const btnSkip = $('btn-skip');
const btnOpen = $('btn-open');
const btnSave = $('btn-save');
const githubList = $('github-list');
const githubSub = $('github-sub');
const hnList = $('hn-list');
const hnSub = $('hn-sub');
const arxivList = $('arxiv-list');
const arxivSub = $('arxiv-sub');
const topicForm = $('topic-form');
const topicInput = $('topic-input');
const topicChips = $('topic-chips');
const topicMatches = $('topic-matches');
const savedList = $('saved-list');

// ---------- App state ----------
const APP = {
  feed: [], hn: [], github: [], arxiv: [],
  topics: [],
  deck: null,
  refreshing: false
};

// ---------- Utilities ----------
function setStatus(mode, text, counts) {
  document.body.classList.remove('loading', 'error-state');
  if (mode === 'loading') document.body.classList.add('loading');
  if (mode === 'error') document.body.classList.add('error-state');
  statusText.textContent = text;
  if (counts !== undefined) statusCounts.textContent = counts;
}

function updateHeaderDate() {
  const d = new Date();
  const day = d.toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase();
  const month = d.toLocaleDateString('en-US', { month: 'short' }).toUpperCase();
  headerDate.innerHTML = `${day} · ${d.getDate()} ${month} ${d.getFullYear()}<br><span style="opacity:0.6">vol.01 / ed.${d.getDate()}</span>`;
}

function openUrl(url) {
  const a = document.createElement('a');
  a.href = url;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  a.click();
}

function hapticTap() {
  if (typeof Android !== 'undefined' && Android.vibrate) Android.vibrate();
  else if (navigator.vibrate) navigator.vibrate(20);
}

function dedupeById(items) {
  const seen = new Set();
  return items.filter(it => !seen.has(it.id) && seen.add(it.id));
}

// ---------- Tabs ----------
function switchTab(name) {
  tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  Object.entries(panels).forEach(([k, el]) => el.classList.toggle('active', k === name));
  if (name === 'topics') renderTopics();
  if (name === 'hn') renderList(hnList, APP.hn, renderHNItem, 'No stories loaded yet.', n => hnSub.textContent = `${n} stories`);
  if (name === 'github') renderList(githubList, APP.github, renderGithubItem, 'No repos loaded yet.', n => githubSub.textContent = `${n} repos · created in last 30 days`);
  if (name === 'arxiv') renderList(arxivList, APP.arxiv, renderArxivItem, 'No papers loaded yet.', n => arxivSub.textContent = `${n} papers · cs.AI / cs.LG / cs.CL`);
}
tabs.forEach(t => t.addEventListener('click', () => { hapticTap(); switchTab(t.dataset.tab); }));

// ---------- Generic list renderer ----------
async function renderList(listEl, items, itemRenderer, emptyMsg, subUpdater) {
  subUpdater?.(items?.length || 0);
  if (!items || items.length === 0) {
    listEl.innerHTML = renderEmptyListItem(emptyMsg);
    return;
  }
  const state = await getState();
  const seen = state.seen || {};
  listEl.innerHTML = items.map((it, i) => itemRenderer(it, i, seen)).join('');
  listEl.querySelectorAll('.list-item').forEach(li => {
    li.addEventListener('click', async () => {
      const id = li.dataset.id;
      if (!id) return;
      if (seen[id] !== 'saved') {
        await markSeen(id, 'read');
        li.classList.add('read');
      }
      hapticTap();
      openUrl(li.dataset.url);
    });
  });
}

// ---------- Feed (swipe cards) ----------
async function rebuildFeed() {
  const state = await getState();
  const seen = state.seen || {};
  tagTopicMatches(APP.feed, APP.topics);

  const unseen = APP.feed.filter(it => !seen[it.id]);
  unseen.sort((a, b) => {
    const am = a.matchedTopics?.length || 0;
    const bm = b.matchedTopics?.length || 0;
    if (am !== bm) return bm - am;
    return b.date - a.date;
  });

  APP.deck.setItems(unseen);
  feedEmpty.style.display = unseen.length ? 'none' : 'flex';
  updateStatusCounts();
}

function updateStatusCounts() {
  const left = APP.deck?.remainingCount() ?? 0;
  statusCounts.textContent = `${left} unread · ${APP.feed.length} total`;
}

async function onDecide(item, action) {
  if (action === 'skip') await markSeen(item.id, 'skip');
  else if (action === 'save') await markSeen(item.id, 'saved');
  else if (action === 'open') { await markSeen(item.id, 'read'); openUrl(item.url); }
  hapticTap();
  updateStatusCounts();
}

// ---------- Topics ----------
async function renderTopics() {
  APP.topics = await getTopics();

  if (APP.topics.length === 0) {
    topicChips.innerHTML = `<div class="topic-chip none">No topics yet. Add one above — e.g. "agents" or "diffusion".</div>`;
  } else {
    topicChips.innerHTML = APP.topics.map(t =>
      `<div class="topic-chip" data-id="${escapeHtml(t.id)}">
         ${escapeHtml(t.text)}
         <button class="x" aria-label="Remove" data-remove="${escapeHtml(t.id)}">×</button>
       </div>`
    ).join('');
    topicChips.querySelectorAll('[data-remove]').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await removeTopic(btn.dataset.remove);
        hapticTap();
        await reapplyTopics();
      });
    });
  }

  const all = [...APP.feed, ...APP.hn, ...APP.github, ...APP.arxiv];
  tagTopicMatches(all, APP.topics);
  const matches = all
    .filter(it => it.matchedTopics?.length)
    .sort((a, b) => b.date - a.date)
    .slice(0, 30);

  await renderList(topicMatches, matches, renderTopicMatchItem,
    APP.topics.length ? 'No matches today. Check back after a refresh.'
                      : 'Add a topic first to see matches here.');

  const state = await getState();
  const savedIds = Object.keys(state.seen || {}).filter(id => state.seen[id] === 'saved');
  const saved = all.filter(it => savedIds.includes(it.id)).sort((a, b) => b.date - a.date);
  await renderList(savedList, saved, renderSavedItem,
    'Nothing saved yet. Swipe right on the Feed tab to save items.');
}

async function reapplyTopics() {
  APP.topics = await getTopics();
  tagTopicMatches(APP.feed, APP.topics);
  tagTopicMatches(APP.hn, APP.topics);
  tagTopicMatches(APP.github, APP.topics);
  tagTopicMatches(APP.arxiv, APP.topics);
  await renderTopics();
  await rebuildFeed();
}

topicForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const txt = topicInput.value.trim();
  if (!txt) return;
  await addTopic(txt);
  topicInput.value = '';
  hapticTap();
  await reapplyTopics();
});

// ---------- Action buttons ----------
btnSkip.addEventListener('click', () => { hapticTap(); APP.deck?.trigger('skip'); });
btnOpen.addEventListener('click', () => { hapticTap(); APP.deck?.trigger('open'); });
btnSave.addEventListener('click', () => { hapticTap(); APP.deck?.trigger('save'); });
feedRefreshBtn.addEventListener('click', () => refresh());
refreshBtn.addEventListener('click', () => { hapticTap(); refresh(); });

// ---------- Main refresh ----------
async function refresh() {
  if (APP.refreshing) return;
  APP.refreshing = true;
  refreshBtn.classList.add('spinning');
  setStatus('loading', 'fetching sources…', statusCounts.textContent);

  const results = {};
  await Promise.all([
    fetchAllRSS((done, total, name) => setStatus('loading', `rss ${done}/${total} · ${name}`))
      .then(v => results.rss = v).catch(e => { console.warn('RSS', e); results.rss = []; }),
    fetchHN({ limit: 50 })
      .then(v => results.hn = v).catch(e => { console.warn('HN', e); results.hn = []; }),
    fetchGitHubTrending({ limit: 30 })
      .then(v => results.github = v).catch(e => { console.warn('GH', e); results.github = []; }),
    fetchArxiv({ limit: 30 })
      .then(v => results.arxiv = v).catch(e => { console.warn('arXiv', e); results.arxiv = []; }),
  ]);

  APP.feed = dedupeById([...(results.rss || []), ...(results.hn || [])]);
  APP.hn = results.hn || [];
  APP.github = results.github || [];
  APP.arxiv = results.arxiv || [];

  APP.topics = await getTopics();
  [APP.feed, APP.hn, APP.github, APP.arxiv].forEach(arr => tagTopicMatches(arr, APP.topics));

  cacheFeed([
    ...APP.feed.map(f => ({ ...f, _bucket: 'feed' })),
    ...APP.hn.map(f => ({ ...f, _bucket: 'hn' })),
    ...APP.github.map(f => ({ ...f, _bucket: 'github' })),
    ...APP.arxiv.map(f => ({ ...f, _bucket: 'arxiv' }))
  ]);

  await rebuildFeed();
  await renderList(hnList, APP.hn, renderHNItem, 'No stories loaded yet.', n => hnSub.textContent = `${n} stories`);
  await renderList(githubList, APP.github, renderGithubItem, 'No repos loaded yet.', n => githubSub.textContent = `${n} repos · created in last 30 days`);
  await renderList(arxivList, APP.arxiv, renderArxivItem, 'No papers loaded yet.', n => arxivSub.textContent = `${n} papers · cs.AI / cs.LG / cs.CL`);
  await renderTopics();

  const ok = ['rss','hn','github','arxiv'].filter(k => results[k]?.length).length;
  if (ok === 0) setStatus('error', 'all sources failed — check connection');
  else if (ok < 4) setStatus('', `${ok}/4 sources ok`, `${APP.deck?.remainingCount() ?? 0} unread`);
  else setStatus('', 'up to date', `${APP.deck?.remainingCount() ?? 0} unread`);

  refreshBtn.classList.remove('spinning');
  APP.refreshing = false;
}

// ---------- Bootstrap ----------
async function boot() {
  updateHeaderDate();
  setInterval(updateHeaderDate, 60000);

  APP.deck = new SwipeDeck(cardStack, {
    render: renderCard,
    onDecide,
    onEmpty: () => {
      feedEmpty.style.display = 'flex';
      updateStatusCounts();
    }
  });

  APP.topics = await getTopics();

  // Cached data first (fast paint)
  const cached = await getCachedFeed();
  if (cached.length) {
    const groups = { feed: [], hn: [], github: [], arxiv: [] };
    for (const it of cached) if (groups[it._bucket]) groups[it._bucket].push(it);
    APP.feed = groups.feed; APP.hn = groups.hn; APP.github = groups.github; APP.arxiv = groups.arxiv;
    [APP.feed, APP.hn, APP.github, APP.arxiv].forEach(arr => tagTopicMatches(arr, APP.topics));
    await rebuildFeed();
    await renderList(hnList, APP.hn, renderHNItem, 'No stories loaded yet.', n => hnSub.textContent = `${n} stories`);
    await renderList(githubList, APP.github, renderGithubItem, 'No repos loaded yet.', n => githubSub.textContent = `${n} repos · created in last 30 days`);
    await renderList(arxivList, APP.arxiv, renderArxivItem, 'No papers loaded yet.', n => arxivSub.textContent = `${n} papers · cs.AI / cs.LG / cs.CL`);
    setStatus('', 'cached · refreshing…', `${APP.deck?.remainingCount() ?? 0} unread`);
  } else {
    setStatus('loading', 'first launch · fetching…');
  }

  await renderTopics();
  refresh();
}
boot();

// Refresh on focus after a while
let lastFocus = Date.now();
window.addEventListener('focus', () => {
  const now = Date.now();
  if (now - lastFocus > 15 * 60 * 1000) {
    lastFocus = now;
    refresh();
  }
});
