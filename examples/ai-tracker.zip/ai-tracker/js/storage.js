// storage.js — persistence (AndroidFS if available, localStorage fallback)

const hasFS = typeof window !== 'undefined'
           && window.AndroidFS
           && typeof window.AndroidFS.read === 'function';

/**
 * Load a JSON file. Returns `fallback` if not found or unparseable.
 */
export async function loadJSON(path, fallback) {
  // Try file system first
  if (hasFS) {
    try {
      const text = await AndroidFS.read(path);
      if (text) return JSON.parse(text);
    } catch (e) { /* fall through */ }
  }
  // Fallback to localStorage
  try {
    const text = localStorage.getItem('signal:' + path);
    if (text) return JSON.parse(text);
  } catch (e) { /* ignore */ }
  return fallback;
}

/**
 * Save a JSON file. Writes to both FS and localStorage as a safety net.
 */
export async function saveJSON(path, data) {
  const text = JSON.stringify(data, null, 2);
  try { localStorage.setItem('signal:' + path, text); } catch (e) {}
  if (hasFS) {
    try { await AndroidFS.write(path, text); } catch (e) { console.warn('AndroidFS write failed', path, e); }
  }
}

// ---------- App state store ----------
// We keep one file on disk: state.json
// Structure: { seen: {id: 'read'|'skip'|'saved'}, topics: [...], lastRefresh: ts, ...}

let cached = null;

export async function getState() {
  if (cached) return cached;
  cached = await loadJSON('data/state.json', {
    seen: {},         // id -> 'read' | 'skip' | 'saved'
    topics: [],       // array of {id, text, addedAt}
    lastRefresh: 0,
    feedCache: null   // last fetched items (so cold start shows something)
  });
  // defensive defaults
  cached.seen ||= {};
  cached.topics ||= [];
  return cached;
}

let saveTimer = null;
export async function commit() {
  if (!cached) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => saveJSON('data/state.json', cached), 250);
}

export async function commitNow() {
  if (!cached) return;
  clearTimeout(saveTimer);
  await saveJSON('data/state.json', cached);
}

// ---------- Seen helpers ----------
export async function markSeen(id, action) {
  const s = await getState();
  s.seen[id] = action;
  commit();
}

export async function getAction(id) {
  const s = await getState();
  return s.seen[id] || null;
}

// ---------- Topic helpers ----------
export async function addTopic(text) {
  const s = await getState();
  const clean = text.trim();
  if (!clean) return;
  const id = clean.toLowerCase();
  if (s.topics.find(t => t.id === id)) return;
  s.topics.push({ id, text: clean, addedAt: Date.now() });
  await commitNow();
}

export async function removeTopic(id) {
  const s = await getState();
  s.topics = s.topics.filter(t => t.id !== id);
  await commitNow();
}

export async function getTopics() {
  const s = await getState();
  return s.topics;
}

// ---------- Feed cache (so cold start has data) ----------
export async function cacheFeed(items) {
  const s = await getState();
  s.feedCache = items.slice(0, 200);  // cap
  s.lastRefresh = Date.now();
  commit();
}

export async function getCachedFeed() {
  const s = await getState();
  return s.feedCache || [];
}
