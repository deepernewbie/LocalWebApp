// sources.js — Fetch items from multiple sources, normalize to a common shape
//
// Common item shape:
//   { id, source, title, url, summary, author?, date(ms), tags[], score? }

// ========================================================================
// RSS feeds (AI-focused)
// ========================================================================
// We use r.jina.ai as a CORS-friendly fetcher/proxy for the RSS XML.
// It returns JSON mode when you pass Accept: application/json, but for
// raw XML we just use text/plain with the prefix.

const RSS_SOURCES = [
  { name: 'OpenAI',        url: 'https://openai.com/news/rss.xml' },
  { name: 'Google AI',     url: 'https://blog.google/technology/ai/rss/' },
  { name: 'DeepMind',      url: 'https://deepmind.google/blog/rss.xml' },
  { name: 'Anthropic',     url: 'https://www.anthropic.com/news/rss.xml' },
  { name: 'HuggingFace',   url: 'https://huggingface.co/blog/feed.xml' },
  { name: 'MIT News — AI', url: 'https://news.mit.edu/rss/topic/artificial-intelligence2' },
  { name: 'The Verge — AI', url: 'https://www.theverge.com/ai-artificial-intelligence/rss/index.xml' },
  { name: 'TechCrunch AI', url: 'https://techcrunch.com/category/artificial-intelligence/feed/' },
  { name: 'Import AI',     url: 'https://jack-clark.net/feed/' },
  { name: 'Simon Willison', url: 'https://simonwillison.net/atom/everything/' },
];

const JINA_PREFIX = 'https://r.jina.ai/';

// ========================================================================
// RSS/Atom parser — works on both formats, tolerant of malformed feeds
// ========================================================================
function parseFeed(xmlText, sourceName, sourceUrl) {
  const doc = new DOMParser().parseFromString(xmlText, 'text/xml');
  if (doc.querySelector('parsererror')) return [];

  const items = [];
  // RSS 2.0: <item>, Atom: <entry>
  const entries = doc.querySelectorAll('item, entry');

  entries.forEach(entry => {
    const title = textOf(entry.querySelector('title'));
    if (!title) return;

    // Link: RSS has <link>TEXT</link>, Atom has <link href="...">
    let url = '';
    const linkEl = entry.querySelector('link');
    if (linkEl) {
      url = linkEl.getAttribute('href') || linkEl.textContent || '';
    }
    url = url.trim();
    if (!url) {
      // Fallback to <guid> if it looks like a URL
      const guid = textOf(entry.querySelector('guid'));
      if (guid && guid.startsWith('http')) url = guid;
    }
    if (!url) return;

    // Date
    const dateText = textOf(entry.querySelector('pubDate, published, updated, dc\\:date'));
    const date = dateText ? new Date(dateText).getTime() : Date.now();

    // Summary: prefer description/summary, fallback to content
    let summary = textOf(entry.querySelector('description, summary'));
    if (!summary) {
      const content = entry.querySelector('content\\:encoded, content');
      summary = content ? content.textContent : '';
    }
    summary = cleanHtml(summary);

    items.push({
      id: 'rss:' + hashString(url),
      source: 'rss',
      sourceName,
      title: decodeEntities(title),
      url,
      summary,
      date: isNaN(date) ? Date.now() : date,
      tags: [sourceName]
    });
  });

  return items;
}

function textOf(el) {
  return el ? (el.textContent || '').trim() : '';
}

function cleanHtml(html) {
  if (!html) return '';
  // Strip tags, decode entities, collapse whitespace
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  const text = tmp.textContent || tmp.innerText || '';
  return text.replace(/\s+/g, ' ').trim().slice(0, 500);
}

function decodeEntities(s) {
  const tmp = document.createElement('textarea');
  tmp.innerHTML = s;
  return tmp.value;
}

function hashString(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h).toString(36);
}

/**
 * Fetch a single RSS feed. Falls back to jina proxy if direct fetch fails
 * (which is likely — very few feeds set CORS headers).
 */
async function fetchRSSFeed(src, { timeoutMs = 12000 } = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);

  // Try direct first (some feeds do set CORS)
  try {
    const resp = await fetch(src.url, { signal: ctrl.signal });
    if (resp.ok) {
      const text = await resp.text();
      clearTimeout(t);
      const items = parseFeed(text, src.name, src.url);
      if (items.length) return items;
    }
  } catch (e) {
    // fall through to proxy
  }

  // Proxy via jina — pass Accept header so we get raw text
  try {
    const proxied = JINA_PREFIX + src.url;
    const resp = await fetch(proxied, {
      signal: ctrl.signal,
      headers: { 'Accept': 'application/xml, application/rss+xml, text/xml' },
    });
    clearTimeout(t);
    if (!resp.ok) return [];
    const text = await resp.text();
    // jina returns a readable form with metadata; the XML block is usually
    // fenced. We try to find a valid XML chunk first; if not, parse raw.
    const xmlStart = text.indexOf('<?xml');
    const body = xmlStart > -1 ? text.slice(xmlStart) : text;
    return parseFeed(body, src.name, src.url);
  } catch (e) {
    clearTimeout(t);
    return [];
  }
}

/**
 * Fetch all RSS sources in parallel with limited concurrency.
 */
export async function fetchAllRSS(onProgress) {
  const all = [];
  let done = 0;
  // Fire all in parallel — they share a hard timeout anyway
  const results = await Promise.all(
    RSS_SOURCES.map(src =>
      fetchRSSFeed(src).then(items => {
        done++;
        onProgress?.(done, RSS_SOURCES.length, src.name);
        return items;
      }).catch(() => [])
    )
  );
  for (const items of results) all.push(...items);
  return all;
}

// ========================================================================
// Hacker News — Algolia API (has CORS)
// ========================================================================
export async function fetchHN({ limit = 40 } = {}) {
  // Search for AI-related stories in the last 7 days
  const tags = 'story';
  const url = `https://hn.algolia.com/api/v1/search_by_date?` +
    `query=${encodeURIComponent('AI OR LLM OR "artificial intelligence" OR "machine learning" OR GPT')}` +
    `&tags=${tags}` +
    `&hitsPerPage=${limit}` +
    `&numericFilters=points>10`;

  const resp = await fetch(url);
  if (!resp.ok) throw new Error('HN fetch failed');
  const json = await resp.json();

  return (json.hits || []).map(h => ({
    id: 'hn:' + h.objectID,
    source: 'hn',
    sourceName: 'Hacker News',
    title: h.title || '',
    url: h.url || `https://news.ycombinator.com/item?id=${h.objectID}`,
    hnUrl: `https://news.ycombinator.com/item?id=${h.objectID}`,
    summary: h.story_text ? cleanHtml(h.story_text) : '',
    author: h.author,
    date: new Date(h.created_at).getTime(),
    points: h.points || 0,
    comments: h.num_comments || 0,
    tags: ['HN']
  }));
}

// ========================================================================
// GitHub trending (via Search API — sort by stars, recently created/pushed)
// ========================================================================
export async function fetchGitHubTrending({ limit = 30 } = {}) {
  // Recent AI repos gaining stars. We search for AI/ML/LLM keywords.
  // Using created>N days ago biases toward newer projects.
  const date = new Date();
  date.setDate(date.getDate() - 30);
  const dateStr = date.toISOString().slice(0, 10);

  const query = encodeURIComponent(
    `AI OR LLM OR "machine learning" OR "large language model" OR agent OR "deep learning" ` +
    `created:>${dateStr} stars:>50`
  );
  const url = `https://api.github.com/search/repositories?q=${query}&sort=stars&order=desc&per_page=${limit}`;

  const resp = await fetch(url, {
    headers: { 'Accept': 'application/vnd.github+json' }
  });
  if (!resp.ok) throw new Error('GitHub fetch failed');
  const json = await resp.json();

  return (json.items || []).map(r => ({
    id: 'gh:' + r.id,
    source: 'github',
    sourceName: 'GitHub',
    title: r.full_name,
    name: r.name,
    owner: r.owner?.login,
    url: r.html_url,
    summary: r.description || '',
    author: r.owner?.login,
    date: new Date(r.created_at).getTime(),
    pushedAt: new Date(r.pushed_at).getTime(),
    stars: r.stargazers_count,
    language: r.language,
    tags: [r.language, ...(r.topics || []).slice(0, 4)].filter(Boolean)
  }));
}

// ========================================================================
// arXiv — Atom feed API, has CORS
// ========================================================================
export async function fetchArxiv({ limit = 30 } = {}) {
  // cs.AI OR cs.LG OR cs.CL, sorted by submission date
  const url = `http://export.arxiv.org/api/query?` +
    `search_query=${encodeURIComponent('cat:cs.AI OR cat:cs.LG OR cat:cs.CL')}` +
    `&sortBy=submittedDate&sortOrder=descending&max_results=${limit}`;

  let text;
  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error('arxiv direct failed');
    text = await resp.text();
  } catch (e) {
    // Fallback via jina if direct fails (arxiv sometimes has CORS issues)
    const resp = await fetch(JINA_PREFIX + url);
    if (!resp.ok) throw new Error('arxiv fetch failed');
    text = await resp.text();
    const xmlStart = text.indexOf('<?xml');
    if (xmlStart > -1) text = text.slice(xmlStart);
  }

  const doc = new DOMParser().parseFromString(text, 'text/xml');
  const entries = doc.querySelectorAll('entry');
  const out = [];

  entries.forEach(entry => {
    const title = textOf(entry.querySelector('title')).replace(/\s+/g, ' ');
    if (!title) return;

    // arXiv link: find the <link rel="alternate" type="text/html">
    let url = '';
    entry.querySelectorAll('link').forEach(l => {
      if (l.getAttribute('rel') === 'alternate') url = l.getAttribute('href') || '';
    });
    if (!url) return;

    const published = textOf(entry.querySelector('published'));
    const summary = textOf(entry.querySelector('summary')).replace(/\s+/g, ' ');
    const authors = Array.from(entry.querySelectorAll('author name')).map(n => n.textContent.trim());

    // Categories (tags)
    const cats = Array.from(entry.querySelectorAll('category'))
      .map(c => c.getAttribute('term'))
      .filter(Boolean);

    out.push({
      id: 'arxiv:' + hashString(url),
      source: 'arxiv',
      sourceName: 'arXiv',
      title,
      url,
      summary: summary.slice(0, 500),
      author: authors.slice(0, 3).join(', '),
      date: new Date(published).getTime(),
      tags: cats.slice(0, 4)
    });
  });

  return out;
}

// ========================================================================
// Topic matching — tag items whose title/summary contain a user topic.
// Matches are case-insensitive. A topic matches if either:
//   - the item text contains the topic string, OR
//   - the item text contains the topic's "stem" (strip trailing s/es/ing)
// so "agents" matches "agent", "diffusion" matches "diffusion", etc.
// ========================================================================
function stem(word) {
  let w = word.toLowerCase();
  if (w.length > 4 && w.endsWith('ies')) return w.slice(0, -3) + 'y';
  if (w.length > 4 && w.endsWith('ing')) return w.slice(0, -3);
  if (w.length > 3 && w.endsWith('es')) return w.slice(0, -2);
  if (w.length > 3 && w.endsWith('s')) return w.slice(0, -1);
  return w;
}

export function tagTopicMatches(items, topics) {
  if (!topics?.length) {
    for (const it of items) it.matchedTopics = [];
    return items;
  }
  // Precompute stems for topics
  const topicStems = topics.map(t => ({
    text: t.text,
    full: t.id,          // already lowercased
    stem: stem(t.id)
  }));

  for (const it of items) {
    const hay = ((it.title || '') + ' ' + (it.summary || '')).toLowerCase();
    const matches = [];
    for (const t of topicStems) {
      // Fast path: full substring match
      if (hay.includes(t.full)) {
        matches.push(t.text);
        continue;
      }
      // Stem match: find whole-word matches on the stem
      // Use a simple word-boundary check rather than a regex on every word
      const idx = hay.indexOf(t.stem);
      if (idx >= 0) {
        const before = idx === 0 ? ' ' : hay[idx - 1];
        if (!/[a-z0-9]/.test(before)) {
          matches.push(t.text);
        }
      }
    }
    it.matchedTopics = matches;
  }
  return items;
}

export { RSS_SOURCES };
