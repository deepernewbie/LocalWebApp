// templates-extra-2.js — 10 templates: art/creative (5) + retro (5)

const gfonts = (family) => `<link href="https://fonts.googleapis.com/css2?${family}&display=swap" rel="stylesheet">`;

function basicRender(ctx, opts = {}) {
  const { slide, isCover, esc, bullets, img, editable } = ctx;
  const e = (f) => editable ? `data-field="${f}"` : '';
  return `<section class="slide ${isCover ? 'cover' : ''}">
    ${opts.before ? opts.before(ctx) : ''}
    <h1 ${e('title')}>${esc(slide.title)}</h1>
    ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
    ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
    ${bullets(slide.bullets)}
    ${img(slide)}
    ${opts.after ? opts.after(ctx) : ''}
  </section>`;
}

// ============ ART / CREATIVE (5) ============

const watercolor = {
  id: 'watercolor', name: 'Watercolor', tag: 'Soft · Painterly',
  fonts: gfonts('family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=Caveat:wght@400'),
  css: `
    body { background: #fbf7f0; color: #3a3a3a; font-family: 'Cormorant Garamond', serif; position: relative; }
    body::before { content: ''; position: fixed; inset: 0; background: radial-gradient(ellipse at 15% 20%, rgba(166,124,164,0.18), transparent 40%), radial-gradient(ellipse at 85% 80%, rgba(245,180,140,0.18), transparent 40%), radial-gradient(ellipse at 50% 50%, rgba(120,158,180,0.12), transparent 50%); pointer-events: none; }
    .slide { padding: 8vmin 10vmin; justify-content: center; z-index: 1; }
    h1 { font-size: clamp(36px, 7vw, 66px); font-weight: 400; line-height: 1.05; margin-bottom: 20px; color: #2d2d2d; font-style: italic; }
    h1::first-letter { color: #a67ca4; font-size: 1.3em; font-weight: 600; }
    .subtitle { font-family: 'Caveat', cursive; font-size: clamp(22px, 3.2vw, 30px); color: #a67ca4; margin-bottom: 24px; }
    .body { font-size: clamp(16px, 2vw, 19px); line-height: 1.7; max-width: 750px; margin-bottom: 14px; color: #4a4a4a; }
    ul { list-style: none; max-width: 750px; }
    li { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.65; padding: 8px 0 8px 30px; position: relative; }
    li::before { content: '\u273F'; position: absolute; left: 0; top: 8px; color: #a67ca4; }
    .slide img { max-width: 430px; max-height: 45vh; margin-top: 20px; border-radius: 4px; box-shadow: 0 20px 40px rgba(166,124,164,0.2); filter: saturate(0.85); }
    .cover { text-align: center; align-items: center; }
    .cover h1 { font-size: clamp(46px, 10vw, 94px); }
    .deck-progress { background: #a67ca4; height: 2px; }
  `,
  preview: () => `<div style="background:#fbf7f0;height:100%;padding:10px;position:relative">
    <div style="position:absolute;inset:0;background:radial-gradient(circle at 30% 30%,rgba(166,124,164,.4),transparent 50%),radial-gradient(circle at 70% 70%,rgba(245,180,140,.4),transparent 50%)"></div>
    <div style="font-family:serif;font-style:italic;font-size:12px;color:#2d2d2d;position:relative">Soft</div>
    <div style="font-family:cursive;font-size:7px;color:#a67ca4;position:relative;margin-top:2px">painted</div></div>`,
  render: (ctx) => basicRender(ctx)
};

const oilPaint = {
  id: 'oil-paint', name: 'Oil Paint', tag: 'Rich · Renaissance',
  fonts: gfonts('family=Cormorant:ital,wght@0,400;0,700;1,400&family=Italianno'),
  css: `
    body { background: #2a1f1a; color: #f2e8d8; font-family: 'Cormorant', serif; }
    body::before { content: ''; position: fixed; inset: 0; background: radial-gradient(ellipse at 30% 30%, rgba(200,140,60,0.25), transparent 50%), radial-gradient(ellipse at 70% 70%, rgba(120,40,30,0.3), transparent 50%); pointer-events: none; }
    .slide { padding: 8vmin 10vmin; justify-content: center; z-index: 1; }
    h1 { font-family: 'Italianno', cursive; font-size: clamp(54px, 11vw, 100px); font-weight: 400; line-height: 1; color: #e6c77a; margin-bottom: 18px; text-shadow: 2px 4px 10px rgba(0,0,0,0.5); }
    .subtitle { font-style: italic; font-size: clamp(18px, 2.6vw, 26px); color: #d8c9a8; margin-bottom: 24px; max-width: 800px; }
    .body { font-size: clamp(16px, 2vw, 20px); line-height: 1.7; max-width: 750px; margin-bottom: 14px; }
    ul { list-style: none; max-width: 750px; }
    li { font-size: clamp(15px, 1.9vw, 19px); line-height: 1.6; padding: 8px 0 8px 32px; position: relative; border-bottom: 1px solid rgba(230,199,122,0.2); }
    li::before { content: '\u2756'; position: absolute; left: 0; top: 10px; color: #e6c77a; }
    .slide img { max-width: 400px; max-height: 45vh; margin-top: 22px; border: 8px solid #3a2d1f; box-shadow: 0 20px 40px rgba(0,0,0,0.5); filter: sepia(0.2) saturate(1.1); }
    .cover { text-align: center; align-items: center; }
    .deck-progress { background: #e6c77a; }
  `,
  preview: () => `<div style="background:#2a1f1a;height:100%;padding:8px;position:relative">
    <div style="position:absolute;inset:0;background:radial-gradient(circle at 50% 50%,rgba(200,140,60,.4),transparent 60%)"></div>
    <div style="font-family:cursive;font-size:16px;color:#e6c77a;position:relative;line-height:1">Renoir</div>
    <div style="font-family:serif;font-style:italic;font-size:5px;color:#d8c9a8;position:relative;margin-top:2px">\u2014 a study \u2014</div></div>`,
  render: (ctx) => basicRender(ctx)
};

const collage = {
  id: 'collage', name: 'Collage', tag: 'Cut & Paste',
  fonts: gfonts('family=Bebas+Neue&family=Caveat:wght@700&family=Libre+Baskerville:ital@1'),
  css: `
    body { background: #eaeadf; color: #111; font-family: 'Libre Baskerville', serif; }
    .slide { padding: 6vmin; }
    .paper-bg { position: absolute; inset: 4vmin; background: #fefcf6; box-shadow: 0 10px 30px rgba(0,0,0,0.1); z-index: 0; }
    .content { position: relative; z-index: 1; padding: 4vmin 5vmin; }
    h1 { font-family: 'Bebas Neue', sans-serif; font-size: clamp(40px, 9vw, 82px); line-height: .95; letter-spacing: .02em; margin-bottom: 18px; color: #111; transform: rotate(-1deg); display: inline-block; position: relative; }
    h1::after { content: ''; position: absolute; bottom: 4px; left: 0; right: 0; height: 10px; background: #ffeb3b; z-index: -1; transform: skewX(-10deg); }
    .subtitle { font-family: 'Caveat', cursive; font-size: clamp(20px, 3vw, 28px); color: #c03030; transform: rotate(1.5deg); margin-bottom: 20px; display: inline-block; }
    .body { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.6; font-style: italic; background: #f5ede0; padding: 10px 14px; border: 1px solid #333; max-width: 680px; margin-bottom: 12px; transform: rotate(-.5deg); }
    ul { list-style: none; max-width: 680px; }
    li { font-size: clamp(13px, 1.7vw, 16px); padding: 6px 12px; background: #fff; border: 1px dashed #333; margin-bottom: 6px; font-style: italic; transform: rotate(-.5deg); }
    li:nth-child(even) { background: #ffe066; transform: rotate(.7deg); }
    li:nth-child(3n) { background: #d0e6f5; }
    .slide img { max-width: 280px; max-height: 30vh; border: 4px solid #fff; box-shadow: 4px 4px 0 #333; transform: rotate(3deg); margin-top: 14px; }
    .tape { position: absolute; width: 60px; height: 20px; background: rgba(255,235,59,0.6); border-left: 1px dashed rgba(0,0,0,0.2); border-right: 1px dashed rgba(0,0,0,0.2); transform: rotate(-15deg); top: 4vmin; left: 50%; margin-left: -30px; z-index: 2; }
    .deck-progress { background: #c03030; }
  `,
  preview: () => `<div style="background:#eaeadf;height:100%;padding:4px;position:relative">
    <div style="background:#fefcf6;height:100%;padding:4px">
      <div style="font-family:sans-serif;font-weight:700;font-size:10px;background:#ffeb3b;display:inline-block;padding:0 2px;transform:rotate(-2deg)">CUT!</div>
      <div style="font-family:cursive;font-size:6px;color:#c03030;margin-top:3px;transform:rotate(2deg)">paste it</div></div></div>`,
  render: (ctx) => {
    const { slide, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="paper-bg"></div>
      <div class="tape"></div>
      <div class="content">
        <h1 ${e('title')}>${esc(slide.title)}</h1>
        ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
        ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
        ${bullets(slide.bullets)}
        ${img(slide)}
      </div>
    </section>`;
  }
};

const risograph = {
  id: 'risograph', name: 'Risograph', tag: 'Print · Duotone',
  fonts: gfonts('family=Space+Grotesk:wght@500;700&family=Fraunces:ital,opsz,wght@1,9..144,600'),
  css: `
    body { background: #f3ede0; color: #2a1d3f; font-family: 'Space Grotesk', sans-serif; }
    body::before { content: ''; position: fixed; inset: 0; background-image: radial-gradient(circle at 2px 2px, rgba(42,29,63,0.08) 1px, transparent 0); background-size: 5px 5px; pointer-events: none; mix-blend-mode: multiply; }
    .slide { padding: 7vmin 9vmin; justify-content: center; }
    .blob { position: absolute; border-radius: 50%; mix-blend-mode: multiply; filter: blur(2px); opacity: 0.7; pointer-events: none; }
    .blob.b1 { top: -100px; right: -80px; background: #ff6b9d; width: 300px; height: 300px; }
    .blob.b2 { bottom: -120px; left: -80px; background: #5bc0eb; width: 400px; height: 400px; }
    h1 { font-family: 'Fraunces', serif; font-style: italic; font-size: clamp(40px, 7.5vw, 72px); font-weight: 600; line-height: 1; margin-bottom: 20px; color: #2a1d3f; position: relative; }
    .subtitle { font-size: clamp(16px, 2.2vw, 22px); color: #ff6b9d; font-weight: 700; margin-bottom: 22px; text-transform: uppercase; letter-spacing: .15em; position: relative; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.6; max-width: 720px; margin-bottom: 14px; position: relative; }
    ul { list-style: none; max-width: 720px; position: relative; }
    li { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.55; padding: 8px 0 8px 30px; position: relative; font-weight: 500; }
    li::before { content: '\u25CF'; position: absolute; left: 0; top: 6px; color: #ff6b9d; font-size: 1.3em; }
    .slide img { max-width: 380px; max-height: 40vh; margin-top: 18px; filter: sepia(1) hue-rotate(280deg) saturate(3); mix-blend-mode: multiply; position: relative; }
    .cover h1 { font-size: clamp(54px, 12vw, 118px); }
    .deck-progress { background: #ff6b9d; }
  `,
  preview: () => `<div style="background:#f3ede0;height:100%;padding:8px;position:relative;overflow:hidden">
    <div style="position:absolute;top:-10px;right:-10px;width:30px;height:30px;border-radius:50%;background:#ff6b9d;opacity:.6"></div>
    <div style="position:absolute;bottom:-10px;left:-10px;width:30px;height:30px;border-radius:50%;background:#5bc0eb;opacity:.6"></div>
    <div style="font-family:serif;font-style:italic;font-size:12px;font-weight:700;position:relative;color:#2a1d3f">Riso</div>
    <div style="font-size:4px;color:#ff6b9d;font-weight:700;position:relative;margin-top:2px;letter-spacing:1px">DUOTONE</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: () => `<div class="blob b1"></div><div class="blob b2"></div>`
  })
};

const blueprint = {
  id: 'blueprint', name: 'Blueprint', tag: 'Technical drawing',
  fonts: gfonts('family=Nanum+Gothic+Coding:wght@400;700&family=Antonio:wght@400;700'),
  css: `
    body { background: #103060; color: #e3eeff; font-family: 'Nanum Gothic Coding', monospace; background-image: linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px); background-size: 20px 20px; }
    .slide { padding: 7vmin; }
    .title-box { border: 1px solid #e3eeff; padding: 16px 22px; display: inline-block; margin-bottom: 18px; max-width: 90%; }
    h1 { font-family: 'Antonio', sans-serif; font-size: clamp(32px, 6.5vw, 58px); line-height: 1.1; font-weight: 700; letter-spacing: .02em; text-transform: uppercase; }
    .subtitle { font-size: clamp(14px, 1.7vw, 17px); margin-top: 10px; color: #b4c9e8; }
    .body { font-size: clamp(13px, 1.6vw, 16px); line-height: 1.6; max-width: 820px; margin-bottom: 12px; }
    ul { list-style: none; max-width: 820px; counter-reset: sp; }
    li { font-size: clamp(12px, 1.5vw, 15px); line-height: 1.7; padding: 4px 0 4px 70px; position: relative; counter-increment: sp; }
    li::before { content: 'SPEC-' counter(sp, decimal-leading-zero); position: absolute; left: 0; top: 4px; color: #90b4e8; font-weight: 700; }
    .slide img { max-width: 360px; max-height: 40vh; margin-top: 14px; border: 1px solid #e3eeff; filter: hue-rotate(180deg) saturate(0) brightness(1.5); }
    .legend { position: absolute; bottom: 4vmin; right: 5vmin; border: 1px solid #e3eeff; padding: 6px 12px; font-size: 10px; }
    .legend-row { display: flex; justify-content: space-between; gap: 20px; }
    .cross { position: absolute; width: 12px; height: 12px; }
    .cross.tl { top: 8px; left: 8px; border-left: 1px solid #e3eeff; border-top: 1px solid #e3eeff; }
    .cross.tr { top: 8px; right: 8px; border-right: 1px solid #e3eeff; border-top: 1px solid #e3eeff; }
    .cross.bl { bottom: 8px; left: 8px; border-left: 1px solid #e3eeff; border-bottom: 1px solid #e3eeff; }
    .cross.br { bottom: 8px; right: 8px; border-right: 1px solid #e3eeff; border-bottom: 1px solid #e3eeff; }
    .deck-progress { background: #e3eeff; height: 1px; }
  `,
  preview: () => `<div style="background:#103060;height:100%;padding:4px;position:relative;background-image:linear-gradient(rgba(255,255,255,.1) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.1) 1px,transparent 1px);background-size:4px 4px">
    <div style="border:1px solid #e3eeff;padding:2px;display:inline-block;color:#e3eeff;font-family:monospace;font-weight:700;font-size:8px">PLAN</div></div>`,
  render: (ctx) => {
    const { slide, project, index, total, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="cross tl"></div><div class="cross tr"></div><div class="cross bl"></div><div class="cross br"></div>
      <div class="title-box">
        <h1 ${e('title')}>${esc(slide.title)}</h1>
        ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      </div>
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      <div class="legend">
        <div class="legend-row"><span>PROJECT</span><span>${esc(project.topic).slice(0,20)}</span></div>
        <div class="legend-row"><span>SHEET</span><span>${String(index+1).padStart(3,'0')} / ${String(total).padStart(3,'0')}</span></div>
        <div class="legend-row"><span>DATE</span><span>${new Date(project.createdAt).toISOString().slice(0,10)}</span></div>
      </div>
    </section>`;
  }
};

// ============ RETRO (5) ============

const vaporwave = {
  id: 'vaporwave', name: 'Vaporwave', tag: 'Retro · Neon',
  fonts: gfonts('family=VT323&family=Shippori+Mincho:wght@700'),
  css: `
    body { background: linear-gradient(180deg, #0a0030 0%, #4a0080 50%, #ff006e 100%); color: #ffeaf4; font-family: 'VT323', monospace; }
    body::before { content: ''; position: fixed; inset: 0; background-image: linear-gradient(rgba(0,255,255,0.1) 1px, transparent 1px); background-size: 100% 30px; background-position: 0 50%; pointer-events: none; transform: perspective(400px) rotateX(60deg); transform-origin: center 80%; }
    .slide { padding: 7vmin; justify-content: center; z-index: 1; }
    h1 { font-family: 'Shippori Mincho', serif; font-size: clamp(42px, 9vw, 82px); font-weight: 700; line-height: 1; color: #fff; text-shadow: 0 0 20px #ff00ff, 3px 3px 0 #00ffff; margin-bottom: 20px; letter-spacing: -.02em; }
    .subtitle { font-size: clamp(20px, 2.8vw, 28px); color: #00ffff; text-shadow: 0 0 10px #00ffff; margin-bottom: 22px; letter-spacing: .15em; }
    .body { font-size: clamp(17px, 2.2vw, 22px); line-height: 1.6; max-width: 820px; margin-bottom: 14px; }
    ul { list-style: none; max-width: 820px; }
    li { font-size: clamp(17px, 2.2vw, 22px); line-height: 1.6; padding: 8px 0 8px 34px; position: relative; }
    li::before { content: '\u2666'; position: absolute; left: 0; top: 8px; color: #ff00ff; text-shadow: 0 0 8px #ff00ff; }
    .slide img { max-width: 380px; max-height: 40vh; margin-top: 18px; border: 2px solid #00ffff; box-shadow: 0 0 30px #ff00ff; filter: saturate(1.4) hue-rotate(-10deg); }
    .japanese { font-family: 'Shippori Mincho', serif; color: #ff00ff; text-shadow: 0 0 8px #ff00ff; font-size: clamp(16px, 2.3vw, 24px); letter-spacing: .3em; margin-bottom: 10px; }
    .deck-progress { background: linear-gradient(90deg, #ff00ff, #00ffff); box-shadow: 0 0 8px #ff00ff; }
  `,
  preview: () => `<div style="background:linear-gradient(180deg,#0a0030,#ff006e);height:100%;padding:8px;position:relative">
    <div style="font-family:serif;color:#fff;font-size:14px;font-weight:700;text-shadow:1px 1px 0 #00ffff,-1px -1px 0 #ff00ff;line-height:1">Vapor</div>
    <div style="font-family:monospace;color:#00ffff;font-size:6px;letter-spacing:2px;margin-top:2px">A E S T H E T I C</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ isCover }) => isCover ? `<div class="japanese">\u30B3\u30F3\u30D4\u30E5\u30FC\u30BF</div>` : ''
  })
};

const arcade80s = {
  id: 'arcade-80s', name: '80s Arcade', tag: 'Pixel · Chrome',
  fonts: gfonts('family=Press+Start+2P&family=Audiowide'),
  css: `
    body { background: #0a0025; color: #ffd700; font-family: 'Audiowide', sans-serif; }
    body::before { content: ''; position: fixed; inset: 0; background-image: linear-gradient(rgba(255,0,128,0.2) 1px, transparent 1px); background-size: 100% 40px; background-position: 0 100%; transform: perspective(300px) rotateX(60deg); transform-origin: center bottom; pointer-events: none; z-index: 0; }
    body::after { content: ''; position: fixed; top: 0; left: 0; right: 0; height: 50%; background: radial-gradient(ellipse at center, transparent, transparent 70%, rgba(10,0,37,0.8)); pointer-events: none; z-index: 0; }
    .slide { padding: 7vmin; justify-content: center; z-index: 1; }
    h1 { font-size: clamp(36px, 8vw, 70px); font-weight: 700; line-height: 1; background: linear-gradient(180deg, #ffd700 0%, #ff00a8 50%, #3d00a8 100%); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 22px; text-shadow: 0 0 30px rgba(255,215,0,0.4); letter-spacing: .05em; }
    .subtitle { font-family: 'Press Start 2P', monospace; font-size: clamp(11px, 1.6vw, 15px); color: #00ffff; margin-bottom: 24px; letter-spacing: .1em; line-height: 1.6; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.7; max-width: 800px; color: #fff; margin-bottom: 14px; }
    ul { list-style: none; max-width: 800px; }
    li { font-family: 'Press Start 2P', monospace; font-size: clamp(10px, 1.3vw, 13px); line-height: 2; color: #fff; padding: 6px 0 6px 30px; position: relative; }
    li::before { content: '\u25B6'; position: absolute; left: 0; color: #ff00a8; }
    .slide img { max-width: 380px; max-height: 40vh; margin-top: 20px; border: 3px solid #ffd700; image-rendering: pixelated; filter: saturate(1.5); }
    .highscore { position: absolute; top: 4vmin; left: 7vmin; font-family: 'Press Start 2P', monospace; color: #ffd700; font-size: 10px; letter-spacing: .1em; }
    .cover h1 { font-size: clamp(44px, 11vw, 100px); }
    .deck-progress { background: #ff00a8; height: 4px; box-shadow: 0 0 10px #ff00a8; }
  `,
  preview: () => `<div style="background:#0a0025;height:100%;padding:8px;position:relative;overflow:hidden">
    <div style="font-family:sans-serif;font-weight:900;font-size:10px;background:linear-gradient(180deg,#ffd700,#ff00a8);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;line-height:1">ARCADE</div>
    <div style="font-family:monospace;font-size:4px;color:#00ffff;margin-top:2px">PRESS START</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ index }) => `<div class="highscore">SCORE \u00D7 ${String(index+1).padStart(6,'0')}</div>`
  })
};

const artDeco = {
  id: 'art-deco', name: 'Art Deco', tag: 'Gatsby · Gold',
  fonts: gfonts('family=Poiret+One&family=Cinzel:wght@400;700'),
  css: `
    body { background: #1a1411; color: #e8d4a8; font-family: 'Cinzel', serif; }
    .slide { padding: 8vmin 10vmin; justify-content: center; text-align: center; align-items: center; }
    .slide::before { content: ''; position: absolute; top: 3vmin; left: 3vmin; right: 3vmin; bottom: 3vmin; border: 1px solid #d4af37; pointer-events: none; }
    .slide::after { content: ''; position: absolute; top: 4vmin; left: 4vmin; right: 4vmin; bottom: 4vmin; border: 1px solid #d4af37; pointer-events: none; }
    .ornament { color: #d4af37; font-size: 24px; margin-bottom: 14px; letter-spacing: .5em; }
    h1 { font-family: 'Poiret One', sans-serif; font-size: clamp(38px, 8vw, 72px); font-weight: 400; line-height: 1.05; color: #d4af37; margin-bottom: 18px; letter-spacing: .05em; text-transform: uppercase; }
    .subtitle { font-size: clamp(15px, 1.8vw, 19px); letter-spacing: .35em; text-transform: uppercase; color: #b89560; margin-bottom: 24px; }
    .body { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.8; max-width: 720px; margin: 0 auto 14px; font-style: italic; }
    ul { list-style: none; max-width: 700px; margin: 0 auto; }
    li { font-size: clamp(13px, 1.7vw, 16px); line-height: 1.8; padding: 6px 0; border-top: 1px solid rgba(212,175,55,0.2); text-align: center; letter-spacing: .1em; }
    li:first-child { border-top: 1px solid #d4af37; }
    li:last-child { border-bottom: 1px solid #d4af37; }
    .slide img { max-width: 340px; max-height: 35vh; margin: 20px auto 0; border: 2px solid #d4af37; filter: sepia(0.3); }
    .cover h1 { font-size: clamp(50px, 12vw, 120px); }
    .deck-progress { background: #d4af37; height: 1px; }
  `,
  preview: () => `<div style="background:#1a1411;height:100%;padding:4px;position:relative">
    <div style="position:absolute;inset:2px;border:1px solid #d4af37"></div>
    <div style="position:absolute;inset:4px;border:1px solid #d4af37;padding:4px 2px;text-align:center">
      <div style="font-family:serif;font-size:10px;color:#d4af37;line-height:1">DECO</div>
      <div style="font-size:4px;color:#b89560;letter-spacing:2px;margin-top:2px">EST. 1925</div></div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: () => `<div class="ornament">\u2756 \u2756 \u2756</div>`
  })
};

const midCentury = {
  id: 'mid-century', name: 'Mid Century', tag: '1960s modern',
  fonts: gfonts('family=Archivo:wght@500;700;900&family=DM+Serif+Display'),
  css: `
    body { background: #e8dcc4; color: #2b1d0f; font-family: 'Archivo', sans-serif; }
    .slide { padding: 8vmin 10vmin; justify-content: center; }
    .slide::before { content: ''; position: absolute; top: 0; right: 0; width: 35%; height: 100%; background: radial-gradient(circle at 70% 30%, #ff6b35 0, #ff6b35 60px, transparent 60px), linear-gradient(135deg, #d4533f 0%, #c03030 100%); opacity: .9; clip-path: polygon(20% 0, 100% 0, 100% 100%, 0 100%); }
    h1 { font-family: 'DM Serif Display', serif; font-size: clamp(38px, 8vw, 72px); font-weight: 400; line-height: .95; letter-spacing: -.02em; margin-bottom: 18px; color: #2b1d0f; max-width: 60%; position: relative; }
    .subtitle { font-size: clamp(15px, 1.9vw, 19px); color: #7a5a38; margin-bottom: 22px; max-width: 60%; letter-spacing: .05em; text-transform: uppercase; font-weight: 700; position: relative; }
    .body { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.7; max-width: 60%; margin-bottom: 14px; font-weight: 500; position: relative; }
    ul { list-style: none; max-width: 60%; position: relative; }
    li { font-size: clamp(13px, 1.7vw, 16px); line-height: 1.6; padding: 6px 0 6px 28px; position: relative; font-weight: 500; }
    li::before { content: ''; position: absolute; left: 0; top: 12px; width: 16px; height: 4px; background: #ff6b35; }
    .slide img { max-width: 280px; max-height: 30vh; margin-top: 16px; filter: sepia(0.2); position: relative; }
    .cover h1 { font-size: clamp(52px, 11vw, 110px); max-width: 100%; }
    .deck-progress { background: #ff6b35; }
  `,
  preview: () => `<div style="background:#e8dcc4;height:100%;padding:6px;position:relative;overflow:hidden">
    <div style="position:absolute;right:-8px;top:-8px;width:20px;height:20px;background:#ff6b35;border-radius:50%"></div>
    <div style="font-family:serif;font-size:10px;font-weight:700;color:#2b1d0f;line-height:1;position:relative">Modern</div>
    <div style="font-size:4px;color:#7a5a38;letter-spacing:1px;margin-top:3px;position:relative">CIRCA 1962</div></div>`,
  render: (ctx) => basicRender(ctx)
};

const postcard = {
  id: 'postcard', name: 'Postcard', tag: 'Vintage · Travel',
  fonts: gfonts('family=Fraunces:ital,wght@1,700&family=Homemade+Apple'),
  css: `
    body { background: #f0e4d0; color: #2a1d0f; font-family: 'Georgia', serif; }
    .slide { padding: 5vmin; display: none; }
    .slide.active { display: grid; grid-template-columns: 1fr 1fr; gap: 4vmin; }
    .slide::before { content: ''; position: absolute; inset: 3vmin; border: 1px dashed rgba(0,0,0,0.3); pointer-events: none; }
    .left, .right { padding: 3vmin; position: relative; }
    .left { border-right: 1px solid rgba(0,0,0,0.2); display: flex; align-items: center; justify-content: center; }
    h1 { font-family: 'Fraunces', serif; font-style: italic; font-size: clamp(32px, 6.5vw, 58px); line-height: 1.05; margin-bottom: 14px; color: #8b4513; }
    .subtitle { font-family: 'Homemade Apple', cursive; font-size: clamp(15px, 2vw, 20px); color: #5a3a1f; margin-bottom: 18px; }
    .body { font-family: 'Homemade Apple', cursive; font-size: clamp(13px, 1.7vw, 16px); line-height: 1.9; margin-bottom: 12px; color: #2a1d0f; }
    ul { list-style: none; }
    li { font-family: 'Homemade Apple', cursive; font-size: clamp(12px, 1.6vw, 15px); line-height: 1.9; padding: 2px 0 2px 24px; position: relative; color: #2a1d0f; }
    li::before { content: '\u2665'; position: absolute; left: 0; color: #c03030; top: 4px; }
    .slide img { max-width: 100%; max-height: 60vh; object-fit: cover; border: 4px solid #fff; box-shadow: 2px 2px 8px rgba(0,0,0,0.3); filter: sepia(0.3) saturate(0.85); }
    .stamp { position: absolute; top: 3vmin; right: 3vmin; width: 70px; height: 80px; border: 2px dashed #8b4513; padding: 6px; text-align: center; transform: rotate(5deg); }
    .stamp span { font-family: 'Fraunces', serif; font-size: 9px; color: #8b4513; text-transform: uppercase; letter-spacing: .1em; font-style: italic; font-weight: 700; display: block; line-height: 1.2; }
    .postmark { display: inline-block; border: 2px solid #8b4513; color: #8b4513; padding: 4px 10px; font-size: 10px; border-radius: 50px; font-family: 'Fraunces', serif; font-style: italic; margin-bottom: 14px; }
    .placeholder { background: #c9b99a; height: 80%; width: 100%; border: 4px solid #fff; display: grid; place-items: center; font-family: serif; font-style: italic; color: #8b4513; box-shadow: 2px 2px 8px rgba(0,0,0,0.3); }
    .deck-progress { background: #8b4513; height: 2px; }
    @media (max-width: 800px) { .slide.active { grid-template-columns: 1fr; } .left { border-right: none; border-bottom: 1px solid rgba(0,0,0,0.2); padding-bottom: 3vmin; } }
  `,
  preview: () => `<div style="background:#f0e4d0;height:100%;padding:4px;display:grid;grid-template-columns:1fr 1fr;gap:2px">
    <div style="background:#ddd;min-height:100%"></div>
    <div style="padding:2px">
      <div style="font-family:serif;font-style:italic;font-size:10px;color:#8b4513;line-height:1">Greetings</div>
      <div style="font-family:cursive;font-size:5px;color:#2a1d0f;margin-top:2px">wish you<br>were here</div></div></div>`,
  render: (ctx) => {
    const { slide, project, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    const imgHtml = img(slide);
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="left">${imgHtml || `<div class="placeholder">${esc(project.topic).slice(0,30)}</div>`}</div>
      <div class="right">
        <div class="postmark">Greetings</div>
        <h1 ${e('title')}>${esc(slide.title)}</h1>
        ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
        ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
        ${bullets(slide.bullets)}
        <div class="stamp"><span>Postage</span><span style="font-size:16px;margin-top:4px">\u2708</span><span>Air Mail</span></div>
      </div>
    </section>`;
  }
};

export const TEMPLATES_EXTRA_2 = [watercolor, oilPaint, collage, risograph, blueprint, vaporwave, arcade80s, artDeco, midCentury, postcard];
