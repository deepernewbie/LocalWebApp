// templates-core.js — the original 10 templates, adapted to the shared scaffold
// Each template is an object: { id, name, tag, fonts, vars, css, preview, render }
// - `fonts`: <link> tags for web fonts
// - `vars`: CSS custom properties injected under :root
// - `css`: the template's unique styles
// - `preview`: returns a small HTML snippet for the picker
// - `render(ctx)`: returns the HTML for one slide

// Shared helper for putting fonts link tags
const gfonts = (family) => `<link href="https://fonts.googleapis.com/css2?${family}&display=swap" rel="stylesheet">`;

// ---- 1. EDITORIAL ----
const editorial = {
  id: 'editorial', name: 'Editorial', tag: 'Serif · Classic',
  fonts: gfonts('family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;0,9..144,800;1,9..144,400&family=Inter:wght@400;500;600'),
  css: `
    body { background: #f6f2e8; color: #1a1613; font-family: 'Inter', sans-serif; }
    .slide { padding: 8vmin 8vmin 10vmin; }
    .slide::before { content: attr(data-num); position: absolute; top: 3vmin; right: 8vmin; font-family: 'Fraunces', serif; font-style: italic; color: #a89a7f; font-size: 14px; }
    .slide::after { content: attr(data-title); position: absolute; top: 3vmin; left: 8vmin; font-size: 10px; letter-spacing: .2em; text-transform: uppercase; color: #a89a7f; font-weight: 600; }
    h1 { font-family: 'Fraunces', serif; font-weight: 800; font-size: clamp(40px, 7vw, 72px); letter-spacing: -.02em; line-height: 1.05; margin-bottom: 20px; }
    h1 em { font-style: italic; font-weight: 400; color: #8b1e1e; }
    .subtitle { font-family: 'Fraunces', serif; font-style: italic; font-size: clamp(18px, 2.2vw, 22px); color: #6b5d48; margin-bottom: 24px; }
    .body { font-family: 'Fraunces', serif; font-size: clamp(16px, 1.9vw, 19px); line-height: 1.55; margin-bottom: 14px; max-width: 900px; }
    ul { list-style: none; max-width: 820px; }
    li { font-family: 'Fraunces', serif; font-size: clamp(16px, 1.9vw, 19px); line-height: 1.5; padding: 10px 0 10px 30px; border-bottom: 1px dotted #bfb49d; position: relative; }
    li::before { content: '\u00A7'; position: absolute; left: 0; top: 10px; color: #8b1e1e; font-weight: 600; }
    .cover { justify-content: center; align-items: flex-start; }
    .cover h1 { font-size: clamp(48px, 9vw, 88px); }
    .kicker { font-size: 12px; letter-spacing: .3em; text-transform: uppercase; color: #8b1e1e; font-weight: 600; margin-bottom: 20px; }
    .slide img { max-width: 55%; max-height: 55%; object-fit: cover; align-self: center; margin-top: 20px; filter: sepia(.08); }
    .deck-nav { color: #1a1613; background: rgba(246,242,232,0.9); }
    .deck-progress { background: #8b1e1e; }
  `,
  preview: () => `<div style="background:#f6f2e8;height:100%;padding:10px;display:flex;flex-direction:column;justify-content:space-between">
    <div style="font-family:Georgia,serif;font-weight:800;font-size:10px;color:#111;line-height:1.1">Editorial</div>
    <div style="border-top:2px solid #111;padding-top:4px"><div style="font-family:Georgia,serif;font-size:6px;color:#666">Essay · Vol. I</div></div></div>`,
  render: ({ slide, index, total, project, isCover, esc, ed, bullets, img, editable }) => `
    <section class="slide ${isCover ? 'cover' : ''}" data-num="${String(index+1).padStart(2,'0')}" data-title="${esc(project.topic).slice(0,40)}">
      ${isCover ? `<div class="kicker">A Presentation</div>` : ''}
      <h1 ${editable?`data-field="title"`:''}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`
};

// ---- 2. MINIMAL ----
const minimal = {
  id: 'minimal', name: 'Minimal', tag: 'Clean · Light',
  fonts: gfonts('family=Manrope:wght@200;400;600;800'),
  css: `
    body { background: #fff; color: #0a0a0a; font-family: 'Manrope', sans-serif; font-weight: 400; }
    .slide { padding: 10vmin; justify-content: center; }
    h1 { font-size: clamp(40px, 7vw, 64px); font-weight: 200; letter-spacing: -.04em; line-height: 1.05; margin-bottom: 24px; }
    .subtitle { font-size: clamp(18px, 2.5vw, 22px); color: #737373; margin-bottom: 20px; font-weight: 300; }
    .body { font-size: clamp(16px, 1.9vw, 19px); line-height: 1.6; color: #525252; max-width: 700px; margin-bottom: 14px; }
    ul { list-style: none; max-width: 700px; }
    li { font-size: clamp(16px, 1.9vw, 19px); line-height: 1.6; padding: 12px 0 12px 24px; color: #525252; border-bottom: 1px solid #f0f0f0; position: relative; }
    li::before { content: ''; position: absolute; left: 0; top: 20px; width: 6px; height: 6px; background: #0a0a0a; border-radius: 50%; }
    .cover h1 { font-size: clamp(48px, 10vw, 96px); }
    .cover .dot { width: 40px; height: 2px; background: #0a0a0a; margin-bottom: 32px; }
    .slide-num { position: absolute; top: 3vmin; right: 4vmin; font-size: 11px; color: #a3a3a3; letter-spacing: .2em; font-weight: 600; }
    .slide img { max-width: 500px; max-height: 45vh; margin-top: 32px; border-radius: 4px; }
    .deck-nav { background: rgba(255,255,255,0.9); border: 1px solid #e5e5e5; color: #0a0a0a; }
    .deck-progress { background: #0a0a0a; height: 1px; }
  `,
  preview: () => `<div style="background:#fff;height:100%;padding:10px;display:flex;align-items:center;justify-content:center">
    <div style="text-align:center"><div style="width:16px;height:1px;background:#000;margin:0 auto 6px"></div>
    <div style="font-family:sans-serif;font-size:8px;font-weight:300;color:#111;letter-spacing:2px">MINIMAL</div></div></div>`,
  render: ({ slide, index, total, isCover, esc, ed, bullets, img, editable }) => `
    <section class="slide ${isCover ? 'cover' : ''}">
      <div class="slide-num">${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}</div>
      ${isCover ? '<div class="dot"></div>' : ''}
      <h1 ${editable?`data-field="title"`:''}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`
};

// ---- 3. BRUTALIST ----
const brutalist = {
  id: 'brutalist', name: 'Brutalist', tag: 'Raw · Bold',
  fonts: gfonts('family=Archivo+Black&family=Space+Mono:wght@400;700'),
  css: `
    body { background: #f5f0e1; color: #000; font-family: 'Space Mono', monospace; }
    .slide { padding: 6vmin; border: 8px solid #000; }
    h1 { font-family: 'Archivo Black', sans-serif; font-size: clamp(52px, 10vw, 96px); line-height: .9; text-transform: uppercase; letter-spacing: -.03em; margin-bottom: 20px; }
    .subtitle { font-family: 'Archivo Black', sans-serif; font-size: clamp(28px, 5vw, 48px); text-transform: uppercase; background: #000; color: #f5f0e1; display: inline-block; padding: 6px 16px; margin-bottom: 24px; width: fit-content; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.5; font-weight: 700; margin-bottom: 14px; max-width: 750px; }
    ul { list-style: none; }
    li { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.4; padding: 10px 16px; background: #fff; border: 3px solid #000; margin-bottom: 8px; font-weight: 700; max-width: 750px; box-shadow: 4px 4px 0 #000; }
    .cover h1 { font-size: clamp(68px, 14vw, 140px); }
    .cover { justify-content: center; background: repeating-linear-gradient(45deg, #f5f0e1, #f5f0e1 30px, #e8dfc5 30px, #e8dfc5 60px); }
    .cover h1 span { background: #ff2d2d; color: #fff; padding: 0 12px; display: inline-block; transform: rotate(-2deg); }
    .slide img { max-width: 500px; max-height: 45vh; border: 4px solid #000; margin-top: 20px; filter: grayscale(.3) contrast(1.1); }
    .slide-tag { position: absolute; top: 3vmin; right: 5vmin; background: #ff2d2d; color: #fff; padding: 4px 10px; font-weight: 700; font-size: 12px; text-transform: uppercase; transform: rotate(2deg); }
    .deck-nav { background: #000; color: #f5f0e1; border: 3px solid #000; }
    .deck-progress { background: #ff2d2d; height: 6px; }
  `,
  preview: () => `<div style="background:#fff;height:100%;padding:6px;border:3px solid #000">
    <div style="background:#000;color:#fff;padding:3px 6px;font-family:sans-serif;font-weight:900;font-size:10px;display:inline-block">BRUTAL.</div>
    <div style="font-family:sans-serif;font-size:7px;font-weight:900;color:#000;margin-top:6px;line-height:1">RAW<br>BOLD<br>LOUD</div></div>`,
  render: ({ slide, index, isCover, esc, bullets, img, editable }) => `
    <section class="slide ${isCover ? 'cover' : ''}">
      <div class="slide-tag">No.${String(index+1).padStart(2,'0')}</div>
      <h1 ${editable?`data-field="title"`:''}>${isCover ? `<span>${esc(slide.title)}</span>` : esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`
};

// ---- 4. GRADIENT ----
const gradient = {
  id: 'gradient', name: 'Gradient', tag: 'Modern · Vibrant',
  fonts: gfonts('family=Sora:wght@300;600;800'),
  css: `
    body { background: #0a0015; color: #fff; font-family: 'Sora', sans-serif; }
    body::before { content: ''; position: fixed; inset: -20%; background: radial-gradient(circle at 20% 20%, #7c3aed 0%, transparent 40%), radial-gradient(circle at 80% 60%, #ec4899 0%, transparent 40%), radial-gradient(circle at 60% 90%, #f97316 0%, transparent 40%); filter: blur(80px); opacity: .6; animation: drift 20s ease-in-out infinite alternate; z-index: 0; }
    @keyframes drift { to { transform: translate(30px, -20px) scale(1.1); } }
    .slide { padding: 7vmin; justify-content: center; z-index: 1; position: absolute; }
    h1 { font-size: clamp(44px, 9vw, 80px); font-weight: 800; letter-spacing: -.04em; line-height: 1.0; margin-bottom: 24px; background: linear-gradient(135deg, #fff 0%, #fbbf24 70%); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
    .subtitle { font-size: clamp(20px, 3vw, 26px); color: rgba(255,255,255,.75); margin-bottom: 20px; font-weight: 300; }
    .body { font-size: clamp(17px, 2vw, 20px); line-height: 1.6; color: rgba(255,255,255,.85); max-width: 800px; margin-bottom: 14px; font-weight: 300; }
    ul { list-style: none; max-width: 800px; }
    li { font-size: clamp(16px, 1.9vw, 19px); line-height: 1.5; padding: 14px 20px; margin-bottom: 10px; background: rgba(255,255,255,.06); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,.1); border-radius: 14px; font-weight: 300; }
    li::before { content: '\u2726'; color: #fbbf24; margin-right: 10px; }
    .cover h1 { font-size: clamp(56px, 13vw, 120px); }
    .tagline { font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: .3em; color: #fbbf24; margin-bottom: 24px; }
    .slide img { max-width: 500px; max-height: 45vh; border-radius: 20px; margin-top: 24px; box-shadow: 0 30px 60px rgba(0,0,0,.4); }
    .deck-nav { background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); color: #fff; }
    .deck-progress { background: linear-gradient(90deg, #7c3aed, #ec4899, #f97316); }
  `,
  preview: () => `<div style="background:linear-gradient(135deg,#7c3aed,#ec4899,#f97316);height:100%;padding:10px;display:flex;align-items:flex-end">
    <div style="font-family:sans-serif;font-size:10px;font-weight:700;color:#fff">Gradient \u2726</div></div>`,
  render: ({ slide, isCover, esc, bullets, img, editable }) => `
    <section class="slide ${isCover ? 'cover' : ''}">
      ${isCover ? `<div class="tagline">\u2726 Presentation</div>` : ''}
      <h1 ${editable?`data-field="title"`:''}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`
};

// ---- 5. TERMINAL ----
const terminal = {
  id: 'terminal', name: 'Terminal', tag: 'Mono · Hacker',
  fonts: gfonts('family=JetBrains+Mono:wght@400;600;800'),
  css: `
    body { background: #0a0a0a; color: #d4d4d4; font-family: 'JetBrains Mono', monospace; }
    body::before { content: ''; position: fixed; inset: 0; background: repeating-linear-gradient(0deg, transparent 0px, transparent 2px, rgba(0,255,100,.02) 3px, rgba(0,255,100,.02) 3px); pointer-events: none; z-index: 100; }
    .slide { padding: 5vmin 6vmin; }
    .prompt { color: #737373; font-size: 14px; margin-bottom: 12px; }
    .prompt::before { content: 'user@deck:~$ '; color: #4ade80; }
    h1 { color: #4ade80; font-size: clamp(32px, 6vw, 52px); font-weight: 800; margin-bottom: 20px; letter-spacing: -.02em; }
    h1::before { content: '# '; }
    .subtitle { color: #737373; font-size: clamp(16px, 1.8vw, 18px); margin-bottom: 20px; }
    .subtitle::before { content: '> '; }
    .body { color: #e5e5e5; font-size: clamp(14px, 1.7vw, 17px); line-height: 1.6; margin-bottom: 12px; max-width: 900px; }
    ul { list-style: none; max-width: 900px; }
    li { color: #d4d4d4; font-size: clamp(13px, 1.6vw, 16px); line-height: 1.6; padding: 6px 0 6px 24px; position: relative; }
    li::before { content: '\u25B8'; position: absolute; left: 0; color: #4ade80; }
    .slide img { max-width: 500px; max-height: 40vh; border: 1px solid #262626; margin-top: 16px; filter: brightness(.9) contrast(1.1); }
    .cover { justify-content: center; }
    .cover h1 { font-size: clamp(40px, 8vw, 70px); }
    .meta-strip { position: absolute; top: 3vmin; left: 6vmin; right: 6vmin; display: flex; justify-content: space-between; color: #525252; font-size: 11px; }
    .meta-strip .status { color: #4ade80; }
    .deck-nav { background: #1a1a1a; border-color: #4ade80; color: #4ade80; }
    .deck-progress { background: #4ade80; box-shadow: 0 0 8px #4ade80; height: 2px; }
  `,
  preview: () => `<div style="background:#0a0a0a;height:100%;padding:8px;font-family:monospace;font-size:7px;color:#4ade80">
    <div>$ cat deck.md</div><div style="color:#a3a3a3;margin-top:2px">&gt; Terminal</div><div style="color:#fff">&gt; ready_</div></div>`,
  render: ({ slide, index, total, isCover, isEnd, esc, bullets, img, editable }) => `
    <section class="slide ${isCover ? 'cover' : ''}">
      <div class="meta-strip"><span>slide-${String(index+1).padStart(3,'0')}.md</span><span class="status">\u25CF ONLINE</span></div>
      <div class="prompt">cat slide-${String(index+1).padStart(3,'0')}.md</div>
      <h1 ${editable?`data-field="title"`:''}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      ${isEnd ? '<div style="margin-top:30px;color:#4ade80">\u2588 EOF</div>' : ''}
    </section>`
};

// ---- 6. ACADEMIC ----
const academic = {
  id: 'academic', name: 'Academic', tag: 'Formal · Dense',
  fonts: gfonts('family=EB+Garamond:ital,wght@0,400;0,500;0,700;1,400&family=IBM+Plex+Sans:wght@400;600'),
  css: `
    body { background: #f5f1e8; color: #1a1410; font-family: 'EB Garamond', serif; }
    .slide { padding: 8vmin 10vmin; background: linear-gradient(rgba(245,241,232,.97), rgba(245,241,232,.97)), repeating-linear-gradient(90deg, #e8dfc5 0, #e8dfc5 1px, transparent 1px, transparent 60px); }
    .slide::before { content: ''; position: absolute; left: 10vmin; top: 6vmin; bottom: 6vmin; width: 2px; background: #8b1e1e; }
    h1 { font-weight: 500; font-size: clamp(32px, 5.5vw, 48px); line-height: 1.15; margin-bottom: 12px; max-width: 850px; }
    h1 em { color: #8b1e1e; font-style: italic; font-weight: 400; }
    .section-label { font-family: 'IBM Plex Sans', sans-serif; font-size: 12px; text-transform: uppercase; letter-spacing: .25em; color: #8b1e1e; font-weight: 600; margin-bottom: 20px; }
    .body { font-size: clamp(15px, 1.8vw, 18px); line-height: 1.7; margin-bottom: 14px; max-width: 750px; text-indent: 1em; }
    .lede { font-size: clamp(18px, 2.2vw, 22px); text-indent: 0; font-style: italic; color: #4a3f33; border-left: 3px solid #8b1e1e; padding-left: 16px; margin: 16px 0 24px; }
    ul { max-width: 750px; list-style: none; counter-reset: it; }
    li { font-size: clamp(15px, 1.8vw, 17px); line-height: 1.55; padding: 8px 0 8px 36px; position: relative; counter-increment: it; }
    li::before { content: counter(it, lower-roman) '.'; position: absolute; left: 0; top: 8px; font-style: italic; color: #8b1e1e; font-weight: 500; width: 28px; }
    .slide img { max-width: 420px; max-height: 45vh; margin-top: 18px; border: 1px solid #c4b896; filter: sepia(.15); }
    .cover { justify-content: center; text-align: center; align-items: center; }
    .cover::before { display: none; }
    .cover h1 { font-size: clamp(36px, 7vw, 60px); }
    .sep { width: 120px; height: 1px; background: #8b1e1e; margin: 24px 0; }
    .page-num { position: absolute; bottom: 5vmin; right: 10vmin; font-style: italic; color: #a89a7f; font-size: 14px; }
    .section-name { position: absolute; top: 5vmin; right: 10vmin; font-family: 'IBM Plex Sans', sans-serif; font-size: 10px; text-transform: uppercase; letter-spacing: .2em; color: #a89a7f; }
    .deck-nav { background: rgba(245,241,232,0.9); color: #1a1410; }
    .deck-progress { background: #8b1e1e; height: 1px; }
  `,
  preview: () => `<div style="background:#f5f2ea;height:100%;padding:8px">
    <div style="font-family:Georgia,serif;font-size:8px;color:#333;font-weight:700">\u00A7 Abstract</div>
    <div style="width:60%;height:2px;background:#8b1e1e;margin:3px 0"></div>
    <div style="font-family:Georgia,serif;font-size:5px;color:#555;line-height:1.4">A study in formal presentation.</div></div>`,
  render: ({ slide, index, total, isCover, esc, bullets, img, editable }) => `
    <section class="slide ${isCover ? 'cover' : ''}">
      <div class="section-name">${isCover ? 'Frontispiece' : 'Section ' + index}</div>
      ${!isCover ? `<div class="section-label">\u00A7 ${String(index).padStart(2,'0')}</div>` : ''}
      <h1 ${editable?`data-field="title"`:''}>${esc(slide.title)}</h1>
      ${isCover && slide.subtitle ? `<div class="sep"></div><div class="lede" ${editable?`data-field="subtitle"`:''} style="text-align:center;border:none;padding:0;text-indent:0">${esc(slide.subtitle)}</div>` : ''}
      ${slide.subtitle && !isCover ? `<div class="lede" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      <div class="page-num">\u2014 ${String(index+1).padStart(2,'0')} \u2014</div>
    </section>`
};

// ---- 7. PITCH DECK ----
const pitch = {
  id: 'pitch', name: 'Pitch Deck', tag: 'Startup · Punchy',
  fonts: gfonts('family=Syne:wght@500;700;800&family=Inter:wght@400;600'),
  css: `
    body { background: #0d0d0f; color: #fff; font-family: 'Inter', sans-serif; }
    .slide { padding: 7vmin; justify-content: center; }
    h1 { font-family: 'Syne', sans-serif; font-size: clamp(56px, 11vw, 108px); font-weight: 800; line-height: .95; letter-spacing: -.04em; margin-bottom: 24px; }
    h1 .hl { color: #fbbf24; }
    .subtitle { font-size: clamp(22px, 3vw, 32px); font-weight: 500; color: #fff; max-width: 1000px; margin-bottom: 24px; }
    .body { font-size: clamp(17px, 2.2vw, 22px); line-height: 1.55; max-width: 900px; color: #d4d4d8; margin-bottom: 14px; }
    ul { list-style: none; max-width: 900px; counter-reset: li-c; }
    li { font-size: clamp(17px, 2.2vw, 22px); line-height: 1.55; padding: 16px 0; border-bottom: 1px solid #27272a; color: #d4d4d8; display: flex; gap: 20px; align-items: baseline; }
    li::before { content: counter(li-c, decimal-leading-zero); counter-increment: li-c; color: #fbbf24; font-family: 'Syne', sans-serif; font-weight: 700; font-size: 18px; min-width: 36px; }
    .cover h1 { font-size: clamp(68px, 16vw, 150px); }
    .tag { display: inline-block; padding: 6px 14px; background: #fbbf24; color: #0d0d0f; font-weight: 700; font-size: 12px; text-transform: uppercase; letter-spacing: .2em; margin-bottom: 28px; border-radius: 4px; width: fit-content; }
    .slide img { max-width: 520px; max-height: 50vh; border-radius: 8px; margin-top: 24px; box-shadow: 0 20px 60px rgba(251,191,36,.15); }
    .brand { position: absolute; bottom: 5vmin; left: 7vmin; font-family: 'Syne', sans-serif; font-weight: 800; font-size: 14px; letter-spacing: .1em; color: #71717a; }
    .brand::before { content: '\u25CF '; color: #fbbf24; }
    .slide-idx { position: absolute; bottom: 5vmin; right: 7vmin; font-family: 'Syne', sans-serif; font-weight: 700; font-size: 14px; color: #71717a; }
    .deck-nav { background: rgba(255,255,255,.05); border: 1px solid #27272a; color: #fff; }
    .deck-progress { background: #fbbf24; height: 4px; }
  `,
  preview: () => `<div style="background:#111;height:100%;padding:10px;display:flex;flex-direction:column;justify-content:center">
    <div style="font-family:sans-serif;font-size:12px;font-weight:800;color:#fff;line-height:1">Big.<br><span style="color:#fbbf24">Idea.</span></div></div>`,
  render: ({ slide, index, total, project, isCover, esc, bullets, img, editable }) => `
    <section class="slide ${isCover ? 'cover' : ''}">
      ${isCover ? `<div class="tag">${esc(project.audience || 'Pitch')}</div>` : ''}
      <h1 ${editable?`data-field="title"`:''}>${isCover ? esc(slide.title).replace(/(\S+)$/, '<span class="hl">$1</span>') : esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      <div class="brand">${esc(project.topic).slice(0,30).toUpperCase()}</div>
      <div class="slide-idx">${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}</div>
    </section>`
};

// ---- 8. STORYBOOK ----
const storybook = {
  id: 'storybook', name: 'Storybook', tag: 'Warm · Narrative',
  fonts: gfonts('family=Lora:ital,wght@0,400;0,600;1,400&family=Caveat:wght@500'),
  css: `
    body { background: #f4e9d6; color: #3d2817; font-family: 'Lora', serif; background-image: radial-gradient(circle at 20% 80%, rgba(201,110,61,.08) 0%, transparent 50%); }
    .slide { padding: 8vmin 10vmin; justify-content: center; }
    h1 { font-size: clamp(40px, 7vw, 64px); font-weight: 600; line-height: 1.1; margin-bottom: 24px; color: #3d2817; letter-spacing: -.01em; }
    .subtitle { font-family: 'Caveat', cursive; font-size: clamp(22px, 3vw, 28px); color: #8b6f47; margin: 14px 0; max-width: 600px; }
    .body { font-size: clamp(17px, 2.2vw, 21px); line-height: 1.65; max-width: 780px; margin-bottom: 18px; color: #3d2817; }
    ul { list-style: none; max-width: 780px; }
    li { font-size: clamp(16px, 2vw, 19px); line-height: 1.65; padding: 8px 0 8px 32px; position: relative; color: #3d2817; }
    li::before { content: '\u25C8'; position: absolute; left: 0; top: 8px; color: #c96e3d; }
    .slide img { max-width: 450px; max-height: 45vh; border-radius: 12px; margin-top: 20px; box-shadow: 8px 8px 0 rgba(201,110,61,.25); border: 4px solid #f4e9d6; outline: 1px solid #c96e3d; }
    .cover { text-align: center; align-items: center; }
    .cover h1 { font-size: clamp(48px, 10vw, 88px); }
    .ornament { font-size: 40px; color: #c96e3d; margin-bottom: 16px; }
    .chapter { position: absolute; top: 5vmin; left: 10vmin; font-family: 'Caveat', cursive; font-size: clamp(18px, 2.5vw, 24px); color: #8b6f47; transform: rotate(-2deg); }
    .page { position: absolute; bottom: 5vmin; right: 10vmin; font-style: italic; color: #8b6f47; font-size: 14px; }
    .deck-nav { background: #c96e3d; color: #f4e9d6; }
    .deck-progress { background: #c96e3d; }
  `,
  preview: () => `<div style="background:#f4e9d6;height:100%;padding:8px;display:flex;flex-direction:column;justify-content:space-between">
    <div style="font-family:Georgia,serif;font-style:italic;font-size:7px;color:#8b6f47">Once upon a time...</div>
    <div style="width:20px;height:20px;border-radius:50%;background:#c96e3d;margin:auto"></div>
    <div style="font-family:Georgia,serif;font-size:6px;color:#8b6f47;text-align:center">\u2014 fin \u2014</div></div>`,
  render: ({ slide, index, isCover, esc, bullets, img, editable }) => `
    <section class="slide ${isCover ? 'cover' : ''}">
      <div class="chapter">${isCover ? 'A story' : 'Chapter ' + index}</div>
      ${isCover ? '<div class="ornament">\u2766</div>' : ''}
      <h1 ${editable?`data-field="title"`:''}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      <div class="page">page ${index+1}</div>
    </section>`
};

// ---- 9. NEON ----
const neon = {
  id: 'neon', name: 'Neon', tag: 'Dark · Cyberpunk',
  fonts: gfonts('family=Orbitron:wght@500;700;900&family=Rajdhani:wght@400;600'),
  css: `
    body { background: #05020c; color: #e8e6f0; font-family: 'Rajdhani', sans-serif; }
    body::before { content: ''; position: fixed; inset: 0; background-image: linear-gradient(rgba(0,255,217,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,217,.04) 1px, transparent 1px); background-size: 40px 40px; pointer-events: none; z-index: 1; }
    body::after { content: ''; position: fixed; inset: 0; background: radial-gradient(ellipse at 20% 50%, rgba(255,0,168,.12), transparent 40%), radial-gradient(ellipse at 80% 80%, rgba(0,255,217,.15), transparent 40%); pointer-events: none; z-index: 2; }
    .slide { padding: 7vmin; z-index: 3; justify-content: center; }
    h1 { font-family: 'Orbitron', sans-serif; font-size: clamp(42px, 8vw, 80px); font-weight: 900; line-height: 1; letter-spacing: -.02em; margin-bottom: 24px; color: #00ffd9; text-shadow: 0 0 30px rgba(0,255,217,.5), 0 0 60px rgba(0,255,217,.2); }
    h1::before { content: '// '; color: #ff00a8; }
    .subtitle { font-family: 'Orbitron', sans-serif; font-size: clamp(24px, 4vw, 40px); color: #ff00a8; text-shadow: 0 0 20px rgba(255,0,168,.5); font-weight: 700; margin-bottom: 20px; letter-spacing: .02em; }
    .body { font-size: clamp(16px, 2vw, 20px); line-height: 1.55; max-width: 850px; color: #e8e6f0; margin-bottom: 14px; }
    ul { list-style: none; max-width: 850px; }
    li { font-size: clamp(15px, 1.9vw, 19px); line-height: 1.5; padding: 10px 16px 10px 36px; background: rgba(0,255,217,.05); border: 1px solid rgba(0,255,217,.3); margin-bottom: 8px; position: relative; font-weight: 600; }
    li::before { content: '\u25BA'; position: absolute; left: 14px; top: 10px; color: #ff00a8; text-shadow: 0 0 8px #ff00a8; }
    .slide img { max-width: 500px; max-height: 45vh; border: 1px solid #00ffd9; box-shadow: 0 0 30px rgba(0,255,217,.3); margin-top: 20px; filter: hue-rotate(-10deg) saturate(1.2); }
    .cover h1 { font-size: clamp(54px, 12vw, 110px); }
    .sys { font-family: 'Orbitron', sans-serif; font-size: 14px; color: #00ffd9; letter-spacing: .4em; margin-bottom: 20px; }
    .hud-top { position: absolute; top: 4vmin; left: 7vmin; right: 7vmin; display: flex; justify-content: space-between; font-family: 'Orbitron', sans-serif; font-size: 11px; color: #00ffd9; letter-spacing: .2em; z-index: 5; }
    .hud-top .dot { display: inline-block; width: 6px; height: 6px; background: #00ffd9; border-radius: 50%; margin-right: 6px; box-shadow: 0 0 8px #00ffd9; animation: pulse 1.5s infinite; }
    @keyframes pulse { 50% { opacity: .4; } }
    .corner { position: absolute; width: 30px; height: 30px; border: 2px solid #00ffd9; z-index: 5; }
    .c-tl { top: 20px; left: 20px; border-right: none; border-bottom: none; }
    .c-tr { top: 20px; right: 20px; border-left: none; border-bottom: none; }
    .c-bl { bottom: 20px; left: 20px; border-right: none; border-top: none; }
    .c-br { bottom: 20px; right: 20px; border-left: none; border-top: none; }
    .deck-nav { background: transparent; border: 1px solid #00ffd9; color: #00ffd9; }
    .deck-progress { background: linear-gradient(90deg, #ff00a8, #00ffd9); box-shadow: 0 0 10px #00ffd9; height: 2px; }
  `,
  preview: () => `<div style="background:#05020c;height:100%;padding:10px;position:relative;overflow:hidden">
    <div style="font-family:monospace;font-size:9px;color:#00ffd9;text-shadow:0 0 4px #00ffd9;font-weight:700">// NEON</div>
    <div style="font-family:sans-serif;font-size:6px;color:#ff00a8;text-shadow:0 0 4px #ff00a8;margin-top:4px">SYSTEM ONLINE</div>
    <div style="position:absolute;bottom:6px;right:6px;width:16px;height:1px;background:#00ffd9;box-shadow:0 0 4px #00ffd9"></div></div>`,
  render: ({ slide, index, total, isCover, esc, bullets, img, editable }) => `
    <div class="corner c-tl"></div><div class="corner c-tr"></div><div class="corner c-bl"></div><div class="corner c-br"></div>
    <section class="slide ${isCover ? 'cover' : ''}">
      <div class="hud-top"><span><span class="dot"></span>SYS.ACTIVE</span><span>REC ${String(index+1).padStart(3,'0')}/${String(total).padStart(3,'0')}</span></div>
      ${isCover ? '<div class="sys">\u25B8 INITIALIZING TRANSMISSION</div>' : ''}
      <h1 ${editable?`data-field="title"`:''}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`
};

// ---- 10. SWISS ----
const swiss = {
  id: 'swiss', name: 'Swiss Grid', tag: 'Grid · Typographic',
  fonts: gfonts('family=DM+Sans:wght@400;500;700'),
  css: `
    body { background: #fff; color: #000; font-family: 'DM Sans', Helvetica, sans-serif; }
    .slide { padding: 6vmin 7vmin; display: none; }
    .slide.active { display: grid; grid-template-columns: repeat(12, 1fr); grid-template-rows: auto 1fr auto; gap: 18px; }
    .head { grid-column: 1 / 13; display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 1.5px solid #000; padding-bottom: 10px; font-weight: 700; font-size: 12px; letter-spacing: .05em; text-transform: uppercase; }
    .content { grid-column: 1 / 10; grid-row: 2; display: flex; flex-direction: column; justify-content: center; }
    .side { grid-column: 10 / 13; grid-row: 2; display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-start; gap: 10px; }
    .side .block { width: 100%; height: 40%; background: #e60000; }
    .foot { grid-column: 1 / 13; grid-row: 3; display: flex; justify-content: space-between; font-size: 11px; font-weight: 500; color: #666; border-top: 1px solid #ccc; padding-top: 8px; }
    h1 { font-weight: 700; font-size: clamp(44px, 9vw, 84px); line-height: .92; letter-spacing: -.04em; margin-bottom: 18px; }
    h1 .red { color: #e60000; }
    .subtitle { font-weight: 500; font-size: clamp(22px, 3.5vw, 32px); line-height: 1.2; margin-bottom: 18px; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.5; max-width: 680px; margin-bottom: 12px; }
    ul { list-style: none; max-width: 680px; display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
    li { font-size: clamp(13px, 1.6vw, 15px); line-height: 1.5; padding: 10px 0 10px 20px; position: relative; border-top: 1px solid #000; font-weight: 500; }
    li::before { content: ''; position: absolute; left: 0; top: 16px; width: 10px; height: 3px; background: #e60000; }
    .cover h1 { font-size: clamp(56px, 14vw, 140px); }
    .cover .content { justify-content: center; }
    .slide img { max-width: 100%; max-height: 60%; object-fit: cover; grid-column: 7 / 13; grid-row: 2; filter: grayscale(1); }
    .deck-nav { background: #000; color: #fff; }
    .deck-progress { background: #e60000; height: 4px; }
    @media (max-width: 700px) {
      .slide.active { gap: 10px; }
      ul { grid-template-columns: 1fr; }
      .content { grid-column: 1 / 13; }
      .side { grid-column: 1 / 13; grid-row: auto; }
      .slide img { grid-column: 1 / 13; grid-row: auto; }
    }
  `,
  preview: () => `<div style="background:#fff;height:100%;padding:6px;display:grid;grid-template-rows:auto 1fr auto;gap:4px">
    <div style="display:flex;justify-content:space-between;font-family:sans-serif;font-size:6px;color:#000;font-weight:600"><span>01</span><span>SWISS</span></div>
    <div style="background:#d00;width:40%"></div>
    <div style="font-family:sans-serif;font-size:8px;font-weight:700;color:#000">Grid System</div></div>`,
  render: ({ slide, index, total, project, isCover, esc, bullets, img, editable }) => {
    const hasImg = slide.localImage || slide.imageUrl;
    return `
    <section class="slide ${isCover ? 'cover' : ''}">
      <div class="head"><span>${esc(project.topic).slice(0,40)}</span><span>${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}</span></div>
      <div class="content">
        <h1 ${editable?`data-field="title"`:''}>${isCover ? esc(slide.title).replace(/(\S+)$/, '<span class="red">$1</span>') : esc(slide.title)}</h1>
        ${slide.subtitle ? `<div class="subtitle" ${editable?`data-field="subtitle"`:''}>${esc(slide.subtitle)}</div>` : ''}
        ${slide.body ? `<div class="body" ${editable?`data-field="body"`:''}>${esc(slide.body)}</div>` : ''}
        ${bullets(slide.bullets)}
      </div>
      ${hasImg ? img(slide) : `<div class="side"><div class="block"></div><div style="font-size:10px;font-weight:700;letter-spacing:.2em;text-transform:uppercase">Grid \u00B7 12col</div></div>`}
      <div class="foot"><span>DECK / ${esc(project.templateId).toUpperCase()}</span><span>${new Date(project.createdAt).toISOString().slice(0,10)}</span></div>
    </section>`;
  }
};

export const TEMPLATES_CORE = [editorial, minimal, brutalist, gradient, terminal, academic, pitch, storybook, neon, swiss];
