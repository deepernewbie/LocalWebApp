// pipeline.js - the generation pipeline

import { chat } from './llm.js';
import { researchTopic, searchImages, fetchImageBytes } from './research.js';
import { getLanguage, DEFAULT_LANGUAGE } from './languages.js';
import * as fs from './storage.js';

// Returns a prompt snippet describing the target language and the field-level
// rule that imageQuery stays in English (so image search engines, which work
// best with English keywords, return relevant results regardless of the
// presentation's display language).
function buildLanguageInstruction(project, opts = {}) {
  const lang = getLanguage(project.language || DEFAULT_LANGUAGE);
  const includeImageQueryRule = opts.includeImageQueryRule !== false;
  const useImages = project.useImages !== false;
  const lines = [];
  if (lang.code !== 'en') {
    lines.push(`LANGUAGE REQUIREMENT:`);
    lines.push(`- All natural-language fields (titles, subtitles, body text, bullets, captions, speaker notes, angles) MUST be written in ${lang.promptName} (${lang.nativeName}).`);
    lines.push(`- Use natural, fluent ${lang.promptName} — do not produce a word-for-word translation from English.`);
    if (includeImageQueryRule && useImages) {
      lines.push(`- EXCEPTION: the "imageQuery" field MUST remain in English. Image search engines work much better with English keywords. For example: even when writing slides in ${lang.promptName}, imageQuery should be like "Roman aqueduct cross section", not the ${lang.promptName} translation.`);
    }
    lines.push(`- Proper nouns (people, places, brands) should follow standard ${lang.promptName} usage.`);
  }
  if (!useImages && includeImageQueryRule) {
    lines.push(`IMAGES DISABLED:`);
    lines.push(`- This is a text-only deck. Set "imageQuery" to "" (empty string) and "imageCaption" to "" for every slide. Don't suggest images.`);
  }
  return lines.length ? '\n' + lines.join('\n') : '';
}

// ---- Step 1: PLAN ----
export async function generatePlan(project, onLog) {
  onLog('running', `Planning ${project.slideCount} slides...`);
  const sys = `You are an expert presentation designer. You return ONLY valid, parseable JSON.

JSON RULES (MUST follow exactly):
- Output ONE JSON object and NOTHING else — no markdown fences, no prose before or after, no comments.
- Every key in every object MUST be a string in double quotes followed by a colon. No bare values.
- Every string value MUST be wrapped in double quotes and separated from the next key by a comma.
- Valid: {"role": "cover", "title": "Intro"}
- Invalid: {"cover", "title": "Intro"}          ← missing "role":
- Invalid: {"role": "cover" "title": "Intro"}    ← missing comma
- Invalid: {"angle": "text goes"imageQuery": "x"} ← missing ", after value
- Do NOT repeat the response. Stop after the single closing brace.`;

  const user = `Topic: ${project.topic}
Slide count: ${project.slideCount}
Audience: ${project.audience || 'general'}
Tone: ${project.tone}
${buildLanguageInstruction(project)}
Return a JSON object with this shape (role must be one of: "cover", "section", "content", "conclusion"):

{
  "slides": [
    {
      "role": "cover",
      "title": "short slide title",
      "angle": "1-2 sentences on what this slide covers",
      "imageQuery": "3-6 word image search query"
    }
  ]
}

EXAMPLE (for topic "The Roman Aqueducts", 4 slides, audience=students):
{
  "slides": [
    {
      "role": "cover",
      "title": "The Roman Aqueducts",
      "angle": "An introduction to the engineering marvel that supplied water to Rome for centuries.",
      "imageQuery": "Pont du Gard aqueduct"
    },
    {
      "role": "content",
      "title": "How They Worked",
      "angle": "Explains gravity-fed water transport, gradient calculations, and arcade design.",
      "imageQuery": "Roman aqueduct cross section"
    },
    {
      "role": "content",
      "title": "Scale and Reach",
      "angle": "Covers the network size — over 500 km serving Rome — and cities supplied across the empire.",
      "imageQuery": "ancient Rome water map"
    },
    {
      "role": "conclusion",
      "title": "Enduring Legacy",
      "angle": "Summarises why aqueducts still inspire modern civil engineering.",
      "imageQuery": "aqueduct modern ruins"
    }
  ]
}

Now produce the plan for "${project.topic}".

Rules:
- Exactly ${project.slideCount} slides.
- First slide role is "cover", last is "conclusion" (unless count is 1).
- For decks with more than 5 slides, include 1-2 "section" divider slides between major topic groups.
- Titles short and punchy (max 6 words).
- imageQuery should be factual and visual (e.g. "Eiffel Tower Paris" not "beauty of architecture").
- Vary coverage — no two slides on the same sub-topic.`;

  const result = await chat({ system: sys, user, json: true, maxTokens: 4000, temperature: 0.7, label: 'plan' });
  if (!result?.slides || !Array.isArray(result.slides)) {
    throw new Error('Plan response was not in expected format.');
  }
  const planned = result.slides.length;

  // Ensure count matches. If the LLM returned fewer slides than requested we
  // pad with placeholders — but we mark them as `placeholder: true` so the UI
  // can highlight them and the drafter can skip or treat them specially.
  result.slides = result.slides.slice(0, project.slideCount);
  const padded = project.slideCount - result.slides.length;
  while (result.slides.length < project.slideCount) {
    result.slides.push({
      role: 'content',
      title: '',
      angle: '',
      imageQuery: '',
      placeholder: true
    });
  }
  // Guard against missing/invalid roles after recovery from a damaged response
  for (let i = 0; i < result.slides.length; i++) {
    const s = result.slides[i];
    if (!s.role) s.role = i === 0 ? 'cover' : (i === result.slides.length - 1 ? 'conclusion' : 'content');
    if (!['cover','section','content','conclusion'].includes(s.role)) s.role = 'content';
    if (!s.title) s.title = '';
    if (!s.angle) s.angle = '';
    if (typeof s.imageQuery !== 'string') s.imageQuery = '';
    // Treat any slide with empty title+angle as a placeholder, regardless of source
    if (!s.title.trim() && !s.angle.trim()) s.placeholder = true;
  }
  if (padded > 0) {
    onLog('running', `LLM returned ${planned} slides (asked for ${project.slideCount}). ${padded} placeholder slide(s) added — fill them in before drafting.`);
  }
  onLog('done', `Plan ready — ${result.slides.length} slides (${padded > 0 ? padded + ' placeholder' : 'all filled'})`);
  return result.slides;
}

// ---- Fill a single placeholder plan slot using the LLM ----
// Takes the topic + surrounding plan items and asks the model to suggest a
// single slide (title + angle + imageQuery) that fits at the given index.
export async function fillPlanSlot(project, plan, index) {
  const total = plan.length;
  // Give the model context: what came before and what's coming after
  const before = plan.slice(0, index).map((p, i) => `  ${i+1}. [${p.role}] ${p.title || '(placeholder)'} — ${p.angle || '(no angle yet)'}`).join('\n') || '  (none)';
  const after = plan.slice(index + 1).map((p, i) => `  ${index + 2 + i}. [${p.role}] ${p.title || '(placeholder)'} — ${p.angle || '(no angle yet)'}`).join('\n') || '  (none)';
  const role = plan[index]?.role || (index === 0 ? 'cover' : (index === total - 1 ? 'conclusion' : 'content'));

  const sys = `You are an expert presentation designer. You return ONLY valid, parseable JSON — one object, nothing else.`;
  const user = `TOPIC: ${project.topic}
AUDIENCE: ${project.audience || 'general'}
TONE: ${project.tone}
${buildLanguageInstruction(project)}
Here is the current plan (${total} slides). Slide ${index + 1} is missing or incomplete.

Slides before:
${before}

Slide ${index + 1} position (role = "${role}"): NEEDS CONTENT

Slides after:
${after}

Fill in slide ${index + 1}. It should be a sensible "${role}" slide that fits between its neighbours and does NOT duplicate any nearby slide. Return a single JSON object:

{
  "title": "2-6 word slide title",
  "angle": "1-2 sentences describing what this slide covers and why it belongs here",
  "imageQuery": "3-6 word image search query (or empty string)"
}

Example for filling a "content" slot in a deck about "The Roman Aqueducts", sitting between slides on How They Worked and Modern Legacy:
{
  "title": "Scale and Reach",
  "angle": "Covers the network size — over 500 km serving Rome — and cities supplied across the empire.",
  "imageQuery": "ancient Rome water map"
}`;
  const result = await chat({ system: sys, user, json: true, maxTokens: 800, temperature: 0.7, label: `fill-plan-${index+1}` });
  if (!result || typeof result !== 'object') throw new Error('Empty fill response');
  return {
    role,
    title: result.title || '',
    angle: result.angle || '',
    imageQuery: result.imageQuery || '',
    placeholder: false
  };
}

// ---- Step 2: RESEARCH ----
export async function doResearch(project, onLog) {
  const lang = getLanguage(project.language || DEFAULT_LANGUAGE);
  onLog('running', `Gathering background in ${lang.name} (Wikipedia, Wikibooks, DuckDuckGo, arXiv)…`);
  const snippets = await researchTopic(project.topic, msg => onLog('running', msg), { wikiLang: lang.wiki });
  onLog('done', `Found ${snippets.length} research snippet${snippets.length === 1 ? '' : 's'}`);
  return snippets;
}

// ---- Step 3: DRAFT ----
// Drafts slides ONE AT A TIME using draftOneSlide. This is more reliable
// than asking for all slides in a single LLM call, because:
//   - Each call has its own full token budget — no truncation of later slides
//   - Each slide's response is validated independently; a failure on slide 6
//     doesn't affect slides 1-5 that already succeeded
//   - We can retry individual slides if they come back empty
//   - Progress is visible in the log as slides complete
export async function draftSlides(project, plan, research, onLog) {
  onLog('running', `Drafting ${plan.length} slides one by one\u2026`);

  // Pre-compute full research context; draftOneSlide will use its own slicing.
  const totalSlides = plan.length;
  const merged = [];

  for (let i = 0; i < totalSlides; i++) {
    const planItem = plan[i];
    const isPlaceholder = planItem.placeholder ||
      (!planItem.title?.trim() && !planItem.angle?.trim());

    onLog('running', `Slide ${i+1}/${totalSlides}: ${planItem.title || '(placeholder)'}\u2026`);

    // Skip drafting placeholder slots — they need to be filled in the plan
    // step first. We emit an empty scaffold and continue.
    if (isPlaceholder) {
      onLog('running', `Slide ${i+1}: plan is empty, skipping draft.`);
      merged.push(buildEmptySlide(planItem, i));
      continue;
    }

    // Try up to 2 times per slide (same retry policy as per-slide regen).
    let fresh = null;
    let lastErr = null;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        fresh = await draftOneSlide(project, planItem, research, i, totalSlides);
        break;
      } catch (e) {
        lastErr = e;
        if (attempt === 1) {
          onLog('running', `Slide ${i+1}: first attempt failed (${e.message}) \u2014 retrying\u2026`);
        }
      }
    }

    if (!fresh) {
      onLog('err', `Slide ${i+1}: both attempts failed (${lastErr?.message || 'unknown'}). Use per-slide Regen to retry later.`);
      merged.push(buildEmptySlide(planItem, i));
      continue;
    }

    merged.push({
      id: 'slide-' + i,
      role: planItem.role,
      title: fresh.title || planItem.title,
      subtitle: fresh.subtitle || '',
      body: fresh.body || '',
      bullets: Array.isArray(fresh.bullets) ? fresh.bullets : [],
      imageCaption: fresh.imageCaption || '',
      imageQuery: fresh.imageQuery || planItem.imageQuery || '',
      speakerNotes: fresh.speakerNotes || '',
      imageUrl: null,
      localImage: null,
      imageCandidates: []
    });
  }

  const filled = merged.filter(s => s.body || (s.bullets && s.bullets.length > 0)).length;
  onLog('done', `Drafted ${filled}/${totalSlides} slides with content${filled < totalSlides ? ' — use per-slide Regen on empty ones' : ''}`);
  return merged;
}

function buildEmptySlide(planItem, i) {
  return {
    id: 'slide-' + i,
    role: planItem.role || (i === 0 ? 'cover' : 'content'),
    title: planItem.title || '',
    subtitle: '',
    body: '',
    bullets: [],
    imageCaption: '',
    imageQuery: planItem.imageQuery || '',
    speakerNotes: '',
    imageUrl: null,
    localImage: null,
    imageCandidates: []
  };
}

// ---- Legacy all-at-once drafter ----
// Kept for reference / fallback; not used by default. Prone to token-limit
// truncation on longer decks — see draftSlides above for the per-slide
// version that's now the default.
async function draftSlidesBulk(project, plan, research, onLog) {
  onLog('running', 'Drafting slide content with LLM (bulk)...');
  const researchText = research.map(r => `[${r.title}]\n${r.text}`).join('\n\n---\n\n').slice(0, 8000);

  const sys = `You are writing presentation slide content. You return ONLY valid, parseable JSON.

GROUNDING RULES:
- Specific claims (numbers, dates, names, quotes) MUST come from the research context.
- Generic framing ("is commonly used", "tends to be") is fine without research.
- Never invent specifics. Prefer generic-but-truthful over specific-but-unsupported.

JSON RULES:
- Output ONE JSON object and NOTHING else.
- Do NOT repeat the JSON. Stop after the single closing brace.`;

  const user = `TOPIC: ${project.topic}
TONE: ${project.tone}
AUDIENCE: ${project.audience || 'general'}
${buildLanguageInstruction(project)}
${researchText ? `RESEARCH CONTEXT:\n${researchText}` : 'NO RESEARCH AVAILABLE.'}

PLAN:
${JSON.stringify(plan, null, 2)}

Return {"slides": [{...}, ...]} with exactly ${plan.length} slide objects, each having title, subtitle, body, bullets, imageCaption, imageQuery, speakerNotes.`;

  // Token budget scales with slide count. Each slide draft takes roughly
  // 300-500 tokens including JSON syntax and speaker notes. Plus the
  // wrapping {"slides": [...]} structure. We use 1000 tokens per slide
  // with a 16k floor for short decks (so even a 3-slide deck has plenty
  // of headroom for verbose output).
  const slideCount = plan.length;
  const draftMaxTokens = Math.max(16000, slideCount * 1000);
  const result = await chat({ system: sys, user, json: true, maxTokens: draftMaxTokens, temperature: 0.5, label: 'draft-bulk' });
  if (!result?.slides || !Array.isArray(result.slides)) {
    throw new Error('Draft response was not in expected format.');
  }

  return plan.map((p, i) => {
    const d = result.slides[i] || {};
    return {
      id: 'slide-' + i,
      role: p.role,
      title: d.title || p.title,
      subtitle: d.subtitle || '',
      body: d.body || '',
      bullets: Array.isArray(d.bullets) ? d.bullets : [],
      imageCaption: d.imageCaption || '',
      imageQuery: d.imageQuery || p.imageQuery || '',
      speakerNotes: d.speakerNotes || '',
      imageUrl: null,
      localImage: null,
      imageCandidates: []
    };
  });
}

// ---- Step 4: FETCH IMAGES ----
export async function fetchImagesForSlides(project, slides, onLog) {
  // Honour project-level "no images" setting. We still iterate so any
  // imageUrl/localImage left from a previous run gets cleared, otherwise
  // toggling images off mid-project would leave stale references.
  if (project.useImages === false) {
    onLog('running', 'Image search skipped (text-only deck)');
    for (const s of slides) {
      s.imageQuery = '';
      s.imageCandidates = [];
      s.imageUrl = null;
      s.localImage = null;
      s.imageCaption = '';
    }
    onLog('done', 'No images for this deck');
    return slides;
  }
  for (let i = 0; i < slides.length; i++) {
    const s = slides[i];
    if (!s.imageQuery) continue;
    onLog('running', `Image ${i+1}/${slides.length}: "${s.imageQuery}"`);
    const results = await searchImages(s.imageQuery, 4);
    s.imageCandidates = results;
    if (results.length > 0) {
      // default to first result
      s.imageUrl = results[0].url;
    }
  }
  onLog('done', `Image search complete`);
  return slides;
}

// ---- Step 5: DOWNLOAD selected images into the project folder ----
export async function downloadSelectedImages(project, slides, onLog) {
  onLog('running', 'Downloading selected images to disk...');
  let count = 0;
  for (let i = 0; i < slides.length; i++) {
    const s = slides[i];
    if (!s.imageUrl) continue;
    const ext = guessExt(s.imageUrl);
    const filename = `slide-${String(i+1).padStart(2, '0')}${ext}`;
    const bytes = await fetchImageBytes(s.imageUrl);
    if (bytes) {
      await fs.writeBytes(`projects/${project.id}/images/${filename}`, bytes);
      s.localImage = filename;
      count++;
    }
  }
  onLog('done', `Saved ${count} images locally`);
  return slides;
}

function guessExt(url) {
  const m = url.toLowerCase().match(/\.(jpe?g|png|webp|gif)(?:$|\?)/);
  if (m) return '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]);
  return '.jpg';
}

// ---- Generate speaker notes for a single slide ----
// Focused LLM call just for the notes text. Returns a plain string (not JSON).
export async function generateSpeakerNotes(project, slide, index, total) {
  const sys = `You write concise, useful speaker notes for a presenter. Output plain text only — no JSON, no markdown, no quotes around the output. 2-4 sentences maximum.`;
  const bullets = Array.isArray(slide.bullets) && slide.bullets.length
    ? '\nBullets:\n' + slide.bullets.map(b => '- ' + b).join('\n')
    : '';
  const user = `TOPIC: ${project.topic}
AUDIENCE: ${project.audience || 'general'}
TONE: ${project.tone}
${buildLanguageInstruction(project, { includeImageQueryRule: false })}
Slide ${index + 1} of ${total}:
Title: ${slide.title}
${slide.subtitle ? 'Subtitle: ' + slide.subtitle : ''}
${slide.body ? 'Body: ' + slide.body : ''}${bullets}

Write 2-4 sentences of speaker notes for this slide. Give the presenter:
- Context or a hook they can open with
- A memorable detail, number, or quote (only if grounded — do not fabricate)
- A natural transition cue if it's not the last slide

Do NOT just paraphrase the bullets. Output the notes directly, nothing else.`;
  const result = await chat({ system: sys, user, json: false, maxTokens: 600, temperature: 0.6, label: `notes-${index+1}` });
  return (result || '').trim().replace(/^["']+|["']+$/g, '');
}

// ---- Draft a single slide (for per-slide regeneration) ----
// Uses the same system prompt and JSON rules as the full drafter, but asks
// for a single slide object. Returns an object with the same shape as one
// element of the `slides` array from draftSlides.
export async function draftOneSlide(project, planItem, research, index, total) {
  // If we have no research or the plan item's angle references something very
  // specific, fetch targeted research just for this slide.
  let effectiveResearch = Array.isArray(research) ? [...research] : [];
  const needsMore = effectiveResearch.length === 0 ||
    (planItem.angle && planItem.angle.length > 30 && effectiveResearch.every(r => !slideAngleOverlapsResearch(planItem, r)));

  if (needsMore) {
    try {
      const targetQuery = planItem.title && planItem.angle
        ? `${project.topic} ${planItem.title}`
        : (planItem.title || project.topic);
      const langCfg = getLanguage(project.language || DEFAULT_LANGUAGE);
      const extra = await researchTopic(targetQuery, () => {}, { wikiLang: langCfg.wiki });
      for (const r of extra) {
        // Avoid duplicates
        if (!effectiveResearch.find(x => x.title === r.title)) {
          effectiveResearch.push(r);
        }
      }
    } catch { /* non-fatal */ }
  }

  const researchText = effectiveResearch.map(r => `[${r.title}]\n${r.text}`).join('\n\n---\n\n').slice(0, 6000);
  const hasResearch = researchText.trim().length > 0;

  const sys = `You are writing presentation slide content. You return ONLY valid, parseable JSON.

GROUNDING RULES (MUST follow):
- SPECIFIC FACTS (numbers, dates, names, quotes, statistics) MUST come from the research context. If the research doesn't contain a specific fact, do not include it.
- GENERIC FRAMING is always allowed and encouraged when the research is thin. Phrases like "is commonly used", "tends to be", "offers", "typically involves" are fine because they don't claim specifics.
- Do NOT draw on your training knowledge for specific claims — but DO use it to structure generic, non-committal framings that keep the slide useful.
- Prefer a slide with honest generic framing over a slide with invented specifics, and prefer either over an empty slide.
- Bullets should be concrete in topic but generic in claims if research is thin. E.g. "Developed as an alternative to silk" (generic, fine) vs "Developed in 1892 in Switzerland" (specific — must be in research).

JSON RULES (MUST follow exactly):
- Output ONE JSON object and NOTHING else — no markdown fences, no prose before or after.
- Every key MUST be a quoted string followed by a colon.
- Every string value MUST end with a closing quote and be followed by a comma before the next key.
- The object must NOT be wrapped in {"slides": [...]} — return just the single slide object.
- Do NOT repeat the JSON. Stop after the single closing brace.`;

  const user = `TOPIC: ${project.topic}
TONE: ${project.tone}
AUDIENCE: ${project.audience || 'general'}
${buildLanguageInstruction(project)}
${hasResearch ? `RESEARCH CONTEXT (use this as your only factual source — rephrase, do not copy):\n${researchText}` : 'NO RESEARCH AVAILABLE — write generic, non-specific content only. Do not invent facts.'}

You are writing slide ${index + 1} of ${total}. Plan for this slide:
${JSON.stringify(planItem, null, 2)}

Return a SINGLE JSON object with this shape (not wrapped in "slides"):

{
  "title": "2-6 word slide title",
  "subtitle": "tagline or empty string",
  "body": "optional 1-3 sentence paragraph, or empty string",
  "bullets": ["short bullet", "short bullet"],
  "imageCaption": "caption for the image",
  "imageQuery": "same or refined query from plan",
  "speakerNotes": "2-4 sentences of what the presenter should say — context, memorable detail, or transition. NOT a repeat of the bullets."
}

EXAMPLE (slide on aqueduct engineering, with research provided):
{
  "title": "How They Worked",
  "subtitle": "",
  "body": "",
  "bullets": [
    "Gravity-fed channels with precise gradients of about 1 in 200",
    "Arcade bridges carried water across valleys",
    "Tunnels and siphons handled hills and dips"
  ],
  "imageCaption": "Cross section of a typical aqueduct channel",
  "imageQuery": "Roman aqueduct cross section",
  "speakerNotes": "The key idea is the gradient — too steep and water erodes the channel; too shallow and it stagnates. Roman surveyors used a tool called the chorobates to measure slope over long distances."
}

Rules:
- For a ${planItem.role} slide, follow the usual conventions (cover = tagline in subtitle, no bullets; conclusion = summary or 2-3 takeaways; content = 2-5 bullets OR a short body paragraph).
- Content and conclusion slides MUST have either a non-empty body OR at least 2 bullets. Returning an empty slide is a failure.
- LENGTH LIMITS (critical — the slide is a fixed size, overflow breaks layout):
  * Title: maximum 8 words.
  * Subtitle: one short sentence, maximum 15 words.
  * Body: maximum 3 sentences, ~250 characters total.
  * Bullets: 2-5 items, each 10 words or fewer. Short is better than complete.
  * Speaker notes are unlimited — those are in a separate panel.
- No filler. No "In conclusion". No opening "This slide...".
- Grounding policy:
  * Specific facts (numbers, dates, names, quotes, statistics) MUST come from the research context. Never invent them.
  * Generic framing is allowed ("is commonly used for", "tends to be softer", "offers a balance between X and Y") — do NOT leave a slide empty because the research is thin.
  * Prefer generic-but-truthful phrasing over specific-but-unsupported claims.`;

  const raw = await chat({ system: sys, user, json: true, maxTokens: 3000, temperature: 0.5, label: `draft-slide-${index+1}` });
  const parsed = coerceSlideShape(raw);
  if (!parsed) {
    throw new Error('Slide response was not in expected format (could not coerce to a slide object).');
  }

  const rawBullets = Array.isArray(parsed.bullets) ? parsed.bullets.filter(b => typeof b === 'string' && b.trim()).map(b => fixWordSpacing(b.trim())) : [];
  const title = fixWordSpacing((parsed.title || '').trim());
  const subtitle = fixWordSpacing((parsed.subtitle || '').trim());
  const body = fixWordSpacing((parsed.body || '').trim());
  const notes = (parsed.speakerNotes || '').trim();

  // Hard-cap content so it fits on a fixed-size slide. Models often ignore
  // the "15 words max" rule in the prompt — we enforce it here so overflow
  // can't push the title off-screen.
  const bullets = capBullets(rawBullets, 5, 18);
  const cappedBody = capBody(body, 280);
  const cappedSubtitle = capText(subtitle, 120);

  // Sanity check: the LLM must produce something meaningful.
  // Cover and section slides can be title-only (with subtitle); content and
  // conclusion slides must have body or bullets — otherwise they render
  // as a big empty panel.
  const role = planItem.role || 'content';
  const isTitleOnlyRole = role === 'cover' || role === 'section';
  const hasBodyOrBullets = cappedBody || bullets.length > 0;
  const hasAnyContent = isTitleOnlyRole
    ? (title || cappedSubtitle || cappedBody || bullets.length > 0 || notes)
    : hasBodyOrBullets;
  if (!hasAnyContent) {
    throw new Error(`LLM returned an empty ${role} slide (no body or bullets). The response will be retried.`);
  }

  return {
    title: capText(title || planItem.title || '', 60),
    subtitle: cappedSubtitle,
    body: cappedBody,
    bullets,
    imageCaption: capText(fixWordSpacing((parsed.imageCaption || '').trim()), 100),
    imageQuery: (parsed.imageQuery || planItem.imageQuery || '').trim(),
    speakerNotes: fixWordSpacing(notes)
  };
}

// Truncate a bullet list so total content fits on a slide. Caps:
//   - max `maxBullets` entries
//   - max `maxWords` words per bullet (longer ones are truncated mid-bullet
//     with an ellipsis at the nearest word boundary)
function capBullets(bullets, maxBullets, maxWords) {
  return bullets.slice(0, maxBullets).map(b => {
    const words = b.split(/\s+/);
    if (words.length <= maxWords) return b;
    return words.slice(0, maxWords).join(' ') + '\u2026';
  });
}

function capBody(text, maxChars) {
  if (!text || text.length <= maxChars) return text;
  // Prefer to cut at the nearest sentence end before the limit.
  const slice = text.slice(0, maxChars);
  const lastSentence = Math.max(slice.lastIndexOf('. '), slice.lastIndexOf('! '), slice.lastIndexOf('? '));
  if (lastSentence > 0) return slice.slice(0, lastSentence + 1);
  // No sentence boundary — cut at the nearest word.
  const lastSpace = slice.lastIndexOf(' ');
  return slice.slice(0, lastSpace > 0 ? lastSpace : maxChars) + '\u2026';
}

function capText(text, maxChars) {
  if (!text || text.length <= maxChars) return text;
  const slice = text.slice(0, maxChars);
  const lastSpace = slice.lastIndexOf(' ');
  return slice.slice(0, lastSpace > 0 ? lastSpace : maxChars) + '\u2026';
}

// Repair concatenated words like "AircraftDesign" → "Aircraft Design".
// Some LLMs occasionally drop spaces between words in headline-cased text.
// This insert spaces before any uppercase letter that follows a lowercase
// letter, which fixes "AircraftDesign" but leaves intact:
//   - All-caps words (USA, AI, NASA — no lowercase before uppercase)
//   - Proper-case names already separated (Aircraft Design)
//   - CamelCase brand names that intentionally have no space (iPhone — but
//     the lowercase-i before P would split it; we accept that trade-off
//     because it's rare in slide titles and easy to fix manually)
function fixWordSpacing(text) {
  if (!text || typeof text !== 'string') return text;
  // Only split when a lowercase letter is followed by an uppercase letter
  // AND the uppercase letter is followed by a lowercase letter (so we
  // don't split inside acronyms like "iOSDevice" → keep "iOS Device").
  return text.replace(/([a-z\u00DF-\u00F6\u00F8-\u00FF])([A-Z\u00C0-\u00D6\u00D8-\u00DE])(?=[a-z\u00DF-\u00F6\u00F8-\u00FF])/g, '$1 $2');
}

// Coerce a parsed LLM response into a single slide-shaped object.
// Handles:
//   - a bare slide object
//   - {"slides": [slide]} or {"slide": slide} wrappers
//   - an array of slides (takes the first)
function coerceSlideShape(raw) {
  if (!raw || typeof raw !== 'object') return null;
  // Already a slide-shaped object?
  const looksLikeSlide = (o) =>
    o && typeof o === 'object' && !Array.isArray(o) && (
      'title' in o || 'bullets' in o || 'body' in o || 'subtitle' in o || 'speakerNotes' in o
    );
  if (looksLikeSlide(raw) && !Array.isArray(raw.slides) && !looksLikeSlide(raw.slide)) return raw;
  // Wrapped as {"slides": [...]}
  if (Array.isArray(raw.slides) && raw.slides.length > 0 && looksLikeSlide(raw.slides[0])) {
    return raw.slides[0];
  }
  // Wrapped as {"slide": {...}}
  if (looksLikeSlide(raw.slide)) return raw.slide;
  // Bare array
  if (Array.isArray(raw) && raw.length > 0 && looksLikeSlide(raw[0])) return raw[0];
  // Nested one level — {"response": {"slides": [...]}}, {"result": {...}}, etc.
  for (const k of Object.keys(raw)) {
    const v = raw[k];
    if (looksLikeSlide(v)) return v;
    if (Array.isArray(v) && v.length > 0 && looksLikeSlide(v[0])) return v[0];
    // Recurse one level: check if v is itself a wrapper object
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      if (Array.isArray(v.slides) && v.slides.length > 0 && looksLikeSlide(v.slides[0])) {
        return v.slides[0];
      }
      if (looksLikeSlide(v.slide)) return v.slide;
    }
  }
  // Last resort — if it at least has a title field, treat it as a slide even if sparse
  if (raw.title || raw.bullets) return raw;
  return null;
}

// Cheap check: does the slide's title/angle share significant keywords with a
// research snippet? Used to decide whether the existing research covers this
// slide's subtopic or we should fetch more.
function slideAngleOverlapsResearch(planItem, researchSnippet) {
  const text = ((planItem.title || '') + ' ' + (planItem.angle || '')).toLowerCase();
  const words = text.split(/\W+/).filter(w => w.length >= 5); // "rayon", "modal", etc.
  if (words.length === 0) return true; // no specific terms to check
  const haystack = ((researchSnippet.title || '') + ' ' + (researchSnippet.text || '')).toLowerCase();
  const hits = words.filter(w => haystack.includes(w));
  return hits.length >= Math.min(2, Math.ceil(words.length / 3));
}

// Append-only shortener: takes a slide and asks the LLM to produce a tighter
// version, preserving the same meaning but using fewer words. Designed to be
// called repeatedly — each call operates on the current slide content, so
// pressing "Shorten" three times produces progressively shorter copy than
// pressing once. The level parameter is just an intensity hint passed to the
// prompt so the model knows how aggressive to be.
//
// Image fields (imageUrl, localImage, imageQuery, imageCaption) are NOT
// touched. Speaker notes ARE shortened proportionally — the goal is the
// whole slide stays in sync.
export async function shortenSlide(project, slide, level = 1) {
  // Cap at 5 — beyond that, content is reduced to almost nothing and
  // further LLM calls produce diminishing returns or refusals.
  const intensity = Math.max(1, Math.min(5, level));

  const intensityHint = intensity === 1
    ? 'Trim about 30% — tighten phrasing, drop filler words, keep all the substance.'
    : intensity === 2
    ? 'Trim aggressively — about half the length. Remove every non-essential word.'
    : intensity === 3
    ? 'Make it terse — short bullets, punchy sentences. Aim for headline-style brevity.'
    : intensity === 4
    ? 'Telegram-tight: 2-3 word bullets, very short title, minimal subtitle.'
    : 'Maximum compression: title under 4 words, bullets under 4 words each, body 1 short sentence or empty.';

  const sys = `You are an editor compressing presentation slide text. Return ONLY a single JSON object — no markdown, no commentary.

Output shape:
{
  "title": "<shortened title>",
  "subtitle": "<shortened subtitle, may be empty>",
  "body": "<shortened body paragraph, may be empty>",
  "bullets": ["<shortened bullet>", "..."],
  "imageCaption": "<shortened caption, may be empty>",
  "speakerNotes": "<shortened notes>"
}

Rules:
- Preserve the meaning and key facts. Do not add new information or invent details.
- Keep the same number of bullets unless one is truly redundant.
- Keep the same language as the input. Do not translate.
- Do not add ellipsis ("...") or "see notes" — just produce shorter text.
- Output valid JSON only.`;

  const langCfg = getLanguage(project.language || DEFAULT_LANGUAGE);
  const langInstr = langCfg.code !== 'en'
    ? `\nLANGUAGE: keep all text in ${langCfg.promptName} (${langCfg.nativeName}). Do not translate.`
    : '';

  const user = `${intensityHint}${langInstr}

Current slide content (intensity level ${intensity}/5):
${JSON.stringify({
    title: slide.title || '',
    subtitle: slide.subtitle || '',
    body: slide.body || '',
    bullets: slide.bullets || [],
    imageCaption: slide.imageCaption || '',
    speakerNotes: slide.speakerNotes || ''
  }, null, 2)}

Return the shortened version as JSON.`;

  const result = await chat({
    system: sys,
    user,
    json: true,
    maxTokens: 1500,
    temperature: 0.2,
    label: 'shorten-slide'
  });

  if (!result || typeof result !== 'object') {
    throw new Error('Shorten produced no result');
  }

  // Apply spacing fix to all text fields (in case LLM concatenates words)
  return {
    title: fixWordSpacing((result.title || slide.title || '').trim()),
    subtitle: fixWordSpacing((result.subtitle || '').trim()),
    body: fixWordSpacing((result.body || '').trim()),
    bullets: Array.isArray(result.bullets)
      ? result.bullets.filter(b => typeof b === 'string' && b.trim()).map(b => fixWordSpacing(b.trim()))
      : (slide.bullets || []),
    imageCaption: fixWordSpacing((result.imageCaption || slide.imageCaption || '').trim()),
    speakerNotes: fixWordSpacing((result.speakerNotes || '').trim())
  };
}
