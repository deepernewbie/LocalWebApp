// Language definitions used by the project model, prompts, research, and HTML output.
// Each entry: { code (ISO 639-1, used in <html lang>), name (in English), nativeName,
//               wiki (Wikipedia subdomain), promptName (the language name to use in
//               LLM prompts — clearer than just code letters) }

export const LANGUAGES = [
  { code: 'en', name: 'English',  nativeName: 'English',  wiki: 'en', promptName: 'English' },
  { code: 'tr', name: 'Turkish',  nativeName: 'Türkçe',   wiki: 'tr', promptName: 'Turkish' },
  { code: 'fr', name: 'French',   nativeName: 'Français', wiki: 'fr', promptName: 'French' },
  { code: 'es', name: 'Spanish',  nativeName: 'Español',  wiki: 'es', promptName: 'Spanish' },
  { code: 'de', name: 'German',   nativeName: 'Deutsch',  wiki: 'de', promptName: 'German' },
  { code: 'zh', name: 'Chinese',  nativeName: '中文',      wiki: 'zh', promptName: 'Simplified Chinese' }
];

export function getLanguage(code) {
  return LANGUAGES.find(l => l.code === code) || LANGUAGES[0];
}

// English remains the implicit default for back-compat; older projects without
// a language field continue to work.
export const DEFAULT_LANGUAGE = 'en';
