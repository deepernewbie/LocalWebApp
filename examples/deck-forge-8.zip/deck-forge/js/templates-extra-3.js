// templates-extra-3.js — 10 templates: bold/statement (5) + nature/organic (4) + experimental (1)

const gfonts = (family) => `<link href="https://fonts.googleapis.com/css2?${family}&display=swap" rel="stylesheet">`;

function basicRender(ctx, opts = {}) {
  const { slide, isCover, esc, bullets, img, editable } = ctx;
  const e = (f) => editable ? `data-field="${f}"` : '';
  return `<section class="slide ${isCover ? 'cover' : ''}">
    ${opts.before ? opts.before(ctx) : ''}
    <h1 ${e('title')}>${esc(slide.title)}</h1>
    ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
    ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
    ${bullets(slide.bullets)}
    ${img(slide)}
    ${opts.after ? opts.after(ctx) : ''}
  </section>`;
}

// ============ BOLD / STATEMENT (5) ============

const bigType = {
  id: 'big-type', name: 'Big Type', tag: 'Massive typography',
  fonts: gfonts('family=Anton&family=Inter:wght@400;600'),
  css: `
    body { background: #fffef5; color: #0a0a0a; font-family: 'Inter', sans-serif; }
    .slide { padding: 6vmin; justify-content: center; }
    h1 { font-family: 'Anton', sans-serif; font-size: clamp(64px, 15vw, 200px); line-height: .85; letter-spacing: -.03em; text-transform: uppercase; margin-bottom: 20px; color: #0a0a0a; word-break: break-word; }
    .subtitle { font-size: clamp(18px, 2.6vw, 26px); font-weight: 500; color: #333; max-width: 800px; margin-bottom: 22px; line-height: 1.3; }
    .body { font-size: clamp(15px, 1.9vw, 19px); line-height: 1.55; max-width: 700px; margin-bottom: 12px; color: #333; }
    ul { list-style: none; max-width: 700px; counter-reset: l; }
    li { font-family: 'Anton', sans-serif; font-size: clamp(20px, 3.2vw, 32px); line-height: 1.1; padding: 10px 0; text-transform: uppercase; letter-spacing: -.01em; border-top: 2px solid #0a0a0a; counter-increment: l; }
    li:last-child { border-bottom: 2px solid #0a0a0a; }
    li::before { content: counter(l, decimal-leading-zero) '\u00A0\u00A0'; color: #ff0040; font-size: .6em; }
    .slide img { max-width: 380px; max-height: 35vh; margin-top: 20px; filter: grayscale(1); }
    .cover h1 { font-size: clamp(84px, 22vw, 280px); }
    .deck-progress { background: #ff0040; height: 6px; }
  `,
  preview: () => `<div style="background:#fffef5;height:100%;padding:4px;display:flex;align-items:center;justify-content:center">
    <div style="font-family:sans-serif;font-weight:900;font-size:32px;line-height:.8;letter-spacing:-2px">BIG</div></div>`,
  render: (ctx) => basicRender(ctx)
};

const maximalist = {
  id: 'maximalist', name: 'Maximalist', tag: 'Chaos · Layered',
  fonts: gfonts('family=Archivo+Black&family=Caveat:wght@700&family=Playfair+Display:ital,wght@1,700'),
  css: `
    body { background: #ffeb3b; color: #000; font-family: Georgia, serif; overflow: hidden; }
    body::before { content: ''; position: fixed; inset: 0; background: repeating-linear-gradient(45deg, transparent 0 30px, rgba(255,0,128,0.05) 30px 60px), radial-gradient(circle at 80% 20%, rgba(0,100,255,0.2), transparent 30%), radial-gradient(circle at 20% 80%, rgba(255,0,128,0.2), transparent 30%); pointer-events: none; }
    .slide { padding: 5vmin; }
    h1 { font-family: 'Archivo Black', sans-serif; font-size: clamp(38px, 8vw, 72px); line-height: .95; text-transform: uppercase; margin-bottom: 10px; position: relative; z-index: 2; display: inline-block; background: #ff0080; color: #ffeb3b; padding: 2px 14px; transform: rotate(-1deg); box-shadow: 6px 6px 0 #0064ff; }
    .subtitle { font-family: 'Playfair Display', serif; font-style: italic; font-size: clamp(20px, 3vw, 28px); color: #0064ff; margin: 16px 0 14px; display: inline-block; background: #fff; padding: 2px 10px; transform: rotate(1deg); }
    .body { font-family: 'Caveat', cursive; font-weight: 700; font-size: clamp(18px, 2.5vw, 24px); line-height: 1.3; max-width: 700px; margin-bottom: 10px; background: #000; color: #ffeb3b; padding: 10px 14px; display: inline-block; transform: rotate(-.5deg); }
    ul { list-style: none; max-width: 800px; }
    li { font-family: 'Archivo Black', sans-serif; font-size: clamp(14px, 1.8vw, 18px); padding: 6px 12px; background: #000; color: #ffeb3b; margin-bottom: 6px; display: inline-block; margin-right: 8px; transform: rotate(-.5deg); }
    li:nth-child(even) { background: #ff0080; color: #fff; transform: rotate(.8deg); }
    li:nth-child(3n) { background: #0064ff; color: #fff; transform: rotate(-1deg); }
    .slide img { max-width: 260px; max-height: 30vh; border: 6px solid #000; transform: rotate(-3deg); margin-top: 14px; box-shadow: 10px 10px 0 #ff0080; filter: saturate(1.5); }
    .cover h1 { font-size: clamp(52px, 12vw, 120px); }
    .deck-progress { background: #ff0080; height: 8px; }
  `,
  preview: () => `<div style="background:#ffeb3b;height:100%;padding:4px;position:relative;overflow:hidden">
    <div style="background:#ff0080;color:#ffeb3b;font-family:sans-serif;font-weight:900;font-size:9px;display:inline-block;padding:0 2px;transform:rotate(-2deg)">MAX!</div>
    <div style="background:#000;color:#ffeb3b;font-family:cursive;font-size:7px;display:inline-block;padding:0 2px;margin-top:3px;transform:rotate(1deg)">more more</div></div>`,
  render: (ctx) => basicRender(ctx)
};

const protest = {
  id: 'protest', name: 'Protest', tag: 'Poster · Urgent',
  fonts: gfonts('family=Bebas+Neue&family=Oswald:wght@700'),
  css: `
    body { background: #111; color: #fff; font-family: 'Oswald', sans-serif; }
    .slide { padding: 7vmin; justify-content: center; text-align: center; align-items: center; background: repeating-linear-gradient(-8deg, #111 0, #111 80px, #1f1f1f 80px, #1f1f1f 82px); }
    h1 { font-family: 'Bebas Neue', sans-serif; font-size: clamp(52px, 12vw, 140px); line-height: .9; letter-spacing: .01em; text-transform: uppercase; margin-bottom: 18px; color: #fff; text-shadow: 5px 5px 0 #ff2d2d; }
    .subtitle { font-family: 'Bebas Neue', sans-serif; background: #ff2d2d; color: #fff; font-size: clamp(20px, 3.5vw, 36px); padding: 6px 20px; display: inline-block; letter-spacing: .1em; margin-bottom: 22px; transform: skewX(-8deg); }
    .subtitle span { display: inline-block; transform: skewX(8deg); }
    .body { font-family: 'Oswald', sans-serif; font-weight: 700; font-size: clamp(16px, 2.3vw, 22px); line-height: 1.4; text-transform: uppercase; letter-spacing: .05em; max-width: 800px; margin: 0 auto 14px; }
    ul { list-style: none; max-width: 800px; margin: 0 auto; }
    li { font-family: 'Bebas Neue', sans-serif; font-size: clamp(22px, 3.5vw, 34px); line-height: 1.1; padding: 12px 0; letter-spacing: .03em; border-top: 3px solid #fff; }
    li:last-child { border-bottom: 3px solid #fff; }
    li::before { content: '!'; color: #ff2d2d; font-weight: 700; font-size: 1.3em; margin-right: 10px; }
    .slide img { max-width: 280px; max-height: 30vh; margin: 18px auto 0; filter: grayscale(1) contrast(1.3); border: 4px solid #fff; }
    .cover h1 { font-size: clamp(70px, 18vw, 240px); }
    .deck-progress { background: #ff2d2d; height: 6px; }
  `,
  preview: () => `<div style="background:#111;height:100%;padding:6px;text-align:center;background:repeating-linear-gradient(-5deg,#111 0 8px,#1f1f1f 8px 9px)">
    <div style="font-family:sans-serif;font-weight:900;font-size:14px;color:#fff;text-shadow:2px 2px 0 #ff2d2d;line-height:1">RISE UP</div>
    <div style="background:#ff2d2d;color:#fff;font-family:sans-serif;font-weight:700;font-size:6px;display:inline-block;padding:1px 3px;margin-top:3px">DEMAND CHANGE</div></div>`,
  render: (ctx) => {
    const { slide, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle"><span ${e('subtitle')}>${esc(slide.subtitle)}</span></div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`;
  }
};

const tabloid = {
  id: 'tabloid', name: 'Tabloid', tag: 'Sensational',
  fonts: gfonts('family=Oswald:wght@700;900&family=Bitter:ital@1'),
  css: `
    body { background: #fffbed; color: #111; font-family: 'Bitter', serif; }
    .slide { padding: 5vmin 6vmin; }
    .top-bar { background: #c10f0f; color: #fff; padding: 6px 12px; font-family: 'Oswald', sans-serif; font-weight: 900; font-size: 13px; letter-spacing: .15em; text-transform: uppercase; margin-bottom: 20px; display: flex; justify-content: space-between; }
    h1 { font-family: 'Oswald', sans-serif; font-weight: 900; font-size: clamp(42px, 9vw, 92px); line-height: .9; text-transform: uppercase; letter-spacing: -.02em; margin-bottom: 14px; color: #000; }
    h1 .red { color: #c10f0f; }
    .subtitle { font-style: italic; font-size: clamp(18px, 2.4vw, 22px); color: #333; margin-bottom: 20px; border-left: 5px solid #c10f0f; padding-left: 14px; }
    .body { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.6; column-count: 2; column-gap: 30px; margin-bottom: 12px; }
    ul { list-style: none; }
    li { font-size: clamp(13px, 1.7vw, 16px); line-height: 1.5; padding: 6px 0 6px 30px; position: relative; border-top: 1px dashed #666; font-weight: 500; }
    li::before { content: 'EXCLUSIVE \u00BB'; position: absolute; left: 0; top: 6px; color: #c10f0f; font-family: 'Oswald', sans-serif; font-weight: 900; font-size: .75em; letter-spacing: .05em; }
    .slide img { max-width: 360px; max-height: 40vh; margin-top: 14px; border: 3px solid #000; filter: grayscale(1) contrast(1.2); }
    .sticker { position: absolute; top: 6vmin; right: 6vmin; background: #ffeb00; color: #c10f0f; padding: 10px 16px; font-family: 'Oswald', sans-serif; font-weight: 900; font-size: 14px; transform: rotate(8deg); border: 3px solid #000; box-shadow: 4px 4px 0 #000; text-transform: uppercase; }
    .cover h1 { font-size: clamp(54px, 14vw, 160px); }
    .deck-progress { background: #c10f0f; height: 4px; }
  `,
  preview: () => `<div style="background:#fffbed;height:100%;padding:4px">
    <div style="background:#c10f0f;color:#fff;padding:1px 2px;font-family:sans-serif;font-weight:900;font-size:5px;letter-spacing:1px">BREAKING!</div>
    <div style="font-family:sans-serif;font-weight:900;font-size:12px;line-height:1;margin-top:3px;text-transform:uppercase">SHOCK <span style="color:#c10f0f">NEWS</span></div></div>`,
  render: (ctx) => {
    const { slide, index, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    const titleHtml = isCover ? esc(slide.title).replace(/(\S+)$/, '<span class="red">$1</span>') : esc(slide.title);
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="top-bar"><span>\u26A0 Breaking</span><span>Story \u00A0${String(index+1).padStart(2,'0')}</span></div>
      <h1 ${e('title')}>${titleHtml}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      ${isCover ? `<div class="sticker">MUST READ</div>` : ''}
    </section>`;
  }
};

const quoteCentric = {
  id: 'quote', name: 'Quote', tag: 'One big idea',
  fonts: gfonts('family=Playfair+Display:ital,wght@1,500;1,700&family=Inter:wght@400;600'),
  css: `
    body { background: #0d0d0d; color: #f5f5f5; font-family: 'Inter', sans-serif; }
    .slide { padding: 10vmin; justify-content: center; align-items: center; text-align: center; }
    .mark { font-family: 'Playfair Display', serif; font-style: italic; font-size: clamp(80px, 16vw, 200px); color: #fbbf24; line-height: .6; margin-bottom: 20px; opacity: .8; }
    h1 { font-family: 'Playfair Display', serif; font-style: italic; font-size: clamp(34px, 6vw, 58px); font-weight: 500; line-height: 1.25; margin-bottom: 28px; max-width: 1000px; }
    .subtitle { font-size: clamp(16px, 2vw, 19px); color: #fbbf24; margin-bottom: 10px; letter-spacing: .2em; text-transform: uppercase; font-weight: 600; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.7; max-width: 720px; color: #a3a3a3; margin-bottom: 14px; }
    ul { list-style: none; max-width: 640px; margin: 0 auto; }
    li { font-family: 'Playfair Display', serif; font-style: italic; font-size: clamp(17px, 2.3vw, 22px); line-height: 1.5; padding: 10px 0; border-top: 1px solid #262626; }
    li:last-child { border-bottom: 1px solid #262626; }
    .slide img { max-width: 280px; max-height: 30vh; margin-top: 24px; border-radius: 8px; filter: grayscale(1) brightness(.85); border: 1px solid #262626; }
    .attribution { margin-top: 20px; font-size: 13px; color: #737373; letter-spacing: .15em; text-transform: uppercase; font-weight: 600; }
    .cover h1 { font-size: clamp(40px, 8vw, 78px); }
    .deck-progress { background: #fbbf24; }
  `,
  preview: () => `<div style="background:#0d0d0d;height:100%;padding:8px;text-align:center;display:flex;flex-direction:column;justify-content:center">
    <div style="font-family:serif;font-style:italic;font-size:22px;color:#fbbf24;line-height:.6">\u201C</div>
    <div style="font-family:serif;font-style:italic;font-size:8px;color:#f5f5f5;line-height:1.3;margin-top:2px">a single truth</div></div>`,
  render: (ctx) => {
    const { slide, project, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="mark">\u201C</div>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      <div class="attribution">\u2014 ${esc(project.topic).slice(0, 40)}</div>
    </section>`;
  }
};

// ============ NATURE / ORGANIC (4) ============

const botanical = {
  id: 'botanical', name: 'Botanical', tag: 'Natural · Herbarium',
  fonts: gfonts('family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=Fraunces:ital,opsz@1,9..144'),
  css: `
    body { background: #f4efe3; color: #2d3b2d; font-family: 'Cormorant Garamond', serif; }
    body::before { content: ''; position: fixed; inset: 0; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cpath d='M50 20 Q30 40 50 80 Q70 40 50 20' fill='none' stroke='%23a5b0a0' stroke-width='.5' opacity='.3'/%3E%3C/svg%3E"); opacity: .3; pointer-events: none; }
    .slide { padding: 8vmin 10vmin; justify-content: center; z-index: 1; }
    h1 { font-family: 'Fraunces', serif; font-style: italic; font-size: clamp(40px, 7.5vw, 72px); font-weight: 400; line-height: 1.05; margin-bottom: 16px; color: #3a4a38; }
    .latin { font-style: italic; color: #6b8068; font-size: clamp(14px, 1.8vw, 17px); margin-bottom: 20px; letter-spacing: .05em; }
    .subtitle { font-size: clamp(16px, 2vw, 20px); color: #5a6a58; margin-bottom: 22px; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.7; max-width: 720px; margin-bottom: 14px; color: #3a4a38; }
    ul { list-style: none; max-width: 720px; }
    li { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.7; padding: 6px 0 6px 30px; position: relative; border-bottom: 1px solid rgba(107,128,104,0.2); }
    li::before { content: '\u{1F342}'; position: absolute; left: 0; top: 6px; font-size: 14px; filter: grayscale(.5) sepia(.3); }
    .slide img { max-width: 380px; max-height: 40vh; margin-top: 18px; border: 1px solid #a5b0a0; padding: 4px; background: #fff; filter: sepia(0.1); }
    .specimen { position: absolute; top: 4vmin; right: 6vmin; font-family: 'Fraunces', serif; font-style: italic; color: #6b8068; font-size: 13px; letter-spacing: .1em; }
    .cover h1 { font-size: clamp(52px, 11vw, 110px); }
    .deck-progress { background: #6b8068; }
  `,
  preview: () => `<div style="background:#f4efe3;height:100%;padding:8px">
    <div style="font-family:serif;font-style:italic;font-size:12px;color:#3a4a38;line-height:1">Flora</div>
    <div style="font-family:serif;font-style:italic;font-size:5px;color:#6b8068;margin-top:2px">— Botanica —</div>
    <div style="font-size:8px;margin-top:3px">\u{1F342} \u{1F343} \u{1F33F}</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ index }) => `<div class="specimen">N\u00B0 ${String(index+1).padStart(3,'0')}</div>`
  })
};

const japaneseMin = {
  id: 'japanese', name: 'Japanese', tag: 'Minimal · Wabi-sabi',
  fonts: gfonts('family=Shippori+Mincho:wght@400;600;800&family=Noto+Sans+JP:wght@300;500'),
  css: `
    body { background: #f4f0e8; color: #1c1c1c; font-family: 'Shippori Mincho', serif; }
    .slide { padding: 10vmin 12vmin; justify-content: center; position: relative; }
    .slide::before { content: ''; position: absolute; top: 8vmin; left: 8vmin; width: 2px; height: 60px; background: #c14d4d; }
    h1 { font-weight: 800; font-size: clamp(40px, 8vw, 76px); line-height: 1.1; margin-bottom: 18px; letter-spacing: -.02em; }
    .kanji { font-size: clamp(32px, 6vw, 56px); color: #c14d4d; margin-bottom: 14px; font-weight: 400; letter-spacing: .1em; }
    .subtitle { font-family: 'Noto Sans JP', sans-serif; font-weight: 300; font-size: clamp(15px, 2vw, 19px); color: #555; margin-bottom: 22px; letter-spacing: .15em; }
    .body { font-size: clamp(15px, 2vw, 19px); line-height: 1.8; max-width: 680px; margin-bottom: 14px; }
    ul { list-style: none; max-width: 680px; }
    li { font-size: clamp(14px, 1.9vw, 18px); line-height: 1.8; padding: 8px 0 8px 36px; position: relative; }
    li::before { content: '\u4E00'; position: absolute; left: 0; top: 8px; color: #c14d4d; font-family: 'Shippori Mincho', serif; font-weight: 800; }
    li:nth-child(2)::before { content: '\u4E8C'; }
    li:nth-child(3)::before { content: '\u4E09'; }
    li:nth-child(4)::before { content: '\u56DB'; }
    li:nth-child(5)::before { content: '\u4E94'; }
    li:nth-child(6)::before { content: '\u516D'; }
    .slide img { max-width: 360px; max-height: 40vh; margin-top: 18px; filter: grayscale(.4) contrast(.95); }
    .circle { position: absolute; top: 6vmin; right: 8vmin; width: 90px; height: 90px; border: 2px solid #1c1c1c; border-radius: 50%; background: rgba(193,77,77,0.1); }
    .cover h1 { font-size: clamp(48px, 11vw, 110px); }
    .deck-progress { background: #c14d4d; height: 1px; }
  `,
  preview: () => `<div style="background:#f4f0e8;height:100%;padding:8px;position:relative">
    <div style="width:2px;height:10px;background:#c14d4d"></div>
    <div style="font-family:serif;font-size:16px;font-weight:800;color:#1c1c1c;line-height:1;margin-top:4px">\u9759</div>
    <div style="font-size:6px;color:#555;letter-spacing:2px;margin-top:2px">SILENCE</div>
    <div style="position:absolute;top:4px;right:4px;width:16px;height:16px;border:1px solid #1c1c1c;border-radius:50%"></div></div>`,
  render: (ctx) => {
    const { slide, index, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    const kanji = ['\u9ED8','\u98A8','\u6728','\u6C34','\u706B','\u571F','\u7A7A','\u5149','\u5F71','\u9759','\u6D41','\u82B1','\u6E90','\u8DEF','\u5FC3','\u9053','\u5E73','\u7D50','\u59CB','\u7D42'];
    const k = kanji[index % kanji.length];
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="circle"></div>
      <div class="kanji">${k}</div>
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`;
  }
};

const desert = {
  id: 'desert', name: 'Desert', tag: 'Warm · Terracotta',
  fonts: gfonts('family=Marcellus&family=Nunito:wght@300;600'),
  css: `
    body { background: linear-gradient(180deg, #f2c179 0%, #d97759 60%, #b33c2b 100%); color: #2d1810; font-family: 'Nunito', sans-serif; }
    body::before { content: ''; position: fixed; bottom: 0; left: 0; right: 0; height: 40%; background: linear-gradient(180deg, transparent 0%, rgba(60,20,10,0.3) 100%); pointer-events: none; }
    .slide { padding: 8vmin 10vmin; justify-content: center; z-index: 1; }
    h1 { font-family: 'Marcellus', serif; font-size: clamp(42px, 9vw, 80px); font-weight: 400; line-height: 1; margin-bottom: 16px; color: #fff; text-shadow: 1px 2px 6px rgba(60,20,10,0.3); letter-spacing: -.01em; }
    .subtitle { font-family: 'Marcellus', serif; font-size: clamp(18px, 2.5vw, 24px); color: #fbeed3; margin-bottom: 24px; letter-spacing: .1em; font-style: italic; }
    .body { font-size: clamp(16px, 2vw, 19px); line-height: 1.65; max-width: 720px; margin-bottom: 14px; color: #2d1810; font-weight: 300; }
    ul { list-style: none; max-width: 720px; }
    li { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.6; padding: 10px 16px; background: rgba(255,240,210,0.6); backdrop-filter: blur(10px); border-radius: 30px; margin-bottom: 8px; font-weight: 600; padding-left: 40px; position: relative; }
    li::before { content: '\u25C6'; position: absolute; left: 18px; top: 10px; color: #b33c2b; }
    .slide img { max-width: 360px; max-height: 40vh; margin-top: 18px; border-radius: 20px; box-shadow: 0 20px 50px rgba(60,20,10,0.4); filter: sepia(0.25); }
    .sun { position: absolute; top: 6vmin; right: 8vmin; width: 70px; height: 70px; border-radius: 50%; background: radial-gradient(circle, #fef0c0, #fbeed3 70%, rgba(255,240,210,0) 100%); box-shadow: 0 0 40px rgba(254,240,192,0.6); }
    .cover h1 { font-size: clamp(54px, 13vw, 130px); }
    .deck-progress { background: #fff; }
  `,
  preview: () => `<div style="background:linear-gradient(180deg,#f2c179,#d97759,#b33c2b);height:100%;padding:8px;position:relative">
    <div style="position:absolute;top:4px;right:4px;width:14px;height:14px;border-radius:50%;background:#fef0c0;box-shadow:0 0 8px #fef0c0"></div>
    <div style="font-family:serif;font-size:14px;color:#fff;line-height:1;text-shadow:1px 1px 3px rgba(60,20,10,.3)">Sahara</div>
    <div style="font-family:serif;font-style:italic;font-size:5px;color:#fbeed3;margin-top:2px">desert winds</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: () => `<div class="sun"></div>`
  })
};

const ocean = {
  id: 'ocean', name: 'Ocean', tag: 'Blue · Flowing',
  fonts: gfonts('family=DM+Serif+Display&family=Karla:wght@300;500'),
  css: `
    body { background: linear-gradient(180deg, #013a63 0%, #016aa3 50%, #01acd9 100%); color: #f0f8ff; font-family: 'Karla', sans-serif; }
    body::before { content: ''; position: fixed; inset: 0; background-image: repeating-linear-gradient(135deg, transparent 0 40px, rgba(255,255,255,0.03) 40px 42px); pointer-events: none; }
    .slide { padding: 8vmin 10vmin; justify-content: center; z-index: 1; }
    h1 { font-family: 'DM Serif Display', serif; font-size: clamp(42px, 9vw, 80px); font-weight: 400; line-height: 1.05; margin-bottom: 18px; letter-spacing: -.01em; color: #fff; }
    .subtitle { font-style: italic; font-size: clamp(18px, 2.5vw, 24px); color: #b0e0f7; margin-bottom: 24px; font-weight: 300; }
    .body { font-size: clamp(16px, 2vw, 20px); line-height: 1.7; max-width: 780px; margin-bottom: 14px; font-weight: 300; }
    ul { list-style: none; max-width: 780px; }
    li { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.65; padding: 10px 18px 10px 40px; background: rgba(255,255,255,0.08); backdrop-filter: blur(10px); border-left: 3px solid #80dfff; margin-bottom: 8px; border-radius: 0 8px 8px 0; position: relative; font-weight: 500; }
    li::before { content: '\u2248'; position: absolute; left: 16px; top: 9px; color: #80dfff; font-size: 1.3em; }
    .slide img { max-width: 400px; max-height: 45vh; margin-top: 18px; border-radius: 14px; box-shadow: 0 30px 60px rgba(1,58,99,0.5); filter: saturate(1.2); }
    .wave { position: absolute; bottom: 0; left: 0; right: 0; height: 60px; background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1200 60' preserveAspectRatio='none'%3E%3Cpath d='M0 30 Q 300 0 600 30 T 1200 30 V60 H0' fill='rgba(255,255,255,0.1)'/%3E%3C/svg%3E"); }
    .cover h1 { font-size: clamp(54px, 13vw, 130px); }
    .deck-progress { background: #80dfff; box-shadow: 0 0 10px #80dfff; }
  `,
  preview: () => `<div style="background:linear-gradient(180deg,#013a63,#01acd9);height:100%;padding:8px;position:relative">
    <div style="font-family:serif;font-size:14px;color:#fff;line-height:1">Marina</div>
    <div style="font-family:serif;font-style:italic;font-size:5px;color:#b0e0f7;margin-top:2px">deep blue</div>
    <div style="position:absolute;bottom:4px;left:4px;right:4px;height:6px;background:rgba(255,255,255,.2);border-radius:50% 50% 0 0"></div></div>`,
  render: (ctx) => basicRender(ctx, {
    after: () => `<div class="wave"></div>`
  })
};

// ============ EXPERIMENTAL (1 placed here; rest in part 4) ============

const ascii = {
  id: 'ascii', name: 'ASCII', tag: 'Text art',
  fonts: gfonts('family=IBM+Plex+Mono:wght@400;700'),
  css: `
    body { background: #0a0a0a; color: #00ff88; font-family: 'IBM Plex Mono', monospace; font-size: 14px; line-height: 1.4; }
    .slide { padding: 6vmin; overflow-y: auto; }
    .ascii-box { display: inline-block; margin-bottom: 18px; }
    .ascii-line { white-space: pre; color: #00ff88; font-size: clamp(10px, 1.3vw, 14px); letter-spacing: 0; }
    h1 { font-size: clamp(30px, 5.5vw, 48px); font-weight: 700; line-height: 1.1; margin-bottom: 18px; color: #00ff88; letter-spacing: -.02em; }
    h1::before { content: '[ '; color: #ff6b6b; }
    h1::after { content: ' ]'; color: #ff6b6b; }
    .subtitle { color: #ffd93d; font-size: clamp(15px, 1.9vw, 18px); margin-bottom: 20px; }
    .subtitle::before { content: '# '; color: #6bcf7f; }
    .body { color: #e0e0e0; font-size: clamp(13px, 1.6vw, 16px); line-height: 1.8; margin-bottom: 14px; max-width: 900px; }
    ul { list-style: none; max-width: 900px; background: rgba(0,255,136,0.05); border: 1px dashed #00ff88; padding: 14px 20px; }
    li { font-size: clamp(12px, 1.5vw, 15px); line-height: 1.8; color: #e0e0e0; }
    li::before { content: '+-- '; color: #00ff88; }
    .slide img { max-width: 380px; max-height: 40vh; margin-top: 14px; border: 1px solid #00ff88; filter: brightness(.8) hue-rotate(60deg); }
    .cover h1 { font-size: clamp(34px, 7vw, 60px); }
    .deck-progress { background: #00ff88; box-shadow: 0 0 8px #00ff88; height: 2px; }
  `,
  preview: () => `<div style="background:#0a0a0a;height:100%;padding:4px;font-family:monospace">
    <div style="color:#00ff88;font-size:4px;white-space:pre;line-height:1">+------+
|ASCII |
+------+</div>
    <div style="color:#ff6b6b;font-size:5px;margin-top:3px">[ title ]</div></div>`,
  render: (ctx) => {
    const { slide, index, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    // simple ASCII art banner per slide
    const banner = makeAsciiBanner(index);
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="ascii-box"><pre class="ascii-line">${banner}</pre></div>
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`;
  }
};

function makeAsciiBanner(i) {
  const banners = [
    '+=====================+\n|   >>  DECK  <<    |\n+=====================+',
    '  .-.\n / | \\\n|  |  |\n \\ | /\n  `-`',
    '/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\',
    '[====][====][====]',
    '|*| |*| |*| |*| |*|',
    '<<<<<<<<  >>>>>>>>'
  ];
  return banners[i % banners.length];
}

export const TEMPLATES_EXTRA_3 = [bigType, maximalist, protest, tabloid, quoteCentric, botanical, japaneseMin, desert, ocean, ascii];
