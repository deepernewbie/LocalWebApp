// storage.js - thin wrapper over AndroidFS with localStorage fallback

const hasFS = typeof window !== 'undefined'
           && window.AndroidFS
           && typeof window.AndroidFS.read === 'function';

export const isNative = hasFS;

// ---- text ----

export async function readText(path) {
  if (hasFS) return await AndroidFS.read(path);
  return localStorage.getItem('fs::' + path);
}

export async function writeText(path, text) {
  if (hasFS) return await AndroidFS.write(path, text);
  localStorage.setItem('fs::' + path, text);
  return true;
}

// ---- json ----

export async function readJSON(path, fallback = null) {
  const t = await readText(path);
  if (!t) return fallback;
  try { return JSON.parse(t); } catch { return fallback; }
}

export async function writeJSON(path, data) {
  return await writeText(path, JSON.stringify(data, null, 2));
}

// ---- binary ----
//
// Binary data is stored as base64 *text* with a `B64:` prefix so it round-
// trips reliably through both the Android JS bridge (which only marshals
// strings) and localStorage in the browser fallback. Callers see a
// Uint8Array on read and pass a Uint8Array on write — the encoding is
// internal.

export async function writeBytes(path, u8) {
  const b64 = uint8ToBase64(u8);
  return await writeText(path, 'B64:' + b64);
}

export async function readBytes(path) {
  const v = await readText(path);
  if (!v) return null;
  if (typeof v !== 'string') {
    // Some bridges might (unexpectedly) give us bytes back already.
    // Coerce defensively.
    try { return new Uint8Array(v); } catch { return null; }
  }
  if (!v.startsWith('B64:')) return null;
  return base64ToUint8(v.slice(4));
}

function uint8ToBase64(u8) {
  if (!u8) return '';
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < u8.length; i += chunk) {
    binary += String.fromCharCode.apply(null, u8.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function base64ToUint8(b64) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

// Read raw base64 (no decode/encode round-trip) — used by the inliner
// to skip the Uint8Array → base64 step when the data is already base64.
export async function readBytesAsBase64(path) {
  const v = await readText(path);
  if (!v || typeof v !== 'string') return null;
  if (v.startsWith('B64:')) return v.slice(4);
  return null;
}

// ---- fs ops ----

export async function list(path) {
  if (hasFS) return await AndroidFS.list(path);
  // browser fallback — scan localStorage keys
  const prefix = 'fs::' + path.replace(/\/$/, '') + '/';
  const names = new Set();
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(prefix)) {
      const rest = k.slice(prefix.length);
      names.add(rest.split('/')[0]);
    }
  }
  return Array.from(names);
}

export async function exists(path) {
  if (hasFS) return await AndroidFS.exists(path);
  return localStorage.getItem('fs::' + path) !== null;
}

export async function mkdir(path) {
  if (hasFS) return await AndroidFS.mkdir(path);
  return true;
}

export async function remove(path) {
  if (hasFS) return await AndroidFS.delete(path);
  localStorage.removeItem('fs::' + path);
  return true;
}

// ---- helpers ----

export function slugify(s) {
  return s.toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 50) || 'untitled';
}

export function shortId() {
  return Math.random().toString(36).slice(2, 8);
}
