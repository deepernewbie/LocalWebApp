// app.js - main entry, routing, and view rendering

import * as fs from './storage.js';
import * as projects from './projects.js';
import * as settings from './settings.js';
import { TEMPLATES, getTemplate, renderPresentation } from './templates.js';
import { generatePlan, fillPlanSlot, doResearch, draftSlides, draftOneSlide, fetchImagesForSlides, downloadSelectedImages, shortenSlide } from './pipeline.js';
import { chat, readLog, clearLog } from './llm.js';
import { LANGUAGES } from './languages.js';
import { SLIDE_TRANSITIONS, CONTENT_ANIMATIONS } from './animations.js';
import { toast, vibrate, modal, confirm, icon, escapeHtml } from './ui.js';

const root = document.getElementById('app');
let state = {
  view: 'home',
  projectId: null,
  tab: 'plan' // plan | draft | render
};

// ---- Router ----

function nav(view, opts = {}) {
  state.view = view;
  Object.assign(state, opts);
  render();
  window.scrollTo(0, 0);
}

function render() {
  root.innerHTML = '';
  switch (state.view) {
    case 'home': return renderHome();
    case 'new': return renderNewProject();
    case 'project': return renderProject();
    case 'settings': return renderSettings();
    case 'preview': return renderPreview();
  }
}

// ========================================================================
// HOME
// ========================================================================

async function renderHome() {
  const topbar = document.createElement('div');
  topbar.className = 'topbar';
  topbar.innerHTML = `
    <div class="brand">Deck<em>Forge</em></div>
    <button class="icon-btn" id="btnSettings" aria-label="Settings">${icon('settings')}</button>
  `;
  root.appendChild(topbar);

  const view = document.createElement('div');
  view.className = 'view';
  view.innerHTML = `
    <h1 class="page-title">Your <em>decks</em></h1>
    <p class="page-subtitle">AI-generated presentations. Editable. Yours.</p>
    <div id="projectList"></div>
  `;
  root.appendChild(view);

  const fab = document.createElement('button');
  fab.className = 'fab';
  fab.innerHTML = icon('plus', 26);
  fab.onclick = () => { vibrate(); nav('new'); };
  root.appendChild(fab);

  topbar.querySelector('#btnSettings').onclick = () => nav('settings');

  const list = view.querySelector('#projectList');
  const all = await projects.listProjects();

  if (all.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="big-icon">◇</div>
        <div>No decks yet. Tap + to create one.</div>
      </div>`;
    return;
  }

  for (const p of all) {
    const tpl = getTemplate(p.templateId);
    const card = document.createElement('div');
    card.className = 'card interactive';
    const age = timeAgo(p.updatedAt);
    card.innerHTML = `
      <div class="card-title">${escapeHtml(p.topic)}</div>
      <div class="card-meta">${p.slideCount} slides · ${escapeHtml(tpl.name)} · ${stageLabel(p.stage)} · ${age}</div>
    `;
    card.onclick = () => nav('project', { projectId: p.id, tab: 'plan' });
    list.appendChild(card);
  }
}

function stageLabel(stage) {
  return {
    new: 'New',
    planned: 'Planned',
    researched: 'Researched',
    drafted: 'Draft',
    rendered: 'Rendered'
  }[stage] || stage;
}

function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  if (s < 86400) return `${Math.floor(s/3600)}h ago`;
  if (s < 7 * 86400) return `${Math.floor(s/86400)}d ago`;
  return new Date(ts).toLocaleDateString();
}

// ========================================================================
// NEW PROJECT
// ========================================================================

async function renderNewProject() {
  const cfg = await settings.loadSettings();
  const hasKey = !!cfg.apiKey;

  const topbar = document.createElement('div');
  topbar.className = 'topbar';
  topbar.innerHTML = `
    <button class="back-btn" id="back">${icon('back', 16)} <span>Decks</span></button>
    <div></div>
  `;
  topbar.querySelector('#back').onclick = () => nav('home');
  root.appendChild(topbar);

  const view = document.createElement('div');
  view.className = 'view';
  view.innerHTML = `
    <h1 class="page-title">New <em>deck</em></h1>
    <p class="page-subtitle">Describe it and pick a look.</p>

    ${!hasKey ? `<div class="card" style="border-color:var(--accent-2)"><div style="font-size:13px">⚠️ No API key set. <a href="#" id="gotoSettings" style="color:var(--accent);text-decoration:underline">Add one in Settings</a> before generating.</div></div>` : ''}

    <div class="field">
      <label>Topic</label>
      <textarea id="topic" placeholder="e.g. The History of the Silk Road" rows="2"></textarea>
    </div>

    <div class="field-row">
      <div class="field">
        <label>Slides</label>
        <input type="number" id="count" value="8" min="1" max="30">
      </div>
      <div class="field">
        <label>Tone</label>
        <select id="tone" style="padding:12px 14px;width:100%;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);color:var(--ink)">
          <option value="professional">Professional</option>
          <option value="casual">Casual</option>
          <option value="academic">Academic</option>
          <option value="playful">Playful</option>
          <option value="dramatic">Dramatic</option>
        </select>
      </div>
    </div>

    <div class="field">
      <label>Language</label>
      <select id="language" style="padding:12px 14px;width:100%;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);color:var(--ink)">
        ${LANGUAGES.map(l => `<option value="${l.code}">${l.name}${l.code !== 'en' ? ' — ' + l.nativeName : ''}</option>`).join('')}
      </select>
    </div>

    <div class="field">
      <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-weight:500">
        <input type="checkbox" id="useImages" checked style="width:18px;height:18px;accent-color:var(--accent);cursor:pointer">
        <span>Include images</span>
      </label>
      <div style="font-size:12px;color:var(--ink-mute);margin-top:4px;margin-left:28px">Uncheck for a text-only deck. Skips image search and gives you cleaner type-driven layouts.</div>
    </div>

    <div class="field">
      <label>Presenter name <span style="color:var(--ink-mute)">(optional, shown on intro slide)</span></label>
      <input type="text" id="presenterName" placeholder="e.g. Jane Smith">
    </div>

    <div class="field-row">
      <div class="field">
        <label>Slide transition</label>
        <select id="slideTransition" style="padding:12px 14px;width:100%;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);color:var(--ink)">
          ${SLIDE_TRANSITIONS.map(t => `<option value="${t.id}"${t.id === 'fade' ? ' selected' : ''}>${t.name}</option>`).join('')}
        </select>
      </div>
      <div class="field">
        <label>Audience <span style="color:var(--ink-mute)">(optional)</span></label>
        <input type="text" id="audience" placeholder="e.g. students">
      </div>
    </div>

    <div class="divider"></div>

    <h2 style="font-family:var(--serif);font-size:20px;margin-bottom:4px;font-weight:600;letter-spacing:-.02em">Template</h2>
    <p class="page-subtitle" style="margin-bottom:14px">Pick one — you can change it later.</p>
    <div class="template-grid" id="templates"></div>

    <div style="margin-top:24px">
      <button class="btn btn-primary btn-block" id="createBtn">Create deck</button>
    </div>
  `;
  root.appendChild(view);

  if (!hasKey) {
    view.querySelector('#gotoSettings').onclick = e => { e.preventDefault(); nav('settings'); };
  }

  const tplGrid = view.querySelector('#templates');
  let selectedTpl = TEMPLATES[0].id;
  for (const t of TEMPLATES) {
    const card = document.createElement('button');
    card.className = 'template-card' + (t.id === selectedTpl ? ' active' : '');
    card.innerHTML = `
      <div class="template-preview">${t.preview()}</div>
      <div class="template-name">${t.name}</div>
      <div class="template-tag">${t.tag}</div>
    `;
    card.onclick = () => {
      selectedTpl = t.id;
      vibrate();
      tplGrid.querySelectorAll('.template-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
    };
    tplGrid.appendChild(card);
  }

  view.querySelector('#createBtn').onclick = async () => {
    const topic = view.querySelector('#topic').value.trim();
    const count = parseInt(view.querySelector('#count').value, 10);
    const tone = view.querySelector('#tone').value;
    const language = view.querySelector('#language').value;
    const useImages = view.querySelector('#useImages').checked;
    const presenterName = view.querySelector('#presenterName').value.trim();
    const slideTransition = view.querySelector('#slideTransition').value;
    const audience = view.querySelector('#audience').value.trim();
    if (!topic) { toast('Enter a topic first'); return; }
    if (isNaN(count) || count < 1 || count > 30) { toast('Slide count must be 1–30'); return; }

    const p = await projects.createProject({
      topic, slideCount: count, templateId: selectedTpl, audience, tone, language, useImages, presenterName, slideTransition
    });
    toast('Deck created');
    nav('project', { projectId: p.id, tab: 'plan' });
  };
}

// ========================================================================
// PROJECT VIEW (plan → draft → render)
// ========================================================================

async function renderProject() {
  const project = await projects.getProject(state.projectId);
  if (!project) { toast('Project not found'); nav('home'); return; }
  const tpl = getTemplate(project.templateId);

  const topbar = document.createElement('div');
  topbar.className = 'topbar';
  topbar.innerHTML = `
    <button class="back-btn" id="back">${icon('back', 16)} <span>Decks</span></button>
    <button class="icon-btn" id="del" aria-label="Delete">${icon('trash')}</button>
  `;
  topbar.querySelector('#back').onclick = () => nav('home');
  topbar.querySelector('#del').onclick = async () => {
    const ok = await confirm('Delete this deck? This cannot be undone.', 'Delete deck');
    if (ok) { await projects.deleteProject(project.id); toast('Deleted'); nav('home'); }
  };
  root.appendChild(topbar);

  const view = document.createElement('div');
  view.className = 'view';
  view.innerHTML = `
    <h1 class="page-title" style="font-size:24px">${escapeHtml(project.topic)}</h1>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">
      <span class="chip">${project.slideCount} slides</span>
      <span class="chip">${escapeHtml(tpl.name)}</span>
      <span class="chip">${escapeHtml(project.tone)}</span>
      ${project.language && project.language !== 'en' ? `<span class="chip">${escapeHtml(LANGUAGES.find(l => l.code === project.language)?.nativeName || project.language)}</span>` : ''}
      ${project.useImages === false ? `<span class="chip">text only</span>` : ''}
    </div>

    <div class="tabs">
      <button data-tab="plan" class="${state.tab==='plan'?'active':''}">1 · Plan</button>
      <button data-tab="draft" class="${state.tab==='draft'?'active':''}">2 · Draft</button>
      <button data-tab="render" class="${state.tab==='render'?'active':''}">3 · Render</button>
    </div>

    <div id="tabBody"></div>
  `;
  root.appendChild(view);

  view.querySelectorAll('.tabs button').forEach(b => {
    b.onclick = () => { state.tab = b.dataset.tab; render(); };
  });

  const body = view.querySelector('#tabBody');
  if (state.tab === 'plan') renderPlanTab(body, project);
  else if (state.tab === 'draft') renderDraftTab(body, project);
  else renderRenderTab(body, project);
}

// ---- PLAN TAB ----

function renderPlanTab(container, project) {
  container.innerHTML = '';
  if (!project.plan) {
    const box = document.createElement('div');
    box.innerHTML = `
      <div class="card">
        <div style="font-size:14px;margin-bottom:12px">Start by generating a slide-by-slide plan. The LLM will outline titles and angles. You can edit before moving on.</div>
        <button class="btn btn-primary btn-block" id="genPlan">✦ Generate plan</button>
      </div>
      <div id="log"></div>
    `;
    container.appendChild(box);
    box.querySelector('#genPlan').onclick = async () => {
      const log = box.querySelector('#log');
      log.innerHTML = '<div class="progress-log" id="pl"></div>';
      const plEl = log.querySelector('#pl');
      const onLog = (kind, msg) => addLogLine(plEl, kind, msg);
      try {
        box.querySelector('#genPlan').disabled = true;
        const plan = await generatePlan(project, onLog);
        project.plan = plan;
        project.stage = 'planned';
        await projects.saveProject(project);
        toast('Plan ready');
        render();
      } catch (e) {
        onLog('err', e.message);
        box.querySelector('#genPlan').disabled = false;
      }
    };
    return;
  }

  // Plan exists — show editable list
  const placeholderIndices = project.plan
    .map((p, i) => (p.placeholder || (!p.title?.trim() && !p.angle?.trim())) ? i : -1)
    .filter(i => i >= 0);
  const hasPlaceholders = placeholderIndices.length > 0;

  if (hasPlaceholders) {
    const warn = document.createElement('div');
    warn.className = 'card';
    warn.style.cssText = 'background:rgba(244,184,96,0.08);border-color:var(--accent);margin-bottom:12px';
    warn.innerHTML = `
      <div style="font-size:13px;color:var(--ink);line-height:1.5">
        <strong style="color:var(--accent)">${placeholderIndices.length} slide${placeholderIndices.length > 1 ? 's are' : ' is'} empty.</strong>
        The LLM didn't produce content for slide${placeholderIndices.length > 1 ? 's' : ''} ${placeholderIndices.map(i => i + 1).join(', ')}.
        Drafting won't produce useful results until these are filled.
      </div>
      <div class="btn-row" style="margin-top:10px">
        <button class="btn btn-primary" id="fillAll" style="flex:1">\u2726 Auto-fill with AI</button>
      </div>
    `;
    warn.querySelector('#fillAll').onclick = async () => {
      const btn = warn.querySelector('#fillAll');
      btn.disabled = true;
      for (const idx of placeholderIndices) {
        btn.textContent = `Filling slide ${idx + 1}\u2026`;
        try {
          const filled = await fillPlanSlot(project, project.plan, idx);
          const p = project.plan[idx];
          p.title = filled.title;
          p.angle = filled.angle;
          p.imageQuery = filled.imageQuery;
          p.placeholder = false;
        } catch (e) {
          toast(`Slide ${idx + 1}: ${e.message}`);
        }
      }
      await projects.saveProject(project);
      render();
    };
    container.appendChild(warn);
  }

  const list = document.createElement('div');
  for (let i = 0; i < project.plan.length; i++) {
    const p = project.plan[i];
    const isPlaceholder = p.placeholder || (!p.title?.trim() && !p.angle?.trim());
    const item = document.createElement('div');
    item.className = 'plan-item' + (isPlaceholder ? ' placeholder' : '');
    const displayTitle = p.title?.trim() || `<span style="color:var(--accent);font-style:italic">Empty \u2014 needs content</span>`;
    const displayAngle = p.angle?.trim() || `<span style="color:var(--ink-mute);font-style:italic">No angle yet</span>`;
    item.innerHTML = `
      <div class="n">${String(i+1).padStart(2,'0')}</div>
      <div class="content">
        <div class="t">${p.title?.trim() ? escapeHtml(p.title) : displayTitle} <span style="color:var(--ink-mute);font-weight:400;font-size:11px">\u00B7 ${escapeHtml(p.role)}</span></div>
        <div class="d">${p.angle?.trim() ? escapeHtml(p.angle) : displayAngle}</div>
        ${p.imageQuery ? `<div class="d" style="margin-top:4px;color:var(--ink-mute);font-family:var(--mono);font-size:11px">\u{1F5BC} ${escapeHtml(p.imageQuery)}</div>` : ''}
        ${isPlaceholder ? `<button class="btn btn-ghost fill-one" data-i="${i}" style="margin-top:8px;padding:4px 10px;font-size:12px">\u2726 Fill with AI</button>` : ''}
      </div>
      <button class="rm" data-i="${i}">edit</button>
    `;
    if (isPlaceholder) {
      item.querySelector('.fill-one').onclick = async (e) => {
        e.stopPropagation();
        const btn = item.querySelector('.fill-one');
        btn.disabled = true;
        btn.textContent = 'Filling\u2026';
        try {
          const filled = await fillPlanSlot(project, project.plan, i);
          p.title = filled.title;
          p.angle = filled.angle;
          p.imageQuery = filled.imageQuery;
          p.placeholder = false;
          await projects.saveProject(project);
          render();
        } catch (err) {
          toast('Fill failed: ' + err.message);
          btn.disabled = false;
          btn.textContent = '\u2726 Fill with AI';
        }
      };
    }
    item.querySelector('.rm').onclick = async () => {
      const res = await modal({
        title: `Edit slide ${i+1}`,
        content: `
          <div class="field"><label>Title</label><input id="eT" value="${escapeHtml(p.title)}"></div>
          <div class="field"><label>Angle</label><textarea id="eA" rows="3">${escapeHtml(p.angle)}</textarea></div>
          <div class="field"><label>Image search query</label><input id="eQ" value="${escapeHtml(p.imageQuery || '')}"></div>
        `,
        actions: [
          { label: 'Delete', kind: 'danger', onClick: async () => {
            project.plan.splice(i, 1);
            await projects.saveProject(project);
            return 'del';
          }},
          { label: 'Save', kind: 'primary', onClick: async (box) => {
            p.title = box.querySelector('#eT').value.trim() || p.title;
            p.angle = box.querySelector('#eA').value.trim();
            p.imageQuery = box.querySelector('#eQ').value.trim();
            // If both title and angle are now non-empty, clear placeholder flag
            if (p.title.trim() && p.angle.trim()) p.placeholder = false;
            await projects.saveProject(project);
            return 'saved';
          }}
        ]
      });
      if (res) render();
    };
    list.appendChild(item);
  }
  container.appendChild(list);

  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-ghost btn-block';
  addBtn.style.marginBottom = '14px';
  addBtn.innerHTML = '+ Add slide';
  addBtn.onclick = async () => {
    const res = await modal({
      title: 'New slide',
      content: `
        <div class="field"><label>Title</label><input id="nT" placeholder="Short title"></div>
        <div class="field"><label>Angle</label><textarea id="nA" rows="3" placeholder="What this slide covers"></textarea></div>
        <div class="field"><label>Image query (optional)</label><input id="nQ" placeholder="e.g. Ancient Silk Road map"></div>
      `,
      actions: [
        { label: 'Cancel', kind: 'ghost', value: null },
        { label: 'Add', kind: 'primary', onClick: async (box) => {
          const t = box.querySelector('#nT').value.trim();
          if (!t) return false;
          project.plan.push({
            role: 'content',
            title: t,
            angle: box.querySelector('#nA').value.trim(),
            imageQuery: box.querySelector('#nQ').value.trim()
          });
          await projects.saveProject(project);
          return 'added';
        }}
      ]
    });
    if (res) render();
  };
  container.appendChild(addBtn);

  const actions = document.createElement('div');
  actions.className = 'btn-row';
  actions.style.marginTop = '12px';
  actions.innerHTML = `
    <button class="btn btn-ghost" id="regen">Regenerate</button>
    <button class="btn btn-primary" id="next">Next: Draft →</button>
  `;
  actions.querySelector('#regen').onclick = async () => {
    const hasDraft = Array.isArray(project.slides) && project.slides.length > 0;
    const msg = hasDraft
      ? 'Replace current plan with a new one? This will also discard the existing draft and rendered HTML — they need to match the plan.'
      : 'Replace current plan with a new one?';
    if (!(await confirm(msg))) return;
    project.plan = null;
    if (hasDraft) {
      project.slides = null;
      project.research = null;
      project.renderedAt = null;
    }
    project.stage = 'new';
    await projects.saveProject(project);
    render();
  };
  actions.querySelector('#next').onclick = async () => {
    if (hasPlaceholders) {
      const ok = await confirm(`${placeholderIndices.length} slide${placeholderIndices.length > 1 ? 's are' : ' is'} still empty (slides ${placeholderIndices.map(i => i + 1).join(', ')}). Proceed anyway? The drafter won't be able to produce useful content for them.`);
      if (!ok) return;
    }
    state.tab = 'draft';
    render();
  };
  container.appendChild(actions);
}

// ---- DRAFT TAB ----

function renderDraftTab(container, project) {
  container.innerHTML = '';

  if (!project.plan) {
    container.innerHTML = `<div class="card"><div style="font-size:14px">Create a plan first (tab 1).</div></div>`;
    return;
  }

  // Shared draft-run routine (used by both first-run and regenerate).
  // Pass {preserveImages: true} to keep existing local image files as fallback.
  async function runDraftPipeline(logEl, { preserveImages = false } = {}) {
    logEl.innerHTML = '<div class="progress-log" id="pl"></div>';
    const plEl = logEl.querySelector('#pl');
    const onLog = (kind, msg) => addLogLine(plEl, kind, msg);
    const oldSlides = preserveImages && Array.isArray(project.slides) ? project.slides : null;
    try {
      const research = await doResearch(project, onLog);
      project.research = research;
      project.stage = 'researched';
      await projects.saveProject(project);

      const slides = await draftSlides(project, project.plan, research, onLog);
      project.slides = slides;
      project.stage = 'drafted';
      await projects.saveProject(project);

      await fetchImagesForSlides(project, slides, onLog);
      // If preserving, carry over any local images from matching titles.
      if (oldSlides) {
        for (const s of slides) {
          const match = oldSlides.find(o => o && o.title === s.title && o.localImage);
          if (match && !s.localImage) s.localImage = match.localImage;
        }
      }
      // Regenerating a draft invalidates the previously-rendered HTML.
      project.renderedAt = null;
      await projects.saveProject(project);
      toast('Draft ready');
      render();
    } catch (e) {
      onLog('err', e.message);
      return false;
    }
    return true;
  }

  if (!project.slides) {
    const box = document.createElement('div');
    box.innerHTML = `
      <div class="card">
        <div style="font-size:14px;margin-bottom:12px">This step fetches research from multiple sources, drafts each slide's content, then searches for images. You'll review and edit before rendering.</div>
        <button class="btn btn-primary btn-block" id="run">\u2726 Run full draft</button>
      </div>
      <div id="log"></div>
    `;
    container.appendChild(box);
    box.querySelector('#run').onclick = async () => {
      box.querySelector('#run').disabled = true;
      const ok = await runDraftPipeline(box.querySelector('#log'));
      if (!ok) box.querySelector('#run').disabled = false;
    };
    return;
  }

  // Slides exist — show editable slide list
  const list = document.createElement('div');
  for (let i = 0; i < project.slides.length; i++) {
    const s = project.slides[i];
    const item = document.createElement('div');
    item.className = 'slide-item';

    const hasContent = (s.body && s.body.trim()) || (s.bullets && s.bullets.length > 0) || (s.subtitle && s.subtitle.trim());
    const isEmpty = !hasContent && s.role !== 'cover';
    const emptyBadge = isEmpty ? `<span style="background:#d93b3b;color:#fff;font-size:10px;padding:2px 6px;border-radius:4px;margin-left:6px;font-weight:700;letter-spacing:.05em">EMPTY</span>` : '';

    const thumbs = (s.imageCandidates || []).slice(0, 4);
    const imgsHtml = thumbs.map((c, k) => {
      const isSel = s.imageUrl === c.url;
      return `<img src="${c.url}" loading="lazy" data-k="${k}" class="thumb${isSel ? ' sel' : ''}" title="Tap to select">`;
    }).join('');

    item.innerHTML = `
      <div class="slide-num"><span>SLIDE ${String(i+1).padStart(2,'0')} · ${escapeHtml(s.role)}${emptyBadge}</span></div>
      <h4>${escapeHtml(s.title)}</h4>
      ${s.subtitle ? `<div style="color:var(--accent);font-size:13px;font-style:italic;margin-bottom:6px">${escapeHtml(s.subtitle)}</div>` : ''}
      ${s.body ? `<div class="body-text">${escapeHtml(s.body)}</div>` : ''}
      ${s.bullets && s.bullets.length ? `<ul style="margin-top:8px;padding-left:18px;font-size:13px;color:var(--ink-soft);line-height:1.6">${s.bullets.map(b => `<li>${escapeHtml(b)}</li>`).join('')}</ul>` : ''}
      ${s.speakerNotes ? `<details class="notes-detail" style="margin-top:10px"><summary style="cursor:pointer;color:var(--accent);font-size:12px;user-select:none">\u{1F4DD} Speaker notes</summary><div style="font-size:12px;color:var(--ink-soft);line-height:1.55;margin-top:6px;padding:8px 10px;background:var(--bg-soft);border-radius:6px;white-space:pre-wrap">${escapeHtml(s.speakerNotes)}</div></details>` : `<div style="font-size:11px;color:var(--ink-mute);margin-top:8px;font-style:italic">No speaker notes \u00B7 <a href="#" class="gen-notes" data-i="${i}" style="color:var(--accent)">Generate</a></div>`}
      ${imgsHtml ? `<div class="img-thumb" style="margin-top:10px">${imgsHtml}</div>` : ''}
      <div class="slide-actions">
        <button data-a="edit">Edit</button>
        <button data-a="regen">\u21BB Regen</button>
        <button data-a="shorten" title="Shorten text — press repeatedly for tighter copy">\u2702 Shorten${s.shortenLevel ? ' (' + s.shortenLevel + ')' : ''}</button>
        ${project.useImages !== false ? `<button data-a="img">${thumbs.length > 0 ? 'More images' : 'Find image'}</button>` : ''}
        <button data-a="insert">+ Insert after</button>
        <button data-a="del" class="del">Delete</button>
      </div>
    `;
    // "Generate notes" inline link for slides without notes
    const genLink = item.querySelector('.gen-notes');
    if (genLink) {
      genLink.onclick = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await generateNotesForSlide(project, i);
      };
    }
    // Direct thumbnail tap → select that image for the slide
    item.querySelectorAll('.thumb').forEach(t => {
      t.onclick = async (e) => {
        e.stopPropagation();
        const k = parseInt(t.dataset.k, 10);
        const picked = (s.imageCandidates || [])[k];
        if (!picked) return;
        if (s.imageUrl === picked.url) return; // already selected, no-op
        s.imageUrl = picked.url;
        s.localImage = null; // force re-download on next render
        project.renderedAt = null; // rendered HTML is stale now
        await projects.saveProject(project);
        render();
      };
    });
    item.querySelectorAll('[data-a]').forEach(b => {
      b.onclick = () => handleSlideAction(project, i, b.dataset.a);
    });
    list.appendChild(item);
  }
  container.appendChild(list);

  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-ghost btn-block';
  addBtn.style.marginBottom = '14px';
  addBtn.innerHTML = '+ Add slide at end';
  addBtn.onclick = () => handleSlideAction(project, project.slides.length - 1, 'insert');
  container.appendChild(addBtn);

  // Detect plan/draft mismatch so the user can see when regen is needed.
  const planTitles = (project.plan || []).map(p => p.title).join('|');
  const draftTitles = project.slides.map(s => s.title).join('|');
  const planCount = (project.plan || []).length;
  const draftCount = project.slides.length;
  const mismatch = planCount !== draftCount;

  const missingNotes = project.slides.filter(s => !s.speakerNotes || !s.speakerNotes.trim()).length;

  // The draft action bar has both secondary actions (toggle images, refetch,
  // regen, generate notes) and the primary "Next" action. With 4-5 buttons
  // sitting in a single horizontal row they overflow on phone widths and
  // the user has to side-scroll to find the primary action — bad UX.
  //
  // Layout: secondary actions on a wrapping row at the top, primary "Next"
  // button on its own full-width row below. The Next button stays
  // immediately visible and tappable regardless of screen size.
  const actions = document.createElement('div');
  actions.style.marginTop = '6px';
  actions.innerHTML = `
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px">
      <button class="btn btn-ghost" id="toggleImages" style="flex:1 1 auto;min-width:max-content">${project.useImages === false ? '\u{1F5BC} Enable images' : '\u{1F4DD} Text-only'}</button>
      ${project.useImages === false ? '' : '<button class="btn btn-ghost" id="refetch" style="flex:1 1 auto;min-width:max-content">Refetch images</button>'}
      ${missingNotes > 0 ? `<button class="btn btn-ghost" id="gen-all-notes" style="flex:1 1 auto;min-width:max-content">\u{1F4DD} Notes (${missingNotes})</button>` : ''}
      <button class="btn btn-ghost" id="regen-draft" style="flex:1 1 auto;min-width:max-content">\u21BB Regenerate draft</button>
    </div>
    <button class="btn btn-primary" id="next" style="width:100%">Next: Render \u2192</button>
  `;
  if (mismatch) {
    const warn = document.createElement('div');
    warn.className = 'card';
    warn.style.cssText = 'background:rgba(244,184,96,0.08);border-color:var(--accent);margin-bottom:10px';
    warn.innerHTML = `<div style="font-size:13px;color:var(--ink);line-height:1.5">
      <strong style="color:var(--accent)">Plan and draft are out of sync.</strong><br>
      Plan has ${planCount} slides, draft has ${draftCount}. Tap <em>Regenerate draft</em> to rebuild from the current plan.
    </div>`;
    container.insertBefore(warn, list);
  }
  actions.querySelector('#toggleImages').onclick = async () => {
    const turningOff = project.useImages !== false;
    const msg = turningOff
      ? 'Switch this deck to text-only? Existing images will be cleared from all slides.'
      : 'Re-enable images for this deck? You\'ll need to refetch images afterwards.';
    if (!(await confirm(msg))) return;
    project.useImages = !turningOff;
    if (turningOff) {
      // Clear image data so the new render reflects the change
      for (const s of project.slides) {
        s.imageQuery = '';
        s.imageCandidates = [];
        s.imageUrl = null;
        s.localImage = null;
        s.imageCaption = '';
      }
    }
    project.renderedAt = null;
    await projects.saveProject(project);
    render();
  };
  const refetchBtn = actions.querySelector('#refetch');
  if (refetchBtn) {
    refetchBtn.onclick = async () => {
      const log = document.createElement('div');
      log.innerHTML = '<div class="progress-log" id="pl"></div>';
      container.appendChild(log);
      const plEl = log.querySelector('#pl');
      await fetchImagesForSlides(project, project.slides, (k, m) => addLogLine(plEl, k, m));
      await projects.saveProject(project);
      render();
    };
  }
  actions.querySelector('#regen-draft').onclick = async () => {
    const msg = 'Regenerate the entire draft from the current plan? Your per-slide text edits will be lost, but matching images will be carried over where possible.';
    if (!(await confirm(msg))) return;
    // Wipe slides + rendered state and run the pipeline again.
    const logBox = document.createElement('div');
    container.appendChild(logBox);
    project.slides = null;
    project.research = null;
    project.renderedAt = null;
    project.stage = 'planned';
    await projects.saveProject(project);
    await runDraftPipeline(logBox, { preserveImages: false });
  };
  const genAllBtn = actions.querySelector('#gen-all-notes');
  if (genAllBtn) {
    genAllBtn.onclick = async () => {
      genAllBtn.disabled = true;
      const orig = genAllBtn.textContent;
      const { added, failed } = await generateAllNotes(project, (done, total) => {
        genAllBtn.textContent = `Generating ${done}/${total}\u2026`;
      });
      toast(`Added notes to ${added} slide${added === 1 ? '' : 's'}${failed ? ` (${failed} failed)` : ''}`);
      render();
    };
  }
  actions.querySelector('#next').onclick = () => { state.tab = 'render'; render(); };
  container.appendChild(actions);
}

// Generate speaker notes for a single slide using the LLM.
async function generateNotesForSlide(project, i) {
  const s = project.slides[i];
  if (!s) return;
  toast('Generating notes for slide ' + (i + 1) + '\u2026');
  try {
    const { generateSpeakerNotes } = await import('./pipeline.js');
    const notes = await generateSpeakerNotes(project, s, i, project.slides.length);
    s.speakerNotes = notes;
    project.renderedAt = null;
    await projects.saveProject(project);
    toast('Notes added');
    render();
  } catch (e) {
    toast('Note generation failed: ' + e.message);
  }
}

async function generateAllNotes(project, onProgress) {
  const { generateSpeakerNotes } = await import('./pipeline.js');
  let added = 0, failed = 0;
  for (let i = 0; i < project.slides.length; i++) {
    const s = project.slides[i];
    if (s.speakerNotes && s.speakerNotes.trim()) continue;
    onProgress && onProgress(i + 1, project.slides.length);
    try {
      s.speakerNotes = await generateSpeakerNotes(project, s, i, project.slides.length);
      added++;
    } catch {
      failed++;
    }
  }
  project.renderedAt = null;
  await projects.saveProject(project);
  return { added, failed };
}

async function handleSlideAction(project, i, action) {
  const s = project.slides[i];

  // Per-slide regenerate: redraft content (body / bullets / subtitle) from
  // the plan + research, keeping image + title intact by default.
  if (action === 'regen') {
    const planItem = (project.plan || [])[i] || {
      role: s.role || 'content',
      title: s.title,
      angle: '',
      imageQuery: s.imageQuery || ''
    };
    const ok = await confirm(`Regenerate slide ${i+1} ("${s.title}")?\n\nThis re-asks the LLM for fresh content using the current plan and research. Your text edits on this slide will be replaced.`);
    if (!ok) return;

    // Inline progress indicator on the slide card
    toast('Regenerating slide ' + (i + 1) + '...');
    try {
      const research = project.research || [];
      let effectivePlanItem = planItem;

      // If the plan item is empty/placeholder, fill it first. Otherwise the
      // drafter has nothing useful to work with and will return generic junk.
      const isEmpty = planItem.placeholder ||
                      (!planItem.title?.trim() && !planItem.angle?.trim()) ||
                      (planItem.angle?.trim() === 'Additional detail');
      if (isEmpty) {
        toast('Plan slot empty — filling first\u2026');
        try {
          const filled = await fillPlanSlot(project, project.plan || [], i);
          effectivePlanItem = { ...planItem, ...filled };
          // Persist the filled plan back
          if (project.plan && project.plan[i]) {
            project.plan[i] = { ...project.plan[i], ...filled };
          }
        } catch (e) {
          toast('Could not fill empty plan slot: ' + e.message);
          return;
        }
      }

      // Try regen up to 2 times. The second pass includes the first failure in
      // the prompt so the model can correct course.
      let fresh = null;
      let lastErr = null;
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          fresh = await draftOneSlide(project, effectivePlanItem, research, i, project.slides.length);
          break;
        } catch (e) {
          lastErr = e;
          if (attempt === 1) {
            toast('Retrying slide ' + (i + 1) + '\u2026');
          }
        }
      }
      if (!fresh) {
        throw lastErr || new Error('Could not produce slide content');
      }

      // Preserve role and image state; replace text fields
      s.title = fresh.title || effectivePlanItem.title || s.title;
      s.subtitle = fresh.subtitle || '';
      s.body = fresh.body || '';
      s.bullets = fresh.bullets || [];
      s.imageCaption = fresh.imageCaption || s.imageCaption || '';
      s.speakerNotes = fresh.speakerNotes || '';
      // Regenerated content — start fresh shorten counter
      s.shortenLevel = 0;
      // If the fresh imageQuery differs meaningfully, update and clear local image
      if (fresh.imageQuery && fresh.imageQuery !== s.imageQuery) {
        s.imageQuery = fresh.imageQuery;
        // Re-search images for the new query
        const { searchImages } = await import('./research.js');
        try {
          s.imageCandidates = await searchImages(fresh.imageQuery, 4);
          if (s.imageCandidates[0]) {
            s.imageUrl = s.imageCandidates[0].url;
            s.localImage = null;
          }
        } catch {}
      }
      // Invalidate the rendered HTML — it's stale now
      project.renderedAt = null;
      await projects.saveProject(project);
      toast('Slide ' + (i + 1) + ' updated');
      render();
    } catch (e) {
      toast('Regen failed: ' + e.message + ' \u2014 see Settings \u2192 LLM Log for the raw response.');
    }
    return;
  }

  if (action === 'shorten') {
    // Each press increments shortenLevel and asks the LLM for a tighter
    // version. Capped at 5 — beyond that, content is reduced to almost
    // nothing and the LLM either refuses or produces unhelpful copy. The
    // button text shows the current level so the user knows how many times
    // they've pressed it.
    const currentLevel = s.shortenLevel || 0;
    if (currentLevel >= 5) {
      toast('Already at maximum compression. Edit manually or regenerate to start over.');
      return;
    }
    const nextLevel = currentLevel + 1;
    toast(`Shortening slide ${i + 1} (level ${nextLevel}/5)\u2026`);

    try {
      const tighter = await shortenSlide(project, s, nextLevel);
      // Apply changes; preserve image fields
      s.title = tighter.title || s.title;
      s.subtitle = tighter.subtitle;
      s.body = tighter.body;
      s.bullets = tighter.bullets.length ? tighter.bullets : s.bullets;
      s.imageCaption = tighter.imageCaption;
      // Only overwrite speaker notes if the model produced something — empty
      // notes after shortening would lose useful context.
      if (tighter.speakerNotes) s.speakerNotes = tighter.speakerNotes;
      s.shortenLevel = nextLevel;
      project.renderedAt = null; // text changed — need to re-render
      await projects.saveProject(project);
      toast(`Slide ${i + 1} shortened (level ${nextLevel}/5).`);
      render();
    } catch (err) {
      toast('Shorten failed: ' + err.message);
    }
    return;
  }

  if (action === 'del') {
    const ok = await confirm(`Delete slide ${i+1}?`);
    if (!ok) return;
    project.slides.splice(i, 1);
    await projects.saveProject(project);
    render();
    return;
  }
  if (action === 'insert') {
    const res = await modal({
      title: 'Insert new slide',
      content: `
        <div class="field"><label>Title</label><input id="nT" placeholder="Slide title"></div>
        <div class="field"><label>Subtitle (optional)</label><input id="nS"></div>
        <div class="field"><label>Body (optional)</label><textarea id="nB" rows="2"></textarea></div>
        <div class="field"><label>Bullets (one per line)</label><textarea id="nBu" rows="4"></textarea></div>
        <div class="field"><label>Image query (optional)</label><input id="nQ"></div>
      `,
      actions: [
        { label: 'Cancel', kind: 'ghost', value: null },
        { label: 'Insert', kind: 'primary', onClick: async (box) => {
          const title = box.querySelector('#nT').value.trim();
          if (!title) return false;
          const newSlide = {
            id: 'slide-' + Date.now(),
            role: 'content',
            title,
            subtitle: box.querySelector('#nS').value.trim(),
            body: box.querySelector('#nB').value.trim(),
            bullets: box.querySelector('#nBu').value.split('\n').map(l => l.trim()).filter(Boolean),
            imageCaption: '',
            imageQuery: box.querySelector('#nQ').value.trim(),
            imageUrl: null,
            localImage: null,
            imageCandidates: []
          };
          project.slides.splice(i + 1, 0, newSlide);
          // fetch image for the new slide if query given
          if (newSlide.imageQuery) {
            const { searchImages } = await import('./research.js');
            newSlide.imageCandidates = await searchImages(newSlide.imageQuery, 4);
            if (newSlide.imageCandidates[0]) newSlide.imageUrl = newSlide.imageCandidates[0].url;
          }
          await projects.saveProject(project);
          return 'inserted';
        }}
      ]
    });
    if (res) render();
    return;
  }
  if (action === 'edit') {
    const currentAnim = s.contentAnimation || '';
    const res = await modal({
      title: `Edit slide ${i+1}`,
      content: `
        <div class="field"><label>Title</label><input id="eT" value="${escapeHtml(s.title)}"></div>
        <div class="field"><label>Subtitle</label><input id="eS" value="${escapeHtml(s.subtitle)}"></div>
        <div class="field"><label>Body</label><textarea id="eB" rows="3">${escapeHtml(s.body)}</textarea></div>
        <div class="field"><label>Bullets (one per line)</label><textarea id="eBu" rows="5">${escapeHtml((s.bullets||[]).join('\n'))}</textarea></div>
        ${project.useImages !== false ? `<div class="field"><label>Image search query</label><input id="eQ" value="${escapeHtml(s.imageQuery || '')}"></div>` : ''}
        <div class="field">
          <label>Speaker notes <span style="color:var(--ink-mute);font-weight:400;font-size:11px">(shown in Presenter mode)</span></label>
          <textarea id="eN" rows="4" placeholder="Talking points, context, a memorable detail\u2026">${escapeHtml(s.speakerNotes || '')}</textarea>
        </div>
        <div class="field">
          <label>Content animation <span style="color:var(--ink-mute);font-weight:400;font-size:11px">(overrides deck default)</span></label>
          <select id="eAnim" style="padding:10px 12px;width:100%;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);color:var(--ink)">
            <option value=""${currentAnim === '' ? ' selected' : ''}>(use deck default)</option>
            ${CONTENT_ANIMATIONS.map(a => `<option value="${a.id}"${currentAnim === a.id ? ' selected' : ''}>${a.name}</option>`).join('')}
          </select>
        </div>
      `,
      actions: [
        { label: 'Cancel', kind: 'ghost', value: null },
        { label: 'Save', kind: 'primary', onClick: async (box) => {
          s.title = box.querySelector('#eT').value.trim() || s.title;
          s.subtitle = box.querySelector('#eS').value.trim();
          s.body = box.querySelector('#eB').value.trim();
          s.bullets = box.querySelector('#eBu').value.split('\n').map(l => l.trim()).filter(Boolean);
          s.speakerNotes = box.querySelector('#eN').value.trim();
          const animVal = box.querySelector('#eAnim').value;
          // Empty string means "use deck default" — store as undefined so
          // the renderer falls back to project.contentAnimation.
          if (animVal) s.contentAnimation = animVal;
          else delete s.contentAnimation;
          const queryEl = box.querySelector('#eQ');
          if (queryEl) {
            const newQuery = queryEl.value.trim();
            if (newQuery && newQuery !== s.imageQuery) {
              s.imageQuery = newQuery;
              const { searchImages } = await import('./research.js');
              s.imageCandidates = await searchImages(newQuery, 4);
              if (s.imageCandidates[0]) s.imageUrl = s.imageCandidates[0].url;
            }
          }
          project.renderedAt = null;
          await projects.saveProject(project);
          return 'saved';
        }}
      ]
    });
    if (res) render();
    return;
  }
  if (action === 'img') {
    // If no candidates yet, fetch them now using the current query
    if (!s.imageCandidates || s.imageCandidates.length === 0) {
      if (!s.imageQuery) {
        toast('No image query set. Edit the slide to add one.');
        return;
      }
      toast('Searching images\u2026');
      try {
        const { searchImages } = await import('./research.js');
        s.imageCandidates = await searchImages(s.imageQuery, 6);
        await projects.saveProject(project);
      } catch (e) {
        toast('Image search failed: ' + e.message);
        return;
      }
      if (s.imageCandidates.length === 0) {
        toast('No images found. Try a different query.');
        return;
      }
    }
    // Open the picker. The "Find new set" action stays inside the modal —
    // the onClick returns null to signal "I handled it, don't close" so
    // the modal helper leaves the modal mounted while we swap in fresh
    // candidates. The user can keep tapping Find new set until they find
    // an image they like.
    const res = await modal({
      title: 'Pick an image',
      subtitle: `For "${s.title}"  \u00B7  query: ${s.imageQuery || '(none)'}`,
      content: buildImagePicker(s),
      actions: [
        { label: 'Find new set', kind: 'ghost', onClick: async (box) => {
          // Fetch a fresh page of candidates. We append a random nonce to
          // the query so the underlying search actually returns different
          // results — many image search APIs cache identical queries.
          try {
            const { searchImages } = await import('./research.js');
            const seed = Math.floor(Math.random() * 1000);
            let fresh = await searchImages(`${s.imageQuery} ${seed}`, 6);
            if (!fresh || fresh.length === 0) {
              fresh = await searchImages(s.imageQuery, 6);
            }
            if (!fresh || fresh.length === 0) {
              toast('No new images found');
              return null;
            }
            // Filter out URLs we already had so the user sees genuinely new
            // options on each tap (not the same first 4 again).
            const existingUrls = new Set((s.imageCandidates || []).map(c => c.url));
            const newOnes = fresh.filter(c => !existingUrls.has(c.url));
            s.imageCandidates = newOnes.length > 0 ? newOnes : fresh;
            await projects.saveProject(project);
            toast(`Found ${s.imageCandidates.length} fresh images`);
          } catch (e) {
            toast('Search failed: ' + e.message);
            return null;
          }
          // Re-render the picker contents in place. We find the existing
          // grid and replace its parent's contents with a fresh picker.
          const oldGrid = box.querySelector('.image-picker-grid');
          if (oldGrid) {
            const wrapper = oldGrid.parentElement;
            wrapper.innerHTML = '';
            wrapper.appendChild(buildImagePicker(s));
          }
          return null; // keep modal open
        }},
        { label: 'None', kind: 'ghost', onClick: () => { s.imageUrl = null; s.localImage = null; return 'none'; }},
        { label: 'Save', kind: 'primary', onClick: async (box) => {
          const sel = box.querySelector('.slot.selected');
          if (sel) {
            if (s.imageUrl !== sel.dataset.url) {
              s.imageUrl = sel.dataset.url;
              s.localImage = null; // force re-download on next render
            }
          }
          await projects.saveProject(project);
          return 'saved';
        }}
      ]
    });
    if (res) { await projects.saveProject(project); render(); }
    return;
  }
}

function buildImagePicker(slide) {
  const div = document.createElement('div');
  const candidates = slide.imageCandidates || [];
  if (candidates.length === 0) {
    div.innerHTML = '<div style="color:var(--ink-mute);font-size:13px">No image results. Try editing the search query.</div>';
    return div;
  }
  const grid = document.createElement('div');
  grid.className = 'img-grid image-picker-grid';
  candidates.forEach((c, k) => {
    const slot = document.createElement('div');
    slot.className = 'slot' + (slide.imageUrl === c.url ? ' selected' : '');
    slot.dataset.url = c.url;
    slot.innerHTML = `<img src="${c.url}" loading="lazy">`;
    slot.onclick = () => {
      grid.querySelectorAll('.slot').forEach(s => s.classList.remove('selected'));
      slot.classList.add('selected');
    };
    grid.appendChild(slot);
  });
  div.appendChild(grid);
  return div;
}

// ---- RENDER TAB ----

function renderRenderTab(container, project) {
  container.innerHTML = '';
  if (!project.slides) {
    container.innerHTML = `<div class="card"><div style="font-size:14px">Draft the slides first (tab 2).</div></div>`;
    return;
  }

  const tpl = getTemplate(project.templateId);
  const mode = project.renderMode || 'auto';
  const box = document.createElement('div');
  box.innerHTML = `
    <div class="card">
      <div style="font-size:14px;font-weight:600;margin-bottom:12px">Deck options</div>

      <div class="field" style="margin-bottom:12px">
        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-weight:500">
          <input type="checkbox" id="showIntro" ${project.showIntroSlide !== false && project.presenterName ? 'checked' : ''} style="width:18px;height:18px;accent-color:var(--accent);cursor:pointer">
          <span>Show intro slide</span>
        </label>
      </div>
      <div class="field" style="margin-bottom:8px">
        <label style="font-size:12px;color:var(--ink-soft)">Presenter name</label>
        <input type="text" id="presenterName" value="${escapeHtml(project.presenterName || '')}" placeholder="e.g. Jane Smith">
      </div>
      <div class="field" style="margin-bottom:14px">
        <label style="font-size:12px;color:var(--ink-soft)">Intro subtitle (optional)</label>
        <input type="text" id="introSubtitle" value="${escapeHtml(project.introSubtitle || '')}" placeholder="e.g. A quarterly review">
      </div>

      <div class="field" style="margin-bottom:8px">
        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-weight:500">
          <input type="checkbox" id="showOutro" ${project.showOutroSlide !== false ? 'checked' : ''} style="width:18px;height:18px;accent-color:var(--accent);cursor:pointer">
          <span>Show thank-you slide</span>
        </label>
      </div>
      <div class="field" style="margin-bottom:14px">
        <label style="font-size:12px;color:var(--ink-soft)">Custom thank-you message (optional)</label>
        <input type="text" id="thankYouMessage" value="${escapeHtml(project.thankYouMessage || '')}" placeholder="Defaults to 'Thank you' / language equivalent">
      </div>

      <div class="field-row">
        <div class="field">
          <label>Slide transition</label>
          <select id="slideTransition" style="padding:10px 12px;width:100%;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);color:var(--ink)">
            ${SLIDE_TRANSITIONS.map(t => `<option value="${t.id}"${(project.slideTransition || 'fade') === t.id ? ' selected' : ''}>${t.name}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Default content animation</label>
          <select id="contentAnim" style="padding:10px 12px;width:100%;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);color:var(--ink)">
            ${CONTENT_ANIMATIONS.map(a => `<option value="${a.id}"${(project.contentAnimation || 'fade-up') === a.id ? ' selected' : ''}>${a.name}</option>`).join('')}
          </select>
        </div>
      </div>
      <div style="font-size:11px;color:var(--ink-mute);margin-top:6px">Per-slide animations override the default. Set per slide in the draft tab's Edit modal.</div>
    </div>

    <div class="card">
      <div style="font-size:14px;margin-bottom:10px">Current template: <strong>${escapeHtml(tpl.name)}</strong></div>
      <div style="font-size:13px;color:var(--ink-soft);margin-bottom:14px">Render to a standalone HTML file. Images are downloaded into the project folder for offline viewing.</div>

      <div style="font-size:13px;color:var(--ink-soft);margin-bottom:6px">Display mode</div>
      <div class="seg" id="modeSeg" style="display:flex;gap:6px;margin-bottom:14px">
        <button class="btn btn-ghost seg-btn${mode==='auto'?' active':''}" data-mode="auto" style="flex:1;font-size:13px">Auto</button>
        <button class="btn btn-ghost seg-btn${mode==='mobile'?' active':''}" data-mode="mobile" style="flex:1;font-size:13px">Mobile</button>
        <button class="btn btn-ghost seg-btn${mode==='desktop'?' active':''}" data-mode="desktop" style="flex:1;font-size:13px">Desktop</button>
      </div>

      <div class="btn-row">
        <button class="btn btn-ghost" id="changeTpl">Change template</button>
        <button class="btn btn-primary" id="render">\u2726 Render HTML</button>
      </div>
    </div>
    ${project.renderedAt ? `
    <div class="card">
      <div style="font-size:13px;color:var(--ink-soft);margin-bottom:10px">Last rendered ${timeAgo(project.renderedAt)}</div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px">
        <button class="btn btn-primary" id="preview" style="flex:1 1 auto;min-width:max-content">Preview</button>
        <button class="btn btn-ghost" id="download" style="flex:1 1 auto;min-width:max-content">\u21E9 Download</button>
        <button class="btn btn-ghost" id="share" style="flex:1 1 auto;min-width:max-content">Share path</button>
      </div>
      <button class="btn btn-ghost" id="showDiag" style="width:100%;font-size:12px;color:var(--ink-mute)">\u{1F50D} Show last download diagnostic</button>
    </div>` : ''}
    <div id="log"></div>
  `;
  container.appendChild(box);

  // Auto-save deck options on change. These don't need a "save" button —
  // they'll be picked up the next time the deck is rendered.
  const saveOption = async (field, value) => {
    project[field] = value;
    project.renderedAt = null; // any option change invalidates rendered HTML
    await projects.saveProject(project);
  };
  box.querySelector('#showIntro').onchange = (e) => saveOption('showIntroSlide', e.target.checked);
  box.querySelector('#showOutro').onchange = (e) => saveOption('showOutroSlide', e.target.checked);
  box.querySelector('#presenterName').onblur = (e) => saveOption('presenterName', e.target.value.trim());
  box.querySelector('#introSubtitle').onblur = (e) => saveOption('introSubtitle', e.target.value.trim());
  box.querySelector('#thankYouMessage').onblur = (e) => saveOption('thankYouMessage', e.target.value.trim());
  box.querySelector('#slideTransition').onchange = (e) => saveOption('slideTransition', e.target.value);
  box.querySelector('#contentAnim').onchange = (e) => saveOption('contentAnimation', e.target.value);

  // inject a small stylesheet for the segmented mode selector
  if (!document.getElementById('seg-style')) {
    const st = document.createElement('style');
    st.id = 'seg-style';
    st.textContent = `.seg-btn.active{background:var(--accent);color:#1a1612;border-color:var(--accent)}`;
    document.head.appendChild(st);
  }

  box.querySelectorAll('.seg-btn').forEach(b => {
    b.onclick = async () => {
      project.renderMode = b.dataset.mode;
      await projects.saveProject(project);
      render();
    };
  });

  box.querySelector('#changeTpl').onclick = async () => {
    const wrap = document.createElement('div');
    wrap.className = 'template-grid';
    wrap.style.maxHeight = '55vh';
    wrap.style.overflowY = 'auto';
    TEMPLATES.forEach(t => {
      const c = document.createElement('button');
      c.className = 'template-card' + (t.id === project.templateId ? ' active' : '');
      c.innerHTML = `<div class="template-preview">${t.preview()}</div><div class="template-name">${t.name}</div><div class="template-tag">${t.tag}</div>`;
      c.onclick = () => {
        wrap.querySelectorAll('.template-card').forEach(x => x.classList.remove('active'));
        c.classList.add('active');
        wrap.dataset.selected = t.id;
      };
      wrap.appendChild(c);
    });
    wrap.dataset.selected = project.templateId;
    const res = await modal({
      title: 'Change template',
      content: wrap,
      actions: [
        { label: 'Cancel', kind: 'ghost', value: null },
        { label: 'Apply', kind: 'primary', onClick: async () => {
          project.templateId = wrap.dataset.selected;
          await projects.saveProject(project);
          return 'ok';
        }}
      ]
    });
    if (res) render();
  };

  box.querySelector('#render').onclick = async () => {
    const log = box.querySelector('#log');
    log.innerHTML = '<div class="progress-log" id="pl"></div>';
    const plEl = log.querySelector('#pl');
    const onLog = (k, m) => addLogLine(plEl, k, m);
    try {
      box.querySelector('#render').disabled = true;
      await downloadSelectedImages(project, project.slides, onLog);
      onLog('running', 'Rendering HTML template...');
      const html = renderPresentation(project, getTemplate(project.templateId), { mode: project.renderMode || 'auto' });
      await fs.writeText(`projects/${project.id}/presentation.html`, html);
      project.renderedAt = Date.now();
      project.stage = 'rendered';
      await projects.saveProject(project);
      onLog('done', 'Saved presentation.html');
      toast('Presentation rendered');
      setTimeout(() => render(), 400);
    } catch (e) {
      onLog('err', e.message);
      box.querySelector('#render').disabled = false;
    }
  };

  if (project.renderedAt) {
    box.querySelector('#preview').onclick = () => nav('preview', { projectId: project.id });
    box.querySelector('#download').onclick = async () => {
      try {
        await downloadPresentation(project);
      } catch (e) {
        toast('Download failed: ' + e.message);
      }
    };
    box.querySelector('#share').onclick = () => {
      const path = `projects/${project.id}/presentation.html`;
      if (typeof Android !== 'undefined' && Android.share) {
        Android.share(`Presentation saved at: ${path}`);
      } else {
        navigator.clipboard?.writeText(path);
        toast('Path copied');
      }
    };
    box.querySelector('#showDiag').onclick = () => {
      const d = window.__lastDownloadDiagnostic;
      if (!d) {
        toast('No download attempted yet in this session');
        return;
      }
      const ageSec = Math.round((Date.now() - d.timestamp) / 1000);
      showInlineDiagnostic({
        title: `Last download (${ageSec}s ago): ${d.inlinedCount}/${d.neededSize} inlined`,
        log: d.debugLog,
        project,
        htmlSize: d.htmlSize
      });
    };
  }
}

// Export the rendered HTML to a user-accessible file.
// Tries Android native save first (if available), then browser blob download.
// Inlines all local images as base64 data URLs so the HTML is self-contained.
async function downloadPresentation(project) {
  let html = await fs.readText(`projects/${project.id}/presentation.html`);
  if (!html) throw new Error('No rendered HTML found. Render first.');

  toast('Preparing download (inlining images)\u2026');

  // Inline images so the file is fully self-contained when opened anywhere.
  // See inlineProjectImages comment for the fallback strategy.
  const imgResult = await inlineProjectImages(project, html);
  html = imgResult.html;
  const inlinedCount = imgResult.inlinedCount;
  const inlinedViaNetwork = imgResult.inlinedViaNetwork;
  const neededSize = imgResult.totalNeeded;
  const failedPaths = imgResult.failedPaths;
  const debugLog = imgResult.debugLog || [];

  // Stash diagnostic globally so it can be reviewed via the "Show download
  // diagnostic" button on the render tab even if the toast succeeded. This
  // lets the user inspect what actually happened: how big the html ended
  // up, which images were sourced from the network vs. local, etc.
  const diagnostic = {
    timestamp: Date.now(),
    htmlSize: html.length,
    inlinedCount,
    inlinedViaNetwork,
    neededSize,
    failedPaths,
    debugLog
  };
  window.__lastDownloadDiagnostic = diagnostic;

  // Show a persistent diagnostic if anything went wrong. Toasts disappear
  // too quickly for the user to read details — and "the images don't work"
  // is the kind of bug where details matter.
  if (neededSize > 0 && inlinedCount < neededSize) {
    showInlineDiagnostic({
      title: `Image inlining: ${inlinedCount}/${neededSize} succeeded`,
      log: debugLog,
      project,
      htmlSize: html.length
    });
  } else if (neededSize > 0) {
    // Even on success, log the size so we can verify inlining actually grew
    // the html. Original ~30KB → with 8 images embedded ~2-5MB typically.
    const sizeMB = (html.length / 1024 / 1024).toFixed(2);
    console.log(`[downloadPresentation] html size after image inline: ${html.length} bytes (${sizeMB} MB)`);
    if (inlinedViaNetwork > 0) {
      toast(`\u2713 ${inlinedCount} images inlined (${sizeMB} MB).`);
    } else {
      toast(`\u2713 ${inlinedCount} images inlined (${sizeMB} MB).`);
    }
  }

  // Inline Google Fonts so the deck renders with the intended typography
  // even when opened offline. Without this the file would still display
  // (system font fallback), but it loses the template's visual identity.
  // We fetch the Google Fonts CSS, then fetch every woff2 it references,
  // and rewrite the stylesheet in-place as a <style> block with embedded
  // base64 data URLs.
  toast('Embedding fonts\u2026');
  try {
    html = await inlineGoogleFonts(html);
  } catch (e) {
    console.warn('Font inlining failed (non-fatal):', e);
    // Fall through — file still works, fonts just fall back to system defaults
  }

  const slug = (project.topic || 'presentation').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'presentation';
  const filename = `${slug}-${project.id.slice(-6)}.html`;

  // CRITICAL: write the inlined HTML to disk BEFORE calling Android.saveDownload.
  // The host APK's saveDownload implementation may either:
  //   (a) use the html argument we pass, or
  //   (b) ignore it and copy the file from the project folder.
  // If (b), we'd otherwise be saving the UN-inlined html. By overwriting the
  // disk copy first, both paths produce a fully-inlined file. We use a
  // temporary "downloads" filename so the editable copy in projects/ stays
  // intact for further editing.
  toast('Writing file\u2026');
  try {
    await fs.writeText(`projects/${project.id}/${filename}`, html);
  } catch (e) {
    console.warn('Could not write inlined html to disk:', e);
  }
  // Also overwrite presentation.html so any consumer reading from the canonical
  // project path also gets the inlined version.
  try {
    await fs.writeText(`projects/${project.id}/presentation.html`, html);
  } catch (e) {
    console.warn('Could not update presentation.html with inlined html:', e);
  }

  // Native Android save (if the APK host exposes a download bridge).
  // The HTML argument we pass MAY exceed the JS bridge's message size limit
  // (usually around 1 MB on Android). If it throws or silently fails, we
  // fall through to the browser blob download which has no size limit.
  if (typeof Android !== 'undefined' && typeof Android.saveDownload === 'function') {
    try {
      Android.saveDownload(filename, html);
      toast('Saved to Downloads');
      return;
    } catch (e) {
      console.warn('Android.saveDownload failed, falling back to blob:', e);
    }
  }

  // Fallback: browser blob download
  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 1000);
  toast('Downloaded ' + filename);
}

function guessImageMime(path) {
  const ext = (path.split('.').pop() || '').toLowerCase();
  return ext === 'png' ? 'image/png'
    : ext === 'gif' ? 'image/gif'
    : ext === 'webp' ? 'image/webp'
    : ext === 'svg' ? 'image/svg+xml'
    : 'image/jpeg';
}

// Persistent diagnostic panel for inlining failures. Toasts disappear
// before the user can read them; this stays on screen until dismissed.
// We also include slide.imageUrl values so the user can spot if URLs are
// missing on their slides (a common cause of inlining failure).
function showInlineDiagnostic({ title, log, project, htmlSize }) {
  // Add per-slide imageUrl summary to the diagnostic
  const slideInfo = (project.slides || []).map((s, i) => {
    const idx = String(i + 1).padStart(2, '0');
    const hasLocal = s.localImage ? 'localImage=' + s.localImage : 'NO localImage';
    const hasUrl = s.imageUrl ? 'imageUrl=' + s.imageUrl.slice(0, 60) + (s.imageUrl.length > 60 ? '\u2026' : '') : 'NO imageUrl';
    return `slide ${idx}: ${hasLocal} | ${hasUrl}`;
  });

  const sizeInfo = htmlSize
    ? `HTML size after inlining: ${htmlSize} bytes (${(htmlSize / 1024 / 1024).toFixed(2)} MB)`
    : '';

  const fullText = [
    title,
    sizeInfo,
    '',
    '--- Per-image trace ---',
    ...(log || []),
    '',
    '--- Per-slide image data ---',
    ...slideInfo
  ].filter(Boolean).join('\n');

  modal({
    title: 'Image inlining issue',
    content: `
      <div style="font-size:13px;color:var(--ink);margin-bottom:12px;line-height:1.55">
        Some images couldn't be embedded into the downloaded HTML. The downloaded
        file will work, but those images will appear broken when opened away from
        this device.
      </div>
      <div style="font-size:13px;color:var(--ink-soft);margin-bottom:8px">
        The most common cause: the device was offline during download, and the
        local image files couldn't be read either. <strong>Try again with internet
        connected.</strong>
      </div>
      <details style="margin-top:10px">
        <summary style="cursor:pointer;color:var(--accent);font-size:12px;user-select:none;padding:6px 0">Show diagnostic details</summary>
        <pre style="font-size:11px;color:var(--ink-soft);background:var(--bg-soft);padding:10px;border-radius:6px;white-space:pre-wrap;word-break:break-all;max-height:300px;overflow:auto;margin-top:6px">${escapeHtml(fullText)}</pre>
      </details>
    `,
    actions: [
      { label: 'Copy diagnostic', kind: 'ghost', onClick: () => {
        if (navigator.clipboard) navigator.clipboard.writeText(fullText);
        toast('Copied');
        return null; // keep modal open
      }},
      { label: 'OK', kind: 'primary', value: true }
    ]
  });
}

// Replace `src="images/..."` references in rendered HTML with base64 data
// URLs. Used for both downloads (so the file is self-contained) and
// previews (because images on disk are stored as base64 text behind the
// Android JS bridge — the WebView can't load them as raw image files).
//
// Strategy is NETWORK-FIRST. Local storage on Android has been an unreliable
// path for binary data (the JS bridge struggles with Uint8Arrays); rather
// than fight it, we just refetch the original imageUrl for each slide. The
// user has internet when they tap Download (they just rendered a deck), so
// this is fine. If the network fetch fails, we fall back to local storage
// (in case we're truly offline). This way the download is reliable on Day 1
// regardless of how local images were stored.
//
// Returns { html, inlinedCount, inlinedViaNetwork, totalNeeded, failedPaths }
async function inlineProjectImages(project, html) {
  const imgSrcRegex = /src\s*=\s*"(images\/([^"]+))"/g;
  const needed = new Map(); // path -> filename
  let m;
  while ((m = imgSrcRegex.exec(html))) {
    needed.set(m[1], m[2]);
  }
  if (needed.size === 0) {
    return { html, inlinedCount: 0, inlinedViaNetwork: 0, totalNeeded: 0, failedPaths: [] };
  }

  // Build a filename -> imageUrl map so we know which source URL each
  // slide-XX.jpg came from
  const localToUrl = new Map();
  for (const s of (project.slides || [])) {
    if (s.localImage && s.imageUrl) {
      localToUrl.set(s.localImage, s.imageUrl);
    }
  }

  const dataUrls = new Map();
  let inlinedCount = 0;
  let inlinedViaNetwork = 0;
  const failedPaths = [];
  const debugLog = [];

  // Process all images in parallel — inlining 8 images sequentially is slow
  await Promise.all(Array.from(needed.entries()).map(async ([path, filename]) => {
    let b64 = null;
    let mime = guessImageMime(path);
    let source = '';

    // 1. Network first: refetch from the original imageUrl. This is the
    //    most reliable path on Android because it avoids the storage layer
    //    entirely and just uses fetch() which always works in WebView.
    const sourceUrl = localToUrl.get(filename);
    if (sourceUrl) {
      try {
        const res = await fetch(sourceUrl);
        if (res.ok) {
          const buf = await res.arrayBuffer();
          b64 = bytesToBase64(new Uint8Array(buf));
          const ct = res.headers.get('content-type');
          if (ct && ct.startsWith('image/')) mime = ct.split(';')[0];
          inlinedViaNetwork++;
          source = 'network';
        } else {
          debugLog.push(`${path}: network ${res.status}`);
        }
      } catch (e) {
        debugLog.push(`${path}: network error - ${e.message}`);
      }
    } else {
      debugLog.push(`${path}: no imageUrl in project.slides`);
    }

    // 2. Local fast path: read base64 text directly (works for files
    //    written with the new B64: prefixed storage format)
    if (!b64) {
      try {
        const direct = await fs.readBytesAsBase64(`projects/${project.id}/${path}`);
        if (direct) {
          b64 = direct;
          source = 'local-fast';
        }
      } catch (e) {
        debugLog.push(`${path}: readBytesAsBase64 error - ${e.message}`);
      }
    }

    // 3. Local slow fallback: read raw bytes and re-encode
    if (!b64) {
      try {
        const bytes = await fs.readBytes(`projects/${project.id}/${path}`);
        if (bytes && (bytes.length > 0 || bytes.byteLength > 0)) {
          b64 = bytesToBase64(bytes);
          source = 'local-slow';
        }
      } catch (e) {
        debugLog.push(`${path}: readBytes error - ${e.message}`);
      }
    }

    if (b64) {
      dataUrls.set(path, `data:${mime};base64,${b64}`);
      inlinedCount++;
      debugLog.push(`${path}: ✓ inlined via ${source} (${b64.length} chars b64)`);
    } else {
      failedPaths.push(path);
      debugLog.push(`${path}: ✗ ALL FALLBACKS FAILED`);
    }
  }));

  // Print full diagnostic to console — the user can copy from devtools if
  // they want to share what's happening
  console.log('[inlineProjectImages] diagnostic:\n' + debugLog.join('\n'));

  let outHtml = html;
  if (dataUrls.size > 0) {
    outHtml = html.replace(/src\s*=\s*"(images\/[^"]+)"/g, (match, path) => {
      const url = dataUrls.get(path);
      return url ? `src="${url}"` : match;
    });
  }
  return { html: outHtml, inlinedCount, inlinedViaNetwork, totalNeeded: needed.size, failedPaths, debugLog };
}

function bytesToBase64(bytes) {
  // Different bridges marshal "bytes" differently:
  //   - Plain Uint8Array (browser fallback): use the chunked conversion
  //   - String (Android bridge often passes base64 already): pass through
  //   - String "data:..." (already a data URL): extract base64 portion
  //   - ArrayBuffer: wrap into Uint8Array
  //   - Plain object/array (some buggy bridges): coerce to Uint8Array
  if (bytes == null) return '';
  if (typeof bytes === 'string') {
    // Already a base64 string (or data URL — strip the prefix)
    const m = bytes.match(/^data:[^;]+;base64,(.+)$/);
    if (m) return m[1];
    return bytes;
  }
  if (bytes instanceof ArrayBuffer) bytes = new Uint8Array(bytes);
  if (!(bytes instanceof Uint8Array)) {
    try {
      bytes = new Uint8Array(bytes);
    } catch {
      return '';
    }
  }
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

// Replace each <link href="https://fonts.googleapis.com/css2?..."> in the
// HTML with an inline <style> block containing the @font-face rules from
// Google Fonts, with each woff2 file embedded as a data URL. Result: the
// downloaded HTML displays in the intended template typography even when
// opened with no internet connection.
//
// Cost: typically 100-500 KB per font face, so a deck using two fonts
// with multiple weights might add ~1-2 MB to the HTML. That's worth it
// for a self-contained file. Failures are non-fatal — if the network
// is unavailable, fonts simply fall back to system defaults.
async function inlineGoogleFonts(html) {
  const linkRe = /<link\s+href="(https:\/\/fonts\.googleapis\.com\/css2\?[^"]+)"\s+rel="stylesheet"\s*\/?>/g;
  const matches = [...html.matchAll(linkRe)];
  if (matches.length === 0) return html;

  // Process all font CSS URLs in parallel — much faster than serial
  const replacements = await Promise.all(matches.map(async (m) => {
    const cssUrl = m[1];
    try {
      // Google Fonts returns different woff2 URLs depending on the User-Agent.
      // Modern browsers' default UAs already give woff2; we set one explicitly
      // to be safe. (fetch in WebView/Android automatically sends a modern UA.)
      const cssRes = await fetch(cssUrl);
      if (!cssRes.ok) return { match: m[0], replacement: null };
      let css = await cssRes.text();

      // Find every url(https://fonts.gstatic.com/...woff2) in the CSS and
      // fetch + base64-encode each one in parallel.
      const fontUrlRe = /url\((https:\/\/fonts\.gstatic\.com\/[^)]+\.woff2)\)/g;
      const fontUrls = [...new Set([...css.matchAll(fontUrlRe)].map(fm => fm[1]))];

      const fontMap = new Map();
      await Promise.all(fontUrls.map(async (fu) => {
        try {
          const fr = await fetch(fu);
          if (!fr.ok) return;
          const buf = await fr.arrayBuffer();
          const b64 = bytesToBase64(new Uint8Array(buf));
          fontMap.set(fu, `data:font/woff2;base64,${b64}`);
        } catch { /* skip this font, fall back to next in the unicode-range chain */ }
      }));

      // Substitute each font URL in the CSS with its data URL
      css = css.replace(fontUrlRe, (full, url) => {
        const dataUrl = fontMap.get(url);
        return dataUrl ? `url(${dataUrl})` : full;
      });

      return { match: m[0], replacement: `<style>${css}</style>` };
    } catch (e) {
      return { match: m[0], replacement: null };
    }
  }));

  // Apply replacements (skip nulls so failed ones leave the original link tag,
  // which will at least try to load fonts when the user is online)
  let result = html;
  for (const { match, replacement } of replacements) {
    if (replacement) {
      result = result.replace(match, replacement);
    }
  }
  return result;
}

// ========================================================================
// PREVIEW (iframe)
// ========================================================================

async function renderPreview() {
  const project = await projects.getProject(state.projectId);
  root.innerHTML = '';

  // Local state for this preview session
  let editMode = state.editMode || false;

  const topbar = document.createElement('div');
  topbar.className = 'topbar';
  topbar.innerHTML = `
    <button class="back-btn" id="back">${icon('back', 16)} <span>Edit</span></button>
    <div style="display:flex;gap:8px;align-items:center">
      <button class="btn btn-ghost" id="editBtn" style="padding:6px 12px;font-size:12px;${editMode?'background:var(--accent);color:#1a1612':''}">\u270E ${editMode?'Editing':'Edit text'}</button>
      <button class="btn btn-ghost" id="dlBtn" style="padding:6px 12px;font-size:12px">\u21E9 Download</button>
    </div>
  `;
  topbar.querySelector('#back').onclick = () => {
    window.removeEventListener('message', editListener);
    window.removeEventListener('resize', onResize);
    nav('project', { projectId: state.projectId, tab: 'render' });
  };
  root.appendChild(topbar);

  const view = document.createElement('div');
  view.style.flex = '1';
  view.style.minHeight = '80vh';
  view.style.position = 'relative';
  view.style.overflow = 'hidden';
  view.style.background = '#000';
  root.appendChild(view);

  // Build the iframe markup with current mode + editable flag.
  // Images are inlined as data URLs because images on disk are stored as
  // base64 text behind the Android JS bridge — the WebView can't load
  // them as raw image files via <base href>. Inlining solves this and
  // matches how downloads work, keeping behaviour consistent.
  async function buildHtml() {
    const html = renderPresentation(
      project,
      getTemplate(project.templateId),
      { mode: project.renderMode || 'auto', editable: editMode }
    );
    const result = await inlineProjectImages(project, html);
    return result.html;
  }

  // Helper to refresh the iframe with the latest rendered + inlined HTML.
  // Wrapped so we can call it from initial mount, edit-mode toggle, and
  // any future re-render trigger. We don't need to await the result —
  // the iframe just shows the previous content until the new one is ready.
  async function refreshPreview() {
    iframe.srcdoc = await buildHtml();
  }

  const iframe = document.createElement('iframe');
  iframe.style.border = 'none';
  iframe.style.background = '#000';
  iframe.style.display = 'block';

  // Wrapper used in desktop mode to scale the 1280x720 iframe down to fit
  // the phone screen. We use a wrapper (not transforms on the iframe itself)
  // so the iframe's top-left stays at 0,0 of the wrapper and centering
  // works cleanly.
  const wrapper = document.createElement('div');
  wrapper.style.width = '100%';
  wrapper.style.height = 'calc(100vh - 60px)';
  wrapper.style.display = 'flex';
  wrapper.style.alignItems = 'center';
  wrapper.style.justifyContent = 'center';
  wrapper.style.overflow = 'hidden';
  wrapper.style.background = '#000';

  function sizeIframe() {
    const mode = project.renderMode || 'auto';
    if (mode === 'desktop') {
      // Render at a true 1280x720 viewport so template media queries and
      // vw/vh units resolve against desktop dimensions. Then visually shrink
      // to fit the phone via CSS transform.
      iframe.style.width = '1280px';
      iframe.style.height = '720px';
      iframe.style.flexShrink = '0';
      const vw = wrapper.clientWidth || window.innerWidth;
      const vh = wrapper.clientHeight || (window.innerHeight - 60);
      const scale = Math.min(vw / 1280, vh / 720);
      iframe.style.transform = `scale(${scale})`;
      iframe.style.transformOrigin = 'center center';
    } else {
      iframe.style.width = '100%';
      iframe.style.height = '100%';
      iframe.style.flexShrink = '';
      iframe.style.transform = '';
      iframe.style.transformOrigin = '';
    }
  }
  refreshPreview(); // initial mount — fire-and-forget; iframe shows blank until ready
  wrapper.appendChild(iframe);
  view.appendChild(wrapper);
  requestAnimationFrame(sizeIframe);
  const onResize = () => sizeIframe();
  window.addEventListener('resize', onResize);

  // Handle edits posted from inside the iframe
  const editListener = (ev) => {
    const msg = ev.data;
    if (!msg || typeof msg !== 'object') return;
    if (msg.type === 'deck:edit') {
      applyEdit(project, msg);
      // best-effort save; don't block UI
      projects.saveProject(project).catch(() => {});
    }
    // we could also track msg.type === 'deck:slide' if we wanted to restore position
  };
  window.addEventListener('message', editListener);

  topbar.querySelector('#editBtn').onclick = async () => {
    editMode = !editMode;
    state.editMode = editMode;
    await refreshPreview();
    topbar.querySelector('#editBtn').style.cssText = `padding:6px 12px;font-size:12px;${editMode?'background:var(--accent);color:#1a1612':''}`;
    topbar.querySelector('#editBtn').innerHTML = `\u270E ${editMode?'Editing':'Edit text'}`;
    // Re-size after the new srcdoc loads
    iframe.onload = () => sizeIframe();
    toast(editMode ? 'Tap any text to edit' : 'Edit mode off');
  };

  topbar.querySelector('#dlBtn').onclick = async () => {
    try {
      // Make sure the saved file reflects any pending edits made in this session:
      // re-render with editable=false (clean output for download) and save, then download.
      const cleanHtml = renderPresentation(
        project,
        getTemplate(project.templateId),
        { mode: project.renderMode || 'auto', editable: false }
      );
      await fs.writeText(`projects/${project.id}/presentation.html`, cleanHtml);
      await downloadPresentation(project);
    } catch (e) {
      toast('Download failed: ' + e.message);
    }
  };
}

// Apply an edit message from the preview iframe into project.slides.
function applyEdit(project, msg) {
  if (!project.slides) return;
  const s = project.slides[msg.slideIdx];
  if (!s) return;
  const val = typeof msg.value === 'string' ? msg.value : '';
  if (msg.field === 'bullets' && typeof msg.idx === 'number') {
    s.bullets = Array.isArray(s.bullets) ? s.bullets.slice() : [];
    s.bullets[msg.idx] = val;
  } else if (msg.field === 'title' || msg.field === 'subtitle' || msg.field === 'body') {
    s[msg.field] = val;
  }
}

// ========================================================================
// SETTINGS
// ========================================================================

async function renderSettings() {
  const cfg = await settings.loadSettings();

  const topbar = document.createElement('div');
  topbar.className = 'topbar';
  topbar.innerHTML = `<button class="back-btn" id="back">${icon('back',16)} <span>Back</span></button><div></div>`;
  topbar.querySelector('#back').onclick = () => nav('home');
  root.appendChild(topbar);

  const view = document.createElement('div');
  view.className = 'view';
  view.innerHTML = `
    <h1 class="page-title">Settings</h1>
    <p class="page-subtitle">OpenRouter key and models</p>

    <div class="field">
      <label>OpenRouter API key</label>
      <input type="password" id="key" placeholder="sk-or-..." value="${escapeHtml(cfg.apiKey)}">
      <div class="hint">Stored locally in the app folder. Never sent anywhere except OpenRouter.</div>
    </div>
    <button class="btn btn-primary btn-block" id="saveKey" style="margin-bottom:8px">Save key</button>
    ${cfg.apiKey ? `<button class="btn btn-danger btn-block" id="clearKey" style="margin-bottom:18px">Clear key</button>` : ''}

    <div class="divider"></div>

    <h2 style="font-family:var(--serif);font-size:20px;margin-bottom:4px;font-weight:600;letter-spacing:-.02em">Models</h2>
    <p class="page-subtitle" style="margin-bottom:14px">Tap a model to activate it. Use OpenRouter model IDs (e.g. <code style="font-family:var(--mono);font-size:11px">anthropic/claude-3.5-sonnet</code>).</p>

    <div id="modelList"></div>

    <div class="field-row" style="margin-top:14px">
      <input id="newModel" placeholder="vendor/model-name" style="flex:2">
      <button class="btn btn-ghost" id="addModel" style="flex:1">Add</button>
    </div>
    <div class="hint" style="margin-top:6px;color:var(--ink-mute);font-size:12px">Find IDs at <span style="color:var(--accent)">openrouter.ai/models</span></div>

    <div class="divider"></div>

    <h2 style="font-family:var(--serif);font-size:20px;margin-bottom:4px;font-weight:600;letter-spacing:-.02em">LLM Log</h2>
    <p class="page-subtitle" style="margin-bottom:14px">Recent LLM calls. Tap any entry to see the raw response. If JSON parsing fails, copy the raw output and share it so the parser can be improved.</p>
    <div id="logList"></div>
    <div class="btn-row" style="margin-top:10px">
      <button class="btn btn-ghost" id="refreshLog" style="flex:1">Refresh</button>
      <button class="btn btn-danger" id="clearLogBtn" style="flex:1">Clear log</button>
    </div>

    <div class="divider"></div>
    <div style="color:var(--ink-mute);font-size:12px;font-family:var(--mono);line-height:1.6">
      Storage: ${fs.isNative ? 'Android filesystem' : 'Browser localStorage (fallback)'}<br>
      Config: config/settings.json<br>
      Projects: projects/
    </div>
  `;
  root.appendChild(view);

  // --- LLM log UI ---
  if (!document.getElementById('log-style')) {
    const st = document.createElement('style');
    st.id = 'log-style';
    st.textContent = `
      .log-entry{background:var(--surface-2,rgba(255,255,255,.04));border:1px solid var(--border,rgba(255,255,255,.08));border-radius:8px;padding:10px 12px;margin-bottom:8px;font-size:12px}
      .log-entry.failed{border-color:#d93b3b}
      .log-entry .meta{display:flex;gap:8px;flex-wrap:wrap;align-items:center;font-family:var(--mono);color:var(--ink-soft);font-size:11px}
      .log-entry .status-ok{color:#4ade80}
      .log-entry .status-fail{color:#ff6b6b;font-weight:700}
      .log-entry .label{color:var(--ink);font-weight:600}
      .log-entry details{margin-top:8px}
      .log-entry summary{cursor:pointer;color:var(--accent);font-size:12px;user-select:none}
      .log-entry pre{background:#0a0a0a;color:#d4d4d4;padding:10px;border-radius:4px;font-family:var(--mono);font-size:11px;line-height:1.5;overflow:auto;max-height:300px;margin-top:6px;white-space:pre-wrap;word-break:break-word}
      .log-entry .copy-btn{padding:4px 10px;font-size:11px;margin-top:4px}
      .log-empty{color:var(--ink-mute);font-size:13px;font-style:italic;padding:10px 0}
    `;
    document.head.appendChild(st);
  }

  async function refreshLogList() {
    const el = view.querySelector('#logList');
    el.innerHTML = '<div class="log-empty">Loading…</div>';
    const entries = await readLog();
    if (!entries.length) {
      el.innerHTML = '<div class="log-empty">No LLM calls logged yet.</div>';
      return;
    }
    el.innerHTML = '';
    for (const e of entries.slice(0, 40)) {
      const when = new Date(e.ts || Date.now()).toLocaleString();
      const status = e.error ? 'ERR' : (e.parsed === 'failed' ? 'PARSE-FAIL' : (e.parsed === 'ok' ? 'OK' : 'OK'));
      const statusClass = (e.error || e.parsed === 'failed') ? 'status-fail' : 'status-ok';
      const entryClass = (e.error || e.parsed === 'failed') ? 'log-entry failed' : 'log-entry';
      const dur = e.durationMs ? ` · ${e.durationMs}ms` : '';
      const div = document.createElement('div');
      div.className = entryClass;
      div.innerHTML = `
        <div class="meta">
          <span class="${statusClass}">${status}</span>
          <span class="label">${escapeHtml(e.label || 'chat')}</span>
          <span>${escapeHtml(e.model || '?')}</span>
          <span>${when}${dur}</span>
        </div>
        ${e.parseError ? `<div style="color:#ff6b6b;font-size:11px;margin-top:6px;font-family:var(--mono)">Parse error: ${escapeHtml(e.parseError)}</div>` : ''}
        ${e.error ? `<div style="color:#ff6b6b;font-size:11px;margin-top:6px;font-family:var(--mono)">${escapeHtml(e.error)}</div>` : ''}
        <details>
          <summary>Show raw output &amp; prompt</summary>
          <div style="margin-top:8px;color:var(--ink-soft);font-size:11px">System prompt (preview):</div>
          <pre>${escapeHtml(e.systemPreview || '(none)')}</pre>
          <div style="color:var(--ink-soft);font-size:11px;margin-top:6px">User prompt (preview):</div>
          <pre>${escapeHtml(e.userPreview || '(none)')}</pre>
          <div style="color:var(--ink-soft);font-size:11px;margin-top:6px">Raw response:</div>
          <pre data-raw>${escapeHtml(e.raw || '(no response)')}</pre>
          <button class="btn btn-ghost copy-btn" data-copy>Copy raw response</button>
        </details>
      `;
      div.querySelector('[data-copy]').onclick = async (ev) => {
        ev.stopPropagation();
        const raw = e.raw || '';
        try {
          await navigator.clipboard.writeText(raw);
          toast('Copied to clipboard');
        } catch {
          // fallback: select the <pre> content so the user can copy manually
          const pre = div.querySelector('[data-raw]');
          const range = document.createRange();
          range.selectNodeContents(pre);
          const sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
          toast('Selected — long-press to copy');
        }
      };
      el.appendChild(div);
    }
  }

  view.querySelector('#refreshLog').onclick = refreshLogList;
  view.querySelector('#clearLogBtn').onclick = async () => {
    if (!(await confirm('Clear all LLM log entries?'))) return;
    await clearLog();
    toast('Log cleared');
    refreshLogList();
  };
  refreshLogList();

  view.querySelector('#saveKey').onclick = async () => {
    const v = view.querySelector('#key').value.trim();
    await settings.setApiKey(v);
    toast('Key saved');
    render();
  };
  const clear = view.querySelector('#clearKey');
  if (clear) clear.onclick = async () => {
    if (!(await confirm('Clear the stored API key?'))) return;
    await settings.setApiKey('');
    toast('Cleared');
    render();
  };

  const list = view.querySelector('#modelList');
  for (const m of cfg.models) {
    const pill = document.createElement('div');
    pill.className = 'model-pill' + (m.id === cfg.activeModelId ? ' active' : '');
    pill.innerHTML = `
      <div style="flex:1;min-width:0">
        <div class="name">${escapeHtml(m.id)}</div>
        ${m.id === cfg.activeModelId ? '<div class="tag">ACTIVE</div>' : ''}
      </div>
      <button class="icon-btn" data-a="rm">${icon('trash', 16)}</button>
    `;
    pill.onclick = async (e) => {
      if (e.target.closest('[data-a="rm"]')) {
        if (cfg.models.length <= 1) { toast("Can't remove last model"); return; }
        if (!(await confirm(`Remove "${m.id}"?`))) return;
        await settings.removeModel(m.id);
        render();
        return;
      }
      await settings.setActiveModel(m.id);
      toast('Active: ' + m.id);
      render();
    };
    list.appendChild(pill);
  }

  view.querySelector('#addModel').onclick = async () => {
    const v = view.querySelector('#newModel').value.trim();
    if (!v) { toast('Enter a model ID'); return; }
    if (!v.includes('/')) { toast('Format: vendor/model-name'); return; }
    await settings.addModel(v, v);
    toast('Added');
    render();
  };
}

// ========================================================================
// UTILS
// ========================================================================

function addLogLine(el, kind, msg) {
  // upgrade any previous "running" lines to done
  el.querySelectorAll('.line.running').forEach(l => l.classList.replace('running', 'done'));
  const d = document.createElement('div');
  d.className = 'line ' + kind;
  d.textContent = msg;
  el.appendChild(d);
  el.scrollTop = el.scrollHeight;
}

// ========================================================================
// BOOT
// ========================================================================

(async function main() {
  try {
    await fs.mkdir('config');
    await fs.mkdir('projects');
    await settings.loadSettings();
  } catch (e) {
    console.error('init failed', e);
  }
  render();
})();
