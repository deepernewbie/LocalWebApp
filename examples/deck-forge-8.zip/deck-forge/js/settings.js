// settings.js - API key and model management

import * as fs from './storage.js';

const SETTINGS_PATH = 'config/settings.json';

const DEFAULT_SETTINGS = {
  apiKey: '',
  models: [
    { id: 'anthropic/claude-3.5-sonnet', label: 'Claude 3.5 Sonnet' },
    { id: 'openai/gpt-4o-mini', label: 'GPT-4o mini' },
    { id: 'google/gemini-2.0-flash-001', label: 'Gemini 2.0 Flash' },
    { id: 'meta-llama/llama-3.3-70b-instruct', label: 'Llama 3.3 70B' }
  ],
  activeModelId: 'anthropic/claude-3.5-sonnet'
};

let cache = null;

export async function loadSettings() {
  if (cache) return cache;
  const data = await fs.readJSON(SETTINGS_PATH, null);
  cache = data || structuredClone(DEFAULT_SETTINGS);
  // migrate / ensure fields
  if (!Array.isArray(cache.models) || cache.models.length === 0) {
    cache.models = structuredClone(DEFAULT_SETTINGS.models);
  }
  if (!cache.activeModelId || !cache.models.find(m => m.id === cache.activeModelId)) {
    cache.activeModelId = cache.models[0].id;
  }
  return cache;
}

export async function saveSettings(s) {
  cache = s;
  await fs.writeJSON(SETTINGS_PATH, s);
}

export async function setApiKey(key) {
  const s = await loadSettings();
  s.apiKey = key.trim();
  await saveSettings(s);
}

export async function addModel(id, label) {
  const s = await loadSettings();
  id = id.trim();
  label = (label || id).trim();
  if (!id) return;
  if (s.models.find(m => m.id === id)) return;
  s.models.push({ id, label });
  await saveSettings(s);
}

export async function removeModel(id) {
  const s = await loadSettings();
  s.models = s.models.filter(m => m.id !== id);
  if (s.activeModelId === id) {
    s.activeModelId = s.models[0]?.id || '';
  }
  await saveSettings(s);
}

export async function setActiveModel(id) {
  const s = await loadSettings();
  s.activeModelId = id;
  await saveSettings(s);
}

export function clearCache() { cache = null; }
