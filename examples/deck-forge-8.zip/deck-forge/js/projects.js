// projects.js - project lifecycle

import * as fs from './storage.js';

const INDEX_PATH = 'projects/index.json';

export async function listProjects() {
  const idx = await fs.readJSON(INDEX_PATH, { projects: [] });
  return idx.projects.sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function getProject(id) {
  return await fs.readJSON(`projects/${id}/project.json`, null);
}

export async function createProject({ topic, slideCount, templateId, audience, tone, language, useImages, presenterName, slideTransition }) {
  const id = fs.slugify(topic) + '-' + fs.shortId();
  const now = Date.now();
  const project = {
    id,
    topic,
    slideCount,
    templateId,
    audience: audience || '',
    tone: tone || 'professional',
    language: language || 'en',
    useImages: useImages !== false,
    // Intro/outro slides: rendered but not counted toward slideCount.
    // Empty string disables the corresponding extra slide.
    presenterName: presenterName || '', // who is presenting (shown on intro)
    introSubtitle: '', // optional subtitle for intro slide
    thankYouMessage: '', // optional thank-you closing message; empty = use default
    showIntroSlide: !!presenterName, // intro is shown only if presenter set
    showOutroSlide: true, // thank-you slide on by default
    // Animations: applied at render time
    slideTransition: slideTransition || 'fade', // fade, slide, zoom, flip, push, none
    renderMode: 'desktop',
    createdAt: now,
    updatedAt: now,
    stage: 'new',
    plan: null,
    research: null,
    slides: null,
    renderedAt: null
  };
  await fs.writeJSON(`projects/${id}/project.json`, project);
  await addToIndex(project);
  return project;
}

export async function saveProject(project) {
  project.updatedAt = Date.now();
  await fs.writeJSON(`projects/${project.id}/project.json`, project);
  await addToIndex(project); // refresh index entry
}

export async function deleteProject(id) {
  const idx = await fs.readJSON(INDEX_PATH, { projects: [] });
  idx.projects = idx.projects.filter(p => p.id !== id);
  await fs.writeJSON(INDEX_PATH, idx);
  // best-effort cleanup of files
  try {
    const p = await getProject(id);
    if (p && p.slides) {
      for (const slide of p.slides) {
        if (slide.localImage) await fs.remove(`projects/${id}/images/${slide.localImage}`);
      }
    }
    await fs.remove(`projects/${id}/project.json`);
    await fs.remove(`projects/${id}/presentation.html`);
  } catch {}
}

async function addToIndex(project) {
  const idx = await fs.readJSON(INDEX_PATH, { projects: [] });
  const i = idx.projects.findIndex(p => p.id === project.id);
  const entry = {
    id: project.id,
    topic: project.topic,
    slideCount: project.slideCount,
    stage: project.stage,
    templateId: project.templateId,
    updatedAt: project.updatedAt
  };
  if (i >= 0) idx.projects[i] = entry;
  else idx.projects.push(entry);
  await fs.writeJSON(INDEX_PATH, idx);
}
