// Slide transition + content-appearing animations.
//
// Two systems:
//
// 1) SLIDE TRANSITIONS — applied when navigating between slides. Set at
//    project level (one transition style for the whole deck). The
//    transition runs on the .slide element when it gains/loses .active.
//
// 2) CONTENT ANIMATIONS — applied to elements inside an .active slide.
//    Set per slide (each slide can have its own appearance style). All
//    direct children of the slide animate together (or with a stagger
//    delay for the "stagger" mode).
//
// Implementation: pure CSS animations + .active class on slides and a
// data-anim attribute on slides for the per-slide content style. The
// existing NAV_SCRIPT just toggles .active — animations layer on top
// without script changes.

export const SLIDE_TRANSITIONS = [
  { id: 'none',    name: 'None',     desc: 'Instant slide change, no animation' },
  { id: 'fade',    name: 'Fade',     desc: 'Cross-fade between slides' },
  { id: 'slide',   name: 'Slide',    desc: 'Horizontal slide-in from the right' },
  { id: 'zoom',    name: 'Zoom',     desc: 'Scale-in from a smaller size' },
  { id: 'flip',    name: 'Flip',     desc: '3D flip on the Y axis' },
  { id: 'push'  ,  name: 'Push up',  desc: 'Vertical push from the bottom' }
];

export const CONTENT_ANIMATIONS = [
  { id: 'none',     name: 'None',          desc: 'Content appears immediately' },
  { id: 'fade-up',  name: 'Fade up',       desc: 'Slight upward float-in with fade' },
  { id: 'fade-in',  name: 'Fade in',       desc: 'Plain fade with no movement' },
  { id: 'slide-l',  name: 'Slide from left', desc: 'Items slide in from the left edge' },
  { id: 'scale',    name: 'Scale up',      desc: 'Items scale from 95% to 100%' },
  { id: 'stagger',  name: 'Stagger fade',  desc: 'Each child element fades in with a small delay' }
];

export function getSlideTransition(id) {
  return SLIDE_TRANSITIONS.find(t => t.id === id) || SLIDE_TRANSITIONS[1]; // default fade
}

export function getContentAnimation(id) {
  return CONTENT_ANIMATIONS.find(a => a.id === id) || CONTENT_ANIMATIONS[1]; // default fade-up
}

// CSS injected into rendered presentations. References a few CSS variables
// so the animation timing can be tuned without changing the keyframes.
export const ANIMATIONS_CSS = `
:root {
  --anim-duration: 480ms;
  --anim-easing: cubic-bezier(0.22, 0.61, 0.36, 1);
  --anim-content-duration: 600ms;
  --anim-stagger: 80ms;
}

/* ===== SLIDE TRANSITIONS ===== */

/* The .slide elements are display:none unless .active. We only animate the
   incoming slide (the one gaining .active). The outgoing slide is hidden
   instantly, which is the simplest and most consistent approach across
   browsers and template structures. */

body[data-transition="fade"] .slide.active {
  animation: deck-fade-in var(--anim-duration) var(--anim-easing) both;
}
@keyframes deck-fade-in {
  from { opacity: 0; }
  to   { opacity: 1; }
}

body[data-transition="slide"] .slide.active {
  animation: deck-slide-in var(--anim-duration) var(--anim-easing) both;
}
@keyframes deck-slide-in {
  from { opacity: 0; transform: translateX(8%); }
  to   { opacity: 1; transform: translateX(0); }
}

body[data-transition="zoom"] .slide.active {
  animation: deck-zoom-in var(--anim-duration) var(--anim-easing) both;
}
@keyframes deck-zoom-in {
  from { opacity: 0; transform: scale(0.92); }
  to   { opacity: 1; transform: scale(1); }
}

body[data-transition="flip"] .slide.active {
  animation: deck-flip-in 600ms var(--anim-easing) both;
  transform-style: preserve-3d;
  perspective: 1000px;
}
@keyframes deck-flip-in {
  from { opacity: 0; transform: perspective(1000px) rotateY(-30deg); }
  to   { opacity: 1; transform: perspective(1000px) rotateY(0); }
}

body[data-transition="push"] .slide.active {
  animation: deck-push-up var(--anim-duration) var(--anim-easing) both;
}
@keyframes deck-push-up {
  from { opacity: 0; transform: translateY(10%); }
  to   { opacity: 1; transform: translateY(0); }
}

/* Desktop mode: the .deck has its own translate+scale transform for the
   16:9 canvas, and that transform's already on .deck. Slide-level
   translate/scale animations happen INSIDE that, so they compound
   correctly without breaking the canvas centering. The flip uses
   perspective which is fine inside any parent transform. */

/* ===== CONTENT (PER-SLIDE) ANIMATIONS =====

   The slide gets data-anim="<id>" from the renderer. Direct content
   children (h1, .subtitle, .body, ul, p, img, etc.) animate when the
   slide becomes active. We use animation-delay to give subtle
   stagger or hold-off so they don't all appear at the same instant
   as the transition itself. */

body .slide.active[data-anim="fade-up"] > h1,
body .slide.active[data-anim="fade-up"] > h2,
body .slide.active[data-anim="fade-up"] > .subtitle,
body .slide.active[data-anim="fade-up"] > .body,
body .slide.active[data-anim="fade-up"] > p,
body .slide.active[data-anim="fade-up"] > ul,
body .slide.active[data-anim="fade-up"] > ol,
body .slide.active[data-anim="fade-up"] > img,
body .slide.active[data-anim="fade-up"] > .imageCaption {
  animation: anim-fade-up var(--anim-content-duration) var(--anim-easing) both;
  animation-delay: var(--anim-duration);
}
@keyframes anim-fade-up {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}

body .slide.active[data-anim="fade-in"] > h1,
body .slide.active[data-anim="fade-in"] > h2,
body .slide.active[data-anim="fade-in"] > .subtitle,
body .slide.active[data-anim="fade-in"] > .body,
body .slide.active[data-anim="fade-in"] > p,
body .slide.active[data-anim="fade-in"] > ul,
body .slide.active[data-anim="fade-in"] > ol,
body .slide.active[data-anim="fade-in"] > img,
body .slide.active[data-anim="fade-in"] > .imageCaption {
  animation: anim-fade-in var(--anim-content-duration) var(--anim-easing) both;
  animation-delay: var(--anim-duration);
}
@keyframes anim-fade-in {
  from { opacity: 0; }
  to   { opacity: 1; }
}

body .slide.active[data-anim="slide-l"] > h1,
body .slide.active[data-anim="slide-l"] > h2,
body .slide.active[data-anim="slide-l"] > .subtitle,
body .slide.active[data-anim="slide-l"] > .body,
body .slide.active[data-anim="slide-l"] > p,
body .slide.active[data-anim="slide-l"] > ul,
body .slide.active[data-anim="slide-l"] > ol,
body .slide.active[data-anim="slide-l"] > img,
body .slide.active[data-anim="slide-l"] > .imageCaption {
  animation: anim-slide-l var(--anim-content-duration) var(--anim-easing) both;
  animation-delay: var(--anim-duration);
}
@keyframes anim-slide-l {
  from { opacity: 0; transform: translateX(-30px); }
  to   { opacity: 1; transform: translateX(0); }
}

body .slide.active[data-anim="scale"] > h1,
body .slide.active[data-anim="scale"] > h2,
body .slide.active[data-anim="scale"] > .subtitle,
body .slide.active[data-anim="scale"] > .body,
body .slide.active[data-anim="scale"] > p,
body .slide.active[data-anim="scale"] > ul,
body .slide.active[data-anim="scale"] > ol,
body .slide.active[data-anim="scale"] > img,
body .slide.active[data-anim="scale"] > .imageCaption {
  animation: anim-scale var(--anim-content-duration) var(--anim-easing) both;
  animation-delay: var(--anim-duration);
  transform-origin: center;
}
@keyframes anim-scale {
  from { opacity: 0; transform: scale(0.96); }
  to   { opacity: 1; transform: scale(1); }
}

/* Stagger: each direct child gets an incrementally larger delay so they
   appear one after another. We can't set per-element delay in CSS
   without nth-child math — using nth-child(N) works because slides have
   a small, predictable number of direct children. */
body .slide.active[data-anim="stagger"] > * {
  animation: anim-fade-up var(--anim-content-duration) var(--anim-easing) both;
}
body .slide.active[data-anim="stagger"] > *:nth-child(1) { animation-delay: calc(var(--anim-duration) + 0 * var(--anim-stagger)); }
body .slide.active[data-anim="stagger"] > *:nth-child(2) { animation-delay: calc(var(--anim-duration) + 1 * var(--anim-stagger)); }
body .slide.active[data-anim="stagger"] > *:nth-child(3) { animation-delay: calc(var(--anim-duration) + 2 * var(--anim-stagger)); }
body .slide.active[data-anim="stagger"] > *:nth-child(4) { animation-delay: calc(var(--anim-duration) + 3 * var(--anim-stagger)); }
body .slide.active[data-anim="stagger"] > *:nth-child(5) { animation-delay: calc(var(--anim-duration) + 4 * var(--anim-stagger)); }
body .slide.active[data-anim="stagger"] > *:nth-child(6) { animation-delay: calc(var(--anim-duration) + 5 * var(--anim-stagger)); }
body .slide.active[data-anim="stagger"] > *:nth-child(7) { animation-delay: calc(var(--anim-duration) + 6 * var(--anim-stagger)); }
body .slide.active[data-anim="stagger"] > *:nth-child(8) { animation-delay: calc(var(--anim-duration) + 7 * var(--anim-stagger)); }

/* Respect users who prefer reduced motion */
@media (prefers-reduced-motion: reduce) {
  body[data-transition] .slide.active,
  body .slide.active[data-anim] > * {
    animation: none !important;
  }
}
`;
