// templates-extra-4.js — 10 templates: geometric/abstract (4) + professional/elegant (4) + experimental (2)

const gfonts = (family) => `<link href="https://fonts.googleapis.com/css2?${family}&display=swap" rel="stylesheet">`;

function basicRender(ctx, opts = {}) {
  const { slide, isCover, esc, bullets, img, editable } = ctx;
  const e = (f) => editable ? `data-field="${f}"` : '';
  return `<section class="slide ${isCover ? 'cover' : ''}">
    ${opts.before ? opts.before(ctx) : ''}
    <h1 ${e('title')}>${esc(slide.title)}</h1>
    ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
    ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
    ${bullets(slide.bullets)}
    ${img(slide)}
    ${opts.after ? opts.after(ctx) : ''}
  </section>`;
}

// ============ GEOMETRIC / ABSTRACT (4) ============

const bauhaus = {
  id: 'bauhaus', name: 'Bauhaus', tag: 'Primary · Geometric',
  fonts: gfonts('family=Archivo:wght@400;700;900'),
  css: `
    body { background: #f5f0e8; color: #1a1a1a; font-family: 'Archivo', sans-serif; }
    .slide { padding: 7vmin; justify-content: center; position: relative; }
    .shape { position: absolute; pointer-events: none; }
    .circle-red { top: 8vmin; right: 10vmin; width: 120px; height: 120px; background: #e63946; border-radius: 50%; }
    .square-blue { bottom: 10vmin; right: 18vmin; width: 90px; height: 90px; background: #1d4e89; }
    .triangle-yellow { bottom: 8vmin; left: 10vmin; width: 0; height: 0; border-left: 60px solid transparent; border-right: 60px solid transparent; border-bottom: 100px solid #f5d547; }
    h1 { font-weight: 900; font-size: clamp(44px, 9vw, 84px); line-height: .95; letter-spacing: -.03em; margin-bottom: 18px; text-transform: uppercase; max-width: 65%; }
    .subtitle { font-weight: 700; font-size: clamp(16px, 2.2vw, 20px); margin-bottom: 22px; max-width: 65%; letter-spacing: .05em; text-transform: uppercase; color: #e63946; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.6; max-width: 65%; margin-bottom: 14px; font-weight: 400; }
    ul { list-style: none; max-width: 65%; }
    li { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.5; padding: 8px 0 8px 26px; position: relative; font-weight: 700; border-bottom: 2px solid #1a1a1a; }
    li::before { content: '\u25A0'; position: absolute; left: 0; color: #1d4e89; font-size: .85em; top: 10px; }
    li:nth-child(3n)::before { color: #e63946; }
    li:nth-child(3n+1)::before { color: #f5d547; }
    .slide img { max-width: 340px; max-height: 35vh; margin-top: 16px; filter: grayscale(1) contrast(1.1); border: 3px solid #1a1a1a; position: relative; z-index: 2; }
    .cover h1 { font-size: clamp(60px, 14vw, 140px); max-width: 100%; }
    .deck-progress { background: #e63946; height: 4px; }
  `,
  preview: () => `<div style="background:#f5f0e8;height:100%;padding:4px;position:relative">
    <div style="position:absolute;top:4px;right:6px;width:12px;height:12px;border-radius:50%;background:#e63946"></div>
    <div style="position:absolute;bottom:8px;right:12px;width:8px;height:8px;background:#1d4e89"></div>
    <div style="position:absolute;bottom:4px;left:4px;width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:10px solid #f5d547"></div>
    <div style="font-family:sans-serif;font-weight:900;font-size:11px;color:#1a1a1a;line-height:1;text-transform:uppercase">Form</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: () => `<div class="shape circle-red"></div><div class="shape square-blue"></div><div class="shape triangle-yellow"></div>`
  })
};

const memphis = {
  id: 'memphis', name: 'Memphis', tag: '80s · Playful',
  fonts: gfonts('family=Work+Sans:wght@400;700;900'),
  css: `
    body { background: #f7f0e3; color: #1a1a1a; font-family: 'Work Sans', sans-serif; overflow: hidden; }
    body::before { content: ''; position: fixed; inset: 0; background-image: radial-gradient(circle at 10% 10%, #00b5d8 4px, transparent 5px), radial-gradient(circle at 90% 90%, #ffb627 4px, transparent 5px); background-size: 60px 60px; opacity: .5; pointer-events: none; }
    .slide { padding: 7vmin; justify-content: center; position: relative; }
    .shape { position: absolute; pointer-events: none; }
    .squiggle { top: 6vmin; right: 10vmin; font-size: 80px; color: #ff3366; transform: rotate(15deg); font-weight: 900; line-height: 1; }
    .zigzag { bottom: 8vmin; left: 10vmin; width: 80px; height: 40px; background: repeating-linear-gradient(45deg, #00b5d8 0, #00b5d8 8px, transparent 8px, transparent 16px); }
    .triangle { top: 20vmin; left: 6vmin; width: 0; height: 0; border-left: 30px solid transparent; border-right: 30px solid transparent; border-bottom: 50px solid #ffb627; transform: rotate(-20deg); }
    h1 { font-weight: 900; font-size: clamp(44px, 9vw, 82px); line-height: .95; letter-spacing: -.02em; margin-bottom: 18px; color: #1a1a1a; position: relative; z-index: 2; }
    h1 span { color: #ff3366; }
    .subtitle { font-weight: 700; font-size: clamp(17px, 2.4vw, 22px); margin-bottom: 22px; color: #00b5d8; position: relative; z-index: 2; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.6; max-width: 700px; margin-bottom: 14px; position: relative; z-index: 2; }
    ul { list-style: none; max-width: 700px; display: flex; flex-wrap: wrap; gap: 8px; position: relative; z-index: 2; }
    li { font-size: clamp(13px, 1.7vw, 16px); padding: 6px 14px; background: #ffb627; color: #1a1a1a; border-radius: 20px; font-weight: 700; border: 3px solid #1a1a1a; }
    li:nth-child(even) { background: #00b5d8; color: #fff; }
    li:nth-child(3n) { background: #ff3366; color: #fff; }
    .slide img { max-width: 300px; max-height: 32vh; margin-top: 14px; border: 4px solid #1a1a1a; border-radius: 8px; position: relative; z-index: 2; filter: saturate(1.3); }
    .cover h1 { font-size: clamp(58px, 13vw, 130px); }
    .deck-progress { background: #ff3366; height: 4px; }
  `,
  preview: () => `<div style="background:#f7f0e3;height:100%;padding:4px;position:relative">
    <div style="position:absolute;top:2px;right:4px;color:#ff3366;font-weight:900;font-size:14px">~</div>
    <div style="position:absolute;bottom:2px;left:2px;width:10px;height:4px;background:repeating-linear-gradient(45deg,#00b5d8 0 2px,transparent 2px 4px)"></div>
    <div style="font-family:sans-serif;font-weight:900;font-size:11px;line-height:1">Fun<span style="color:#ff3366">!</span></div></div>`,
  render: (ctx) => {
    const { slide, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    const titleHtml = esc(slide.title).replace(/(\S+)$/, '<span>$1</span>');
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="shape squiggle">~</div>
      <div class="shape zigzag"></div>
      <div class="shape triangle"></div>
      <h1 ${e('title')}>${titleHtml}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`;
  }
};

const constructivist = {
  id: 'constructivist', name: 'Constructivist', tag: 'Soviet · Angular',
  fonts: gfonts('family=Oswald:wght@500;700&family=Russo+One'),
  css: `
    body { background: #e8dcc4; color: #1a1a1a; font-family: 'Oswald', sans-serif; }
    .slide { padding: 6vmin; justify-content: center; position: relative; }
    .slide::before { content: ''; position: absolute; top: 0; left: 0; width: 30%; height: 100%; background: #c8262c; clip-path: polygon(0 0, 100% 20%, 70% 100%, 0 80%); }
    .slide::after { content: ''; position: absolute; bottom: 0; right: 0; width: 50%; height: 40%; background: #000; clip-path: polygon(30% 0, 100% 0, 100% 100%, 0 100%); }
    h1 { font-family: 'Russo One', sans-serif; font-size: clamp(44px, 9vw, 82px); line-height: .92; text-transform: uppercase; letter-spacing: -.02em; margin-bottom: 18px; color: #1a1a1a; position: relative; z-index: 2; margin-left: 20%; }
    .subtitle { font-family: 'Oswald', sans-serif; font-weight: 700; font-size: clamp(17px, 2.3vw, 22px); margin-bottom: 22px; color: #c8262c; letter-spacing: .1em; text-transform: uppercase; position: relative; z-index: 2; margin-left: 20%; }
    .body { font-family: 'Oswald', sans-serif; font-size: clamp(15px, 1.9vw, 18px); line-height: 1.55; max-width: 620px; margin-left: 20%; margin-bottom: 14px; position: relative; z-index: 2; font-weight: 500; }
    ul { list-style: none; max-width: 620px; margin-left: 20%; position: relative; z-index: 2; counter-reset: c; }
    li { font-family: 'Oswald', sans-serif; font-weight: 500; font-size: clamp(14px, 1.8vw, 17px); line-height: 1.45; padding: 10px 14px 10px 50px; position: relative; background: #fff; border: 3px solid #1a1a1a; margin-bottom: 6px; counter-increment: c; }
    li::before { content: counter(c); position: absolute; left: 0; top: 0; bottom: 0; width: 40px; background: #c8262c; color: #fff; display: grid; place-items: center; font-family: 'Russo One', sans-serif; font-size: 1.2em; }
    .slide img { max-width: 320px; max-height: 35vh; margin-top: 16px; border: 4px solid #1a1a1a; filter: grayscale(1) contrast(1.2); position: relative; z-index: 2; margin-left: 20%; }
    .cover h1 { font-size: clamp(60px, 14vw, 140px); margin-left: 20%; }
    .deck-progress { background: #c8262c; height: 5px; }
  `,
  preview: () => `<div style="background:#e8dcc4;height:100%;padding:4px;position:relative;overflow:hidden">
    <div style="position:absolute;top:0;left:0;width:30%;height:100%;background:#c8262c;clip-path:polygon(0 0,100% 20%,70% 100%,0 80%)"></div>
    <div style="position:absolute;bottom:0;right:0;width:50%;height:40%;background:#000"></div>
    <div style="font-family:sans-serif;font-weight:900;font-size:11px;line-height:1;text-transform:uppercase;margin-left:30%;position:relative">Build</div></div>`,
  render: (ctx) => basicRender(ctx)
};

const mondrian = {
  id: 'mondrian', name: 'Mondrian', tag: 'De Stijl · Grid',
  fonts: gfonts('family=Archivo:wght@400;800'),
  css: `
    body { background: #f8f5ec; color: #000; font-family: 'Archivo', sans-serif; }
    .slide { padding: 0; display: none; }
    .slide.active { display: grid; grid-template-columns: 2fr 1fr 2fr; grid-template-rows: 1fr 2fr 1fr; gap: 8px; padding: 8px; }
    .slide > div { background: #fafaf5; padding: 18px; overflow: hidden; }
    .block-a { grid-column: 1 / 2; grid-row: 1 / 3; background: #d90429 !important; }
    .block-b { grid-column: 2 / 3; grid-row: 1 / 2; background: #003459 !important; }
    .block-c { grid-column: 3 / 4; grid-row: 1 / 2; background: #fafaf5; }
    .block-content { grid-column: 2 / 4; grid-row: 2 / 4; padding: 26px 32px !important; display: flex; flex-direction: column; justify-content: center; }
    .block-d { grid-column: 1 / 2; grid-row: 3 / 4; background: #fee440 !important; }
    h1 { font-weight: 800; font-size: clamp(36px, 7vw, 62px); line-height: .95; letter-spacing: -.02em; margin-bottom: 14px; color: #000; }
    .subtitle { font-weight: 400; font-size: clamp(15px, 1.9vw, 18px); margin-bottom: 18px; color: #444; }
    .body { font-size: clamp(14px, 1.7vw, 16px); line-height: 1.6; margin-bottom: 12px; }
    ul { list-style: none; }
    li { font-size: clamp(13px, 1.6vw, 15px); line-height: 1.55; padding: 4px 0 4px 22px; position: relative; font-weight: 500; }
    li::before { content: '\u25A0'; position: absolute; left: 0; top: 4px; color: #d90429; }
    .slide img { max-width: 100%; max-height: 100%; object-fit: cover; grid-column: 1 / 2; grid-row: 3 / 4; }
    .cover .block-content h1 { font-size: clamp(48px, 10vw, 90px); }
    .deck-progress { background: #d90429; height: 4px; }
    @media (max-width: 800px) { .slide.active { grid-template-columns: 1fr; grid-template-rows: auto auto auto auto; } .block-a,.block-b,.block-c,.block-d { grid-column: 1; grid-row: auto; min-height: 40px; } .block-content { grid-column: 1; grid-row: auto; padding: 18px !important; } }
  `,
  preview: () => `<div style="background:#f8f5ec;height:100%;padding:3px;display:grid;grid-template-columns:2fr 1fr 2fr;grid-template-rows:1fr 2fr 1fr;gap:1px">
    <div style="background:#d90429;grid-row:1 / 3"></div><div style="background:#003459"></div><div></div>
    <div style="grid-column:2 / 4;background:#fafaf5;padding:2px;font-family:sans-serif;font-weight:900;font-size:6px">Grid</div>
    <div style="background:#fee440"></div></div>`,
  render: (ctx) => {
    const { slide, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="block-a"></div>
      <div class="block-b"></div>
      <div class="block-c"></div>
      <div class="block-content">
        <h1 ${e('title')}>${esc(slide.title)}</h1>
        ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
        ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
        ${bullets(slide.bullets)}
      </div>
      ${img(slide) || `<div class="block-d"></div>`}
    </section>`;
  }
};

// ============ PROFESSIONAL / ELEGANT (4) ============

const luxury = {
  id: 'luxury', name: 'Luxury', tag: 'Refined · Gold',
  fonts: gfonts('family=Cormorant+Garamond:wght@300;400;600&family=Jost:wght@200;400'),
  css: `
    body { background: #0a0a0a; color: #d4c89a; font-family: 'Jost', sans-serif; font-weight: 200; }
    .slide { padding: 10vmin 12vmin; justify-content: center; }
    .slide::before { content: ''; position: absolute; top: 6vmin; left: 10vmin; right: 10vmin; height: 1px; background: linear-gradient(90deg, transparent, #d4af37, transparent); }
    .slide::after { content: ''; position: absolute; bottom: 6vmin; left: 10vmin; right: 10vmin; height: 1px; background: linear-gradient(90deg, transparent, #d4af37, transparent); }
    h1 { font-family: 'Cormorant Garamond', serif; font-size: clamp(40px, 8vw, 76px); font-weight: 300; line-height: 1.1; margin-bottom: 18px; letter-spacing: .02em; color: #e6d6a8; }
    h1 em { color: #d4af37; font-style: italic; font-weight: 400; }
    .subtitle { font-size: clamp(13px, 1.6vw, 16px); letter-spacing: .4em; text-transform: uppercase; color: #8a7848; margin-bottom: 28px; font-weight: 400; }
    .body { font-family: 'Cormorant Garamond', serif; font-size: clamp(17px, 2.2vw, 21px); line-height: 1.7; max-width: 720px; margin-bottom: 14px; color: #c4b68a; font-weight: 400; }
    ul { list-style: none; max-width: 720px; }
    li { font-family: 'Cormorant Garamond', serif; font-size: clamp(16px, 2vw, 19px); line-height: 1.8; padding: 8px 0 8px 34px; position: relative; border-bottom: 1px solid rgba(212,175,55,0.15); }
    li::before { content: '\u2726'; position: absolute; left: 0; top: 10px; color: #d4af37; font-size: .8em; }
    .slide img { max-width: 380px; max-height: 40vh; margin-top: 22px; border: 1px solid #d4af37; padding: 6px; filter: sepia(0.1) brightness(.95); }
    .cover h1 { font-size: clamp(50px, 11vw, 110px); }
    .monogram { font-family: 'Cormorant Garamond', serif; font-size: clamp(16px, 2vw, 19px); color: #d4af37; letter-spacing: .3em; margin-bottom: 16px; font-style: italic; }
    .deck-progress { background: #d4af37; height: 1px; }
  `,
  preview: () => `<div style="background:#0a0a0a;height:100%;padding:6px;display:flex;flex-direction:column;justify-content:center;text-align:center">
    <div style="font-family:serif;font-style:italic;font-size:6px;color:#d4af37;letter-spacing:2px">MAISON</div>
    <div style="font-family:serif;font-size:12px;color:#e6d6a8;font-weight:300;line-height:1;margin-top:2px">Lux<span style="color:#d4af37;font-style:italic">ury</span></div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ isCover }) => isCover ? `<div class="monogram">\u2727 \u2727 \u2727</div>` : ''
  })
};

const monoRefined = {
  id: 'mono-refined', name: 'Mono Refined', tag: 'Black & white',
  fonts: gfonts('family=Inter:wght@300;500;700'),
  css: `
    body { background: #fff; color: #0a0a0a; font-family: 'Inter', sans-serif; }
    .slide { padding: 10vmin 12vmin; justify-content: center; }
    .rule { width: 40px; height: 2px; background: #0a0a0a; margin-bottom: 22px; }
    h1 { font-size: clamp(44px, 9vw, 84px); font-weight: 300; line-height: .95; letter-spacing: -.04em; margin-bottom: 20px; }
    h1 strong { font-weight: 700; }
    .subtitle { font-size: clamp(17px, 2.3vw, 22px); color: #525252; margin-bottom: 24px; font-weight: 300; max-width: 800px; line-height: 1.4; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.7; max-width: 700px; margin-bottom: 14px; color: #333; font-weight: 400; }
    ul { list-style: none; max-width: 700px; counter-reset: n; }
    li { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.6; padding: 14px 0; border-top: 1px solid #e5e5e5; display: grid; grid-template-columns: 48px 1fr; gap: 16px; counter-increment: n; font-weight: 400; }
    li::before { content: counter(n, decimal-leading-zero); color: #0a0a0a; font-weight: 700; font-size: .85em; padding-top: 2px; }
    li:last-child { border-bottom: 1px solid #e5e5e5; }
    .slide img { max-width: 400px; max-height: 40vh; margin-top: 22px; filter: grayscale(1); border-radius: 2px; }
    .meta { position: absolute; top: 6vmin; left: 12vmin; font-size: 11px; letter-spacing: .25em; text-transform: uppercase; color: #737373; font-weight: 500; }
    .meta .sep { color: #d4d4d4; margin: 0 8px; }
    .cover h1 { font-size: clamp(56px, 12vw, 120px); }
    .deck-progress { background: #0a0a0a; height: 1px; }
  `,
  preview: () => `<div style="background:#fff;height:100%;padding:8px;display:flex;flex-direction:column;justify-content:center">
    <div style="width:14px;height:2px;background:#0a0a0a;margin-bottom:4px"></div>
    <div style="font-family:sans-serif;font-size:10px;line-height:.9;font-weight:300"><span style="font-weight:700">Less</span><br>is more</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ project, index, total }) => {
      const esc = (s) => String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
      return `<div class="meta">${esc(project.topic).slice(0,30)}<span class="sep">\u2500</span>${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}</div><div class="rule"></div>`;
    }
  })
};

const corporate = {
  id: 'corporate', name: 'Corporate', tag: 'Clean · Business',
  fonts: gfonts('family=IBM+Plex+Sans:wght@400;500;700'),
  css: `
    body { background: #fafafa; color: #1a1a2e; font-family: 'IBM Plex Sans', sans-serif; }
    .slide { padding: 7vmin 9vmin; }
    .header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 14px; border-bottom: 2px solid #0066cc; margin-bottom: 28px; }
    .brand { font-weight: 700; font-size: 14px; letter-spacing: .1em; text-transform: uppercase; color: #0066cc; }
    .page-ref { font-size: 12px; color: #666; letter-spacing: .05em; }
    h1 { font-size: clamp(32px, 6.5vw, 58px); font-weight: 700; line-height: 1.1; margin-bottom: 14px; letter-spacing: -.02em; }
    .subtitle { color: #555; font-size: clamp(16px, 2.1vw, 20px); margin-bottom: 22px; font-weight: 500; max-width: 820px; line-height: 1.4; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.65; max-width: 820px; margin-bottom: 14px; color: #222; }
    ul { list-style: none; max-width: 820px; display: grid; gap: 10px; }
    li { font-size: clamp(14px, 1.8vw, 16px); line-height: 1.55; padding: 14px 18px; background: #fff; border-left: 4px solid #0066cc; box-shadow: 0 2px 6px rgba(0,0,0,0.05); border-radius: 0 4px 4px 0; }
    .slide img { max-width: 480px; max-height: 40vh; margin-top: 18px; border-radius: 4px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
    .footer { position: absolute; bottom: 4vmin; left: 9vmin; right: 9vmin; display: flex; justify-content: space-between; font-size: 11px; color: #999; border-top: 1px solid #e5e5e5; padding-top: 10px; }
    .cover h1 { font-size: clamp(48px, 10vw, 96px); }
    .deck-progress { background: #0066cc; height: 3px; }
  `,
  preview: () => `<div style="background:#fafafa;height:100%;padding:6px">
    <div style="border-bottom:2px solid #0066cc;padding-bottom:2px;color:#0066cc;font-family:sans-serif;font-weight:700;font-size:5px;letter-spacing:1px">COMPANY</div>
    <div style="font-family:sans-serif;font-weight:700;font-size:11px;margin-top:4px;line-height:1">Strategy</div>
    <div style="font-size:4px;color:#666;margin-top:2px">Q4 Review</div></div>`,
  render: (ctx) => {
    const { slide, project, index, total, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="header">
        <div class="brand">\u25FC ${esc(project.topic).slice(0, 30).toUpperCase()}</div>
        <div class="page-ref">${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}</div>
      </div>
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      <div class="footer"><span>Internal / Confidential</span><span>${new Date(project.createdAt).toISOString().slice(0,10)}</span></div>
    </section>`;
  }
};

const consulting = {
  id: 'consulting', name: 'Consulting', tag: 'McKinsey-style',
  fonts: gfonts('family=Source+Sans+3:wght@400;600;700&family=Source+Serif+4:wght@600'),
  css: `
    body { background: #fff; color: #0c2340; font-family: 'Source Sans 3', sans-serif; }
    .slide { padding: 6vmin 8vmin 10vmin; }
    .slide::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 6px; background: linear-gradient(90deg, #0c2340 0%, #0c2340 70%, #d4a017 70%, #d4a017 100%); }
    .title-line { font-size: clamp(20px, 2.8vw, 24px); font-weight: 700; color: #0c2340; padding-bottom: 6px; border-bottom: 1px solid #d4a017; margin-bottom: 22px; max-width: 1000px; line-height: 1.2; }
    h1 { font-family: 'Source Serif 4', serif; font-size: clamp(28px, 5.5vw, 46px); font-weight: 600; line-height: 1.15; margin-bottom: 18px; color: #0c2340; }
    .subtitle { font-size: clamp(15px, 1.9vw, 18px); color: #555; margin-bottom: 22px; font-style: italic; max-width: 820px; }
    .body { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.65; max-width: 820px; margin-bottom: 14px; }
    ul { list-style: none; max-width: 860px; }
    li { font-size: clamp(13px, 1.6vw, 16px); line-height: 1.6; padding: 8px 0 8px 36px; position: relative; border-bottom: 1px dotted #ccc; }
    li::before { content: '\u25B6'; position: absolute; left: 10px; top: 8px; color: #d4a017; font-size: .8em; }
    .slide img { max-width: 420px; max-height: 40vh; margin-top: 16px; border: 1px solid #e5e5e5; }
    .footer-bar { position: absolute; bottom: 3vmin; left: 8vmin; right: 8vmin; display: flex; justify-content: space-between; font-size: 10px; color: #999; letter-spacing: .1em; text-transform: uppercase; }
    .cover h1 { font-size: clamp(42px, 9vw, 80px); }
    .deck-progress { background: #d4a017; }
  `,
  preview: () => `<div style="background:#fff;height:100%;padding:4px">
    <div style="height:3px;background:linear-gradient(90deg,#0c2340 70%,#d4a017 70%);margin-bottom:3px"></div>
    <div style="font-family:sans-serif;font-weight:700;font-size:6px;color:#0c2340;border-bottom:1px solid #d4a017;padding-bottom:1px">Key finding: revenue</div>
    <div style="font-family:serif;font-size:9px;color:#0c2340;margin-top:3px;line-height:1">Insight</div></div>`,
  render: (ctx) => {
    const { slide, project, index, total, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      ${!isCover && slide.subtitle ? `<div class="title-line" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${isCover && slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
      <div class="footer-bar"><span>${esc(project.topic).slice(0,35)}</span><span>${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}</span></div>
    </section>`;
  }
};

// ============ EXPERIMENTAL (2) ============

const glitch = {
  id: 'glitch', name: 'Glitch', tag: 'Broken · Cyber',
  fonts: gfonts('family=VT323&family=Space+Mono:wght@700'),
  css: `
    body { background: #0a0014; color: #fff; font-family: 'Space Mono', monospace; overflow: hidden; }
    body::before { content: ''; position: fixed; inset: 0; background-image: repeating-linear-gradient(0deg, transparent 0, transparent 2px, rgba(255,0,128,0.03) 3px, rgba(0,255,255,0.03) 4px); pointer-events: none; z-index: 100; }
    .slide { padding: 7vmin; justify-content: center; }
    h1 { font-size: clamp(40px, 8vw, 76px); font-weight: 700; line-height: 1; text-transform: uppercase; letter-spacing: -.02em; margin-bottom: 20px; position: relative; color: #fff; }
    h1::before, h1::after { content: attr(data-text); position: absolute; top: 0; left: 0; width: 100%; }
    h1::before { color: #ff0080; transform: translate(-2px, 0); mix-blend-mode: screen; animation: glitch-1 2s infinite; clip-path: inset(0 0 50% 0); }
    h1::after { color: #00ffff; transform: translate(2px, 0); mix-blend-mode: screen; animation: glitch-2 2.5s infinite; clip-path: inset(50% 0 0 0); }
    @keyframes glitch-1 { 0%,90%,100%{transform:translate(-2px,0)} 92%{transform:translate(-5px,1px)} 94%{transform:translate(-1px,-1px)} 96%{transform:translate(-3px,0)} }
    @keyframes glitch-2 { 0%,88%,100%{transform:translate(2px,0)} 90%{transform:translate(4px,-1px)} 93%{transform:translate(1px,1px)} 95%{transform:translate(3px,0)} }
    .subtitle { font-family: 'VT323', monospace; color: #00ffff; font-size: clamp(20px, 2.8vw, 26px); margin-bottom: 20px; }
    .subtitle::before { content: '> '; color: #ff0080; }
    .body { font-size: clamp(14px, 1.7vw, 16px); line-height: 1.7; max-width: 820px; margin-bottom: 14px; color: #e0e0e0; }
    ul { list-style: none; max-width: 820px; }
    li { font-size: clamp(13px, 1.6vw, 15px); line-height: 1.6; padding: 8px 0 8px 30px; position: relative; color: #e0e0e0; }
    li::before { content: '[\u2713]'; position: absolute; left: 0; color: #ff0080; font-family: 'VT323', monospace; font-size: 1.1em; }
    .slide img { max-width: 380px; max-height: 40vh; margin-top: 18px; border: 1px solid #ff0080; filter: hue-rotate(15deg) saturate(1.3); }
    .err { position: absolute; top: 4vmin; right: 6vmin; font-family: 'VT323', monospace; color: #ff0080; font-size: 12px; letter-spacing: .1em; }
    .err::before { content: '\u26A0 '; }
    .cover h1 { font-size: clamp(50px, 11vw, 100px); }
    .deck-progress { background: linear-gradient(90deg, #ff0080, #00ffff); height: 3px; }
  `,
  preview: () => `<div style="background:#0a0014;height:100%;padding:8px;position:relative">
    <div style="color:#fff;font-family:monospace;font-weight:700;font-size:10px;line-height:1">ERR<span style="color:#ff0080">OR</span></div>
    <div style="color:#00ffff;font-family:monospace;font-size:5px;margin-top:2px">&gt; glitch.exe</div></div>`,
  render: (ctx) => {
    const { slide, index, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="err">ERR_${String(index+1).padStart(4,'0')}</div>
      <h1 data-text="${esc(slide.title)}" ${e('title')}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`;
  }
};

const paperCutout = {
  id: 'paper-cutout', name: 'Paper Cutout', tag: 'Layered paper',
  fonts: gfonts('family=Fraunces:ital,opsz,wght@0,9..144,700;1,9..144,400&family=Inter:wght@500'),
  css: `
    body { background: #f8f2e7; color: #2a2118; font-family: 'Inter', sans-serif; }
    .slide { padding: 5vmin; position: relative; }
    .layer { position: absolute; box-shadow: 0 6px 18px rgba(0,0,0,0.1); }
    .layer.l1 { top: 8vmin; right: 8vmin; width: 260px; height: 260px; background: #fcd7a3; border-radius: 50%; z-index: 1; }
    .layer.l2 { bottom: 8vmin; left: 8vmin; width: 200px; height: 80px; background: #a5b9d4; border-radius: 8px; z-index: 1; transform: rotate(-5deg); }
    .layer.l3 { top: 30vmin; left: 12vmin; width: 80px; height: 80px; background: #d8b4a0; transform: rotate(25deg); z-index: 1; }
    .content { background: #fff; padding: 7vmin 6vmin; box-shadow: 0 10px 40px rgba(0,0,0,0.08); position: relative; z-index: 2; max-width: 750px; margin: 8vmin auto; }
    h1 { font-family: 'Fraunces', serif; font-size: clamp(36px, 7vw, 62px); font-weight: 700; line-height: 1.05; margin-bottom: 16px; letter-spacing: -.02em; }
    .subtitle { font-family: 'Fraunces', serif; font-style: italic; font-size: clamp(17px, 2.3vw, 22px); color: #8a6b4f; margin-bottom: 22px; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.7; margin-bottom: 14px; }
    ul { list-style: none; }
    li { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.7; padding: 6px 0 6px 28px; position: relative; border-bottom: 1px solid #f0e8dc; }
    li::before { content: '\u25CF'; position: absolute; left: 0; top: 6px; color: #d8b4a0; }
    li:nth-child(2)::before { color: #a5b9d4; }
    li:nth-child(3)::before { color: #fcd7a3; }
    .slide img { max-width: 320px; max-height: 32vh; margin-top: 16px; border-radius: 8px; box-shadow: 0 8px 20px rgba(0,0,0,0.15); }
    .cover h1 { font-size: clamp(44px, 10vw, 94px); }
    .deck-progress { background: #d8b4a0; }
  `,
  preview: () => `<div style="background:#f8f2e7;height:100%;padding:2px;position:relative">
    <div style="position:absolute;top:2px;right:2px;width:14px;height:14px;border-radius:50%;background:#fcd7a3"></div>
    <div style="background:#fff;padding:3px;margin:6px;position:relative;box-shadow:0 2px 4px rgba(0,0,0,.1)">
      <div style="font-family:serif;font-weight:700;font-size:9px;color:#2a2118;line-height:1">Paper</div>
      <div style="font-family:serif;font-style:italic;font-size:5px;color:#8a6b4f">layered</div></div></div>`,
  render: (ctx) => {
    const { slide, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="layer l1"></div>
      <div class="layer l2"></div>
      <div class="layer l3"></div>
      <div class="content">
        <h1 ${e('title')}>${esc(slide.title)}</h1>
        ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
        ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
        ${bullets(slide.bullets)}
        ${img(slide)}
      </div>
    </section>`;
  }
};

export const TEMPLATES_EXTRA_4 = [bauhaus, memphis, constructivist, mondrian, luxury, monoRefined, corporate, consulting, glitch, paperCutout];
