// templates-extra-1.js — 10 templates: editorial/print (5) + tech/digital (5)

const gfonts = (family) => `<link href="https://fonts.googleapis.com/css2?${family}&display=swap" rel="stylesheet">`;

function basicRender(ctx, opts = {}) {
  const { slide, isCover, esc, bullets, img, editable } = ctx;
  const e = (f) => editable ? `data-field="${f}"` : '';
  return `<section class="slide ${isCover ? 'cover' : ''}">
    ${opts.before ? opts.before(ctx) : ''}
    <h1 ${e('title')}>${esc(slide.title)}</h1>
    ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
    ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
    ${bullets(slide.bullets)}
    ${img(slide)}
    ${opts.after ? opts.after(ctx) : ''}
  </section>`;
}

function toRoman(n) {
  const rn = ['','I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII','XIV','XV','XVI','XVII','XVIII','XIX','XX'];
  return rn[n] || String(n);
}

// ============ EDITORIAL / PRINT (5) ============

const newspaper = {
  id: 'newspaper', name: 'Newspaper', tag: 'Broadsheet',
  fonts: gfonts('family=Playfair+Display:wght@700;900&family=Old+Standard+TT:ital,wght@0,400;0,700;1,400'),
  css: `
    body { background: #f4f0e8; color: #1a1a1a; font-family: 'Old Standard TT', serif; }
    .slide { padding: 5vmin 6vmin; }
    .masthead { border-top: 4px double #000; border-bottom: 4px double #000; padding: 6px 0; text-align: center; margin-bottom: 18px; font-family: 'Playfair Display', serif; font-weight: 900; font-size: clamp(22px, 3.5vw, 32px); letter-spacing: .05em; }
    .dateline { display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 14px; text-transform: uppercase; letter-spacing: .1em; font-style: italic; }
    h1 { font-family: 'Playfair Display', serif; font-size: clamp(36px, 6.5vw, 64px); font-weight: 900; line-height: 1.02; text-align: center; margin-bottom: 10px; }
    .subtitle { font-style: italic; font-size: clamp(16px, 2vw, 19px); text-align: center; margin-bottom: 18px; color: #444; border-bottom: 1px solid #999; padding-bottom: 12px; }
    .body { font-size: clamp(14px, 1.7vw, 17px); line-height: 1.6; column-count: 2; column-gap: 30px; margin-bottom: 12px; }
    ul { list-style: none; columns: 2; column-gap: 24px; }
    li { font-size: clamp(13px, 1.6vw, 16px); line-height: 1.55; padding: 4px 0 4px 18px; position: relative; break-inside: avoid; }
    li::before { content: '\u25A0'; position: absolute; left: 0; color: #000; font-size: 8px; top: 8px; }
    .cover { text-align: center; justify-content: center; }
    .cover h1 { font-size: clamp(48px, 10vw, 92px); }
    .slide img { max-width: 70%; max-height: 35vh; align-self: center; margin-top: 14px; filter: grayscale(1) contrast(1.05); }
    .deck-progress { background: #000; height: 2px; }
  `,
  preview: () => `<div style="background:#f4f0e8;height:100%;padding:6px;font-family:serif">
    <div style="border-top:2px double #000;border-bottom:2px double #000;text-align:center;font-weight:900;font-size:8px;padding:1px 0">THE DAILY</div>
    <div style="font-weight:900;font-size:7px;line-height:1;margin-top:4px;text-align:center">BREAKING<br>NEWS</div>
    <div style="columns:2;font-size:4px;color:#555;margin-top:3px;line-height:1.3">Lorem ipsum dolor sit amet adipiscing elit.</div></div>`,
  render: (ctx) => {
    const { slide, project, index, total, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="masthead">${esc(project.topic).slice(0,40).toUpperCase()}</div>
      <div class="dateline"><span>Vol. I, No. ${String(index+1)}</span><span>Est. ${new Date(project.createdAt).getFullYear()}</span><span>Page ${index+1}</span></div>
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`;
  }
};

const magazine = {
  id: 'magazine', name: 'Magazine', tag: 'Editorial spread',
  fonts: gfonts('family=Abril+Fatface&family=Lora:wght@400;700'),
  css: `
    body { background: #faf6f0; color: #1a1a1a; font-family: 'Lora', serif; }
    .slide { padding: 6vmin 8vmin; display: none; }
    .slide.active { display: grid; grid-template-columns: 1fr 1fr; grid-template-rows: auto 1fr; gap: 30px 40px; }
    .header { grid-column: 1 / 3; display: flex; justify-content: space-between; padding-bottom: 12px; border-bottom: 1px solid #1a1a1a; font-size: 11px; letter-spacing: .3em; text-transform: uppercase; font-weight: 700; }
    h1 { grid-column: 1; font-family: 'Abril Fatface', serif; font-size: clamp(36px, 7vw, 70px); line-height: .95; letter-spacing: -.02em; color: #c03030; }
    .subtitle { grid-column: 1; font-style: italic; font-size: clamp(16px, 2vw, 20px); color: #666; margin-top: -8px; }
    .body { grid-column: 2; font-size: clamp(14px, 1.7vw, 17px); line-height: 1.7; }
    .body::first-letter { font-family: 'Abril Fatface', serif; font-size: 5em; float: left; line-height: .9; padding: 5px 8px 0 0; color: #c03030; }
    ul { grid-column: 2; list-style: none; counter-reset: ln; }
    li { font-size: clamp(13px, 1.6vw, 16px); line-height: 1.65; padding: 6px 0; border-bottom: 1px solid #e8e0d4; }
    li::before { content: counter(ln, upper-roman) '. '; counter-increment: ln; color: #c03030; font-weight: 700; }
    .slide img { grid-column: 2; max-width: 100%; max-height: 60vh; object-fit: cover; }
    .cover h1 { font-size: clamp(52px, 11vw, 116px); grid-column: 1 / 3; text-align: center; }
    .cover .subtitle { grid-column: 1 / 3; text-align: center; }
    .deck-progress { background: #c03030; }
    @media (max-width: 800px) { .slide.active { grid-template-columns: 1fr; } h1, .subtitle, .body, ul, .slide img { grid-column: 1; } }
  `,
  preview: () => `<div style="background:#faf6f0;height:100%;padding:6px;display:grid;grid-template-columns:1fr 1fr;gap:4px">
    <div style="font-family:serif;font-size:14px;font-weight:900;color:#c03030;line-height:1">Issue</div>
    <div style="background:#ddd"></div>
    <div style="font-size:4px;color:#555;line-height:1.3">Column text flows narrow.</div>
    <div style="font-size:4px;color:#555">I. Item<br>II. Item</div></div>`,
  render: (ctx) => {
    const { slide, project, index, total, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="header"><span>${esc(project.topic).slice(0,30)}</span><span>Issue ${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}</span></div>
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`;
  }
};

const typewriter = {
  id: 'typewriter', name: 'Typewriter', tag: 'Draft · Raw',
  fonts: gfonts('family=Special+Elite&family=Courier+Prime:wght@400;700'),
  css: `
    body { background: #f3ecdc; color: #2a2a20; font-family: 'Courier Prime', monospace; background-image: repeating-linear-gradient(90deg, transparent 0, transparent 40px, rgba(139,119,80,0.02) 40px, rgba(139,119,80,0.02) 41px); }
    .slide { padding: 7vmin 8vmin; filter: contrast(1.05); }
    h1 { font-family: 'Special Elite', serif; font-size: clamp(30px, 5.5vw, 50px); line-height: 1.1; margin-bottom: 18px; letter-spacing: -.01em; }
    h1::before { content: '> '; opacity: .4; }
    .subtitle { font-style: italic; font-size: clamp(15px, 1.8vw, 18px); margin-bottom: 18px; opacity: .7; }
    .body { font-size: clamp(14px, 1.7vw, 17px); line-height: 1.85; margin-bottom: 10px; max-width: 800px; }
    ul { list-style: none; max-width: 800px; }
    li { font-size: clamp(13px, 1.6vw, 16px); line-height: 1.85; padding-left: 30px; position: relative; }
    li::before { content: '[ ]'; position: absolute; left: 0; font-family: 'Special Elite', serif; }
    .slide img { max-width: 380px; max-height: 40vh; margin-top: 16px; filter: sepia(1) contrast(1.1); border: 1px solid #8b7750; }
    .stamp { position: absolute; top: 4vmin; right: 6vmin; font-family: 'Special Elite', serif; color: #8b0000; opacity: .6; border: 2px solid #8b0000; padding: 4px 10px; transform: rotate(-8deg); font-size: 11px; letter-spacing: .2em; }
    .deck-progress { background: #8b7750; height: 2px; }
  `,
  preview: () => `<div style="background:#f3ecdc;height:100%;padding:8px;font-family:'Courier New',monospace">
    <div style="font-size:8px;font-weight:700">&gt; DRAFT</div>
    <div style="font-size:5px;line-height:1.8;margin-top:4px;color:#333">[ ] item one<br>[ ] item two<br>[ ] item three</div>
    <div style="color:#8b0000;border:1px solid #8b0000;padding:1px 3px;font-size:5px;display:inline-block;margin-top:4px;transform:rotate(-5deg)">DRAFT</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ isCover }) => !isCover ? `<div class="stamp">DRAFT</div>` : ''
  })
};

const zine = {
  id: 'zine', name: 'Zine', tag: 'DIY · Punk',
  fonts: gfonts('family=Bungee&family=Special+Elite'),
  css: `
    body { background: #fbf3d8; color: #111; font-family: 'Special Elite', serif; }
    .slide { padding: 5vmin; background-image: radial-gradient(circle at 1px 1px, rgba(0,0,0,0.15) 1px, transparent 0); background-size: 6px 6px; }
    h1 { font-family: 'Bungee', sans-serif; font-size: clamp(34px, 7vw, 64px); line-height: 1; background: #000; color: #fbf3d8; display: inline-block; padding: 4px 14px; transform: rotate(-1.5deg); margin-bottom: 18px; box-shadow: 8px 8px 0 #ff006a; }
    .subtitle { display: inline-block; background: #ff006a; color: #fff; padding: 3px 10px; font-family: 'Bungee', sans-serif; font-size: clamp(16px, 2.2vw, 22px); transform: rotate(1deg); margin-bottom: 20px; }
    .body { font-size: clamp(15px, 1.9vw, 18px); line-height: 1.6; background: #fff; padding: 10px 14px; border: 2px solid #000; max-width: 700px; margin-bottom: 12px; transform: rotate(.5deg); }
    ul { list-style: none; max-width: 700px; }
    li { font-size: clamp(14px, 1.8vw, 17px); line-height: 1.5; padding: 8px 12px; background: #fff; border: 2px solid #000; margin-bottom: 6px; transform: rotate(-.8deg); font-weight: 700; }
    li:nth-child(even) { background: #fbf3d8; transform: rotate(.6deg); }
    li::before { content: '\u2605 '; color: #ff006a; }
    .slide img { max-width: 300px; max-height: 35vh; border: 4px solid #000; transform: rotate(-2deg); margin-top: 10px; filter: grayscale(1) contrast(1.2); box-shadow: 6px 6px 0 #000; }
    .cover h1 { font-size: clamp(50px, 12vw, 110px); transform: rotate(-3deg); }
    .torn { position: absolute; top: 3vmin; right: 3vmin; background: #000; color: #fbf3d8; padding: 3px 8px; font-family: 'Bungee', sans-serif; font-size: 10px; transform: rotate(5deg); }
    .deck-progress { background: #ff006a; height: 5px; }
  `,
  preview: () => `<div style="background:#fbf3d8;height:100%;padding:6px;position:relative">
    <div style="background:#000;color:#fbf3d8;display:inline-block;padding:2px 4px;font-family:sans-serif;font-weight:900;font-size:8px;transform:rotate(-3deg)">ZINE!</div>
    <div style="background:#ff006a;color:#fff;display:inline-block;padding:1px 3px;font-family:sans-serif;font-weight:900;font-size:5px;margin-top:4px;transform:rotate(2deg)">DIY</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ index }) => `<div class="torn">#${String(index+1).padStart(2,'0')}</div>`
  })
};

const manifesto = {
  id: 'manifesto', name: 'Manifesto', tag: 'Bold declarations',
  fonts: gfonts('family=Antonio:wght@400;700&family=Cormorant+Garamond:ital,wght@0,400;1,400'),
  css: `
    body { background: #1a1a1a; color: #f0e9d9; font-family: 'Cormorant Garamond', serif; }
    .slide { padding: 8vmin 10vmin; justify-content: center; align-items: flex-start; }
    h1 { font-family: 'Antonio', sans-serif; font-size: clamp(52px, 11vw, 130px); font-weight: 700; line-height: .85; text-transform: uppercase; letter-spacing: -.03em; margin-bottom: 26px; color: #ff4d1f; }
    .subtitle { font-style: italic; font-size: clamp(20px, 2.8vw, 30px); line-height: 1.3; margin-bottom: 22px; max-width: 800px; border-left: 3px solid #ff4d1f; padding-left: 20px; }
    .body { font-size: clamp(17px, 2.3vw, 22px); line-height: 1.5; max-width: 800px; font-style: italic; margin-bottom: 14px; }
    ul { list-style: none; max-width: 800px; counter-reset: m; }
    li { font-size: clamp(17px, 2.3vw, 22px); line-height: 1.4; padding: 12px 0 12px 70px; position: relative; border-top: 1px solid #333; counter-increment: m; }
    li::before { content: counter(m, decimal-leading-zero); position: absolute; left: 0; top: 12px; font-family: 'Antonio', sans-serif; font-weight: 700; font-size: 40px; color: #ff4d1f; line-height: 1; }
    .cover h1 { font-size: clamp(70px, 16vw, 180px); }
    .article { font-family: 'Antonio', sans-serif; text-transform: uppercase; letter-spacing: .3em; font-size: 13px; color: #ff4d1f; margin-bottom: 10px; font-weight: 700; }
    .slide img { max-width: 380px; max-height: 35vh; margin-top: 20px; filter: grayscale(1) contrast(1.2); border: 1px solid #ff4d1f; }
    .deck-progress { background: #ff4d1f; height: 4px; }
  `,
  preview: () => `<div style="background:#1a1a1a;height:100%;padding:8px">
    <div style="font-family:sans-serif;font-size:4px;color:#ff4d1f;letter-spacing:1px;font-weight:700">ARTICLE I</div>
    <div style="font-family:sans-serif;font-size:14px;font-weight:900;color:#ff4d1f;line-height:.85;margin-top:2px">DOWN WITH</div>
    <div style="font-family:sans-serif;font-size:14px;font-weight:900;color:#f0e9d9;line-height:.85">STATUS QUO</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ index, isCover }) => !isCover ? `<div class="article">Article ${toRoman(index)}</div>` : ''
  })
};

// ============ TECH / DIGITAL (5) ============

const monoDev = {
  id: 'mono-dev', name: 'Mono Dev', tag: 'Developer · Mono',
  fonts: gfonts('family=IBM+Plex+Mono:wght@400;500;700'),
  css: `
    body { background: #fafafa; color: #18181b; font-family: 'IBM Plex Mono', monospace; }
    .slide { padding: 7vmin; }
    .tag { display: inline-block; font-size: 11px; background: #18181b; color: #fafafa; padding: 3px 8px; margin-bottom: 18px; letter-spacing: .05em; }
    h1 { font-size: clamp(32px, 6vw, 56px); font-weight: 700; line-height: 1.1; margin-bottom: 20px; letter-spacing: -.02em; }
    h1::before { content: '// '; color: #71717a; font-weight: 400; }
    .subtitle { color: #52525b; font-size: clamp(16px, 2vw, 19px); margin-bottom: 22px; font-weight: 400; }
    .body { font-size: clamp(14px, 1.7vw, 17px); line-height: 1.7; max-width: 800px; margin-bottom: 12px; color: #27272a; }
    ul { list-style: none; max-width: 800px; background: #f4f4f5; border: 1px solid #e4e4e7; border-radius: 4px; padding: 16px; counter-reset: ln; }
    li { font-size: clamp(13px, 1.6vw, 15px); line-height: 1.7; padding: 4px 0 4px 36px; position: relative; color: #27272a; counter-increment: ln; }
    li::before { content: counter(ln, decimal); position: absolute; left: 0; color: #a1a1aa; width: 28px; text-align: right; border-right: 1px solid #e4e4e7; padding-right: 8px; }
    .slide img { max-width: 480px; max-height: 45vh; margin-top: 20px; border: 1px solid #e4e4e7; border-radius: 4px; }
    .cover h1 { font-size: clamp(42px, 9vw, 78px); }
    .deck-progress { background: #18181b; height: 2px; }
  `,
  preview: () => `<div style="background:#fafafa;height:100%;padding:8px;font-family:monospace">
    <div style="background:#18181b;color:#fafafa;padding:1px 3px;font-size:5px;display:inline-block">// doc.md</div>
    <div style="font-weight:700;font-size:10px;margin-top:4px">// main()</div>
    <div style="font-size:4px;color:#555;margin-top:2px;line-height:1.6">1 | item<br>2 | item<br>3 | item</div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ index }) => `<div class="tag">slide_${String(index+1).padStart(2,'0')}.md</div>`
  })
};

const notionLike = {
  id: 'notion', name: 'Clean Docs', tag: 'Notion-style',
  fonts: gfonts('family=Inter:wght@400;500;700'),
  css: `
    body { background: #ffffff; color: #37352f; font-family: 'Inter', -apple-system, sans-serif; }
    .slide { padding: 8vmin 10vmin; max-width: 1000px; margin: 0 auto; left: 0; right: 0; }
    .emoji { font-size: clamp(44px, 7vw, 70px); margin-bottom: 14px; line-height: 1; }
    h1 { font-size: clamp(32px, 5.5vw, 50px); font-weight: 700; line-height: 1.1; margin-bottom: 12px; letter-spacing: -.02em; }
    .subtitle { color: #787774; font-size: clamp(15px, 1.9vw, 18px); margin-bottom: 24px; line-height: 1.5; }
    .body { font-size: clamp(15px, 1.8vw, 17px); line-height: 1.7; margin-bottom: 14px; }
    ul { list-style: none; padding-left: 0; }
    li { font-size: clamp(14px, 1.7vw, 16px); line-height: 1.7; padding: 4px 0 4px 26px; position: relative; }
    li::before { content: '\u2022'; position: absolute; left: 6px; top: 4px; color: #787774; font-size: 18px; }
    .slide img { max-width: 600px; max-height: 40vh; margin-top: 24px; border-radius: 6px; }
    .breadcrumb { font-size: 12px; color: #787774; margin-bottom: 8px; }
    .deck-progress { background: #37352f; height: 2px; }
  `,
  preview: () => `<div style="background:#fff;height:100%;padding:8px;font-family:sans-serif">
    <div style="font-size:14px;margin-bottom:4px">\u{1F4DD}</div>
    <div style="font-weight:700;font-size:9px;color:#37352f">Page Title</div>
    <div style="color:#787774;font-size:5px;margin-top:4px">\u2022 Item one<br>\u2022 Item two<br>\u2022 Item three</div></div>`,
  render: (ctx) => {
    const { slide, project, index, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    const emojis = ['\u2728','\u{1F4A1}','\u{1F4CA}','\u{1F527}','\u{1F680}','\u{1F4D6}','\u{1F3AF}','\u{1F310}','\u{1F50D}','\u{1F4CC}','\u{1F3C1}'];
    const emoji = isCover ? emojis[0] : emojis[((index - 1) % (emojis.length - 1)) + 1];
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="breadcrumb">${esc(project.topic)} / Slide ${index+1}</div>
      <div class="emoji">${emoji}</div>
      <h1 ${e('title')}>${esc(slide.title)}</h1>
      ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
      ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
      ${bullets(slide.bullets)}
      ${img(slide)}
    </section>`;
  }
};

const dashboard = {
  id: 'dashboard', name: 'Dashboard', tag: 'Data · Analytics',
  fonts: gfonts('family=Inter:wght@400;600;700&family=JetBrains+Mono:wght@500'),
  css: `
    body { background: #0f172a; color: #e2e8f0; font-family: 'Inter', sans-serif; }
    .slide { padding: 5vmin 6vmin; display: none; }
    .slide.active { display: grid; grid-template-rows: auto 1fr auto; gap: 20px; }
    .topstrip { display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid #1e293b; font-family: 'JetBrains Mono', monospace; font-size: 12px; color: #64748b; }
    .topstrip .dot { color: #10b981; }
    .main { display: flex; flex-direction: column; justify-content: center; }
    h1 { font-size: clamp(30px, 5.5vw, 52px); font-weight: 700; line-height: 1.05; letter-spacing: -.02em; margin-bottom: 10px; color: #f1f5f9; }
    .subtitle { color: #94a3b8; font-size: clamp(15px, 1.9vw, 18px); margin-bottom: 20px; }
    .body { font-size: clamp(14px, 1.7vw, 16px); line-height: 1.65; color: #cbd5e1; max-width: 900px; margin-bottom: 14px; }
    ul { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; list-style: none; }
    li { background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 14px 16px 14px 20px; font-size: clamp(13px, 1.6vw, 15px); line-height: 1.5; color: #e2e8f0; position: relative; }
    li::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 3px; background: #10b981; border-radius: 8px 0 0 8px; }
    .slide img { max-width: 50%; max-height: 40vh; border-radius: 8px; border: 1px solid #334155; }
    .bottom-strip { display: flex; gap: 10px; font-family: 'JetBrains Mono', monospace; font-size: 11px; color: #64748b; flex-wrap: wrap; }
    .bottom-strip span { padding: 4px 10px; background: #1e293b; border-radius: 4px; }
    .cover h1 { font-size: clamp(44px, 9vw, 84px); color: #10b981; }
    .deck-progress { background: #10b981; }
  `,
  preview: () => `<div style="background:#0f172a;height:100%;padding:6px;font-family:sans-serif">
    <div style="color:#10b981;font-size:5px;font-weight:700">\u25CF LIVE</div>
    <div style="color:#f1f5f9;font-weight:700;font-size:10px;margin-top:3px">Metric</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:2px;margin-top:3px">
      <div style="background:#1e293b;height:10px;border-left:2px solid #10b981"></div>
      <div style="background:#1e293b;height:10px;border-left:2px solid #10b981"></div></div></div>`,
  render: (ctx) => {
    const { slide, project, index, total, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="topstrip"><span><span class="dot">\u25CF</span> ${esc(project.topic)}</span><span>${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}</span></div>
      <div class="main">
        <h1 ${e('title')}>${esc(slide.title)}</h1>
        ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
        ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
        ${bullets(slide.bullets)}
        ${img(slide)}
      </div>
      <div class="bottom-strip"><span>id=${index+1}</span><span>view=slide</span><span>updated=${new Date(project.createdAt).toISOString().slice(0,10)}</span></div>
    </section>`;
  }
};

const codeIde = {
  id: 'code-ide', name: 'IDE', tag: 'Code editor',
  fonts: gfonts('family=JetBrains+Mono:wght@400;600'),
  css: `
    body { background: #1e1e1e; color: #d4d4d4; font-family: 'JetBrains Mono', monospace; }
    .slide { padding: 0; display: none; }
    .slide.active { display: grid; grid-template-columns: 240px 1fr; }
    .sidebar { background: #252526; padding: 40px 14px; border-right: 1px solid #3c3c3c; font-size: 13px; color: #cccccc; overflow-y: auto; }
    .sidebar .file { padding: 4px 8px; color: #858585; }
    .sidebar .file.active { background: #094771; color: #fff; border-radius: 2px; }
    .sidebar h3 { color: #858585; font-size: 11px; text-transform: uppercase; letter-spacing: .1em; margin-bottom: 10px; font-weight: 500; }
    .editor { padding: 40px 50px; overflow-y: auto; }
    h1 { color: #569cd6; font-size: clamp(28px, 5vw, 46px); font-weight: 700; margin-bottom: 20px; line-height: 1.2; }
    h1::before { content: '/** '; color: #6a9955; font-weight: 400; }
    h1::after { content: ' */'; color: #6a9955; font-weight: 400; }
    .subtitle { color: #9cdcfe; font-size: clamp(15px, 1.9vw, 18px); margin-bottom: 20px; }
    .subtitle::before { content: '// '; color: #6a9955; }
    .body { color: #dcdcdc; font-size: clamp(13px, 1.6vw, 16px); line-height: 1.8; margin-bottom: 16px; max-width: 850px; }
    ul { list-style: none; background: #252526; border: 1px solid #3c3c3c; padding: 18px 20px; max-width: 850px; }
    li { font-size: clamp(12px, 1.5vw, 15px); line-height: 1.8; color: #dcdcdc; }
    li::before { content: '- '; color: #569cd6; }
    .slide img { max-width: 400px; margin-top: 16px; border: 1px solid #3c3c3c; }
    .deck-progress { background: #569cd6; height: 2px; }
    @media (max-width: 900px) { .slide.active { grid-template-columns: 1fr; } .sidebar { display: none; } }
  `,
  preview: () => `<div style="background:#1e1e1e;height:100%;display:grid;grid-template-columns:30px 1fr;padding:0">
    <div style="background:#252526;padding:4px 2px"><div style="font-size:4px;color:#fff;background:#094771;padding:1px">slide.md</div></div>
    <div style="padding:4px 6px;font-family:monospace">
      <div style="color:#569cd6;font-size:6px">/** Title */</div>
      <div style="color:#dcdcdc;font-size:4px;margin-top:3px">- code as slides</div></div></div>`,
  render: (ctx) => {
    const { slide, index, total, isCover, esc, bullets, img, editable } = ctx;
    const e = (f) => editable ? `data-field="${f}"` : '';
    const files = [];
    for (let k = 0; k < total; k++) {
      files.push(`<div class="file ${k === index ? 'active' : ''}">slide-${String(k+1).padStart(2,'0')}.md</div>`);
    }
    return `<section class="slide ${isCover ? 'cover' : ''}">
      <div class="sidebar"><h3>Explorer</h3>${files.join('')}</div>
      <div class="editor">
        <h1 ${e('title')}>${esc(slide.title)}</h1>
        ${slide.subtitle ? `<div class="subtitle" ${e('subtitle')}>${esc(slide.subtitle)}</div>` : ''}
        ${slide.body ? `<div class="body" ${e('body')}>${esc(slide.body)}</div>` : ''}
        ${bullets(slide.bullets)}
        ${img(slide)}
      </div>
    </section>`;
  }
};

const geoTech = {
  id: 'geo-tech', name: 'Geo Tech', tag: 'Geometric · Tech',
  fonts: gfonts('family=Space+Grotesk:wght@400;500;700'),
  css: `
    body { background: #0c0c0e; color: #e4e4e7; font-family: 'Space Grotesk', sans-serif; }
    .slide { padding: 7vmin; justify-content: center; }
    .slide::before { content: ''; position: absolute; top: 0; right: 0; width: 40%; height: 100%; background: linear-gradient(135deg, transparent 40%, rgba(99,102,241,0.12) 60%, transparent 80%); pointer-events: none; }
    .slide::after { content: ''; position: absolute; bottom: 4vmin; right: 4vmin; width: 120px; height: 120px; border: 1px solid #6366f1; transform: rotate(45deg); opacity: .4; }
    .corners { position: absolute; top: 3vmin; right: 3vmin; font-family: monospace; font-size: 10px; color: #6366f1; letter-spacing: .2em; }
    h1 { font-size: clamp(34px, 6vw, 60px); font-weight: 700; line-height: 1.05; letter-spacing: -.03em; margin-bottom: 22px; }
    h1 span { color: #6366f1; }
    .subtitle { color: #a1a1aa; font-size: clamp(16px, 2vw, 20px); margin-bottom: 22px; max-width: 700px; }
    .body { font-size: clamp(15px, 1.8vw, 18px); line-height: 1.65; max-width: 800px; margin-bottom: 12px; color: #d4d4d8; }
    ul { list-style: none; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px; max-width: 900px; }
    li { background: rgba(99,102,241,0.08); border: 1px solid rgba(99,102,241,0.3); padding: 14px; font-size: clamp(13px, 1.6vw, 16px); line-height: 1.5; position: relative; clip-path: polygon(0 0, calc(100% - 12px) 0, 100% 12px, 100% 100%, 0 100%); }
    .slide img { max-width: 400px; max-height: 40vh; margin-top: 18px; border: 1px solid #6366f1; clip-path: polygon(0 0, calc(100% - 20px) 0, 100% 20px, 100% 100%, 0 100%); }
    .cover h1 { font-size: clamp(44px, 10vw, 90px); }
    .deck-progress { background: #6366f1; }
  `,
  preview: () => `<div style="background:#0c0c0e;height:100%;padding:8px;position:relative">
    <div style="font-family:monospace;font-size:4px;color:#6366f1">///</div>
    <div style="color:#fff;font-weight:700;font-size:10px;margin-top:4px">Tech<span style="color:#6366f1">.</span></div>
    <div style="position:absolute;bottom:4px;right:4px;width:12px;height:12px;border:1px solid #6366f1;transform:rotate(45deg)"></div></div>`,
  render: (ctx) => basicRender(ctx, {
    before: ({ index, total }) => `<div class="corners">\u25AC ${String(index+1).padStart(3,'0')}/${String(total).padStart(3,'0')}</div>`
  })
};

export const TEMPLATES_EXTRA_1 = [newspaper, magazine, typewriter, zine, manifesto, monoDev, notionLike, dashboard, codeIde, geoTech];
