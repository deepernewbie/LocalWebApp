// research.js - gather facts + images from multiple CORS-friendly public APIs.
//
// Text sources:
//   - Wikipedia (MediaWiki API)
//   - Wikibooks (same API family, different domain)
//   - DuckDuckGo Instant Answer API
//   - arXiv (for queries that look academic/scientific)
//
// Image sources:
//   - Wikimedia Commons
//   - Openverse (100M+ CC-licensed images, CORS-open)
//
// All sources are queried in parallel; failures are tolerated per-source.

// ----------------------------------------------------------------------
// Utilities
// ----------------------------------------------------------------------

async function safeFetch(url, opts = {}, timeoutMs = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...opts, signal: ctrl.signal });
    if (!res.ok) return null;
    return res;
  } catch (e) {
    return null;
  } finally {
    clearTimeout(t);
  }
}

async function safeJson(url, opts, timeoutMs) {
  const res = await safeFetch(url, opts, timeoutMs);
  if (!res) return null;
  try { return await res.json(); } catch { return null; }
}

// ----------------------------------------------------------------------
// Wikipedia / Wikibooks (MediaWiki API pattern — same on both)
// ----------------------------------------------------------------------

async function mwSearch(domain, query, limit = 2) {
  const url = `https://${domain}/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=${limit}&format=json&origin=*`;
  const data = await safeJson(url);
  return data?.query?.search || [];
}

async function mwExtract(domain, title) {
  const url = `https://${domain}/w/api.php?action=query&prop=extracts&exintro=1&explaintext=1&titles=${encodeURIComponent(title)}&format=json&origin=*`;
  const data = await safeJson(url);
  const pages = data?.query?.pages || {};
  const first = Object.values(pages)[0];
  return first?.extract || '';
}

// Kept as exports for backward compatibility
export async function wikiSearch(query, limit = 3) {
  return mwSearch('en.wikipedia.org', query, limit);
}
export async function wikiExtract(title) {
  return mwExtract('en.wikipedia.org', title);
}

// ----------------------------------------------------------------------
// DuckDuckGo Instant Answer
// ----------------------------------------------------------------------

async function ddgSearch(query) {
  // no_html=1 removes HTML; skip_disambig=1 avoids disambiguation-only responses
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1&t=deckforge`;
  const data = await safeJson(url);
  if (!data) return null;
  const parts = [];
  if (data.AbstractText) parts.push(data.AbstractText);
  if (data.Definition) parts.push(data.Definition);
  if (Array.isArray(data.RelatedTopics)) {
    for (const rt of data.RelatedTopics.slice(0, 3)) {
      if (rt.Text) parts.push(rt.Text);
    }
  }
  const text = parts.join('\n\n').trim();
  if (!text) return null;
  return {
    title: data.Heading || query,
    url: data.AbstractURL || `https://duckduckgo.com/?q=${encodeURIComponent(query)}`,
    text: text.slice(0, 2500),
    source: 'duckduckgo'
  };
}

// ----------------------------------------------------------------------
// arXiv (for academic/scientific-looking queries)
// ----------------------------------------------------------------------

function isAcademicQuery(topic) {
  const t = topic.toLowerCase();
  const markers = /\b(theory|quantum|algorithm|neural|machine learning|ml |protein|genetic|cellular|thermodynamics|relativity|statistical|optimization|computational|bayesian|paper|research)\b/;
  return markers.test(t);
}

async function arxivSearch(query, limit = 2) {
  const url = `https://export.arxiv.org/api/query?search_query=all:${encodeURIComponent(query)}&max_results=${limit}&sortBy=relevance`;
  const res = await safeFetch(url);
  if (!res) return [];
  let xml;
  try { xml = await res.text(); } catch { return []; }

  // very light XML parsing — just grab title and summary from each <entry>
  const entries = [];
  const entryRe = /<entry>([\s\S]*?)<\/entry>/g;
  let m;
  while ((m = entryRe.exec(xml)) && entries.length < limit) {
    const block = m[1];
    const title = extractTag(block, 'title');
    const summary = extractTag(block, 'summary');
    const idTag = extractTag(block, 'id');
    if (!title || !summary) continue;
    entries.push({
      title: title.replace(/\s+/g, ' ').trim(),
      url: idTag || '',
      text: summary.replace(/\s+/g, ' ').trim().slice(0, 1500),
      source: 'arxiv'
    });
  }
  return entries;
}

function extractTag(xml, tag) {
  const re = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i');
  const m = xml.match(re);
  return m ? m[1] : '';
}

// ----------------------------------------------------------------------
// Multi-source research for a topic
// ----------------------------------------------------------------------

export async function researchTopic(topic, onProgress = () => {}, opts = {}) {
  const base = topic.trim();
  if (!base) return [];

  // Wikipedia subdomain: 'en', 'tr', 'fr', 'es', 'de', 'zh' etc. The English
  // Wikipedia is consulted as a fallback because many topics have richer
  // coverage there even when the project language is not English.
  const wikiLang = (opts.wikiLang || 'en').toLowerCase();
  const useEnglishFallback = wikiLang !== 'en';

  const snippets = [];
  const seen = new Set();

  const add = (s) => {
    if (!s || !s.text) return;
    const key = (s.title || '') + '|' + s.text.slice(0, 80);
    if (seen.has(key)) return;
    seen.add(key);
    snippets.push(s);
  };

  // Kick off all sources in parallel
  onProgress('Searching multiple sources…');
  const tasks = [];

  // 1. Native-language Wikipedia (primary when not English, English when English)
  const primaryWiki = `${wikiLang}.wikipedia.org`;
  tasks.push((async () => {
    const results = await mwSearch(primaryWiki, base, 2);
    for (const r of results.slice(0, 2)) {
      onProgress(`Reading ${wikiLang}.wikipedia: "${r.title}"`);
      const extract = await mwExtract(primaryWiki, r.title);
      if (extract) {
        add({
          title: r.title,
          url: `https://${primaryWiki}/wiki/${encodeURIComponent(r.title.replace(/ /g, '_'))}`,
          text: extract.slice(0, 3000),
          source: `wikipedia-${wikiLang}`
        });
      }
    }
  })());

  // 2. Native-language Wikipedia secondary query
  tasks.push((async () => {
    const q = wikiLang === 'en' ? `${base} overview` : base;
    const results = await mwSearch(primaryWiki, q, 1);
    for (const r of results.slice(0, 1)) {
      const extract = await mwExtract(primaryWiki, r.title);
      if (extract) {
        add({
          title: r.title,
          url: `https://${primaryWiki}/wiki/${encodeURIComponent(r.title.replace(/ /g, '_'))}`,
          text: extract.slice(0, 2000),
          source: `wikipedia-${wikiLang}`
        });
      }
    }
  })());

  // 2b. English Wikipedia fallback (only when project language isn't English)
  // English coverage is broader for many topics and the LLM can translate facts.
  if (useEnglishFallback) {
    tasks.push((async () => {
      onProgress('Cross-referencing English Wikipedia…');
      const results = await mwSearch('en.wikipedia.org', base, 1);
      for (const r of results.slice(0, 1)) {
        const extract = await mwExtract('en.wikipedia.org', r.title);
        if (extract) {
          add({
            title: `${r.title} (en)`,
            url: `https://en.wikipedia.org/wiki/${encodeURIComponent(r.title.replace(/ /g, '_'))}`,
            text: extract.slice(0, 2500),
            source: 'wikipedia-en'
          });
        }
      }
    })());
  }

  // 3. Wikibooks (English only — Wikibooks coverage in other languages is
  // sparse and inconsistent. The LLM can still ground in this source even
  // when writing the slide in another language.)
  tasks.push((async () => {
    onProgress('Searching Wikibooks…');
    const results = await mwSearch('en.wikibooks.org', base, 1);
    for (const r of results.slice(0, 1)) {
      const extract = await mwExtract('en.wikibooks.org', r.title);
      if (extract && extract.length > 120) {
        add({
          title: `${r.title} (Wikibooks)`,
          url: `https://en.wikibooks.org/wiki/${encodeURIComponent(r.title.replace(/ /g, '_'))}`,
          text: extract.slice(0, 2000),
          source: 'wikibooks'
        });
      }
    }
  })());

  // 4. DuckDuckGo
  tasks.push((async () => {
    onProgress('Querying DuckDuckGo…');
    const s = await ddgSearch(base);
    if (s) add(s);
  })());

  // 5. arXiv (only for academic-looking queries)
  if (isAcademicQuery(base)) {
    tasks.push((async () => {
      onProgress('Searching arXiv…');
      const entries = await arxivSearch(base, 2);
      for (const e of entries) add(e);
    })());
  }

  await Promise.all(tasks);
  onProgress(`Gathered ${snippets.length} source(s).`);
  return snippets;
}

// ----------------------------------------------------------------------
// Images — Wikimedia Commons + Openverse
// ----------------------------------------------------------------------

async function searchImagesWikimedia(query, limit = 4) {
  const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrsearch=${encodeURIComponent(query)}&gsrlimit=${limit * 2}&prop=imageinfo&iiprop=url|size|mime&iiurlwidth=800&format=json&origin=*`;
  const data = await safeJson(url);
  if (!data) return [];
  const pages = data.query?.pages || {};
  const results = [];
  for (const p of Object.values(pages)) {
    const info = p.imageinfo?.[0];
    if (!info) continue;
    const mime = info.mime || '';
    if (!mime.startsWith('image/')) continue;
    if (mime.includes('svg')) continue;
    if (info.width < 400) continue;
    results.push({
      url: info.thumburl || info.url,
      fullUrl: info.url,
      width: info.thumbwidth || info.width,
      height: info.thumbheight || info.height,
      title: p.title.replace(/^File:/, '').replace(/\.[a-z]+$/i, ''),
      source: 'commons'
    });
    if (results.length >= limit) break;
  }
  return results;
}

async function searchImagesOpenverse(query, limit = 4) {
  // Openverse public API: no key required, CORS open.
  const url = `https://api.openverse.org/v1/images/?q=${encodeURIComponent(query)}&page_size=${limit * 2}&license_type=commercial&mature=false`;
  const data = await safeJson(url);
  if (!data) return [];
  const results = [];
  for (const item of (data.results || [])) {
    if (!item.url) continue;
    const w = item.width || 0, h = item.height || 0;
    if (w && w < 400) continue;
    results.push({
      url: item.thumbnail || item.url,
      fullUrl: item.url,
      width: w || 800,
      height: h || 600,
      title: item.title || query,
      source: 'openverse',
      attribution: item.creator ? `${item.creator} via ${item.source || 'Openverse'}` : (item.source || 'Openverse'),
      license: item.license
    });
    if (results.length >= limit) break;
  }
  return results;
}

// Combined, deduped image search
export async function searchImages(query, limit = 6) {
  // Run both in parallel, merge, dedupe by URL
  const halfLimit = Math.ceil(limit / 2) + 1;
  const [wm, ov] = await Promise.all([
    searchImagesWikimedia(query, halfLimit).catch(() => []),
    searchImagesOpenverse(query, halfLimit).catch(() => [])
  ]);

  // Interleave: first Wikimedia, first Openverse, second Wikimedia, ...
  const merged = [];
  const maxLen = Math.max(wm.length, ov.length);
  for (let i = 0; i < maxLen; i++) {
    if (wm[i]) merged.push(wm[i]);
    if (ov[i]) merged.push(ov[i]);
  }

  // Dedupe by URL
  const seen = new Set();
  const deduped = [];
  for (const r of merged) {
    const key = r.fullUrl || r.url;
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(r);
    if (deduped.length >= limit) break;
  }
  return deduped;
}

// Fetch an image as bytes so we can save it to disk
export async function fetchImageBytes(url) {
  try {
    const res = await safeFetch(url, {}, 15000);
    if (!res) return null;
    const buf = await res.arrayBuffer();
    return new Uint8Array(buf);
  } catch (e) {
    return null;
  }
}
