// llm.js - OpenRouter chat with robust JSON parsing and raw output logging

import { loadSettings } from './settings.js';
import * as fs from './storage.js';

const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';
const LOG_PATH = 'logs/llm.jsonl';
const MAX_LOG_LINES = 200;

// ---- Log buffer (in-memory, flushed periodically) ----
let logBuffer = [];

async function appendLog(entry) {
  logBuffer.push(entry);
  if (logBuffer.length > 20) await flushLog();
}

export async function flushLog() {
  if (logBuffer.length === 0) return;
  const existing = (await fs.readText(LOG_PATH)) || '';
  const lines = existing.split('\n').filter(Boolean);
  for (const e of logBuffer) lines.push(JSON.stringify(e));
  while (lines.length > MAX_LOG_LINES) lines.shift();
  await fs.writeText(LOG_PATH, lines.join('\n') + '\n');
  logBuffer = [];
}

export async function readLog() {
  await flushLog();
  const text = (await fs.readText(LOG_PATH)) || '';
  return text.split('\n').filter(Boolean).map(l => {
    try { return JSON.parse(l); } catch { return { raw: l }; }
  }).reverse(); // newest first
}

export async function clearLog() {
  logBuffer = [];
  await fs.writeText(LOG_PATH, '');
}

// ---- Main chat ----

export async function chat({ system, user, json = false, temperature = 0.7, maxTokens = 3000, label = 'chat' }) {
  const s = await loadSettings();
  if (!s.apiKey) throw new Error('No OpenRouter API key set. Open Settings to add one.');
  if (!s.activeModelId) throw new Error('No active model selected.');

  const messages = [];
  if (system) messages.push({ role: 'system', content: system });
  messages.push({ role: 'user', content: user });

  const body = {
    model: s.activeModelId,
    messages,
    temperature,
    max_tokens: maxTokens
  };
  if (json) body.response_format = { type: 'json_object' };

  const startedAt = Date.now();
  const logEntry = {
    ts: startedAt,
    label,
    model: s.activeModelId,
    json,
    systemPreview: (system || '').slice(0, 200),
    userPreview: (user || '').slice(0, 300)
  };

  let res, rawText = '', parsedData = null, errMsg = null;
  try {
    res = await fetch(OPENROUTER_URL, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + s.apiKey,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://deckforge.local',
        'X-Title': 'DeckForge'
      },
      body: JSON.stringify(body)
    });

    if (!res.ok) {
      const txt = await res.text();
      errMsg = `OpenRouter ${res.status}: ${txt.slice(0, 400)}`;
      logEntry.status = res.status;
      logEntry.error = errMsg;
      logEntry.durationMs = Date.now() - startedAt;
      await appendLog(logEntry);
      throw new Error(errMsg);
    }

    const data = await res.json();
    rawText = data?.choices?.[0]?.message?.content ?? '';
    logEntry.status = 200;
    logEntry.raw = rawText;
    logEntry.usage = data?.usage;

    if (json) {
      try {
        parsedData = parseJSONRobust(rawText);
        logEntry.parsed = 'ok';
        logEntry.durationMs = Date.now() - startedAt;
        await appendLog(logEntry);
        return parsedData;
      } catch (e) {
        errMsg = e.message;
        logEntry.parsed = 'failed';
        logEntry.parseError = errMsg;
        logEntry.durationMs = Date.now() - startedAt;
        await appendLog(logEntry);
        throw new Error(
          'LLM returned invalid JSON. Open the LLM Log (Settings → LLM Log) ' +
          'to see the raw response — you can share it to improve the parser. ' +
          'Tip: try a different model (GPT-4o-mini and Claude usually handle JSON best).'
        );
      }
    }

    logEntry.durationMs = Date.now() - startedAt;
    await appendLog(logEntry);
    return rawText;
  } catch (e) {
    if (!logEntry.error) {
      logEntry.error = e.message;
      logEntry.durationMs = Date.now() - startedAt;
      await appendLog(logEntry);
    }
    throw e;
  }
}

// ============================================================
// Robust JSON extraction
// Handles: plain JSON, fenced blocks, text preamble/postamble,
// Python-style True/False/None, trailing commas, single quotes,
// smart quotes, comments, truncated output (tries to repair)
// ============================================================

export function parseJSONRobust(text) {
  if (!text || typeof text !== 'string') throw new Error('Empty response');

  const deduped = dedupeConcatenated(text);

  // Enumerate every top-level {...} and [...] block. Some LLM responses contain
  // multiple concatenated blocks (planner output + draft output, or a stray
  // per-slide object alongside the real answer). We evaluate each candidate
  // and pick the one that yields the richest parseable result.
  const blocks = [
    text,
    deduped,
    stripFences(text),
    stripFences(deduped),
    ...extractAllBlocks(text),
    ...extractAllBlocks(deduped)
  ];

  // De-dupe identical block strings so we don't waste work.
  const uniqueBlocks = Array.from(new Set(blocks.filter(Boolean)));

  // Per-block parse attempts. Each returns an object/array or throws.
  const attempts = [
    (s) => JSON.parse(s),
    (s) => JSON.parse(normalizeJSON(s)),
    (s) => JSON.parse(fixMissingSeparators(s)),
    (s) => JSON.parse(normalizeJSON(fixMissingSeparators(s))),
    (s) => JSON.parse(fixBareStringsInObject(s)),
    (s) => JSON.parse(normalizeJSON(fixBareStringsInObject(s))),
    (s) => JSON.parse(normalizeJSON(fixMissingSeparators(fixBareStringsInObject(s)))),
    (s) => JSON.parse(repairTruncated(s)),
    (s) => JSON.parse(normalizeJSON(repairTruncated(s))),
    (s) => JSON.parse(normalizeJSON(repairTruncated(fixMissingSeparators(s)))),
    (s) => JSON.parse(normalizeJSON(repairTruncated(fixBareStringsInObject(s)))),
    (s) => JSON.parse(normalizeJSON(repairTruncated(fixMissingSeparators(fixBareStringsInObject(s)))))
  ];

  const candidates = [];
  let lastErr;

  for (const block of uniqueBlocks) {
    for (const attempt of attempts) {
      try {
        const result = attempt(block);
        if (result === undefined || result === null) continue;
        candidates.push(result);
      } catch (e) { lastErr = e; }
    }
  }

  // Always try the progressive array repair — even if earlier attempts
  // succeeded, it may recover more items from a mangled array.
  for (const block of uniqueBlocks) {
    try {
      candidates.push(progressiveArrayRepair(block));
    } catch (e) { lastErr = e; }
  }

  if (candidates.length === 0) {
    throw new Error(`Could not parse JSON after exhausting all strategies. Last error: ${lastErr?.message || 'unknown'}`);
  }

  // Score each candidate. Higher score = richer/more useful result.
  // Heuristic: objects with a sizeable array field score highest, weighted by
  // the number of usable items in that array.
  let best = candidates[0];
  let bestScore = scoreCandidate(best);
  for (let i = 1; i < candidates.length; i++) {
    const s = scoreCandidate(candidates[i]);
    if (s > bestScore) { best = candidates[i]; bestScore = s; }
  }
  return best;
}

function scoreCandidate(v) {
  if (v == null) return -1;
  if (Array.isArray(v)) {
    // A bare array — useful, but less so than an object wrapping it (the
    // caller typically expects result.slides, result.items, etc.).
    return 50 + v.length * 10 + countUsefulFields(v);
  }
  if (typeof v !== 'object') return 0;
  let score = 10;
  for (const key of Object.keys(v)) {
    const val = v[key];
    if (Array.isArray(val)) {
      const usable = val.filter(x => x && typeof x === 'object' && Object.keys(x).length > 0);
      // Big bonus for a wrapping object with a populated array inside — this is
      // the target shape for both planner and drafter responses.
      score += 200 + usable.length * 30 + countUsefulFields(usable);
    } else if (typeof val === 'string' && val.length > 0) {
      score += 1;
    } else if (val && typeof val === 'object') {
      // Nested non-array object — small bonus
      score += 2 + Object.keys(val).length;
    }
  }
  return score;
}

function countUsefulFields(arr) {
  let total = 0;
  for (const item of arr) {
    if (item && typeof item === 'object') total += Object.keys(item).length;
  }
  return total;
}

// Extract every balanced {...} and [...] span in s, not just the first.
function extractAllBlocks(s) {
  if (!s) return [];
  const out = [];
  for (const open of ['{', '[']) {
    const close = open === '{' ? '}' : ']';
    let i = 0;
    while (i < s.length) {
      const start = s.indexOf(open, i);
      if (start < 0) break;
      const end = findBalancedClose(s, start, open, close);
      if (end < 0) {
        // Also emit the truncated tail — repairTruncated may fix it.
        out.push(s.slice(start));
        break;
      }
      out.push(s.slice(start, end + 1));
      i = end + 1;
    }
  }
  return out;
}

function stripFences(s) {
  let t = s.trim();
  t = t.replace(/^```(?:json|javascript|js)?\s*\n?/i, '');
  t = t.replace(/\n?```\s*$/i, '');
  if (t.includes('```')) {
    const parts = t.split('```');
    let best = '';
    for (const p of parts) {
      const stripped = p.replace(/^(?:json|javascript|js)\s*\n?/i, '').trim();
      if ((stripped.includes('{') || stripped.includes('[')) && stripped.length > best.length) {
        best = stripped;
      }
    }
    if (best) t = best;
  }
  return t.trim();
}

function extractJSONBlock(s) {
  const stripped = stripFences(s);
  const objBlock = extractBalanced(stripped, '{', '}');
  const arrBlock = extractBalanced(stripped, '[', ']');
  if (objBlock && arrBlock) return objBlock.length >= arrBlock.length ? objBlock : arrBlock;
  return objBlock || arrBlock || stripped;
}

function extractBalanced(s, open, close) {
  const first = s.indexOf(open);
  if (first < 0) return null;
  let depth = 0;
  let inString = false;
  let stringChar = null;
  let escape = false;
  for (let i = first; i < s.length; i++) {
    const c = s[i];
    if (escape) { escape = false; continue; }
    if (c === '\\') { escape = true; continue; }
    if (inString) {
      if (c === stringChar) inString = false;
      continue;
    }
    if (c === '"' || c === "'") { inString = true; stringChar = c; continue; }
    if (c === open) depth++;
    else if (c === close) {
      depth--;
      // Return the FIRST balanced span — don't keep scanning past depth 0,
      // because a later `{...}` might be a separate repeated copy and
      // extending through it would return junk.
      if (depth === 0) return s.slice(first, i + 1);
    }
  }
  return null;
}

function normalizeJSON(s) {
  if (!s) return s;
  let t = s;
  t = removeComments(t);
  t = t.replace(/[\u201C\u201D\u2033]/g, '"').replace(/[\u2018\u2019\u2032]/g, "'");
  t = t.replace(/\bNone\b/g, 'null').replace(/\bTrue\b/g, 'true').replace(/\bFalse\b/g, 'false');
  t = singleToDoubleQuotes(t);
  t = t.replace(/,(\s*[}\]])/g, '$1');
  t = t.replace(/([{,]\s*)([a-zA-Z_$][\w$]*)(\s*:)/g, '$1"$2"$3');
  return t;
}

function removeComments(s) {
  let out = '';
  let i = 0, inString = false, stringChar = null;
  while (i < s.length) {
    const c = s[i], next = s[i+1];
    if (inString) {
      if (c === '\\') { out += c + (s[i+1] || ''); i += 2; continue; }
      if (c === stringChar) inString = false;
      out += c; i++; continue;
    }
    if (c === '"' || c === "'") { inString = true; stringChar = c; out += c; i++; continue; }
    if (c === '/' && next === '/') {
      while (i < s.length && s[i] !== '\n') i++;
      continue;
    }
    if (c === '/' && next === '*') {
      i += 2;
      while (i < s.length - 1 && !(s[i] === '*' && s[i+1] === '/')) i++;
      i += 2;
      continue;
    }
    out += c; i++;
  }
  return out;
}

function singleToDoubleQuotes(s) {
  let out = '';
  let i = 0, inDouble = false;
  while (i < s.length) {
    const c = s[i];
    if (c === '\\') { out += c + (s[i+1] || ''); i += 2; continue; }
    if (c === '"') { inDouble = !inDouble; out += c; i++; continue; }
    if (c === "'" && !inDouble) {
      let j = i + 1;
      while (j < s.length) {
        if (s[j] === '\\') { j += 2; continue; }
        if (s[j] === "'") break;
        j++;
      }
      if (j < s.length) {
        const content = s.slice(i + 1, j).replace(/"/g, '\\"');
        out += '"' + content + '"';
        i = j + 1;
        continue;
      }
    }
    out += c; i++;
  }
  return out;
}

function repairTruncated(s) {
  if (!s) return s;
  let t = s.trim();
  t = t.replace(/,$/, '');
  const lastUnclosed = findUnclosedString(t);
  if (lastUnclosed >= 0) t = t.slice(0, lastUnclosed);
  const stack = [];
  let inString = false, stringChar = null, escape = false;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (escape) { escape = false; continue; }
    if (c === '\\') { escape = true; continue; }
    if (inString) {
      if (c === stringChar) inString = false;
      continue;
    }
    if (c === '"' || c === "'") { inString = true; stringChar = c; continue; }
    if (c === '{' || c === '[') stack.push(c);
    else if (c === '}' && stack[stack.length-1] === '{') stack.pop();
    else if (c === ']' && stack[stack.length-1] === '[') stack.pop();
  }
  t = t.replace(/,?\s*"[^"]*"\s*:\s*$/, '');
  t = t.replace(/,$/, '');
  while (stack.length) {
    const c = stack.pop();
    t += c === '{' ? '}' : ']';
  }
  return t;
}

function findUnclosedString(s) {
  let inString = false, stringStart = -1, escape = false, stringChar = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (escape) { escape = false; continue; }
    if (c === '\\') { escape = true; continue; }
    if (inString) {
      if (c === stringChar) { inString = false; stringStart = -1; }
      continue;
    }
    if (c === '"' || c === "'") { inString = true; stringChar = c; stringStart = i; }
  }
  return inString ? stringStart : -1;
}

// ============================================================
// Extra repair helpers for pathological LLM outputs
// ============================================================

// Detect when a model emitted its response twice (token-limit restart loop)
// and return just the first copy. Specifically: if the same non-trivial
// prefix starting with "{" appears more than once, slice at the second one.
function dedupeConcatenated(s) {
  if (!s) return s;
  // Look for the first significant "{...}" opening — find two occurrences of
  // a distinctive prefix and cut at the second one.
  const firstBrace = s.indexOf('{');
  if (firstBrace < 0) return s;
  // Take a 60-char signature from around the first brace (skipping the brace itself)
  const sigStart = firstBrace;
  const sig = s.slice(sigStart, sigStart + 60);
  if (sig.length < 30) return s;
  const secondIdx = s.indexOf(sig, sigStart + 60);
  if (secondIdx > 0) {
    return s.slice(0, secondIdx);
  }
  return s;
}

// Targeted fix: remove bare string values inside object bodies, where the key
// has been omitted. Example: `{ "cover", "title": "X" }` → `{ "title": "X" }`.
// We only drop items that look like bare strings; leaves everything else alone.
function fixBareStringsInObject(s) {
  if (!s) return s;
  // Walk the string, tracking whether we're inside an object body and whether
  // we're expecting a key or a value. If we see a string in "key position"
  // that ISN'T followed by `:`, we drop it along with any trailing comma.
  let out = '';
  let i = 0;
  const stack = []; // each entry: 'obj' (inside an object) or 'arr'
  let inString = false, stringChar = null, escape = false;
  let expectingKey = false; // true right after `{` or `,` inside an object

  while (i < s.length) {
    const c = s[i];
    if (inString) {
      out += c;
      if (escape) { escape = false; i++; continue; }
      if (c === '\\') { escape = true; i++; continue; }
      if (c === stringChar) {
        inString = false;
        // If we were in key-position, check what's next: colon = real key, so OK.
        // Anything else means this was a bare string masquerading as a key.
        if (expectingKey && stack[stack.length-1] === 'obj') {
          let j = i + 1;
          while (j < s.length && /\s/.test(s[j])) j++;
          if (s[j] !== ':') {
            // Bare string — roll back the string we just emitted.
            // Find where the string began in `out` (the matching `"`) and chop.
            const lastQuote = out.lastIndexOf('"', out.length - 2);
            if (lastQuote >= 0) {
              out = out.slice(0, lastQuote);
            }
            // Skip forward over optional whitespace + comma so the object stays valid.
            i = j;
            if (s[i] === ',') i++;
            while (i < s.length && /\s/.test(s[i])) i++;
            // Still expecting a key (we just removed one entry)
            continue;
          }
          // Real key — after the colon we'll be expecting a value
          expectingKey = false;
        }
      }
      i++;
      continue;
    }
    if (c === '"' || c === "'") {
      inString = true; stringChar = c;
      out += c; i++;
      continue;
    }
    if (c === '{') { stack.push('obj'); expectingKey = true; out += c; i++; continue; }
    if (c === '[') { stack.push('arr'); expectingKey = false; out += c; i++; continue; }
    if (c === '}' || c === ']') { stack.pop(); expectingKey = false; out += c; i++; continue; }
    if (c === ',') {
      expectingKey = stack[stack.length-1] === 'obj';
      out += c; i++; continue;
    }
    if (c === ':') { expectingKey = false; out += c; i++; continue; }
    out += c; i++;
  }
  return out;
}


function fixMissingSeparators(s) {
  if (!s) return s;
  // Match: "...text..."word":   -->   "...text...", "word":
  // We walk the string character by character so we don't get confused by
  // legitimate punctuation inside strings.
  let out = '';
  let i = 0;
  let inString = false, stringChar = null, escape = false;
  while (i < s.length) {
    const c = s[i];
    if (inString) {
      if (escape) { out += c; escape = false; i++; continue; }
      if (c === '\\') { out += c; escape = true; i++; continue; }
      if (c === stringChar) {
        // String just closed. Peek ahead: is the next non-whitespace char a
        // letter/underscore followed (after more chars) by another `"` and `:`?
        // That means the model forgot ", ".
        let j = i + 1;
        while (j < s.length && /[ \t]/.test(s[j])) j++;
        // If we immediately see an identifier character (not a newline, comma,
        // bracket, colon, or another quote), the separator is missing.
        if (j < s.length && /[A-Za-z_]/.test(s[j])) {
          // Scan to see if this looks like `word":` — i.e. a JSON key
          let k = j;
          while (k < s.length && /[A-Za-z0-9_]/.test(s[k])) k++;
          if (k < s.length && s[k] === '"' && s.slice(k+1).match(/^\s*:/)) {
            out += c + ', "';
            i = j; // continue from where we peeked (the new key starts here)
            inString = false;
            // Wrap the bare key we just detected in quotes too: we already
            // emitted the opening ". Copy the identifier chars, then emit
            // the closing " only if not already there.
            while (i < s.length && /[A-Za-z0-9_]/.test(s[i])) { out += s[i]; i++; }
            // We expect a `"` next, skip it (we already provided the closing ")
            if (s[i] === '"') { out += '"'; i++; }
            else { out += '"'; }
            continue;
          }
        }
        out += c;
        inString = false;
        i++;
        continue;
      }
      out += c; i++; continue;
    }
    if (c === '"') { inString = true; stringChar = c; out += c; i++; continue; }
    out += c; i++;
  }
  return out;
}

// Progressive array repair. If the input is shaped like `{..."slides":[...]}`
// (or any object containing one top-level array), try to parse each element
// of that array independently. Drop elements that fail to parse. This lets us
// salvage 9 good slides when 1 is mangled.
function progressiveArrayRepair(text) {
  if (!text) throw new Error('empty');
  // Pre-fix the entire text: apply fixMissingSeparators, fixBareStringsInObject,
  // and dedupe so that our bracket/quote state tracker won't desync on broken
  // items mid-scan.
  const cleaned = fixBareStringsInObject(fixMissingSeparators(stripFences(text)));

  // Find the top-level array. Simple heuristic: look for `"someKey": [`.
  // If not found, and the whole thing is itself an array `[...]`, use that.
  const arrayKeyMatch = cleaned.match(/"([a-zA-Z_][\w]*)"\s*:\s*\[/);
  let arrayStart, arrayEnd, arrayKey = null, prefix = '', suffix = '';

  if (arrayKeyMatch) {
    arrayKey = arrayKeyMatch[1];
    arrayStart = cleaned.indexOf('[', arrayKeyMatch.index);
    prefix = cleaned.slice(0, arrayStart);
    // find the matching close bracket (balanced, not just the next `]`)
    arrayEnd = findBalancedClose(cleaned, arrayStart, '[', ']');
    // arrayEnd may be -1 if the output was truncated; use end of string
    if (arrayEnd < 0) arrayEnd = cleaned.length;
    suffix = cleaned.slice(arrayEnd + 1);
  } else {
    const bracketStart = cleaned.indexOf('[');
    if (bracketStart < 0) throw new Error('no array found');
    arrayStart = bracketStart;
    arrayEnd = findBalancedClose(cleaned, bracketStart, '[', ']');
    if (arrayEnd < 0) arrayEnd = cleaned.length;
    prefix = cleaned.slice(0, arrayStart);
    suffix = cleaned.slice(arrayEnd + 1);
  }

  const inner = cleaned.slice(arrayStart + 1, arrayEnd);

  // Walk through the array contents and extract each {...} object separately.
  const items = [];
  let depth = 0, inStr = false, strCh = null, esc = false;
  let itemStart = -1;
  for (let i = 0; i < inner.length; i++) {
    const c = inner[i];
    if (esc) { esc = false; continue; }
    if (c === '\\') { esc = true; continue; }
    if (inStr) { if (c === strCh) inStr = false; continue; }
    if (c === '"' || c === "'") { inStr = true; strCh = c; continue; }
    if (c === '{') {
      if (depth === 0) itemStart = i;
      depth++;
    } else if (c === '}') {
      depth--;
      if (depth === 0 && itemStart >= 0) {
        const raw = inner.slice(itemStart, i + 1);
        items.push(raw);
        itemStart = -1;
      }
    }
  }
  // If the last item was truncated (opened but never closed), try to repair and include it
  if (depth > 0 && itemStart >= 0) {
    const tail = inner.slice(itemStart);
    try {
      const repaired = repairTruncated(tail);
      // only accept if it parses
      JSON.parse(normalizeJSON(repaired));
      items.push(repaired);
    } catch {}
  }

  // Parse each item, skipping broken ones
  const parsed = [];
  for (const raw of items) {
    const candidates = [
      () => JSON.parse(raw),
      () => JSON.parse(normalizeJSON(raw)),
      () => JSON.parse(fixMissingSeparators(raw)),
      () => JSON.parse(normalizeJSON(fixMissingSeparators(raw))),
      () => JSON.parse(fixBareStringsInObject(raw)),
      () => JSON.parse(normalizeJSON(fixBareStringsInObject(raw))),
      () => JSON.parse(normalizeJSON(fixMissingSeparators(fixBareStringsInObject(raw))))
    ];
    let got = null;
    for (const c of candidates) {
      try { got = c(); break; } catch {}
    }
    if (got && typeof got === 'object' && Object.keys(got).length > 0) {
      parsed.push(got);
    }
    // else skip — this element is unrecoverable
  }

  if (parsed.length === 0) throw new Error('no recoverable array items');

  // Rebuild the shape. If we found a key, wrap it; otherwise return the array directly.
  if (arrayKey) {
    // Re-parse the prefix (everything before the array) to get the outer object fields
    // Safely: close the object we opened with a stub array, then merge in our parsed items.
    const outerStub = prefix + '[]' + (suffix.match(/}/) ? '}' : '');
    let outer = {};
    try {
      outer = JSON.parse(normalizeJSON(repairTruncated(outerStub))) || {};
    } catch {
      outer = {};
    }
    outer[arrayKey] = parsed;
    return outer;
  }
  return parsed;
}

function findBalancedClose(s, openIdx, open, close) {
  let depth = 0, inStr = false, strCh = null, esc = false;
  for (let i = openIdx; i < s.length; i++) {
    const c = s[i];
    if (esc) { esc = false; continue; }
    if (c === '\\') { esc = true; continue; }
    if (inStr) { if (c === strCh) inStr = false; continue; }
    if (c === '"' || c === "'") { inStr = true; strCh = c; continue; }
    if (c === open) depth++;
    else if (c === close) { depth--; if (depth === 0) return i; }
  }
  return -1;
}
