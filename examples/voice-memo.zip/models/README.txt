This folder is reserved for on-device speech recognition model weights.

Nothing ships here. On first recording the app downloads the Whisper
model from huggingface.co via Transformers.js; the APK's transparent
network cache persists those files to disk so subsequent launches work
fully offline.

You can change which model is used in Settings → STT Model.
