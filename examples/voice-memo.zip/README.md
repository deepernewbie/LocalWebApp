# Voice·Memo

On-device voice memo app for Android WebView (Local Web App Runner).
All transcription runs locally via Whisper compiled to WebAssembly.

## Folder layout

```
index.html              entry point
css/styles.css          single stylesheet
js/
  app.js                main wiring
  bridge.js             window.Android wrapper (safe fallbacks)
  notes.js              pure domain helpers
  notes-actions.js      (none — intentionally merged into app.js)
  storage.js            OPFS + localStorage persistence
  stt.js                mic capture + worker orchestration
  stt-worker.js         Whisper pipeline (runs in Web Worker)
  ui.js                 DOM rendering
notes/
  notes.json            (created at runtime by OPFS mirror — can be exported)
models/
  (reserved — transformers.js caches weights via the browser/APK cache
   automatically; no files need to ship here)
```

## How it stores notes

* Primary: **OPFS** (Origin Private File System) at `notes/notes.json`
  inside the WebView origin. Survives app restarts.
* Mirror: **localStorage** (`vm.notes.v1`), so data is never lost even
  if OPFS is cleared.
* Export: share the JSON via `Android.share()` or download.
* Import: merge a previously-exported JSON file (newer `updatedAt` wins).

Each note contains:

```jsonc
{
  "id": "uuid",
  "title": "…",
  "body":  "…",
  "assignee": "@alex",
  "dueAt": "2025-04-22T14:00:00.000Z",
  "priority": "low|normal|high|urgent",
  "status":   "open|done",
  "tags":     ["work","idea"],
  "children": [                       // chained sub-notes
    { "id":"uuid", "text":"…", "createdAt":"…", "updatedAt":"…" }
  ],
  "createdAt": "2025-04-21T12:34:56.000Z",
  "updatedAt": "2025-04-21T12:40:00.000Z",
  "language":  "tr"
}
```

## How STT works

* Library: `@huggingface/transformers@3.8.1` loaded from jsDelivr.
  The APK's transparent network cache persists this to disk on first load.
* Model: **whisper-base (multilingual)** by default, q8 quantized (~75 MB).
  Switch to `whisper-tiny` (~40 MB, faster, less accurate) or
  `whisper-small` (~240 MB, best accuracy for Turkish, slower) in Settings.
* Language: defaults to **Turkish**. Switchable in Settings.
* All inference runs on-device via WASM (no WebGPU needed).
* The model file is fetched from huggingface.co — the APK caches it so
  it is available fully offline after the first successful recording.

## How to use

1. Tap the mic button → records → releases → transcribes → saves a new memo
   and opens it for editing.
2. Tap a memo to edit title, body, due date, assignee, priority, tags,
   or add sub-notes (chain).
3. Inside a memo, tap "dictate" to append spoken text to the body or to a
   specific sub-note.
4. Long-press the mic to force a fresh memo even when
   "append to last" is enabled.
5. Tap the round circle on the right of a memo to mark it done/open.
6. Menu → Export to share/download the notes JSON for syncing to desktop.
