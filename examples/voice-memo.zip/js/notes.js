// js/notes.js — pure domain helpers for notes.

/**
 * Default due date for newly created notes: tomorrow at 09:00 local time.
 * Callers can override by passing `dueAt` in the partial, or leave it
 * empty by passing `dueAt: ''` explicitly.
 */
export function defaultDueAt() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(9, 0, 0, 0);
  return d.toISOString();
}

export function createNote(partial = {}) {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    title: partial.title || '',
    body: partial.body || '',
    assignee: partial.assignee || '',
    // If dueAt wasn't specified at all, default to tomorrow 9am.
    // If the caller passed an explicit empty string, respect that.
    dueAt: 'dueAt' in partial ? partial.dueAt : defaultDueAt(),
    priority: partial.priority || 'normal',
    status: partial.status || 'open',
    tags: partial.tags || [],
    children: partial.children || [],
    createdAt: now,
    updatedAt: now,
    language: partial.language || '',
  };
}

export function createChild(text = '') {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    text,
    createdAt: now,
    updatedAt: now,
  };
}

export function touchNote(n, patch = {}) {
  return { ...n, ...patch, updatedAt: new Date().toISOString() };
}

export function isOverdue(n) {
  if (!n.dueAt) return false;
  if (n.status === 'done') return false;
  return new Date(n.dueAt).getTime() < Date.now();
}

export function matchesQuery(n, q) {
  if (!q) return true;
  const needle = q.trim().toLowerCase();
  if (!needle) return true;
  const hay = [
    n.title, n.body, n.assignee,
    ...(n.tags || []),
    ...(n.children || []).map((c) => c.text),
  ].join(' ').toLowerCase();
  return hay.includes(needle);
}

export function matchesFilter(n, filter) {
  switch (filter) {
    case 'open':    return n.status !== 'done';
    case 'done':    return n.status === 'done';
    case 'overdue': return isOverdue(n);
    default:        return true;
  }
}

// sort: overdue first, then due soon, then priority, then updated desc
const PRIO = { urgent: 0, high: 1, normal: 2, low: 3 };
export function sortNotes(list) {
  return [...list].sort((a, b) => {
    if (a.status === 'done' && b.status !== 'done') return 1;
    if (a.status !== 'done' && b.status === 'done') return -1;
    const oa = isOverdue(a), ob = isOverdue(b);
    if (oa !== ob) return oa ? -1 : 1;
    const ad = a.dueAt ? new Date(a.dueAt).getTime() : Infinity;
    const bd = b.dueAt ? new Date(b.dueAt).getTime() : Infinity;
    if (ad !== bd) return ad - bd;
    const pa = PRIO[a.priority] ?? 2, pb = PRIO[b.priority] ?? 2;
    if (pa !== pb) return pa - pb;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });
}

export function parseTags(str) {
  if (!str) return [];
  return String(str)
    .split(/[,;\n]/)
    .map((s) => s.trim().replace(/^#/, ''))
    .filter(Boolean);
}

export function formatRelative(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const now = Date.now();
  const diff = Math.round((d.getTime() - now) / 1000);
  const abs = Math.abs(diff);
  const fmt = (n, unit) => {
    const sign = diff < 0 ? '' : 'in ';
    const past = diff < 0 ? ' ago' : '';
    return sign + Math.abs(n) + ' ' + unit + (Math.abs(n) === 1 ? '' : 's') + past;
  };
  if (abs < 60) return 'just now';
  if (abs < 3600) return fmt(Math.round(diff / 60), 'min');
  if (abs < 86400) return fmt(Math.round(diff / 3600), 'hr');
  if (abs < 86400 * 7) return fmt(Math.round(diff / 86400), 'day');
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: abs > 86400 * 365 ? 'numeric' : undefined });
}

export function formatDateTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

// convert ISO to value usable in <input type="datetime-local">
export function toLocalInput(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// convert datetime-local value back to ISO
export function fromLocalInput(v) {
  if (!v) return '';
  const d = new Date(v);
  if (isNaN(d.getTime())) return '';
  return d.toISOString();
}
