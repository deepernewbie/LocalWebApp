// js/stt.js — Speech-to-text using Transformers.js on the MAIN THREAD.
//
// We used to run this in a Web Worker, but module workers with
// cross-origin dynamic imports were unreliable in Android WebView
// (the worker would crash on first load). Running on the main thread
// works reliably; transcription is short (~1-3s for a 10s clip), so
// UI jank is acceptable.

let currentModel = null;
let pipelineFn = null;
let listeners = new Set();

function emit(ev) { for (const fn of listeners) try { fn(ev); } catch {} }
export function onSTT(fn) { listeners.add(fn); return () => listeners.delete(fn); }

// We import via the bare specifier "@huggingface/transformers" and rely
// on the <script type="importmap"> in index.html to resolve it.
//
// This matters because the CDN bundle has nested bare imports for
// "onnxruntime-common" and "onnxruntime-web". Only an import map can
// redirect those to real URLs. Importing transformers.js through a
// direct URL (no map) causes:
//   TypeError: Failed to resolve module specifier "onnxruntime-common"
// which is exactly the failure seen in v9.
const TRANSFORMERS_SPEC = '@huggingface/transformers';

// Tracks which load strategy succeeded, exposed on window for the debug
// screen to read. Values: null | 'direct' | 'blob' | 'script' | 'cached'.
let loadStrategy = null;

async function loadLib() {
  // If a previous call (or the debug probe) already loaded it, reuse.
  if (window.__transformers) {
    loadStrategy = loadStrategy || 'cached';
    window.__transformersLoadStrategy = loadStrategy;
    return window.__transformers;
  }

  const errors = [];

  // Primary: bare-specifier import, resolved by the <script type="importmap">
  // in index.html. This is the only path that correctly resolves the
  // nested "onnxruntime-common" / "onnxruntime-web" imports inside the
  // transformers.js bundle.
  try {
    const mod = await import(/* @vite-ignore */ TRANSFORMERS_SPEC);
    loadStrategy = 'importmap';
    window.__transformers = mod;
    window.__transformersLoadStrategy = loadStrategy;
    return mod;
  } catch (e) {
    errors.push(`importmap: ${e.name}: ${e.message}`);
    console.warn('[stt] importmap import failed, trying script injection:', e.message);
  }

  // Fallback: inject a <script type="module"> that does the same import.
  // Some WebView versions handle script-element imports on a slightly
  // different code path than direct import() expressions, which has
  // rescued us before when the direct form threw opaquely.
  try {
    await new Promise((resolve, reject) => {
      const id = '__stt_tf_script';
      document.getElementById(id)?.remove();
      const s = document.createElement('script');
      s.id = id;
      s.type = 'module';
      s.textContent = `
        import * as T from "${TRANSFORMERS_SPEC}";
        window.__transformers = T;
        window.dispatchEvent(new CustomEvent('__tfOk'));
      `;
      const onOk = () => { cleanup(); resolve(); };
      const onErr = e => { cleanup(); reject(new Error(e.message || 'script error')); };
      function cleanup() {
        window.removeEventListener('__tfOk', onOk);
        window.removeEventListener('error', onErr, true);
      }
      window.addEventListener('__tfOk', onOk, { once: true });
      window.addEventListener('error', onErr, true);
      document.head.appendChild(s);
      setTimeout(() => { cleanup(); reject(new Error('timeout 30s')); }, 30000);
    });
    if (!window.__transformers) throw new Error('script completed but window.__transformers unset');
    loadStrategy = 'script';
    window.__transformersLoadStrategy = loadStrategy;
    return window.__transformers;
  } catch (e) {
    errors.push(`script injection: ${e.name}: ${e.message}`);
  }

  throw new Error('Failed to load transformers.js — ' + errors.join(' | '));
}

export async function initModel(model) {
  if (pipelineFn && currentModel === model) return;
  currentModel = model;
  pipelineFn = null;

  emit({ type: 'progress', stage: 'loading-lib', file: 'transformers.js' });
  const { pipeline, env } = await loadLib();

  env.allowLocalModels = false;
  env.allowRemoteModels = true;
  env.useBrowserCache = true;

  // Android WebView over http://localhost doesn't provide cross-origin
  // isolation (no COOP/COEP headers), so SharedArrayBuffer is unavailable
  // and multi-threaded ONNX WASM crashes. Force single-threaded + pin
  // the wasm helper files to the CDN so the ORT loader can find them.
  try {
    if (env.backends && env.backends.onnx && env.backends.onnx.wasm) {
      env.backends.onnx.wasm.numThreads = 1;
      env.backends.onnx.wasm.simd = true;
      env.backends.onnx.wasm.proxy = false;
      env.backends.onnx.wasm.wasmPaths =
        'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/';
    }
  } catch (e) {
    // non-fatal; defaults will be used
  }

  emit({ type: 'progress', stage: 'loading-model', progress: 0, file: model });

  pipelineFn = await pipeline(
    'automatic-speech-recognition',
    model,
    {
      dtype: 'q8',
      device: 'wasm',
      progress_callback: (p) => {
        emit({
          type: 'progress',
          stage: p.status || 'downloading',
          file: p.file,
          progress: p.progress,
          loaded: p.loaded,
          total: p.total,
        });
      },
    },
  );

  emit({ type: 'ready' });
}

export function isModelReady(model) {
  return !!pipelineFn && currentModel === model;
}

// ──────────────────────────── recording ────────────────────────────
//
// Architecture note:
//
// This APK ships a "native audio shim" that intercepts getUserMedia
// and returns a MediaStream routed through Android's MediaRecorder
// pipeline. That stream works fine with MediaRecorder and with
// AnalyserNode (visualization), but produces ALL ZEROS when consumed
// via ScriptProcessorNode (which is what we used to do for raw
// Float32 capture). That's why the previous pipeline reported
// "peak=0.000" even with loud speech.
//
// So we now use MediaRecorder to record a compressed blob (opus/webm
// or mp4), then on stop we decode the blob via AudioContext's
// decodeAudioData and feed the decoded Float32 samples to Whisper.
// decodeAudioData returns samples in [-1, 1] already, so most of the
// normalization we were doing becomes unnecessary — we still do a
// DC-offset removal and peak normalization because Samsung mics can
// have small DC bias and benefit from consistent level.

let mediaStream = null;
let mediaRecorder = null;
let mediaRecorderError = null;
let recordedBlobs = [];
let recordedMimeType = '';
// AudioContext is kept only for the visualiser (AnalyserNode).
let vizAudioCtx = null;
let vizSource = null;
let analyser = null;
let recording = false;
let startedAt = 0;

const TARGET_SR = 16000;

// Progressive audio constraint profiles. Android WebView on some
// devices rejects the "ideal" constraint set silently at audio-source
// open time (producing the opaque "Could not start audio source"
// error). Each retry strips more options.
// Preferred-first. The "full processing" profile (AGC on) was causing
// clipping on loud speech — Android AGC clamps to ±1.0 and Whisper
// hallucinates boilerplate on saturated input. We want raw mono audio
// and normalize ourselves, so that profile goes first.
const AUDIO_CONSTRAINT_PROFILES = [
  { channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false },
  { channelCount: 1, echoCancellation: true,  noiseSuppression: true,  autoGainControl: false },
  { channelCount: 1 },
  true,
];

// Exported so the debug screen can show what the mic attempt actually
// produced at the OS level. Populated on every startRecording() call.
export let lastMicError = null;
export let lastMicProfileIndex = -1;
// Pre-normalization peak of the most recent recording. Used by
// transcribe() to distinguish real silence (peak near 0) from a quiet
// recording we've since amplified.
let lastRecordingPeak = 0;

async function acquireMicStream() {
  const errors = [];
  for (let i = 0; i < AUDIO_CONSTRAINT_PROFILES.length; i++) {
    const audio = AUDIO_CONSTRAINT_PROFILES[i];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio });
      lastMicProfileIndex = i;
      return stream;
    } catch (e) {
      // Capture the precise DOMException name — the UI toast was hiding
      // this from us. Typical values from Android WebView:
      //   NotReadableError — hardware/OS denied (another app using mic)
      //   NotAllowedError  — user/system denied permission
      //   OverconstrainedError — constraint profile not supported
      //   AbortError       — WebView killed the request
      errors.push(`profile ${i}: ${e.name}: ${e.message}`);
      // Short backoff between attempts — helps when the mic was just
      // released by another app.
      if (i < AUDIO_CONSTRAINT_PROFILES.length - 1) {
        await new Promise(r => setTimeout(r, 200));
      }
    }
  }
  const err = new Error('getUserMedia exhausted all profiles: ' + errors.join(' | '));
  err.detail = errors;
  throw err;
}

export async function startRecording() {
  if (recording) return;
  lastMicError = null;
  lastMicProfileIndex = -1;

  try {
    mediaStream = await acquireMicStream();
  } catch (e) {
    lastMicError = e;
    throw e;
  }

  // Visualiser — Analyser works on the native shim's stream. This is
  // separate from the recording path so even if MediaRecorder fails
  // for some reason, we still get a visual response.
  try {
    vizAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (vizAudioCtx.state === 'suspended') {
      try { await vizAudioCtx.resume(); } catch {}
    }
    vizSource = vizAudioCtx.createMediaStreamSource(mediaStream);
    analyser = vizAudioCtx.createAnalyser();
    analyser.fftSize = 512;
    vizSource.connect(analyser);
  } catch (e) {
    // Non-fatal: record without visualization
    console.warn('[stt] visualiser setup failed:', e);
    analyser = null;
  }

  // Pick the best MediaRecorder mime type. Order matters — opus in
  // webm is the most reliable on Android WebView. Without an explicit
  // type some WebView versions default to an empty container.
  const MIMES = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/ogg;codecs=opus',
    'audio/mp4',
    '',
  ];
  recordedMimeType = '';
  for (const m of MIMES) {
    if (!m) { recordedMimeType = ''; break; }
    if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(m)) {
      recordedMimeType = m;
      break;
    }
  }

  try {
    mediaRecorder = recordedMimeType
      ? new MediaRecorder(mediaStream, { mimeType: recordedMimeType })
      : new MediaRecorder(mediaStream);
  } catch (e) {
    try { mediaStream.getTracks().forEach(t => t.stop()); } catch {}
    mediaStream = null;
    lastMicError = e;
    throw new Error('MediaRecorder init failed: ' + e.name + ': ' + e.message);
  }

  recordedBlobs = [];
  mediaRecorder.ondataavailable = (ev) => {
    if (ev.data && ev.data.size > 0) recordedBlobs.push(ev.data);
  };

  // Capture async errors fired by the native shim's MediaRecorder.
  // On Samsung WebView with the LocalWebApp native audio shim, if
  // AudioRecord.start() fails (ERROR_CODE 7 = service unavailable, which
  // happens when the previous session hasn't fully released the mic),
  // the shim fires an 'error' event asynchronously. We surface it via
  // the mediaRecorderError flag so stopRecording can convert it into
  // a proper rejection instead of showing a misleading "transcribing..."
  // state on a recording that never started.
  mediaRecorderError = null;
  mediaRecorder.addEventListener('error', (ev) => {
    const err = (ev && ev.error) || new Error('MediaRecorder error');
    mediaRecorderError = err;
    console.warn('[stt] MediaRecorder error event:', err.name, err.message);
  });

  // Request a chunk every 250 ms so even if stop() never fires (WebView
  // kill, etc) we have partial audio available.
  mediaRecorder.start(250);

  startedAt = Date.now();
  recording = true;

  // Samsung mic quirk: sometimes recStart() fails on first attempt
  // immediately after a previous session ended. Wait a few ms then
  // check if the error flag fired — if so, tear down and retry once.
  await new Promise(r => setTimeout(r, 120));
  if (mediaRecorderError) {
    const firstErr = mediaRecorderError;
    console.warn('[stt] recording failed immediately, retrying once:', firstErr.message);
    try { mediaRecorder.stop(); } catch {}
    try { mediaStream.getTracks().forEach(t => t.stop()); } catch {}
    recording = false;
    mediaStream = null;
    mediaRecorder = null;
    // Give AudioRecord time to fully release before we reacquire
    await new Promise(r => setTimeout(r, 400));
    // Recurse — but only once; a second failure throws.
    if (window.__sttRetrying) {
      window.__sttRetrying = false;
      throw firstErr;
    }
    window.__sttRetrying = true;
    try {
      await startRecording();
    } finally {
      window.__sttRetrying = false;
    }
  }
}

export function getLevel() {
  if (!analyser) return 0;
  const arr = new Uint8Array(analyser.fftSize);
  analyser.getByteTimeDomainData(arr);
  let sum = 0;
  for (let i = 0; i < arr.length; i++) {
    const v = (arr[i] - 128) / 128;
    sum += v * v;
  }
  return Math.sqrt(sum / arr.length);
}

export function getWaveform() {
  if (!analyser) return null;
  const arr = new Uint8Array(analyser.fftSize);
  analyser.getByteTimeDomainData(arr);
  return arr;
}

export function getElapsedMs() {
  return recording ? Date.now() - startedAt : 0;
}

export function isRecording() { return recording; }

export async function stopRecording() {
  if (!recording) return null;
  recording = false;

  // Stop the MediaRecorder and wait for the final dataavailable + stop.
  let finalBlob = null;
  try {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      finalBlob = await new Promise((resolve) => {
        let settled = false;
        mediaRecorder.onstop = () => {
          if (settled) return;
          settled = true;
          const type = recordedMimeType || (recordedBlobs[0]?.type) || 'audio/webm';
          resolve(new Blob(recordedBlobs, { type }));
        };
        // Safety: if onstop doesn't fire within 1s, assemble what we have.
        setTimeout(() => {
          if (settled) return;
          settled = true;
          const type = recordedMimeType || (recordedBlobs[0]?.type) || 'audio/webm';
          resolve(new Blob(recordedBlobs, { type }));
        }, 1000);
        try { mediaRecorder.stop(); } catch { /* already stopped */ }
      });
    }
  } catch (e) {
    console.warn('[stt] recorder stop failed:', e);
  }

  // Release mic + visualiser
  try { vizSource && vizSource.disconnect(); } catch {}
  try { analyser && analyser.disconnect(); } catch {}
  try { mediaStream && mediaStream.getTracks().forEach((t) => t.stop()); } catch {}
  try { vizAudioCtx && await vizAudioCtx.close(); } catch {}
  vizSource = null; analyser = null; mediaStream = null; vizAudioCtx = null;
  mediaRecorder = null;
  recordedBlobs = [];

  if (!finalBlob || finalBlob.size === 0) {
    lastRecordingPeak = 0;
    return null;
  }

  // Decode the container/codec blob into raw Float32 samples.
  // decodeAudioData needs a fresh AudioContext — the viz one is closed.
  const decodeCtx = new (window.AudioContext || window.webkitAudioContext)();
  let audioBuf;
  try {
    const arr = await finalBlob.arrayBuffer();
    audioBuf = await decodeCtx.decodeAudioData(arr);
  } catch (e) {
    try { await decodeCtx.close(); } catch {}
    lastRecordingPeak = 0;
    throw new Error('decodeAudioData failed: ' + e.message);
  }

  const srcRate = audioBuf.sampleRate;
  // Downmix to mono if needed
  let mono;
  if (audioBuf.numberOfChannels === 1) {
    mono = new Float32Array(audioBuf.length);
    audioBuf.copyFromChannel(mono, 0);
  } else {
    mono = new Float32Array(audioBuf.length);
    const tmp = new Float32Array(audioBuf.length);
    for (let c = 0; c < audioBuf.numberOfChannels; c++) {
      audioBuf.copyFromChannel(tmp, c);
      for (let i = 0; i < mono.length; i++) mono[i] += tmp[i];
    }
    const inv = 1 / audioBuf.numberOfChannels;
    for (let i = 0; i < mono.length; i++) mono[i] *= inv;
  }
  try { await decodeCtx.close(); } catch {}

  // DC-offset removal + peak normalization. decodeAudioData already
  // returns samples in [-1, 1], but level can still vary widely.
  let mean = 0;
  for (let i = 0; i < mono.length; i++) mean += mono[i];
  mean /= mono.length || 1;
  let peak = 0;
  for (let i = 0; i < mono.length; i++) {
    mono[i] -= mean;
    const abs = Math.abs(mono[i]);
    if (abs > peak) peak = abs;
  }
  lastRecordingPeak = peak;
  if (peak > 1e-4) {
    const gain = 0.95 / peak;
    for (let i = 0; i < mono.length; i++) mono[i] *= gain;
  }

  const audio = (srcRate === TARGET_SR)
    ? mono
    : resampleLinear(mono, srcRate, TARGET_SR);

  return audio;
}

export function cancelRecording() {
  if (!recording && !mediaStream) return;
  recording = false;
  try { mediaRecorder && mediaRecorder.state !== 'inactive' && mediaRecorder.stop(); } catch {}
  try { vizSource && vizSource.disconnect(); } catch {}
  try { analyser && analyser.disconnect(); } catch {}
  try { mediaStream && mediaStream.getTracks().forEach((t) => t.stop()); } catch {}
  try { vizAudioCtx && vizAudioCtx.close(); } catch {}
  vizSource = null; analyser = null;
  mediaStream = null; vizAudioCtx = null;
  mediaRecorder = null;
  recordedBlobs = [];
}

// ──────────────────────────── transcription ────────────────────────────

/**
 * Common Whisper hallucinations on silent or near-silent audio. When
 * the model has nothing real to transcribe, it falls back to phrases
 * from its training distribution — YouTube subtitle boilerplate, stock
 * "thank you" closings, etc. We filter these out post-hoc. The list is
 * conservative: exact-match or whole-phrase only, case-insensitive.
 */
const HALLUCINATION_PHRASES = [
  'thanks for watching',
  'thank you for watching',
  'thank you',
  'thanks',
  'please subscribe',
  'subscribe',
  'altyazı m.k.',
  'altyazı: m.k.',
  'altyazı',
  'abone olmayı unutmayın',
  'teşekkür ederim',
  'iyi seyirler',
  'i\'ll see you next time',
  'bye',
  '.',
  '...',
  'you',
];

function isHallucination(text) {
  const t = text.trim().toLowerCase().replace(/[.!?]+$/, '');
  if (!t) return true;
  if (HALLUCINATION_PHRASES.includes(t)) return true;
  // Detect pathological repetition: same short phrase repeated 3+ times.
  // This catches "thank you thank you thank you..." loops that Whisper
  // falls into on ambiguous low-energy audio.
  const words = t.split(/\s+/);
  if (words.length >= 6) {
    const half = Math.floor(words.length / 2);
    const firstHalf = words.slice(0, half).join(' ');
    const secondHalf = words.slice(half, half * 2).join(' ');
    if (firstHalf === secondHalf) return true;
  }
  // Simple unigram-repeat check: if one word is >60% of all words
  // and length is >= 4 words, it's almost certainly a loop.
  if (words.length >= 4) {
    const counts = new Map();
    for (const w of words) counts.set(w, (counts.get(w) || 0) + 1);
    for (const [, c] of counts) {
      if (c / words.length > 0.6) return true;
    }
  }
  return false;
}

export async function transcribe(audio, language) {
  if (!pipelineFn) throw new Error('Model not initialized');
  const t0 = performance.now();

  // Early-out for true silence. We check the peak amplitude *before*
  // normalization — if the mic recorded nothing but floor noise, the
  // pre-norm peak will be under ~0.01 on any real device. After
  // normalization the RMS looks fine (we amplified it), so we can't
  // use post-norm RMS for this check.
  const rawPeak = lastRecordingPeak;
  if (rawPeak < 0.01) {
    return {
      text: '',
      language: language || 'auto',
      durationMs: Math.round(performance.now() - t0),
      skipped: 'silence',
      rawPeak,
    };
  }

  const opts = {
    chunk_length_s: 30,
    stride_length_s: 5,
    return_timestamps: false,
    // Whisper's built-in thresholds. If the model's own confidence is
    // low, it returns empty rather than hallucinating. Sampling is
    // disabled (temperature 0) for stable, deterministic output.
    no_speech_threshold: 0.6,
    logprob_threshold: -1.0,
    temperature: 0,
    condition_on_previous_text: false,
  };
  if (language && language !== 'auto') {
    opts.language = language;
    opts.task = 'transcribe';
  }
  const out = await pipelineFn(audio, opts);
  let text = (out && (out.text ?? out[0]?.text)) || '';
  text = text.trim();

  // Filter known hallucinations post-hoc.
  if (isHallucination(text)) {
    return {
      text: '',
      language: language || 'auto',
      durationMs: Math.round(performance.now() - t0),
      skipped: 'hallucination',
      original: text,
      rawPeak,
    };
  }

  return {
    text,
    language: language || 'auto',
    durationMs: Math.round(performance.now() - t0),
    rawPeak,
  };
}

// ──────────────────────────── helpers ────────────────────────────

function resampleLinear(input, fromRate, toRate) {
  if (fromRate === toRate) return input;
  const ratio = fromRate / toRate;
  const newLen = Math.round(input.length / ratio);
  const out = new Float32Array(newLen);
  for (let i = 0; i < newLen; i++) {
    const idx = i * ratio;
    const i0 = Math.floor(idx);
    const i1 = Math.min(i0 + 1, input.length - 1);
    const frac = idx - i0;
    out[i] = input[i0] * (1 - frac) + input[i1] * frac;
  }
  return out;
}
