// js/storage.js — layered persistent store for notes.
//
// Priority order (first available wins for both read and write):
//
//   1. AndroidFS  → writes notes/notes.json into the SAF folder the user
//      picked when opening the web app. Visible in the file manager,
//      survives uninstall-reinstall of the LocalWebApp shell, survives
//      port changes, and is portable between devices by copying the
//      folder. Exposed by the APK as window.AndroidFS.
//
//   2. OPFS → browser origin-scoped storage. Used when running in a
//      normal browser or if AndroidFS isn't available for some reason.
//      Path is the same (notes/notes.json inside OPFS root).
//
//   3. localStorage → last-resort mirror. Always written so we never
//      lose data. Used as read-source only if AndroidFS and OPFS are
//      both unavailable or empty.
//
// Settings live only in localStorage (small, OK to be origin-scoped).

const NOTES_PATH = 'notes/notes.json';
const NOTES_DIR = 'notes';
const NOTES_FILE = 'notes.json';
const LS_NOTES_KEY = 'vm.notes.v1';
const LS_SETTINGS_KEY = 'vm.settings.v1';

const DEFAULT_SETTINGS = {
  language: 'tr',
  model: 'Xenova/whisper-base',
  haptics: true,
  autoSave: true,
  appendToLast: false,
};

// ──────────────────────────── AndroidFS helpers ────────────────────────────

// Runtime diagnostics — exposed on window so the debug screen can
// render a full history of storage decisions. Crucial for figuring out
// why persistence fails in production.
const storageTrace = [];
window.__storageTrace = storageTrace;
function trace(...args) {
  const line = `[${new Date().toISOString().slice(11, 23)}] ` +
    args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
  storageTrace.push(line);
  if (storageTrace.length > 50) storageTrace.shift();
  console.log('[storage]', ...args);
}

function androidFsAvailable() {
  try {
    return typeof window !== 'undefined'
      && window.AndroidFS
      && typeof window.AndroidFS.read === 'function'
      && typeof window.AndroidFS.write === 'function';
  } catch { return false; }
}

async function androidFsReadNotes() {
  try {
    // Use exists as a hint but don't gate on it — read is ground truth.
    let existsHint = null;
    if (typeof window.AndroidFS.exists === 'function') {
      try {
        const raw = await window.AndroidFS.exists(NOTES_PATH);
        existsHint = !!raw;
        trace('AndroidFS.exists', NOTES_PATH, '→', raw);
      } catch (e) {
        trace('AndroidFS.exists threw:', e.message);
      }
    }
    const raw = await window.AndroidFS.read(NOTES_PATH);
    trace('AndroidFS.read', NOTES_PATH, '→', raw == null ? 'null' : `${String(raw).length} chars`);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    trace('parsed OK, notes:', Array.isArray(parsed.notes) ? parsed.notes.length : '(not array)');
    return parsed;
  } catch (e) {
    trace('AndroidFS.read threw:', e.name, e.message);
    return null;
  }
}

async function androidFsWriteNotes(data) {
  const payload = JSON.stringify(data, null, 2);
  if (typeof window.AndroidFS.mkdir === 'function') {
    try {
      const ok = await window.AndroidFS.mkdir(NOTES_DIR);
      trace('AndroidFS.mkdir', NOTES_DIR, '→', ok);
    } catch (e) {
      trace('AndroidFS.mkdir threw:', e.message);
    }
  }
  const ok = await window.AndroidFS.write(NOTES_PATH, payload);
  trace('AndroidFS.write', NOTES_PATH, payload.length, 'chars →', ok);
  if (!ok) throw new Error('AndroidFS.write returned false');

  // Read-back verification — catches "write said ok but nothing persisted".
  try {
    const back = await window.AndroidFS.read(NOTES_PATH);
    const len = back == null ? 0 : String(back).length;
    trace('AndroidFS.write read-back:', len, 'chars');
    if (len < payload.length) {
      throw new Error(`read-back returned ${len} chars, expected ${payload.length}`);
    }
  } catch (e) {
    trace('AndroidFS.write read-back failed:', e.message);
    throw e;
  }
}

// ──────────────────────────── OPFS helpers ────────────────────────────

function opfsAvailable() {
  try {
    return typeof navigator !== 'undefined'
      && navigator.storage
      && typeof navigator.storage.getDirectory === 'function';
  } catch { return false; }
}

async function getOpfsNotesDir() {
  const root = await navigator.storage.getDirectory();
  return await root.getDirectoryHandle(NOTES_DIR, { create: true });
}

async function opfsReadNotes() {
  try {
    const dir = await getOpfsNotesDir();
    const h = await dir.getFileHandle(NOTES_FILE, { create: false });
    const f = await h.getFile();
    const text = await f.text();
    if (!text) return null;
    return JSON.parse(text);
  } catch {
    return null;
  }
}

async function opfsWriteNotes(data) {
  const dir = await getOpfsNotesDir();
  const h = await dir.getFileHandle(NOTES_FILE, { create: true });
  const w = await h.createWritable();
  await w.write(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  await w.close();
}

// ──────────────────────────── public API ────────────────────────────

// Where the last successful read came from, for debug/about panels.
let lastReadSource = 'none';
export function getStorageSource() { return lastReadSource; }

export async function loadNotes() {
  trace('loadNotes() called');
  trace('  AndroidFS available:', androidFsAvailable(),
        '  window.AndroidFS keys:',
        window.AndroidFS ? Object.keys(window.AndroidFS).join(',') : '(no window.AndroidFS)');
  trace('  OPFS available:', opfsAvailable());

  // 1. AndroidFS — user-visible folder
  if (androidFsAvailable()) {
    const fs = await androidFsReadNotes();
    if (fs && Array.isArray(fs.notes)) {
      lastReadSource = 'AndroidFS';
      trace('→ loaded from AndroidFS,', fs.notes.length, 'notes');
      return normalize(fs);
    }
    trace('AndroidFS empty/failed, falling through');
  }
  // 2. OPFS — browser origin-scoped
  if (opfsAvailable()) {
    const opfs = await opfsReadNotes();
    if (opfs && Array.isArray(opfs.notes)) {
      lastReadSource = 'OPFS';
      trace('→ loaded from OPFS,', opfs.notes.length, 'notes');
      return normalize(opfs);
    }
    trace('OPFS empty, falling through');
  }
  // 3. localStorage mirror
  try {
    const raw = localStorage.getItem(LS_NOTES_KEY);
    if (raw) {
      lastReadSource = 'localStorage';
      const parsed = JSON.parse(raw);
      trace('→ loaded from localStorage,', parsed.notes?.length || 0, 'notes');
      return normalize(parsed);
    }
  } catch {}
  lastReadSource = 'empty';
  trace('→ nothing found, starting fresh');
  return { version: 1, notes: [] };
}

export async function saveNotes(store) {
  const data = { ...store, updatedAt: new Date().toISOString() };
  const payload = JSON.stringify(data, null, 2);
  trace('saveNotes()', data.notes?.length || 0, 'notes,', payload.length, 'bytes');

  // Always mirror to localStorage first — cheapest, never throws to caller.
  try {
    localStorage.setItem(LS_NOTES_KEY, payload);
    trace('  localStorage mirror OK');
  } catch (e) {
    trace('  localStorage mirror failed:', e.message);
  }

  // Preferred target: AndroidFS. Visible in file manager.
  if (androidFsAvailable()) {
    try {
      await androidFsWriteNotes(data);
      trace('→ saved to AndroidFS');
      return data;
    } catch (e) {
      trace('  AndroidFS write failed:', e.message, '— falling back to OPFS');
    }
  }

  // Fallback: OPFS.
  if (opfsAvailable()) {
    try {
      await opfsWriteNotes(data);
      trace('→ saved to OPFS');
      return data;
    } catch (e) {
      trace('  OPFS write failed:', e.message);
    }
  }

  trace('→ only localStorage mirror; no durable store');
  return data;
}

export function loadSettings() {
  try {
    const raw = localStorage.getItem(LS_SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {}
  return { ...DEFAULT_SETTINGS };
}

export function saveSettings(s) {
  const merged = { ...DEFAULT_SETTINGS, ...s };
  try { localStorage.setItem(LS_SETTINGS_KEY, JSON.stringify(merged)); } catch {}
  return merged;
}

// Export notes as a JSON blob + filename
export function exportNotesBlob(store) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename = `voice-memos-${stamp}.json`;
  const blob = new Blob([JSON.stringify(store, null, 2)], { type: 'application/json' });
  return { blob, filename };
}

// Merge imported notes; IDs are preserved. Conflicts: newer `updatedAt` wins.
export function mergeImport(current, imported) {
  if (!imported || !Array.isArray(imported.notes)) {
    throw new Error('Invalid import file');
  }
  const byId = new Map(current.notes.map((n) => [n.id, n]));
  let added = 0, updated = 0;
  for (const n of imported.notes) {
    if (!n.id) continue;
    const existing = byId.get(n.id);
    if (!existing) { byId.set(n.id, n); added++; }
    else {
      const a = new Date(existing.updatedAt || 0).getTime();
      const b = new Date(n.updatedAt || 0).getTime();
      if (b > a) { byId.set(n.id, n); updated++; }
    }
  }
  return {
    store: { ...current, notes: Array.from(byId.values()) },
    added, updated,
  };
}

export async function wipeAll() {
  try { localStorage.removeItem(LS_NOTES_KEY); } catch {}
  if (androidFsAvailable() && typeof window.AndroidFS.delete === 'function') {
    try { await window.AndroidFS.delete(NOTES_PATH); } catch {}
  }
  if (opfsAvailable()) {
    try {
      const dir = await getOpfsNotesDir();
      await dir.removeEntry(NOTES_FILE).catch(() => {});
    } catch {}
  }
}

// ──────────────────────────── migration / defaults ────────────────────────────

function normalize(store) {
  const out = { version: 1, notes: [] };
  if (!store) return out;
  if (store.version) out.version = store.version;
  if (Array.isArray(store.notes)) {
    out.notes = store.notes.map((n) => ({
      id: n.id || crypto.randomUUID(),
      title: n.title || '',
      body: n.body || '',
      assignee: n.assignee || '',
      dueAt: n.dueAt || '',
      priority: n.priority || 'normal',
      status: n.status || 'open',
      tags: Array.isArray(n.tags) ? n.tags : [],
      children: Array.isArray(n.children)
        ? n.children.map((c) => ({
            id: c.id || crypto.randomUUID(),
            text: c.text || '',
            createdAt: c.createdAt || new Date().toISOString(),
            updatedAt: c.updatedAt || c.createdAt || new Date().toISOString(),
          }))
        : [],
      createdAt: n.createdAt || new Date().toISOString(),
      updatedAt: n.updatedAt || n.createdAt || new Date().toISOString(),
      language: n.language || '',
    }));
  }
  return out;
}

export async function storageFacts() {
  const facts = {};
  facts['AndroidFS'] = androidFsAvailable() ? 'available' : 'unavailable';
  facts['OPFS']      = opfsAvailable() ? 'available' : 'unavailable';
  facts['Source']    = lastReadSource;
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const e = await navigator.storage.estimate();
      if (e.quota) facts['Quota'] = `${(e.quota / 1e9).toFixed(2)} GB`;
      if (e.usage) facts['Used']  = `${(e.usage / 1e6).toFixed(1)} MB`;
    }
  } catch {}
  return facts;
}
