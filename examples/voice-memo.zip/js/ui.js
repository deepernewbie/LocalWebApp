// js/ui.js — rendering and DOM helpers.

import {
  isOverdue,
  formatRelative,
  formatDateTime,
  sortNotes,
  matchesQuery,
  matchesFilter,
  toLocalInput,
} from './notes.js';

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

// ──────────────────────────── notes list ────────────────────────────

export function renderList({ listEl, emptyEl, notes, query, filter, onOpen, onToggle }) {
  const filtered = sortNotes(
    notes.filter((n) => matchesQuery(n, query) && matchesFilter(n, filter))
  );

  listEl.innerHTML = '';
  emptyEl.hidden = filtered.length > 0;

  if (!filtered.length) return;

  // Group: Overdue / Today / Upcoming / No due / Done
  const groups = {
    'Overdue':  [],
    'Today':    [],
    'Upcoming': [],
    'Someday':  [],
    'Done':     [],
  };
  const todayEnd = new Date(); todayEnd.setHours(23, 59, 59, 999);
  for (const n of filtered) {
    if (n.status === 'done') { groups['Done'].push(n); continue; }
    if (isOverdue(n))        { groups['Overdue'].push(n); continue; }
    if (n.dueAt && new Date(n.dueAt) <= todayEnd) { groups['Today'].push(n); continue; }
    if (n.dueAt)             { groups['Upcoming'].push(n); continue; }
    groups['Someday'].push(n);
  }

  const frag = document.createDocumentFragment();
  for (const [label, list] of Object.entries(groups)) {
    if (!list.length) continue;
    const sep = document.createElement('div');
    sep.className = 'notes__sep';
    sep.textContent = `${label} · ${list.length}`;
    frag.appendChild(sep);
    for (const n of list) {
      frag.appendChild(renderNoteCard(n, { onOpen, onToggle }));
    }
  }
  listEl.appendChild(frag);
}

function renderNoteCard(n, { onOpen, onToggle }) {
  const el = document.createElement('article');
  el.className = 'note';
  el.dataset.id = n.id;
  el.dataset.priority = n.priority;
  el.dataset.status = n.status;

  const head = document.createElement('div');
  head.className = 'note__head';
  const title = document.createElement('div');
  title.className = 'note__title';
  title.textContent = n.title || (n.body ? n.body.slice(0, 60) : 'Untitled memo');

  const tick = document.createElement('button');
  tick.className = 'note__tick';
  tick.setAttribute('aria-label', n.status === 'done' ? 'Mark open' : 'Mark done');
  tick.addEventListener('click', (ev) => {
    ev.stopPropagation();
    onToggle(n.id);
  });

  head.append(title, tick);
  el.appendChild(head);

  if (n.title && n.body) {
    const body = document.createElement('div');
    body.className = 'note__body';
    body.textContent = n.body;
    el.appendChild(body);
  }

  const meta = document.createElement('div');
  meta.className = 'note__meta';

  if (n.dueAt) {
    const pill = document.createElement('span');
    pill.className = 'pill ' + (isOverdue(n) ? 'pill--overdue' : 'pill--due');
    pill.innerHTML = `<svg viewBox="0 0 24 24" width="10" height="10" style="opacity:.9"><rect x="3" y="5" width="18" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><line x1="3" y1="10" x2="21" y2="10" stroke="currentColor" stroke-width="2"/></svg> ${formatRelative(n.dueAt)}`;
    meta.appendChild(pill);
  }
  if (n.assignee) {
    const pill = document.createElement('span');
    pill.className = 'pill pill--assignee';
    pill.textContent = '@ ' + n.assignee;
    meta.appendChild(pill);
  }
  if (n.children && n.children.length) {
    const pill = document.createElement('span');
    pill.className = 'pill pill--chain';
    pill.textContent = `⛓ ${n.children.length}`;
    meta.appendChild(pill);
  }
  for (const t of (n.tags || []).slice(0, 3)) {
    const pill = document.createElement('span');
    pill.className = 'pill pill--tag';
    pill.textContent = '#' + t;
    meta.appendChild(pill);
  }
  if (meta.children.length) el.appendChild(meta);

  const date = document.createElement('div');
  date.className = 'note__date';
  date.textContent = 'upd · ' + formatRelative(n.updatedAt);
  el.appendChild(date);

  el.addEventListener('click', () => onOpen(n.id));
  return el;
}

// ──────────────────────────── sheets ────────────────────────────

export function openSheet(id) {
  if (window.__openSheet) return window.__openSheet(id);
  const sheet = document.getElementById(id);
  if (!sheet) return;
  sheet.hidden = false;
  sheet.classList.remove('is-closed');
  sheet.style.display = '';
  document.body.style.overflow = 'hidden';
}

export function closeSheet(id) {
  if (window.__closeSheet) return window.__closeSheet(id);
  const sheet = document.getElementById(id);
  if (!sheet) return;
  sheet.hidden = true;
  sheet.classList.add('is-closed');
  sheet.style.display = 'none';
  document.body.style.overflow = '';
}

export function closeAllSheets() {
  $$('.sheet').forEach((s) => {
    s.hidden = true;
    s.classList.add('is-closed');
    s.style.display = 'none';
  });
  document.body.style.overflow = '';
}

// ──────────────────────────── editor population ────────────────────────────

export function fillEditor(n) {
  $('#fTitle').value = n.title || '';
  $('#fBody').value = n.body || '';
  $('#fAssignee').value = n.assignee || '';
  $('#fDue').value = toLocalInput(n.dueAt);
  $('#fPriority').value = n.priority || 'normal';
  $('#fTags').value = (n.tags || []).join(', ');
  renderChildren(n.children || []);
  const meta = [];
  if (n.createdAt) meta.push(`created  · ${formatDateTime(n.createdAt)}`);
  if (n.updatedAt) meta.push(`modified · ${formatDateTime(n.updatedAt)}`);
  if (n.language)  meta.push(`language · ${n.language}`);
  $('#metaTs').textContent = meta.join('\n');
  $('#editorState').textContent = n.createdAt && n.updatedAt && n.createdAt !== n.updatedAt ? 'EDIT' : 'NEW';
}

export function renderChildren(children) {
  const list = $('#childrenList');
  list.innerHTML = '';
  for (const c of children) list.appendChild(childRow(c));
}

export function appendChildRow(child) {
  $('#childrenList').appendChild(childRow(child));
}

function childRow(c) {
  const el = document.createElement('div');
  el.className = 'child';
  el.dataset.id = c.id;

  const ta = document.createElement('textarea');
  ta.className = 'child__text';
  ta.rows = 2;
  ta.value = c.text || '';
  ta.dataset.field = 'text';
  ta.placeholder = 'Sub-note…';
  autoResize(ta);
  ta.addEventListener('input', () => autoResize(ta));

  const foot = document.createElement('div');
  foot.className = 'child__foot';
  const meta = document.createElement('span');
  meta.textContent = formatRelative(c.updatedAt || c.createdAt);
  const actions = document.createElement('span');
  const micBtn = document.createElement('button');
  micBtn.className = 'child__mic';
  micBtn.type = 'button';
  micBtn.innerHTML = '🎙 dictate';
  micBtn.dataset.action = 'mic-child';
  const delBtn = document.createElement('button');
  delBtn.className = 'child__del';
  delBtn.type = 'button';
  delBtn.innerHTML = 'remove';
  delBtn.dataset.action = 'del-child';
  actions.append(micBtn, ' · ', delBtn);
  foot.append(meta, actions);

  el.append(ta, foot);
  return el;
}

function autoResize(ta) {
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 200) + 'px';
}

export function collectChildrenFromDOM() {
  const out = [];
  $$('#childrenList .child').forEach((row) => {
    const id = row.dataset.id;
    const text = row.querySelector('textarea').value.trim();
    if (!text) return;  // drop empty
    out.push({ id, text });
  });
  return out;
}

// ──────────────────────────── search bar ────────────────────────────

export function setActiveFilter(filter) {
  $$('.chip').forEach((c) => c.classList.toggle('is-active', c.dataset.filter === filter));
}

// ──────────────────────────── banner ────────────────────────────

export function showBanner(text, progress = null) {
  $('#banner').hidden = false;
  $('#bannerText').textContent = text;
  if (progress === null) {
    $('#bannerBar').style.width = '0';
  } else {
    $('#bannerBar').style.width = Math.max(0, Math.min(100, progress)) + '%';
  }
}

export function hideBanner() {
  $('#banner').hidden = true;
}

// ──────────────────────────── recorder visualizer ────────────────────────────

let vizRaf = null;
export function startVisualizer(getWaveform, getElapsed) {
  const canvas = $('#vizCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const resize = () => {
    canvas.width = canvas.clientWidth * dpr;
    canvas.height = canvas.clientHeight * dpr;
  };
  resize();

  const tick = () => {
    const data = getWaveform();
    if (!data) { vizRaf = requestAnimationFrame(tick); return; }
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // dashed center line
    ctx.strokeStyle = 'rgba(233,184,114,.15)';
    ctx.setLineDash([3 * dpr, 4 * dpr]);
    ctx.beginPath();
    ctx.moveTo(0, canvas.height / 2);
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // waveform
    ctx.strokeStyle = '#f6a63a';
    ctx.lineWidth = 1.5 * dpr;
    ctx.beginPath();
    const step = canvas.width / data.length;
    for (let i = 0; i < data.length; i++) {
      const v = (data[i] - 128) / 128;
      const x = i * step;
      const y = canvas.height / 2 + v * (canvas.height / 2) * 0.9;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // timer
    if (getElapsed) {
      const ms = getElapsed();
      const secs = Math.floor(ms / 1000);
      const mm = String(Math.floor(secs / 60)).padStart(2, '0');
      const ss = String(secs % 60).padStart(2, '0');
      $('#recTimer').textContent = `${mm}:${ss}`;
      $('#fabTimer').textContent = `${mm}:${ss}`;
    }
    vizRaf = requestAnimationFrame(tick);
  };
  vizRaf = requestAnimationFrame(tick);
}

export function stopVisualizer() {
  if (vizRaf) { cancelAnimationFrame(vizRaf); vizRaf = null; }
}
