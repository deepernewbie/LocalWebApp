// js/bridge.js — Safe wrapper around window.Android.
// All calls are guarded so the app runs in a normal browser too.

const A = () => (typeof Android !== 'undefined' ? Android : null);

export const bridge = {
  isNative() {
    const a = A();
    try { return !!(a && a.isNativeApp && a.isNativeApp()); } catch { return false; }
  },

  platform() {
    const a = A();
    try { return a && a.getPlatform ? a.getPlatform() : 'web'; } catch { return 'web'; }
  },

  version() {
    const a = A();
    try { return a && a.getAppVersion ? a.getAppVersion() : '—'; } catch { return '—'; }
  },

  freeMB() {
    const a = A();
    try { return a && a.getFreeMB ? a.getFreeMB() : null; } catch { return null; }
  },

  toast(msg) {
    const a = A();
    try {
      if (a && a.toast) { a.toast(String(msg)); return; }
    } catch {}
    // fallback DOM toast
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = String(msg);
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2700);
  },

  log(msg) {
    const a = A();
    try { if (a && a.log) a.log(String(msg)); } catch {}
    // mirror to console for web
    // eslint-disable-next-line no-console
    console.log('[voice-memo]', msg);
  },

  share(text) {
    const a = A();
    try {
      if (a && a.share) { a.share(String(text)); return true; }
    } catch {}
    // Web Share API fallback
    if (navigator.share) {
      navigator.share({ text: String(text) }).catch(() => {});
      return true;
    }
    return false;
  },

  vibrate() {
    const a = A();
    try { if (a && a.vibrate) { a.vibrate(); return; } } catch {}
    if (navigator.vibrate) navigator.vibrate(30);
  },
};
