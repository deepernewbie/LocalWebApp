// prayer.js — Fetch prayer times from Aladhan API and pick the next one

const STORAGE_KEY_TIMES = 'salah.times.v1';
const STORAGE_KEY_LOC = 'salah.location.v1';
const STORAGE_KEY_CITY = 'salah.city.v1';

const PRAYER_ORDER = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
// Sunrise is displayed/used as a boundary but is not a "prayer to pray"
const PRAYERS_TO_PRAY = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

/**
 * Synchronous: get the last known location from localStorage.
 * Returns {lat, lon, acc, ts} or null. No freshness check —
 * caller can decide how stale is too stale.
 */
export function getCachedLocation() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_LOC);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}

/**
 * Fetch a fresh location from the GPS. Writes it to cache on success.
 * Throws on failure — caller should fall back to cached location.
 */
export async function fetchFreshLocation() {
  if (!navigator.geolocation) {
    throw new Error('Geolocation unavailable');
  }
  const pos = await new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      resolve,
      reject,
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 5 * 60 * 1000 }
    );
  });
  const loc = {
    lat: pos.coords.latitude,
    lon: pos.coords.longitude,
    acc: pos.coords.accuracy,
    ts: Date.now()
  };
  localStorage.setItem(STORAGE_KEY_LOC, JSON.stringify(loc));
  return loc;
}

/**
 * True if the cached location's coordinates are close enough to the
 * fresh coordinates that we don't need to re-fetch prayer times.
 * (~0.05° ≈ 5km of latitude, negligible impact on prayer times.)
 */
export function locationChangedSignificantly(oldLoc, newLoc) {
  if (!oldLoc || !newLoc) return true;
  const dLat = Math.abs(oldLoc.lat - newLoc.lat);
  const dLon = Math.abs(oldLoc.lon - newLoc.lon);
  return dLat > 0.05 || dLon > 0.05;
}

/**
 * Get a previously-cached city name for the given coordinates.
 * Returns null if we haven't geocoded these coords before.
 */
export function getCachedCity(lat, lon) {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CITY);
    if (!raw) return null;
    const c = JSON.parse(raw);
    // Only valid if within ~0.1° of the cached coords
    if (Math.abs(c.lat - lat) > 0.1 || Math.abs(c.lon - lon) > 0.1) return null;
    return c.name;
  } catch { return null; }
}

/**
 * Reverse geocode lat/lon → city name, and cache the result.
 */
export async function reverseGeocode(lat, lon) {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=10&accept-language=en`;
    const resp = await fetch(url, { headers: { 'User-Agent': 'SalahApp/1.0' } });
    if (!resp.ok) throw new Error('geocode failed');
    const data = await resp.json();
    const a = data.address || {};
    const city = a.city || a.town || a.village || a.hamlet || a.county || a.state;
    const country = a.country_code ? a.country_code.toUpperCase() : '';
    const name = city ? `${city}${country ? ', ' + country : ''}` : 'Unknown';
    try {
      localStorage.setItem(STORAGE_KEY_CITY, JSON.stringify({ lat, lon, name, ts: Date.now() }));
    } catch {}
    return name;
  } catch {
    return `${lat.toFixed(2)}°, ${lon.toFixed(2)}°`;
  }
}

/**
 * Fetch prayer times for today at given location using Aladhan API.
 * Uses method=2 (Islamic Society of North America) by default.
 */
export async function fetchPrayerTimes(lat, lon, method = 2) {
  const now = new Date();
  const dateStr = formatDateForApi(now);
  const cacheKey = `${STORAGE_KEY_TIMES}.${dateStr}.${lat.toFixed(3)}.${lon.toFixed(3)}.${method}`;

  // Try cache for today
  try {
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      const data = JSON.parse(cached);
      return data;
    }
  } catch {}

  const url = `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${lat}&longitude=${lon}&method=${method}`;
  const resp = await fetch(url);
  if (!resp.ok) throw new Error('Prayer times API failed: ' + resp.status);
  const json = await resp.json();
  if (!json?.data?.timings) throw new Error('Invalid prayer times response');

  const result = {
    timings: json.data.timings,         // {Fajr, Sunrise, Dhuhr, Asr, Sunset, Maghrib, Isha, ...}
    date: json.data.date,               // gregorian + hijri info
    meta: json.data.meta,
    fetchedAt: Date.now()
  };

  // Clean up stale cache entries for other days/locations
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(STORAGE_KEY_TIMES) && k !== cacheKey) {
        localStorage.removeItem(k);
      }
    }
    localStorage.setItem(cacheKey, JSON.stringify(result));
  } catch {}

  return result;
}

function formatDateForApi(d) {
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yyyy = d.getFullYear();
  return `${dd}-${mm}-${yyyy}`;  // aladhan expects DD-MM-YYYY
}

/**
 * Synchronous: find the most useful cached prayer-times entry.
 * Prefers today's cache for the given coords; falls back to any cached
 * entry from today (different coords), then to yesterday's if necessary.
 * Returns {data, isToday, isSameLocation} or null.
 */
export function getCachedPrayerTimes(lat, lon, method = 2) {
  const today = formatDateForApi(new Date());
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = formatDateForApi(yesterday);

  const coordPrefix = lat != null && lon != null
    ? `${STORAGE_KEY_TIMES}.${today}.${lat.toFixed(3)}.${lon.toFixed(3)}.${method}`
    : null;

  let best = null;

  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k || !k.startsWith(STORAGE_KEY_TIMES + '.')) continue;

      // Key shape: salah.times.v1.<DD-MM-YYYY>.<lat>.<lon>.<method>
      const parts = k.slice(STORAGE_KEY_TIMES.length + 1).split('.');
      if (parts.length < 4) continue;
      const keyDate = parts[0];
      const keyLat = parseFloat(parts[1] + '.' + parts[2]);
      const keyLon = parseFloat(parts[3] + '.' + parts[4]);

      let data;
      try { data = JSON.parse(localStorage.getItem(k)); } catch { continue; }
      if (!data?.timings) continue;

      const isToday = keyDate === today;
      const isYesterday = keyDate === yesterdayStr;
      if (!isToday && !isYesterday) continue;  // too old

      const sameLocation = lat != null &&
        Math.abs(keyLat - lat) < 0.01 &&
        Math.abs(keyLon - lon) < 0.01;

      // Score: today+sameLoc=4, today=3, yesterday+sameLoc=2, yesterday=1
      const score = (isToday ? 2 : 0) + (sameLocation ? 2 : 0) + (isToday ? 1 : 0);
      if (!best || score > best.score) {
        best = { data, isToday, isSameLocation: sameLocation, score };
      }
    }
  } catch {}

  if (!best) return null;
  return { data: best.data, isToday: best.isToday, isSameLocation: best.isSameLocation };
}

/**
 * Synchronous: get cached tomorrow's Fajr if we've stored it.
 */
export function getCachedTomorrowFajr(lat, lon) {
  try {
    const raw = localStorage.getItem('salah.tomorrowFajr.v1');
    if (!raw) return null;
    const c = JSON.parse(raw);
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = formatDateForApi(tomorrow);
    if (c.dateStr !== tomorrowStr) return null;
    if (lat != null && (Math.abs(c.lat - lat) > 0.01 || Math.abs(c.lon - lon) > 0.01)) return null;
    const d = new Date(tomorrow);
    const [h, m] = c.hhmm.split(':').map(Number);
    d.setHours(h, m, 0, 0);
    return d;
  } catch { return null; }
}

/**
 * Convert a "HH:MM" time string (local) into today's Date object.
 */
function timeStrToDate(hhmm, base = new Date()) {
  // aladhan sometimes returns "HH:MM (TZ)"; strip anything after space
  const clean = hhmm.split(' ')[0];
  const [h, m] = clean.split(':').map(Number);
  const d = new Date(base);
  d.setHours(h, m, 0, 0);
  return d;
}

/**
 * Build an ordered list of today's prayer events with Date objects.
 */
export function buildSchedule(timings, now = new Date()) {
  return PRAYER_ORDER.map(name => ({
    name,
    time: timeStrToDate(timings[name], now),
    timeStr: formatTime(timeStrToDate(timings[name], now)),
    isPrayer: PRAYERS_TO_PRAY.includes(name)
  }));
}

/**
 * Given today's schedule + current time, figure out current prayer
 * and next prayer. If we're past Isha, "next" is tomorrow's Fajr
 * (we return it with a flag so the UI can show the countdown correctly).
 */
export function getCurrentAndNext(schedule, tomorrowFajr, now = new Date()) {
  // Find current: latest prayer whose time <= now (only prayers-to-pray for "current")
  let current = null;
  for (const item of schedule) {
    if (!item.isPrayer) continue;
    if (item.time <= now) current = item;
  }

  // Next: earliest prayer (from schedule) whose time > now
  let next = null;
  for (const item of schedule) {
    if (item.time > now) { next = item; break; }
  }

  if (!next && tomorrowFajr) {
    next = { name: 'Fajr', time: tomorrowFajr, timeStr: formatTime(tomorrowFajr), isPrayer: true, isTomorrow: true };
  }

  return { current, next };
}

export function formatTime(d) {
  let h = d.getHours();
  const m = d.getMinutes();
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${String(m).padStart(2, '0')} ${ampm}`;
}

/**
 * Format countdown in the style "3h 24m" or "24m 15s" if under an hour
 */
export function formatCountdown(ms) {
  if (ms < 0) ms = 0;
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m`;
  return `${m}m ${String(s).padStart(2, '0')}s`;
}

/**
 * Get tomorrow's Fajr as a Date (same lat/lon, same method).
 * Used so that after Isha we can count down to next morning's Fajr.
 * Caches the result so subsequent app opens are instant.
 */
export async function fetchTomorrowFajr(lat, lon, method = 2) {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const dateStr = formatDateForApi(tomorrow);
  try {
    const url = `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${lat}&longitude=${lon}&method=${method}`;
    const resp = await fetch(url);
    if (!resp.ok) return null;
    const json = await resp.json();
    const fajr = json?.data?.timings?.Fajr;
    if (!fajr) return null;
    const hhmm = fajr.split(' ')[0];
    try {
      localStorage.setItem('salah.tomorrowFajr.v1', JSON.stringify({
        lat, lon, dateStr, hhmm
      }));
    } catch {}
    return timeStrToDate(fajr, tomorrow);
  } catch {
    return null;
  }
}

export { PRAYER_ORDER, PRAYERS_TO_PRAY };
