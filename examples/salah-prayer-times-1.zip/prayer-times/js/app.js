// app.js — Main application controller (cache-first, background-refresh)

import {
  getCachedLocation,
  fetchFreshLocation,
  locationChangedSignificantly,
  getCachedCity,
  reverseGeocode,
  fetchPrayerTimes,
  getCachedPrayerTimes,
  fetchTomorrowFajr,
  getCachedTomorrowFajr,
  buildSchedule,
  getCurrentAndNext,
  formatTime,
  formatCountdown,
  PRAYERS_TO_PRAY
} from './prayer.js';

import {
  qiblaBearing,
  distanceToKaaba,
  CompassWatcher
} from './qibla.js';

// ---------- DOM refs ----------
const el = id => document.getElementById(id);

const loadingScreen = el('loading');
const errorScreen = el('error');
const mainScreen = el('main');

const loadingLabel = el('loading-label');
const errorTitle = el('error-title');
const errorMessage = el('error-message');
const retryBtn = el('retry-btn');

const dateHijri = el('date-hijri');
const dateGreg = el('date-greg');
const locationText = el('location-text');

const nextName = el('next-name');
const nextTime = el('next-time');
const countdown = el('countdown');
const progressBar = el('progress-bar');
const currentLabel = el('current-label');
const prayerList = el('prayer-list');

const qiblaDistance = el('qibla-distance');
const compassRose = el('compass-rose');
const compassDegrees = el('compass-degrees');
const qiblaArrow = document.querySelector('.qibla-arrow');
const qiblaHint = el('qibla-hint');
const qiblaAligned = el('qibla-aligned');
const compassEnableBtn = el('compass-enable');

const tabButtons = document.querySelectorAll('.tab-btn');
const tabTimes = el('tab-times');
const tabQibla = el('tab-qibla');

// ---------- State ----------
const state = {
  location: null,
  timingsData: null,
  schedule: [],
  tomorrowFajr: null,
  qiblaAngle: 0,
  heading: 0,
  compassWatcher: null,
  countdownTimer: null,
  hasRenderedOnce: false
};

// ---------- Screens ----------
function show(screen) {
  [loadingScreen, errorScreen, mainScreen].forEach(s => s.classList.remove('active'));
  screen.classList.add('active');
}

function showError(title, message) {
  errorTitle.textContent = title;
  errorMessage.textContent = message;
  show(errorScreen);
}

// ---------- Refreshing indicator ----------
let refreshingCount = 0;
function setRefreshing(on) {
  refreshingCount += on ? 1 : -1;
  if (refreshingCount < 0) refreshingCount = 0;
  document.body.classList.toggle('refreshing', refreshingCount > 0);
}

// ---------- Prayer icons ----------
function iconFor(name) {
  const icons = {
    Fajr: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 3v3M5.6 5.6l2.1 2.1M3 12h3M18 12h3M16.3 7.7l2.1-2.1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M4 18h16M7 15a5 5 0 0 1 10 0" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
    Sunrise: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 4v3M5.6 6.6l2.1 2.1M3 13h3M18 13h3M16.3 8.7l2.1-2.1M4 19h16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M7 16a5 5 0 0 1 10 0" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>`,
    Dhuhr: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="1.5"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
    Asr: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="11" r="3.5" stroke="currentColor" stroke-width="1.5"/><path d="M12 3v2M4 11h2M20 11h2M6 5l1.4 1.4M18 5l-1.4 1.4M8 18c2-1 4-1 4-1s2 0 4 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
    Maghrib: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 15v-3M12 5v1M5.6 13.4L7 12M17 12l1.4 1.4M3 16h3M18 16h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M4 19h16M7 16a5 5 0 0 1 10 0" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
    Isha: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M19 14.5a7 7 0 1 1-8.5-9 5.5 5.5 0 0 0 8.5 9z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><circle cx="16" cy="6" r="0.8" fill="currentColor"/><circle cx="19" cy="9" r="0.6" fill="currentColor"/></svg>`
  };
  return icons[name] || '';
}

const SUB_LABELS = {
  Fajr: 'Dawn',
  Sunrise: 'Shurooq',
  Dhuhr: 'Noon',
  Asr: 'Afternoon',
  Maghrib: 'Sunset',
  Isha: 'Night'
};

// ---------- Date formatting ----------
function formatHijriDate(dateObj) {
  try {
    const h = dateObj.hijri;
    return `${h.day} ${h.month.en} ${h.year} AH`;
  } catch { return '—'; }
}

function formatGregorianDate(dateObj) {
  try {
    const g = dateObj.gregorian;
    return `${g.weekday.en} · ${g.day} ${g.month.en} ${g.year}`;
  } catch {
    const now = new Date();
    return now.toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  }
}

// ---------- Rendering ----------
function renderAll() {
  if (!state.timingsData) return;

  dateHijri.textContent = formatHijriDate(state.timingsData.date);
  dateGreg.textContent = formatGregorianDate(state.timingsData.date);

  if (state.location) {
    state.qiblaAngle = qiblaBearing(state.location.lat, state.location.lon);
    const km = distanceToKaaba(state.location.lat, state.location.lon);
    qiblaDistance.textContent = `${Math.round(km).toLocaleString()} km to the Kaaba`;
  }

  renderSchedule();
}

function renderSchedule() {
  if (!state.timingsData) return;
  state.schedule = buildSchedule(state.timingsData.timings);

  const now = new Date();
  const { current, next } = getCurrentAndNext(state.schedule, state.tomorrowFajr, now);

  prayerList.innerHTML = '';
  state.schedule.forEach(item => {
    if (!item.isPrayer && item.name !== 'Sunrise') return;
    const li = document.createElement('li');
    li.className = 'prayer-row';

    const isPast = item.time < now && (!current || current.name !== item.name);
    const isCurrent = current && current.name === item.name && item.isPrayer;

    if (isPast) li.classList.add('past');
    if (isCurrent) li.classList.add('current');

    li.innerHTML = `
      <div class="prayer-icon">${iconFor(item.name)}</div>
      <div>
        <div class="prayer-name">${item.name}</div>
        <div class="prayer-name-sub">${SUB_LABELS[item.name] || ''}</div>
      </div>
      <div class="prayer-time">${item.timeStr}</div>
    `;
    prayerList.appendChild(li);
  });

  if (next) {
    nextName.textContent = next.name;
    nextTime.textContent = (next.isTomorrow ? 'Tomorrow · ' : '') + next.timeStr;
  } else {
    nextName.textContent = '—';
    nextTime.textContent = '—';
  }

  currentLabel.textContent = current
    ? `Now praying · ${current.name}`
    : (next && next.name === 'Fajr' && next.isTomorrow
        ? 'After Isha · awaiting Fajr'
        : 'Before Fajr');

  updateCountdown();
}

function updateCountdown() {
  if (!state.schedule.length) return;
  const now = new Date();
  const { current, next } = getCurrentAndNext(state.schedule, state.tomorrowFajr, now);

  if (!next) {
    countdown.textContent = '—';
    progressBar.style.width = '0%';
    return;
  }

  const msLeft = next.time - now;
  countdown.textContent = formatCountdown(msLeft);

  let windowStart;
  if (current) {
    windowStart = current.time;
  } else {
    windowStart = new Date(now);
    windowStart.setHours(0, 0, 0, 0);
  }
  const total = next.time - windowStart;
  const elapsed = now - windowStart;
  const pct = Math.max(0, Math.min(100, (elapsed / total) * 100));
  progressBar.style.width = pct + '%';

  if (state._lastCurrent?.name !== current?.name || state._lastNext?.name !== next?.name) {
    state._lastCurrent = current;
    state._lastNext = next;
    queueMicrotask(() => renderSchedule());
  }
}

// ---------- Compass ----------
function updateCompass() {
  compassRose.style.transform = `rotate(${-state.heading}deg)`;
  compassDegrees.textContent = Math.round(state.heading) + '°';
  qiblaArrow.style.setProperty('--q', state.qiblaAngle + 'deg');

  const rel = ((state.qiblaAngle - state.heading) + 360) % 360;
  const diff = Math.min(rel, 360 - rel);
  if (diff < 6) {
    qiblaAligned.classList.add('show');
    qiblaHint.classList.add('hide');
    if (!state._wasAligned) {
      state._wasAligned = true;
      if (typeof Android !== 'undefined' && Android.vibrate) {
        Android.vibrate();
      } else if (navigator.vibrate) {
        navigator.vibrate(40);
      }
    }
  } else {
    qiblaAligned.classList.remove('show');
    qiblaHint.classList.remove('hide');
    state._wasAligned = false;
  }
}

async function startCompass() {
  if (state.compassWatcher) return;
  const watcher = new CompassWatcher(heading => {
    state.heading = heading;
    updateCompass();
  });
  const ok = await watcher.start();
  if (!ok) {
    compassEnableBtn.style.display = 'inline-block';
    qiblaHint.textContent = 'Compass access denied. Enable device orientation in settings.';
    return;
  }
  state.compassWatcher = watcher;
  compassEnableBtn.style.display = 'none';
}

// ---------- Tabs ----------
function switchTab(tab) {
  tabButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
  tabTimes.classList.toggle('active', tab === 'times');
  tabQibla.classList.toggle('active', tab === 'qibla');
  if (tab === 'qibla') {
    startCompass().catch(err => console.warn('Compass start failed:', err));
  }
}

tabButtons.forEach(btn => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));
compassEnableBtn.addEventListener('click', () => startCompass());
retryBtn.addEventListener('click', () => boot());

// ---------- Cache-first boot flow ----------

/**
 * Instantly render from cache. Returns true if successful.
 */
function renderFromCache() {
  const loc = getCachedLocation();
  if (!loc) return false;

  const cached = getCachedPrayerTimes(loc.lat, loc.lon);
  if (!cached) return false;

  state.location = loc;
  state.timingsData = cached.data;
  state.tomorrowFajr = getCachedTomorrowFajr(loc.lat, loc.lon);

  const cachedCity = getCachedCity(loc.lat, loc.lon);
  locationText.textContent = cachedCity || `${loc.lat.toFixed(2)}°, ${loc.lon.toFixed(2)}°`;

  renderAll();
  show(mainScreen);
  state.hasRenderedOnce = true;

  if (state.countdownTimer) clearInterval(state.countdownTimer);
  state.countdownTimer = setInterval(updateCountdown, 1000);

  return true;
}

/**
 * Refresh location, prayer times, and city name from the network.
 * If the UI is already up, updates it silently in the background.
 * If not, will show the main screen once data arrives.
 */
async function refreshInBackground() {
  setRefreshing(true);
  try {
    // 1. Fresh location
    let freshLoc;
    try {
      freshLoc = await fetchFreshLocation();
    } catch (err) {
      if (!state.hasRenderedOnce) throw err;
      console.warn('Background location refresh failed:', err);
      return;
    }

    const locChanged = locationChangedSignificantly(state.location, freshLoc);
    state.location = freshLoc;

    // 2. Fetch new prayer times if we need them
    const cachedData = state.timingsData;
    const cachedDateStr = cachedData?.date?.gregorian?.date; // "DD-MM-YYYY"
    const today = new Date();
    const todayStr = `${String(today.getDate()).padStart(2,'0')}-${String(today.getMonth()+1).padStart(2,'0')}-${today.getFullYear()}`;
    const needFreshTimes = !cachedData || cachedDateStr !== todayStr || locChanged;

    if (needFreshTimes) {
      try {
        state.timingsData = await fetchPrayerTimes(freshLoc.lat, freshLoc.lon);
        renderAll();
        if (!state.hasRenderedOnce) {
          show(mainScreen);
          state.hasRenderedOnce = true;
          if (state.countdownTimer) clearInterval(state.countdownTimer);
          state.countdownTimer = setInterval(updateCountdown, 1000);
        }
      } catch (err) {
        if (!state.hasRenderedOnce) throw err;
        console.warn('Background prayer-times refresh failed:', err);
      }
    } else if (locChanged) {
      // Same-day cache still valid, but coords shifted slightly —
      // recompute qibla bearing & distance.
      renderAll();
    }

    // 3. Tomorrow's Fajr (nice-to-have)
    if (!state.tomorrowFajr || locChanged) {
      fetchTomorrowFajr(freshLoc.lat, freshLoc.lon).then(d => {
        if (d) {
          state.tomorrowFajr = d;
          renderSchedule();
        }
      }).catch(() => {});
    }

    // 4. City name
    const existingCity = getCachedCity(freshLoc.lat, freshLoc.lon);
    if (existingCity) {
      locationText.textContent = existingCity;
    } else {
      reverseGeocode(freshLoc.lat, freshLoc.lon).then(name => {
        locationText.textContent = name;
      });
    }
  } finally {
    setRefreshing(false);
  }
}

/**
 * First-load flow (no cache at all). Shows the spinner.
 */
async function firstLoad() {
  show(loadingScreen);
  loadingLabel.textContent = 'Finding your location…';

  try {
    await refreshInBackground();
  } catch (err) {
    console.error('First-load failed:', err);
    const msg = String(err?.message || err || '');
    if (msg.match(/permission|denied|Geolocation/i)) {
      showError(
        'Location needed',
        'We need your location to calculate prayer times and the Qibla direction. Please enable location access and try again.'
      );
    } else {
      showError(
        'Connection issue',
        "We couldn't load prayer times. Check your internet connection and try again."
      );
    }
  }
}

/**
 * Top-level: instant cache render + background refresh, or spinner + fresh fetch.
 */
async function boot() {
  const rendered = renderFromCache();
  if (rendered) {
    refreshInBackground().catch(err => {
      console.warn('Background refresh failed (showing stale data):', err);
    });
  } else {
    await firstLoad();
  }
  scheduleMidnightRefresh();
}

function scheduleMidnightRefresh() {
  const now = new Date();
  const nextMidnight = new Date(now);
  nextMidnight.setHours(24, 0, 30, 0);
  const ms = nextMidnight - now;
  setTimeout(() => boot(), ms);
}

boot();

// Refresh after a long idle (phone was sleeping)
let lastFocusRefresh = Date.now();
window.addEventListener('focus', () => {
  const now = Date.now();
  if (now - lastFocusRefresh > 10 * 60 * 1000) {
    lastFocusRefresh = now;
    refreshInBackground().catch(() => {});
  }
});
