// qibla.js — Qibla bearing calculation + device orientation handling

// Coordinates of the Kaaba in Makkah
const KAABA_LAT = 21.4225;
const KAABA_LON = 39.8262;

const toRad = d => d * Math.PI / 180;
const toDeg = r => r * 180 / Math.PI;

/**
 * Calculate initial bearing (great-circle) from (lat, lon) toward the Kaaba.
 * Returns bearing in degrees from north, 0..360.
 */
export function qiblaBearing(lat, lon) {
  const φ1 = toRad(lat);
  const φ2 = toRad(KAABA_LAT);
  const Δλ = toRad(KAABA_LON - lon);

  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) -
            Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);

  let bearing = toDeg(Math.atan2(y, x));
  return (bearing + 360) % 360;
}

/**
 * Great-circle distance from (lat, lon) to Kaaba, in km.
 */
export function distanceToKaaba(lat, lon) {
  const R = 6371;
  const φ1 = toRad(lat);
  const φ2 = toRad(KAABA_LAT);
  const Δφ = toRad(KAABA_LAT - lat);
  const Δλ = toRad(KAABA_LON - lon);
  const a = Math.sin(Δφ/2) ** 2 +
            Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ/2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * DeviceOrientation listener that normalizes across browsers
 * to give a consistent compass heading (0 = North, clockwise).
 */
export class CompassWatcher {
  constructor(onHeading) {
    this.onHeading = onHeading;
    this.handler = this._handle.bind(this);
    this.running = false;
    this.lastHeading = null;
  }

  /**
   * Start listening. On iOS Safari this requires a user gesture
   * (click) to call DeviceOrientationEvent.requestPermission().
   * Returns a Promise<boolean> — true if started.
   */
  async start() {
    if (this.running) return true;

    // iOS 13+ permission flow
    if (typeof DeviceOrientationEvent !== 'undefined' &&
        typeof DeviceOrientationEvent.requestPermission === 'function') {
      try {
        const res = await DeviceOrientationEvent.requestPermission();
        if (res !== 'granted') return false;
      } catch {
        return false;
      }
    }

    // Prefer the absolute event when available (gives true compass north)
    const absEvent = 'ondeviceorientationabsolute' in window
      ? 'deviceorientationabsolute'
      : 'deviceorientation';

    window.addEventListener(absEvent, this.handler, true);
    this._eventName = absEvent;
    this.running = true;
    return true;
  }

  stop() {
    if (!this.running) return;
    window.removeEventListener(this._eventName, this.handler, true);
    this.running = false;
  }

  _handle(e) {
    let heading = null;

    // iOS provides webkitCompassHeading directly (0 = N, clockwise).
    if (typeof e.webkitCompassHeading === 'number') {
      heading = e.webkitCompassHeading;
    }
    // Standard deviceorientationabsolute: alpha is 0..360 where 0 = N
    // but with alpha being counter-clockwise from north in most browsers
    else if (e.absolute === true && typeof e.alpha === 'number') {
      heading = (360 - e.alpha) % 360;
    }
    // Fallback: relative orientation — alpha isn't tied to compass north
    // but it's the best we can do.
    else if (typeof e.alpha === 'number') {
      heading = (360 - e.alpha) % 360;
    }

    if (heading == null || isNaN(heading)) return;

    // Smooth a little to avoid jitter
    if (this.lastHeading != null) {
      const diff = shortestAngle(this.lastHeading, heading);
      heading = (this.lastHeading + diff * 0.35 + 360) % 360;
    }
    this.lastHeading = heading;

    this.onHeading(heading);
  }
}

function shortestAngle(from, to) {
  let diff = to - from;
  while (diff > 180) diff -= 360;
  while (diff < -180) diff += 360;
  return diff;
}
